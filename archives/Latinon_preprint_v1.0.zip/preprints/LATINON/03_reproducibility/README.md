# Reproduction: Latinon preprint 1.0

The current sources are in `../05_formalization/Latinon_Lean_v1.0.zip`.
Extract it and use its `lean/` directory with Lean 4.35.0 and the pinned
external packages. Run the following commands sequentially:

```text
lake build LatinonFormalization
lake env lean ReviewAxioms.lean
```

The configured library has 310 roots; the canonical entry imports 299 local
modules. The query file checks twelve declarations, including the three
good-rate properties and the strengthened correction theorem.

The package retains two distinct evidence layers. The original clean build
compiled 309 targets without restored project objects; its original ZIP and
source-bound logs remain in `02_validation/baseline` and `02_validation/clean_run`.
The current additive revision was checked by an incremental build with copied
project objects and the pinned external caches. Its logs and status are in
`02_validation/incremental`. The SHA-256 source mapping proves that only the
new correction module, the entry point, queries and configuration changed;
the source manifest was regenerated for packaging.

From the publication repository root, the following commands verify recorded
evidence and all delivered bytes without invoking Lean or accessing a network:

```text
python scripts/review_axioms.py
python scripts/verify_repository.py
python scripts/verify_release.py
```

`scripts/typeset_preprint.py` generates all four TeX/PDF documents from the
Markdown and the CDR series layout, using Pandoc and Tectonic. It compiles each
PDF twice. `scripts/audit_documents.py` checks bilingual parity and bindings
and renders every page. Human visual inspection follows the final render.
`scripts/seal_preprint.py` is run last to regenerate audit hashes, manifests,
the complete archive and its checksum sidecar. Read-only verifiers run again
after sealing. See the declared typesetting requirements at repository root.
