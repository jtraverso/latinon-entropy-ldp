LATINON ENTROPY -- INTERNAL SOURCE SNAPSHOT

Pinned toolchain:Lean4.35.0. All nine Lake dependency commits are locked.
Canonical public entry:LatinonFormalization.lean.
The build serializes every Lean invocation,including the audit modules.
There are no machine-specific paths in the package's build script.

With Elan,Lake,Git,and Python3 installed,from this directory:
  lake exe cache get
Wait for dependency setup to finish.Then:
  python build_serial.py
Do not start a second build while either command is active.

The source hashes and import closure were checked when staging.
No precompiled .olean files are included.The original proof chain and
the additional conventional-pattern endpoints were kernel checked in
the pinned Windows environment.The fresh standalone build of THIS
source layout has NOT yet been run;do not call this a clean-room build.
Compatibility with Lean4.35.0-rc3 and its Mathlib pin is NOT established.

evidence contains original-environment certificates,the18 exact proof
inputs assembled into LatinonC7Closure,and Graphon provenance.The paths
inside those old certificates refer to the original layout;the module
mapping in source_manifest.json describes this package's layout.
Proof inputs are evidence,not separately compiled Lean modules.
The nine adapted Graphon modules retain their Apache2.0 notices and
LICENSE.graphon.Other sources retain their original headers.No new
public release or blanket licensing decision is made by this snapshot.
