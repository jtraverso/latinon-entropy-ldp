"""Build the source snapshot with ONE Lean compiler at a time."""
from pathlib import Path
import hashlib,json,re,subprocess
root=Path(__file__).resolve().parent
manifest=json.loads((root/'source_manifest.json').read_text(encoding='utf-8'))
for name,sha in manifest['files_sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
modules=manifest['modules']
done=set()
active=set()
def build(name):
    if name in done:return
    assert name not in active,('import cycle',name)
    active.add(name)
    source=root/modules[name]
    for imports in re.findall(r'^(?:public )?import (.+)$',source.read_text(encoding='utf-8-sig'),re.M):
        for dependency in imports.split():
            if dependency in modules:build(dependency)
            else:assert dependency.split('.')[0] in ('Mathlib','Lean','Std','Init','Batteries','Aesop'),dependency
    target=root/'.lake/build/lib/lean'/Path(name.replace('.','/')).with_suffix('.olean')
    target.parent.mkdir(parents=True,exist_ok=True)
    print('BUILD',name,flush=True)
    subprocess.run(['lake','env','lean','-o',str(target),str(source)],cwd=root,check=True)
    active.remove(name)
    done.add(name)
for name in modules:build(name)
print('PASS:serial build;',len(done),'modules')
