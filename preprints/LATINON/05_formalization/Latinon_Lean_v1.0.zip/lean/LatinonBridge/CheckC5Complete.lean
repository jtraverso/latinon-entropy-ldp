/- Complete C5 kernel audit,including the actual compactness and entropy statements. -/
import LatinonSymbolCompression
import LatinonWeakMarginalCompactness
import OrderMapLimits
import LatinonBridge.BipartiteKernel
import OrderMapCompleteness
import LatinonWeakReconstruction
import UnitContinuousIndicator
import LatinonTensorTests
import LatinonWeakBoxLimits
import LatinonRawCutCompleteness
import LatinonBridge.Regularity
import LatinonBridge.FiniteTestPartition
import LatinonBridge.BlockIntegrals
import LatinonBridge.DirectedRegularity
import LatinonBridge.CommonDirectedPartition
import LatinonSynchronousAction
import LatinonSynchronousDistance
import LatinonSynchronousCompleteness
import SymbolIntervalGridApproximation
import LatinonSymbolGridControl
import KernelCutEstimates
import LatinonBridge.StepFamilyEquipartition
import LatinonBridge.StepCoefficientQuantization
import LatinonBridge.CommonCellAlignment
import LatinonBridge.CommonKernelNets
import LatinonKernelFamily
import LatinonBridge.LatinonCompactness
import LatinonBridge.LatinonGlobalDeviations

open MeasureTheory
open scoped ENNReal

example : IsCompact (Set.univ : Set LatinonEntropy.LatinonMeasure) :=
  LatinonEntropy.latinon_full_cut_compact

example (r : ℝ≥0∞) : IsCompact {W : LatinonEntropy.LatinonMeasure | LatinonEntropy.latinonRate W ≤ r} :=
  LatinonEntropy.latinon_rate_sublevels_compact r

#print axioms LatinonEntropy.latinon_xy_preserving
#print axioms LatinonEntropy.latinonSymbolSlice_le
#print axioms LatinonEntropy.latinonSymbolSlice_ac
#print axioms LatinonEntropy.latinonSymbolCompression_measurable
#print axioms LatinonEntropy.latinonSymbolCompression_integrable
#print axioms LatinonEntropy.latinonSymbolCompression_bounds
#print axioms LatinonEntropy.latinonSymbolSlice_rectangle
#print axioms LatinonEntropy.latinonSymbolCompression_rectangle
#print axioms LatinonEntropy.latinon_xz_preserving
#print axioms LatinonEntropy.latinon_yz_preserving
#print axioms LatinonEntropy.uniformPairProbabilitySet_closed
#print axioms LatinonEntropy.uniformPairProbabilitySet_compact
#print axioms LatinonEntropy.latinonProbability_mem_uniformPairProbabilitySet
#print axioms LatinonEntropy.exists_weak_subsequence_uniform_pair_margins
#print axioms LatinonEntropy.unit_mp_of_tendstoInMeasure
#print axioms LatinonEntropy.unit_maps_tendstoInMeasure_of_L1
#print axioms LatinonEntropy.unit_mp_of_L1_limit
#print axioms LatinonEntropy.orderCut_Cauchy_implies_L1_Cauchy
#print axioms LatinonEntropy.bipartiteValue_measurable
#print axioms LatinonEntropy.bipartiteValue_symm
#print axioms LatinonEntropy.bipartiteValue_bounds
#print axioms LatinonEntropy.bipartiteGraphon
#print axioms LatinonEntropy.bipartiteValue_forward
#print axioms LatinonEntropy.dist_real_toL1_eq_integral_abs
#print axioms LatinonEntropy.exists_MP_L1_limit_of_orderCut_Cauchy
#print axioms LatinonEntropy.orderCut_tendsto_of_L1
#print axioms LatinonEntropy.exists_MP_orderCut_limit
#print axioms LatinonEntropy.latinonOfUniformPairs
#print axioms LatinonEntropy.latinonProbability_ofUniformPairs
#print axioms LatinonEntropy.exists_joint_weak_order_limit
#print axioms LatinonEntropy.abs_sub_unit_clip_le
#print axioms LatinonEntropy.exists_continuous_unit_indicator_L1
#print axioms LatinonEntropy.abs_mul_sub_mul_unit_le
#print axioms LatinonEntropy.abs_triple_sub_triple_unit_le
#print axioms LatinonEntropy.latinonTensorTest_measurable
#print axioms LatinonEntropy.latinonTensorTest_bounds
#print axioms LatinonEntropy.latinon_integral_coordinate
#print axioms LatinonEntropy.latinon_box_tensor_error
#print axioms LatinonEntropy.weak_latinon_box_convergence
#print axioms LatinonEntropy.measureCut_limit_of_box_limits
#print axioms LatinonEntropy.measureCut_limit_of_weak_and_Cauchy
#print axioms LatinonEntropy.latinonRawCutCost_nonneg
#print axioms LatinonEntropy.latinonRawCutCost_triangle
#print axioms LatinonEntropy.latinonCutDistance_le_rawCutCost
#print axioms LatinonEntropy.exists_raw_latinon_cut_limit
#print axioms LatinonEntropy.exists_latinon_limit_of_raw_Cauchy
#print axioms LatinonEntropy.exists_bipartite_regular_partition
#print axioms Graphon.regularity
#print axioms Graphon.exists_equipartition_almost_refining
#print axioms Graphon.MeasurePreserving.exists_controlled_cell_alignment
#print axioms LatinonEntropy.finiteTestSignature_measurable
#print axioms LatinonEntropy.finiteTestPartition
#print axioms LatinonEntropy.finiteTestPartition_card
#print axioms LatinonEntropy.finiteTestPartition_decides
#print axioms LatinonEntropy.binaryTagMeasure_singleton
#print axioms LatinonEntropy.binaryTagMeasure_real_singleton
#print axioms LatinonEntropy.ae_bipartite_tag
#print axioms LatinonEntropy.bipartite_setIntegral
#print axioms LatinonEntropy.bipartite_blockIntegral
#print axioms LatinonEntropy.taggedBlock_measurable
#print axioms LatinonEntropy.ae_bipartite_block
#print axioms LatinonEntropy.directedStepApprox_measurable
#print axioms LatinonEntropy.directedStepApprox_bounds
#print axioms LatinonEntropy.exists_directed_regular_approximation
#print axioms LatinonEntropy.taggedFamilyTests_measurable
#print axioms LatinonEntropy.commonDirectedPartition
#print axioms LatinonEntropy.commonDirectedPartition_card
#print axioms LatinonEntropy.commonDirectedPartition_decides
#print axioms LatinonEntropy.directedStepApprox_constant_on_common_parts
#print axioms LatinonEntropy.stepifyFun_bounds_everywhere
#print axioms LatinonEntropy.directedStepApprox_bounds_everywhere
#print axioms LatinonEntropy.commonDirectedCoefficient_bounds
#print axioms LatinonEntropy.directedStepApprox_eq_commonCoefficient
#print axioms LatinonEntropy.exists_simultaneous_directed_regular_approximation
#print axioms LatinonEntropy.latinonMeasure_eq_of_measure_order_eq
#print axioms LatinonEntropy.synchronousRelabel
#print axioms LatinonEntropy.synchronousRelabel_refl
#print axioms LatinonEntropy.synchronousRelabel_comp
#print axioms LatinonEntropy.synchronousRelabel_inverse
#print axioms LatinonEntropy.rawCutCost_synchronous_invariant
#print axioms LatinonEntropy.rawCutCost_synchronous_eq_alignmentCost
#print axioms LatinonEntropy.synchronousRelabel_full_distance_zero
#print axioms LatinonEntropy.synchronousCost_range_nonempty
#print axioms LatinonEntropy.synchronousCost_range_bddBelow
#print axioms LatinonEntropy.synchronousCutDistance_nonneg
#print axioms LatinonEntropy.synchronousCutDistance_le_cost
#print axioms LatinonEntropy.synchronousCutDistance_le_rawCost
#print axioms LatinonEntropy.synchronousCutDistance_self
#print axioms LatinonEntropy.synchronousCutDistance_symm
#print axioms LatinonEntropy.exists_synchronousCost_lt
#print axioms LatinonEntropy.synchronousCutDistance_triangle
#print axioms LatinonEntropy.latinonCutDistance_le_synchronous
#print axioms LatinonEntropy.synchronousLatinon_forget_lipschitz
#print axioms LatinonEntropy.synchronousLatinon_forget_continuous
#print axioms LatinonEntropy.synchronousCutDistance_relabel_zero
#print axioms LatinonEntropy.rawLatinonPseudoMetric
#print axioms LatinonEntropy.synchronousLatinon_complete
#print axioms LatinonEntropy.symbolGridUnion_measurable
#print axioms LatinonEntropy.lebesgueGridCell_point_lt
#print axioms LatinonEntropy.exists_symbol_grid_inner_approximation
#print axioms LatinonEntropy.symbol_grid_inner_approximation_error
#print axioms LatinonEntropy.latinon_box_inner_symbol_error
#print axioms LatinonEntropy.latinon_box_grid_union_sum
#print axioms LatinonEntropy.latinon_grid_union_difference_le
#print axioms LatinonEntropy.measureCut_le_symbol_grid_tests
#print axioms LatinonEntropy.kernelCutClose_of_L1
#print axioms LatinonEntropy.kernelCutClose_of_ae_abs_le
#print axioms LatinonEntropy.kernelCutClose_triangle
#print axioms LatinonEntropy.kernelCutClose_common_pullback
#print axioms LatinonEntropy.kernel_L1_le_two_bad_strips
#print axioms LatinonEntropy.finitePartitionStep_measurable
#print axioms LatinonEntropy.finitePartitionStep_eq_at
#print axioms LatinonEntropy.finitePartitionStep_bounds
#print axioms LatinonEntropy.exists_step_family_equipartition
#print axioms LatinonEntropy.unit_coefficient_floor_bound
#print axioms LatinonEntropy.finiteArrayCoefficient_bounds
#print axioms LatinonEntropy.exists_finite_step_family_net
#print axioms LatinonEntropy.kernelCutClose_congr_right_ae
#print axioms LatinonEntropy.exists_common_step_cell_alignment
#print axioms LatinonEntropy.exists_common_kernel_family_net
#print axioms LatinonEntropy.latinonOrderKernel_measurable
#print axioms LatinonEntropy.latinonOrderKernel_bounds
#print axioms LatinonEntropy.latinonOrderKernel_integrable
#print axioms LatinonEntropy.orderBox_eq_orderKernel_integral
#print axioms LatinonEntropy.orderCut_le_of_orderKernel_close
#print axioms LatinonEntropy.latinonKernelFamily_measurable
#print axioms LatinonEntropy.latinonKernelFamily_bounds
#print axioms LatinonEntropy.latinonKernelFamily_integrable
#print axioms LatinonEntropy.latinon_symbol_relabel_rectangle_integral
#print axioms LatinonEntropy.kernelCutClose_symm
#print axioms LatinonEntropy.rawCutCost_le_of_common_family_approximation
#print axioms LatinonEntropy.synchronousCutDistance_le_aligned_rawCost
#print axioms LatinonEntropy.synchronousLatinon_totallyBounded
#print axioms LatinonEntropy.latinon_full_cut_compact
#print axioms LatinonEntropy.latinon_closed_set_compact
#print axioms LatinonEntropy.latinon_rate_sublevels_compact
#print axioms LatinonEntropy.closed_uniform_latinon_upper
#print axioms LatinonEntropy.open_uniform_latinon_lower
#print axioms LatinonEntropy.latinon_rate_lowerSemicontinuous
#print axioms LatinonEntropy.finite_rate_latinon_entropy_count
