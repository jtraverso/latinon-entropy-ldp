/- Consolidated kernel axiom audit; it does not claim full C5 closure. -/
import OrderMapCompleteness
import LatinonWeakReconstruction
import UnitContinuousIndicator
import LatinonTensorTests
import LatinonWeakBoxLimits
import LatinonRawCutCompleteness
import LatinonBridge.Regularity
import LatinonBridge.FiniteTestPartition
import LatinonBridge.BlockIntegrals
import LatinonBridge.DirectedRegularity
import LatinonBridge.CommonDirectedPartition

#print axioms LatinonEntropy.dist_real_toL1_eq_integral_abs
#print axioms LatinonEntropy.exists_MP_L1_limit_of_orderCut_Cauchy
#print axioms LatinonEntropy.orderCut_tendsto_of_L1
#print axioms LatinonEntropy.exists_MP_orderCut_limit
#print axioms LatinonEntropy.latinonOfUniformPairs
#print axioms LatinonEntropy.latinonProbability_ofUniformPairs
#print axioms LatinonEntropy.exists_joint_weak_order_limit
#print axioms LatinonEntropy.abs_sub_unit_clip_le
#print axioms LatinonEntropy.exists_continuous_unit_indicator_L1
#print axioms LatinonEntropy.abs_mul_sub_mul_unit_le
#print axioms LatinonEntropy.abs_triple_sub_triple_unit_le
#print axioms LatinonEntropy.latinonTensorTest_measurable
#print axioms LatinonEntropy.latinonTensorTest_bounds
#print axioms LatinonEntropy.latinon_integral_coordinate
#print axioms LatinonEntropy.latinon_box_tensor_error
#print axioms LatinonEntropy.weak_latinon_box_convergence
#print axioms LatinonEntropy.measureCut_limit_of_box_limits
#print axioms LatinonEntropy.measureCut_limit_of_weak_and_Cauchy
#print axioms LatinonEntropy.latinonRawCutCost_nonneg
#print axioms LatinonEntropy.latinonRawCutCost_triangle
#print axioms LatinonEntropy.latinonCutDistance_le_rawCutCost
#print axioms LatinonEntropy.exists_raw_latinon_cut_limit
#print axioms LatinonEntropy.exists_latinon_limit_of_raw_Cauchy
#print axioms LatinonEntropy.exists_bipartite_regular_partition
#print axioms Graphon.regularity
#print axioms Graphon.exists_equipartition_almost_refining
#print axioms Graphon.MeasurePreserving.exists_controlled_cell_alignment
#print axioms LatinonEntropy.finiteTestSignature_measurable
#print axioms LatinonEntropy.finiteTestPartition
#print axioms LatinonEntropy.finiteTestPartition_card
#print axioms LatinonEntropy.finiteTestPartition_decides
#print axioms LatinonEntropy.binaryTagMeasure_singleton
#print axioms LatinonEntropy.binaryTagMeasure_real_singleton
#print axioms LatinonEntropy.ae_bipartite_tag
#print axioms LatinonEntropy.bipartite_setIntegral
#print axioms LatinonEntropy.bipartite_blockIntegral
#print axioms LatinonEntropy.taggedBlock_measurable
#print axioms LatinonEntropy.ae_bipartite_block
#print axioms LatinonEntropy.directedStepApprox_measurable
#print axioms LatinonEntropy.directedStepApprox_bounds
#print axioms LatinonEntropy.exists_directed_regular_approximation
#print axioms LatinonEntropy.taggedFamilyTests_measurable
#print axioms LatinonEntropy.commonDirectedPartition
#print axioms LatinonEntropy.commonDirectedPartition_card
#print axioms LatinonEntropy.commonDirectedPartition_decides
#print axioms LatinonEntropy.directedStepApprox_constant_on_common_parts
#print axioms LatinonEntropy.stepifyFun_bounds_everywhere
#print axioms LatinonEntropy.directedStepApprox_bounds_everywhere
#print axioms LatinonEntropy.commonDirectedCoefficient_bounds
#print axioms LatinonEntropy.directedStepApprox_eq_commonCoefficient
#print axioms LatinonEntropy.exists_simultaneous_directed_regular_approximation
