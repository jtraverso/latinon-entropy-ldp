import QuasirandomCorrection

noncomputable section
namespace LatinonEntropy
open Finset

namespace CostWalk
theorem reverse_map_exists {V W : Type*} {R : V → V → Prop} {c : V → V → ℝ}
    {S : W → W → Prop} (d : W → W → ℝ) (f : V → W)
    (hf : ∀ u v, R u v → S (f v) (f u))
    {u v : V} {t : ℝ} {k : ℕ} (p : CostWalk R c u v t k) :
    ∃ s, CostWalk S d (f v) (f u) s k := by
  induction p with
  | nil => exact ⟨0, .nil⟩
  | @snoc v t k p w edge ih =>
      obtain ⟨s,q⟩ := ih
      have first : CostWalk S d (f w) (f v) (0 + d (f w) (f v)) 1 :=
        CostWalk.snoc CostWalk.nil (hf _ _ edge)
      exact ⟨_, by simpa [Nat.add_comm] using first.append q⟩
end CostWalk

namespace ScaledResidualData
def transpose {n : ℕ} (H : ScaledResidualData n) : ScaledResidualData n where
  eps := H.eps
  rho := H.rho
  ell := H.ell
  C := H.C
  d := H.d
  npos := H.npos
  eps_pos := H.eps_pos
  rho_pos := H.rho_pos
  rho_le := H.rho_le
  ell_nonneg := H.ell_nonneg
  ell_le := H.ell_le
  C_pos := H.C_pos
  capacity := H.capacity
  A := fun y z => H.A z y
  B := fun y z => H.B z y
  binary := fun y z => H.binary z y
  Arow := H.Acol
  Acol := H.Arow
  degree := H.degree
  bounds := fun y z => H.bounds z y
  Brow := H.Bcol
  Bcol := H.Brow
  cut := by
    intro S T
    have h := H.cut T S
    have he : rectMass (fun y z => H.A z y) S T = rectMass H.A T S := by
      unfold rectMass
      exact Finset.sum_comm
    rw [he]
    convert h using 1 <;> ring

theorem column_four_steps {n : ℕ} (H : ScaledResidualData n)
    (c : Fin n ⊕ Fin n → Fin n ⊕ Fin n → ℝ) (z target : Fin n) :
    ∃ t, CostWalk (boxResidual (fun i j => H.ell * H.A i j)
      (fun i j => H.C * H.A i j) H.B) c (.inr z) (.inr target) t 4 := by
  obtain ⟨t,p⟩ := H.transpose.row_four_steps (fun _ _ => 0) target z
  apply p.reverse_map_exists c Sum.swap
  intro u v h
  cases u <;> cases v <;> simpa [boxResidual, transpose, Sum.swap] using h

theorem diameter_five {n : ℕ} (H : ScaledResidualData n)
    (c : Fin n ⊕ Fin n → Fin n ⊕ Fin n → ℝ) (u v : Fin n ⊕ Fin n) :
    ∃ t k, CostWalk (boxResidual (fun i j => H.ell * H.A i j)
      (fun i j => H.C * H.A i j) H.B) c u v t k ∧ k ≤ 5 := by
  cases u with
  | inl y =>
      cases v with
      | inl target =>
          obtain ⟨t,p⟩ := H.row_four_steps c y target
          exact ⟨t,4,p,by decide⟩
      | inr z =>
          obtain ⟨target,he⟩ := H.column_forward z
          obtain ⟨t,p⟩ := H.row_four_steps c y target
          exact ⟨_,5,p.snoc he,by decide⟩
  | inr z =>
      cases v with
      | inl target =>
          obtain ⟨y,he⟩ := H.column_backward z
          obtain ⟨t,p⟩ := H.row_four_steps c y target
          have first : CostWalk (boxResidual (fun i j => H.ell * H.A i j)
              (fun i j => H.C * H.A i j) H.B) c (.inr z) (.inl y)
              (0 + c (.inr z) (.inl y)) 1 := CostWalk.snoc CostWalk.nil he
          exact ⟨_,5,first.append p,by decide⟩
      | inr target =>
          obtain ⟨t,p⟩ := H.column_four_steps c z target
          exact ⟨t,4,p,by decide⟩
end ScaledResidualData

theorem correction_cost_unit_margins_five
    {Y Z : Type*} [Fintype Y] [Fintype Z]
    (M Q : Y → Z → ℝ) (u : Y → ℝ) (v : Z → ℝ)
    (hu : ∀ y, |u y| ≤ (5 / 2 : ℝ)) (hv : ∀ z, |v z| ≤ (5 / 2 : ℝ))
    (hrow : ∀ y, ∑ z, Q y z = 1) (hcol : ∀ z, ∑ y, Q y z = 1)
    (hup : ∀ y z, Q y z < M y z → v z - u y ≤ -1)
    (hdown : ∀ y z, M y z < Q y z → 1 ≤ v z - u y) :
    (∑ y, ∑ z, |Q y z - M y z|) ≤
      (5 / 2 : ℝ) * ((∑ y, |(∑ z, M y z) - 1|) + ∑ z, |(∑ y, M y z) - 1|) := by
  have h := correction_cost_of_potentials (fun y z => Q y z - M y z) u v (5 / 2 : ℝ) hu hv
    (fun y z => abs_le_mul_gap
      (fun hd => hdown y z (sub_pos.mp hd))
      (fun hd => hup y z (sub_neg.mp hd)))
  simpa only [Finset.sum_sub_distrib, hrow, hcol, abs_sub_comm] using h


theorem exists_bounded_potential_five
    [Finite V] [Nonempty V] (R : V → V → Prop) (c : V → V → ℝ)
    (hcost : ∀ u v, R u v → c u v ≤ 1)
    (hdiam : ∀ u v, ∃ t n, CostWalk R c u v t n ∧ n ≤ 5)
    (hclosed : ∀ v t n, CostWalk R c v v t n → 0 ≤ t) :
    ∃ phi : V → ℝ, (∀ v, |phi v| ≤ (5 / 2 : ℝ)) ∧
      ∀ u v, R u v → phi v - phi u ≤ c u v := by
  classical
  have hreach : ∀ u v, ∃ t n, CostWalk R c u v t n := by
    intro u v
    obtain ⟨t, n, hp, _⟩ := hdiam u v
    exact ⟨t, n, hp⟩
  obtain ⟨psi, hpsi⟩ := exists_potential_of_closed_walks R c
    (Classical.arbitrary V) hreach hclosed
  obtain ⟨v0, hmin⟩ := Finite.exists_min psi
  refine ⟨fun v => psi v - psi v0 - (5 / 2 : ℝ), ?_, ?_⟩
  · intro v
    obtain ⟨t, n, hp, hn⟩ := hdiam v0 v
    have h1 := hp.potential_le psi hpsi
    have h2 := hp.cost_le_length hcost
    have h3 : (n : ℝ) ≤ 5 := by exact_mod_cast hn
    have h0 := hmin v
    apply abs_le.mpr
    constructor <;> linarith
  · intro u v edge
    have h := hpsi u v edge
    dsimp
    linarith

/-- Existence of graph potentials supplies the matrix correction cost bound.
The graph and its no-negative-closed-walk/diameter properties remain explicit. -/
theorem correction_cost_of_residual_graph_five
    {Y Z : Type*} [Fintype Y] [Fintype Z] [Nonempty Y]
    (M Q : Y → Z → ℝ) (R : Y ⊕ Z → Y ⊕ Z → Prop)
    (c : Y ⊕ Z → Y ⊕ Z → ℝ)
    (hrow : ∀ y, ∑ z, Q y z = 1) (hcol : ∀ z, ∑ y, Q y z = 1)
    (hcost : ∀ u v, R u v → c u v ≤ 1)
    (hdiam : ∀ u v, ∃ t n, CostWalk R c u v t n ∧ n ≤ 5)
    (hclosed : ∀ v t n, CostWalk R c v v t n → 0 ≤ t)
    (hup : ∀ y z, Q y z < M y z →
      R (.inl y) (.inr z) ∧ c (.inl y) (.inr z) ≤ -1)
    (hdown : ∀ y z, M y z < Q y z →
      R (.inr z) (.inl y) ∧ c (.inr z) (.inl y) ≤ -1) :
    (∑ y, ∑ z, |Q y z - M y z|) ≤
      (5 / 2 : ℝ) * ((∑ y, |(∑ z, M y z) - 1|) + ∑ z, |(∑ y, M y z) - 1|) := by
  obtain ⟨phi, hbound, hedge⟩ := exists_bounded_potential_five R c hcost hdiam hclosed
  apply correction_cost_unit_margins_five M Q (fun y => phi (.inl y))
    (fun z => phi (.inr z)) (fun y => hbound _) (fun z => hbound _) hrow hcol
  · intro y z h
    obtain ⟨he, hc⟩ := hup y z h
    exact (hedge _ _ he).trans hc
  · intro y z h
    obtain ⟨he, hc⟩ := hdown y z h
    have hh := (hedge _ _ he).trans hc
    linarith


theorem exists_box_correction_of_residual_diameter_five
    {Y Z : Type*} [Fintype Y] [Fintype Z] [Nonempty Y] [Nonempty Z]
    (M lower upper Q0 : Y → Z → ℝ)
    (hM : M ∈ Set.Icc lower upper)
    (hbox0 : Q0 ∈ Set.Icc lower upper)
    (hrow0 : ∀ y, ∑ z, Q0 y z = 1) (hcol0 : ∀ z, ∑ y, Q0 y z = 1)
    (hdiam : ∀ Q : Y → Z → ℝ, Q ∈ Set.Icc lower upper →
      (∀ y, ∑ z, Q y z = 1) → (∀ z, ∑ y, Q y z = 1) →
      ∀ u v, ∃ t n,
        CostWalk (boxResidual lower upper Q) (boxResidualCost M Q) u v t n ∧ n ≤ 5) :
    ∃ Q : Y → Z → ℝ, Q ∈ Set.Icc lower upper ∧
      (∀ y, ∑ z, Q y z = 1) ∧ (∀ z, ∑ y, Q y z = 1) ∧
      (∑ y, ∑ z, |Q y z - M y z|) ≤
        (5 / 2 : ℝ) * ((∑ y, |(∑ z, M y z) - 1|) + ∑ z, |(∑ y, M y z) - 1|) := by
  obtain ⟨Q, hbox, hrow, hcol, hmin⟩ :=
    exists_box_correction_minimizer M lower upper Q0 hbox0 hrow0 hcol0
  refine ⟨Q, hbox, hrow, hcol, ?_⟩
  apply correction_cost_of_residual_graph_five M Q
    (boxResidual lower upper Q) (boxResidualCost M Q) hrow hcol
    (fun u v _ => boxResidualCost_le_one M Q u v) (hdiam Q hbox hrow hcol)
    (residual_closed_walk_nonnegative M lower upper Q hbox hrow hcol hmin)
  · intro y z h
    refine ⟨lt_of_lt_of_le h (hM.2 y z), ?_⟩
    simp [boxResidualCost, forwardCost, h]
  · intro y z h
    refine ⟨lt_of_le_of_lt (hM.1 y z) h, ?_⟩
    simp [boxResidualCost, backwardCost, h]


theorem quasirandom_box_correction_five
    {n : ℕ} (hn : 0 < n) (eps rho ell C d : ℝ)
    (heps : 0 < eps) (hrho : 0 < rho) (hrho1 : rho ≤ 1)
    (hell : 0 ≤ ell) (hell1 : ell ≤ 1/4) (hC : 0 < C)
    (hcapacity : 16 ≤ C * rho * eps)
    (A M : Fin n → Fin n → ℝ)
    (hA : ∀ y z, A y z = 0 ∨ A y z = 1)
    (hrowA : ∀ y, (∑ z, A y z) = d) (hcolA : ∀ z, (∑ y, A y z) = d)
    (hdegree : eps * n ≤ d)
    (hcut : ∀ S T : Finset (Fin n),
      rho * S.card * T.card - rho * eps * (n : ℝ)^2 / (64*C) ≤ rectMass A S T)
    (hM : ∀ y z, ell / n * A y z ≤ M y z ∧ M y z ≤ C / n * A y z) :
    ∃ Q : Fin n → Fin n → ℝ,
      (∀ y z, ell / n * A y z ≤ Q y z ∧ Q y z ≤ C / n * A y z) ∧
      (∀ y, ∑ z, Q y z = 1) ∧ (∀ z, ∑ y, Q y z = 1) ∧
      (∑ y, ∑ z, |Q y z - M y z|) ≤
        (5 / 2 : ℝ) * ((∑ y, |(∑ z, M y z) - 1|) + ∑ z, |(∑ y, M y z) - 1|) := by
  have hN : (0 : ℝ) < n := Nat.cast_pos.mpr hn
  have : Nonempty (Fin n) := ⟨⟨0, hn⟩⟩
  have hAnonneg : ∀ y z, 0 ≤ A y z := by
    intro y z; rcases hA y z with h | h <;> simp [h]
  have hAone : ∀ y z, A y z ≤ 1 := by
    intro y z; rcases hA y z with h | h <;> simp [h]
  have hd : 0 < d := lt_of_lt_of_le (mul_pos heps hN) hdegree
  have hdN : d ≤ (n : ℝ) := by
    let y0 : Fin n := ⟨0,hn⟩
    calc
      d = ∑ z, A y0 z := (hrowA y0).symm
      _ ≤ ∑ _z : Fin n, (1 : ℝ) := Finset.sum_le_sum fun z _ => hAone y0 z
      _ = n := by simp
  have hCeps : 16 ≤ C * eps := by
    have h := mul_le_mul_of_nonneg_right hrho1 (mul_nonneg hC.le heps.le)
    nlinarith
  have hlo : ell / n ≤ 1 / d := by
    apply (div_le_div_iff₀ hN hd).mpr
    have hh := mul_le_mul_of_nonneg_right (show ell ≤ 1 by linarith) hd.le
    nlinarith
  have hhi : 1 / d ≤ C / n := by
    apply (div_le_div_iff₀ hd hN).mpr
    have h1 := mul_le_mul_of_nonneg_left hdegree hC.le
    have h2 := mul_le_mul_of_nonneg_right hCeps hN.le
    nlinarith
  let lower : Fin n → Fin n → ℝ := fun y z => ell / n * A y z
  let upper : Fin n → Fin n → ℝ := fun y z => C / n * A y z
  let Q0 : Fin n → Fin n → ℝ := fun y z => A y z / d
  have hQ0box : Q0 ∈ Set.Icc lower upper := by
    constructor
    · intro y z
      have h := mul_le_mul_of_nonneg_right hlo (hAnonneg y z)
      simpa [lower, Q0, div_eq_mul_inv, mul_comm] using h
    · intro y z
      have h := mul_le_mul_of_nonneg_right hhi (hAnonneg y z)
      simpa [upper, Q0, div_eq_mul_inv, mul_comm] using h
  have hQ0row : ∀ y, ∑ z, Q0 y z = 1 := by
    intro y
    simp only [Q0, div_eq_mul_inv, ← Finset.sum_mul, hrowA]
    exact mul_inv_cancel₀ hd.ne'
  have hQ0col : ∀ z, ∑ y, Q0 y z = 1 := by
    intro z
    simp only [Q0, div_eq_mul_inv, ← Finset.sum_mul, hcolA]
    exact mul_inv_cancel₀ hd.ne'
  have hMbox : M ∈ Set.Icc lower upper := ⟨fun y z => (hM y z).1, fun y z => (hM y z).2⟩
  have hdiam : ∀ Q : Fin n → Fin n → ℝ, Q ∈ Set.Icc lower upper →
      (∀ y, ∑ z, Q y z = 1) → (∀ z, ∑ y, Q y z = 1) →
      ∀ u v, ∃ t k, CostWalk (boxResidual lower upper Q) (boxResidualCost M Q) u v t k ∧ k ≤ 5 := by
    intro Q hbox hrows hcols u v
    let B : Fin n → Fin n → ℝ := fun y z => (n : ℝ) * Q y z
    have hbounds : ∀ y z, ell * A y z ≤ B y z ∧ B y z ≤ C * A y z := by
      intro y z
      have hl := mul_le_mul_of_nonneg_left (hbox.1 y z) hN.le
      have hu := mul_le_mul_of_nonneg_left (hbox.2 y z) hN.le
      change (n : ℝ) * (ell / n * A y z) ≤ (n : ℝ) * Q y z at hl
      change (n : ℝ) * Q y z ≤ (n : ℝ) * (C / n * A y z) at hu
      rw [scale_entry_bound _ _ _ hN] at hl hu
      exact ⟨hl,hu⟩
    have hBrows : ∀ y, (∑ z, B y z) = (n : ℝ) := by
      intro y
      simp only [B, ← Finset.mul_sum, hrows, mul_one]
    have hBcols : ∀ z, (∑ y, B y z) = (n : ℝ) := by
      intro z
      simp only [B, ← Finset.mul_sum, hcols, mul_one]
    let H : ScaledResidualData n := {
      eps := eps, rho := rho, ell := ell, C := C, d := d,
      npos := hN, eps_pos := heps, rho_pos := hrho, rho_le := hrho1,
      ell_nonneg := hell, ell_le := hell1, C_pos := hC, capacity := hcapacity,
      A := A, B := B, binary := hA, Arow := hrowA, Acol := hcolA,
      degree := hdegree, bounds := hbounds, Brow := hBrows, Bcol := hBcols, cut := hcut }
    obtain ⟨t,k,p,hk⟩ := H.diameter_five (boxResidualCost M Q) u v
    refine ⟨t,k,p.mono_relation ?_,hk⟩
    intro a b he
    cases a with
    | inl y =>
        cases b with
        | inl y' => exact False.elim he
        | inr z =>
            change (n : ℝ) * Q y z < C * A y z at he
            change Q y z < C / n * A y z
            apply lt_of_mul_lt_mul_left (a := (n : ℝ)) ?_ hN.le
            rw [scale_entry_bound _ _ _ hN]
            exact he
    | inr z =>
        cases b with
        | inr z' => exact False.elim he
        | inl y =>
            change ell * A y z < (n : ℝ) * Q y z at he
            change ell / n * A y z < Q y z
            apply lt_of_mul_lt_mul_left (a := (n : ℝ)) ?_ hN.le
            rw [scale_entry_bound _ _ _ hN]
            exact he
  obtain ⟨Q, hbox, hrow, hcol, hcost⟩ :=
    exists_box_correction_of_residual_diameter_five M lower upper Q0 hMbox hQ0box hQ0row hQ0col hdiam
  exact ⟨Q, fun y z => ⟨hbox.1 y z,hbox.2 y z⟩, hrow, hcol, hcost⟩

/-! The handoff's parameters, now with explicit entry bounds. -/

theorem correction_lemma_five
    {n : ℕ} (hn : 0 < n) (eps rho a c d : ℝ)
    (heps : 0 < eps) (hrho : 0 < rho) (hrho1 : rho ≤ 1)
    (ha : 0 < a) (hac : a ≤ c)
    (A M : Fin n → Fin n → ℝ)
    (hA : ∀ y z, A y z = 0 ∨ A y z = 1)
    (hrowA : ∀ y, (∑ z, A y z) = d) (hcolA : ∀ z, (∑ y, A y z) = d)
    (hdegree : eps * n ≤ d)
    (hcut : ∀ S T : Finset (Fin n),
      rho * S.card * T.card - rho * eps * (n : ℝ)^2 /
        (64 * max c (16 / (rho * eps))) ≤ rectMass A S T)
    (hzero : ∀ y z, A y z = 0 → M y z = 0)
    (hM : ∀ y z, A y z = 1 → a / n ≤ M y z ∧ M y z ≤ c / n) :
    ∃ Q : Fin n → Fin n → ℝ,
      (∀ y, ∑ z, Q y z = 1) ∧ (∀ z, ∑ y, Q y z = 1) ∧
      (∀ y z, 0 ≤ Q y z) ∧
      (∀ y z, A y z = 0 → Q y z = 0) ∧
      (∀ y z, A y z = 1 → min (a/2) (1/4) / n ≤ Q y z ∧
        Q y z ≤ max c (16 / (rho * eps)) / n) ∧
      (∑ y, ∑ z, |Q y z - M y z|) ≤
        (5 / 2 : ℝ) * ((∑ y, |(∑ z, M y z) - 1|) + ∑ z, |(∑ y, M y z) - 1|) := by
  let ell : ℝ := min (a/2) (1/4)
  let C : ℝ := max c (16 / (rho * eps))
  have hN : (0 : ℝ) < n := Nat.cast_pos.mpr hn
  have hell : 0 < ell := lt_min (half_pos ha) (by norm_num)
  have hell1 : ell ≤ 1/4 := min_le_right _ _
  have hella : ell ≤ a := (min_le_left _ _).trans (by linarith)
  have hcC : c ≤ C := le_max_left _ _
  have hC : 0 < C := lt_of_lt_of_le (lt_of_lt_of_le ha hac) hcC
  have hcapacity : 16 ≤ C * rho * eps := by
    have hh : 16 / (rho * eps) ≤ C := le_max_right _ _
    have hh' := (div_le_iff₀ (mul_pos hrho heps)).mp hh
    nlinarith
  have hMbox : ∀ y z, ell / n * A y z ≤ M y z ∧ M y z ≤ C / n * A y z := by
    intro y z
    rcases hA y z with hz | ho
    · simp [hz, hzero y z hz]
    · obtain ⟨hl, hu⟩ := hM y z ho
      have hl' := (div_le_div_of_nonneg_right hella hN.le).trans hl
      have hu' := hu.trans (div_le_div_of_nonneg_right hcC hN.le)
      simpa [ho] using And.intro hl' hu'
  obtain ⟨Q, hbox, hrow, hcol, hcost⟩ := quasirandom_box_correction_five hn eps rho ell C d
    heps hrho hrho1 hell.le hell1 hC hcapacity A M hA hrowA hcolA hdegree hcut hMbox
  have hoff : ∀ y z, A y z = 0 → Q y z = 0 := by
    intro y z hz
    have hh := hbox y z
    simp only [hz, mul_zero] at hh
    exact le_antisymm hh.2 hh.1
  have hon : ∀ y z, A y z = 1 → ell / n ≤ Q y z ∧ Q y z ≤ C / n := by
    intro y z hz
    simpa only [hz, mul_one] using hbox y z
  have hnonneg : ∀ y z, 0 ≤ Q y z := by
    intro y z
    rcases hA y z with hz | ho
    · rw [hoff y z hz]
    · exact (div_nonneg hell.le hN.le).trans (hon y z ho).1
  exact ⟨Q,hrow,hcol,hnonneg,hoff,hon,hcost⟩


end LatinonEntropy
#print axioms LatinonEntropy.ScaledResidualData.diameter_five
#print axioms LatinonEntropy.correction_lemma_five
