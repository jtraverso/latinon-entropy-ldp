# colour-stats-lean

Lean 4 formalization of *Counting Steiner triple systems, Latin squares and
1-factorizations with prescribed colour statistics* (draft 6, 14 November 2026).

## Build

The project reuses the compiled Mathlib and the compiled corpus of the CDR III
clean run (`C:\nw\cdr-clean-20261113\snapshot\lean`) through `packagesDir` and a
path dependency, so nothing upstream is rebuilt. Check this before a build:

    lake build --no-build ColourStats   # must only list ColourStats.* as out of date
    lake build ColourStats

Toolchain `leanprover/lean4:v4.35.0-rc3`, Mathlib `c55e6e786f49471c72fbddbec5415808896aec1e`.

## Contents

| Module | Paper | Status |
|---|---|---|
| `ColourStats/PaschHub.lean` | Lemma 5.14 (Pasch hub basis) | proved |
| `ColourStats/PaschRank.lean` | Lemma 5.14: `rank Λ = C(k + 1, 3)`; the hub trade is the switch of the Pasch configuration `{012, 034, 135, 245} → {013, 024, 125, 345}` | proved |
| `ColourStats/TriangleInverse.lean` | Lemma 5.13 (inverse for the triangles of `K_m`) | proved |
| `ColourStats/ColourFirst.lean` | Lemma 5.12 (colour-first identity for all types): double count, (a), (b) | proved |
| `ColourStats/TypeCount.lean` | `N_τ = Π_X C(c_X, τ_X)`; Lemma 5.12(b) in the form `Φ(t)` | proved |
| `ColourStats/E2Inverse.lean` | Lemma 5.16 (inverse on balanced vectors of `K_m ∨ C_h`, `K = 13`) | proved |
| `ColourStats/E2Lattice.lean` | Lemma 5.17 (triangle lattice of rich hosts in `K_m ∨ C_h`), with explicit richness hypotheses | proved |
| `ColourStats/E2Swap.lean` | Lemma 5.18 (alternating swaps generate the pair-preserving lattice; explicit basis of size `C(k,2)(ℓ−1)`) | proved |
| `ColourStats/E2SwapRank.lean` | Lemma 5.18: `rank Λ = C(k, 2)(ℓ − 1)` | proved |
| `ColourStats/E3Lattice.lean` | Lemma 5.20 (triangle lattice of rich graphs), into the corpus `TypedTriangle.IsPhysical` | proved |
| `ColourStats/E3Gadget.lean` | Lemma 5.19: `K₄` gadget identity and `AΦ₁r = r − Tr` | proved |
| `ColourStats/PairMap.lean` | Lemma 5.19: the pair map is onto (explicit preimages) | proved |
| `ColourStats/Neumann.lean` | Lemma 5.19: Neumann series step | proved |
| `ColourStats/E3Assembly.lean` | Lemma 5.19 from its four estimates; row-sum operator norm bound | proved |
| `ColourStats/Typical.lean` | `(η, h)`-typical graphs; load estimate of a type weighting | proved |
| `ColourStats/Weighting.lean`, `WeightingError.lean` | Lemma 5.19: explicit weighting `W_1` and its error | proved |
| `ColourStats/Counting.lean`, `Host519`–`K2519` | Lemma 5.19: typicality estimates on the concrete host | proved |
| `ColourStats/Prop13.lean`, `Prop13Bridge.lean` | Proposition 1.3 (normalised rate), error `(n/6)|log n − 2| + n`; bridge to `Theorem_1_2` | proved |
| `ColourStats/Lemma519.lean` | **Lemma 5.19** (`lemma_5_19_exists`): bounded right inverse `‖Φ‖ ≤ K/m` on typical hosts | proved |
| `ColourStats/TypedChain.lean`, `TypedChain2.lean` | Section 4.2: typed chain rule in counting form; conditioning reduces entropy; coarser past | proved |
| `ColourStats/TypedSTS.lean`, `TypedBox.lean`, `TypedPair.lean` | Section 4.2: revealing lemma with six pairs, label boxes and Jensen, the bound for one pair | proved |
| `ColourStats/TypedAssembly.lean`, `TypedAggregate.lean`, `TypedAnalytic.lean`, `TypedStats.lean` | Section 4.2: assembly over labels, aggregation over pair classes, analytic estimates, pair statistics `m_π(τ) t_τ` | proved |
| `ColourStats/TypedFinal.lean`, `TypedThm.lean` | **Bound (4.3), all block types** (`typed_upper`): `log N^all_t ≤ Φ(t) + n²((5 log n + 16)/n + 8 c₁^{−1/4})`; upper halves of Theorems 1.2 and 1.5 (`theorem_1_5_upper_exp`) | proved |
| `ColourStats/Typed1F.lean`, `Typed1FAgg.lean`, `Typed1FThm.lean`, `Typed1FMain.lean` | **Upper half of Theorem 1.7** (`typed_upper_1F`): `log N^{1F}_t ≤ Φ(t) + n²((log n + 4)/n + 7 h₁^{−1/4})`; `theorem_1_7_upper_exp` | proved |
| `ColourStats/TypedG.lean`, `TypedGBox.lean`, `TypedGPair.lean`, `TypedGAgg.lean`, `TypedGStats.lean`, `TypedGFinal.lean`, `TypedGThm.lean` | **Upper half of Theorem 1.9(a)** (`typed_upper_G`): `log N_t(G) ≤ Φ_G(t) + n²((5 log n + 16)/n + 8 c₁^{−1/4} + η)` for `(η, 5)`-typical `G`; `theorem_1_9a_upper_exp` under `TypHyp` | proved |
| `ColourStats/Challenge.lean` | Theorems 1.2, 1.5 (statements only) | statements |
| `ColourStats/Statements.lean` | Theorems 1.1, 1.7, 1.9, 1.10 and Corollaries 1.4, 1.6, 1.8, 1.11 (statements only) | statements |
| `ColourStats/Cor111.lean` | Corollary 1.11 from Theorem 1.10 for Theorem 1.9(a): completions of `Q` are the triangle decompositions of `K_n − L_Q`, which is triangle-divisible | proved (conditional) |
| `ColourStats/Thm15From19.lean` | Theorem 1.5 from Theorem 1.9(a) applied to `K_n` | proved (conditional) |

`checks/Axioms.lean` prints the axioms of the proved lemmas: only `propext`,
`Classical.choice` and `Quot.sound`.
