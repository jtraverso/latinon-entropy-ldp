# Hoja de ruta de la formalización

Fecha: 2026-11-15. Paper: `C:\cdr-bicolour-lean\docs\PAPER_COLOUR_STATS_DRAFT_20261114.md`
(borrador 6).

## Base reutilizada (ya compilada, sin recompilar)

Árbol: `C:\nw\cdr-clean-20261113\snapshot\lean` (corrida limpia de CDR III, 9672 módulos).
`lake build --no-build` confirma que solo los módulos `ColourStats.*` quedan por compilar.

| Insumo del paper | Módulo del corpus |
|---|---|
| Teorema T con monitores lineales (T+) | `RequestProject.TypedTriangle.MainPaperIIITriangleMonitors` (`main_theorem_T_with_triangle_monitors`; axiomas estándar) |
| Umbral en torre de T | `RequestProject.TypedTriangle.MainPaperIIITower` (`paperIIITowerThreshold`) |
| EGJ (emparejamientos con pesos) | `RequestProject.Pseudorandom.Theorem12`, `RequestProject.TypedTriangle.ClonedEGJ` |
| Linial–Luria para STS (cota superior explícita) | `CountingCone.LL.STSMain` (`sts_upper_bound_explicit`, `theorem_1_1`) |
| Van der Waerden y conteo de emparejamientos regulares | `CountingCone.VanDerWaerden.Full`, `CDRBicolour.KBicolor.PrescribedCounting.RegularFactorizations` |
| STS bicoloreados con tipos prescritos, escala `(1/6 ± ε) n² log n` | `CDRBicolour.KBicolor.optimal_prescribed_type_count` (`exactTypeCount`, `TypeCoord`) |
| Contornos latinos prescritos, cota inferior `n²(log n + log δ − 2)` | `CDRBicolour.KBicolor.PrescribedCounting.exact_outline_entropy` (`outlineTables`) |
| Nash–Williams para grafos grandes [DP26] | `C:\nw\nash-williams-lean` (TD1) |

Los Teoremas 1.1 y 1.2 del paper afinan los dos teoremas del corpus marcados arriba: pasan
de la escala `n² log n` (o de una pérdida `log δ` por celda) a `Φ(t) + o(n²)`.

## Capas

**A. Álgebra finita (sin asintótica).**
- A1. Lema 5.14, base de Pasch con hub: `ColourStats/PaschHub.lean`. **Probado**
  (`hub_pairPreserving`, `hub_unique`, `hub_basis`; axiomas estándar). En
  `ColourStats/PaschRank.lean`: `rank Λ = C(k + 1, 3)` (`finrank_Lam`, vía
  `Λ ≅ ℤ^{tipos que evitan o}`), y el enlace con la configuración de Pasch: las familias
  `{012, 034, 135, 245}` y `{013, 024, 125, 345}` del paper son sistemas triples parciales que
  cubren los mismos doce pares, y con clases `a, b, c` en `0, 1, 2` y `o` en `3, 4, 5` el
  cambio de tipos es exactamente `hub o {a, b, c}` (`hub_eq_pasch`).
- A2. Lema 5.13, inversa explícita para los triángulos de `K_m`: `ColourStats/TriangleInverse.lean`.
  **Probado** (`apply_inverse` para m ≥ 5, `inverse_bound` con 24‖x‖/m para m ≥ 8; axiomas
  estándar).
- A3. Lema 5.12: `ColourStats/ColourFirst.lean` y `ColourStats/TypeCount.lean`. **Probado**
  (axiomas estándar):
  - doble conteo `w(τ, π) e_π = m_π(τ) N_τ` (`compl_mul_typeNum`);
  - (a) `D_τ` no depende del vértice elegido (`apex_eq`, `apex_indep`); la forma simétrica es
    `D_τ = Π_π m_π(τ) · N_τ · t'_τ² / Π_π e_π`;
  - (b) identidad de entropía para `ν` y `t'` positivos (`entropy_identity`); no usa las
    identidades de pares, que solo hacen de `P(·|π)` una probabilidad (`sum_P`);
  - con `ν ≡ 1` y `t' = t`, el lado derecho es `Φ(t)` de `Challenge.lean` (`colour_first_Phi`),
    usando `N_τ = Π_X C(c_X, τ_X)` (`card_type`, `numTriples_eq`, `numPairs_eq`).
  Hipótesis: toda clase tiene al menos 3 puntos (2 para (a)).
- A4. E2 y E3.
  - Lema 5.16, inversa en vectores balanceados de `K_m ∨ C_h`: `ColourStats/E2Inverse.lean`.
    **Probado** (`pair_load`, `colour_load`; `inverse_bound` con `K = 13`; `m ≥ 3`, `h ≥ 1`).
    No usa la simetría de `x`.
  - Lema 5.20, red de triángulos de grafos ricos: `ColourStats/E3Lattice.lean`. **Probado**:
    forma dual sobre cualquier grupo abeliano (`sum_eq_zero_of_rich`) y conclusión en la red
    del corpus, `TypedTriangle.IsPhysical` con todos los triángulos permitidos
    (`isPhysical_of_rich`). Lectura elegida: "tres vértices" sin exigir que sean distintos;
    el camino dentro de la vecindad común se pide para dos vértices distintos.
  - Lema 5.19: probadas las piezas algebraicas.
    - Identidad del gadget `K₄` en forma entera (`ColourStats/E3Gadget.lean`,
      `gadget_identity`, sobre `TypedTriangle.ind` y `triEdges` del corpus).
    - `AΦ₁r = r − Tr` para cualquier `A` lineal y gadgets con `A g(e, f) = 1_e − 1_f`
      (`apply_Phi₁`).
    - La aplicación de pares es sobreyectiva, con preimágenes explícitas
      `1_{XX} = M(⅓·1_{XXX})` y `1_{XY} = M(½·1_{XXY} − ⅙·1_{XXX})`
      (`ColourStats/PairMap.lean`, `pairMap_surjective`).
    - Serie de Neumann (`ColourStats/Neumann.lean`, `exists_right_inverse`).
    - Ensamblaje del lema a partir de sus estimaciones (`ColourStats/E3Assembly.lean`,
      `right_inverse_of_estimates`): si `AΦ₁ = I − T`, `‖Φ₁‖ ≤ a/m`, `‖T‖ ≤ τ`,
      `T² = σ ⊗ 1_{π₀} + E₁` con `‖E₁‖ ≤ ε₁`, `‖σ‖ ≤ s`, `A w = 1_{π₀} + e₂` con `‖e₂‖ ≤ ε₂`,
      `‖w‖ ≤ b/m` y `ε₁ + s ε₂ ≤ 1/2`, entonces hay inversa derecha con
      `‖Φ‖ ≤ 2(a + aτ + sb)/m`. También la cota de normas por sumas de filas
      (`opNorm_le_of_rowSum`).
    - Tipicidad `(η, h)` con densidades, tal como la define el paper (`ColourStats/Typical.lean`,
      `IsTypical`), y la estimación de carga de una pesadura por tipos (`load_estimate`).
    - La pesadura `W_1` explícita, `α·1_{AAB} + [A ≠ B]·β·1_{AAA}`, que resuelve exactamente
      las ecuaciones de carga ideal (`ColourStats/Weighting.lean`, `idealLoad_weight`), y su
      error `|carga − 1_{π₀}| ≤ η Σ_Z |w| |Z| d d` en cada par (`WeightingError.lean`,
      `load_weight_error`). No hace falta la aplicación de pares general.
    - **Lema 5.19 cerrado** (`ColourStats/Lemma519.lean`, `lemma_5_19_exists`): para
      `δ₀ ∈ (0, 1]` y `d₀ > 0` existen `η₀ > 0`, `m₀` y `K` tales que todo grafo
      `(η, 5)`-típico con `η ≤ η₀`, `m ≥ m₀` vértices, clases de tamaño `≥ δ₀ m` y densidades
      en `[d₀, 1]` tiene una inversa derecha lineal de la incidencia aristas–triángulos con
      `‖Φ‖_{∞→∞} ≤ K/m`. Versión con constantes explícitas: `Hyp.lemma_5_19`
      (`η₀ = min(1/10, δ₀² d₀/168)`, `p = δ₀² d₀⁵/4`).
      Piezas: `Counting` (aproximaciones y conteo de aristas en vecindades comunes),
      `Host519` (operadores `A`, `T`, `Φ₁`, gadget, `AΦ₁ = I − T`), `Edges519`,
      `Estimates519` (`|P_e| ≥ p m²`, `‖T‖ ≤ 1/p`), `Phi519` (`‖Φ₁‖ ≤ 108/(p m)`),
      `W519` (`A W₁ = 1_{E₀} + e₂`, `|e₂| ≤ η`), `K2519` (`|K₂ − 1/|E₀|| ≤ 19η/M` en pares
      disjuntos).
      Diferencias con el paper: se toma `π₀ = {A₀, A₀}`; `K₂` se estima por conteo directo
      con tipicidad para cinco vértices, sin el argumento de normalización `Σ_f K₂ = 1`; se
      usa `d ≤ 1`, implícito en el paper.
  - Lema 5.17 (red de `K_m ∨ C_h`): `ColourStats/E2Lattice.lean`. **Probado**
    (`sum_eq_zero_of_rich`, `mem_span_of_rich`) con hipótesis de riqueza explícitas: tres
    colores tienen un vecino común; dos vértices adyacentes a dos colores `c, c'` tienen un
    vecino común también adyacente a `c, c'`; toda arista `uv` está en un triángulo. La
    hipótesis del paper, leída literalmente, obliga a que `H` sea todo `K_m ∨ C_h`; conviene
    reemplazarla por estas.
  - Lema 5.18: `ColourStats/E2Swap.lean`. **Probado**: los intercambios preservan pares
    (`swapVec_inLambda`), y los intercambios `swapVec o o Y Z ω Γ` con `{Y, Z} ∌ o`, `Γ ≠ ω`
    forman una base de `Λ` con coeficientes `d(π, Γ)` (`inLambda_unique`, `inLambda_repr`).
    Son `C(k, 2)(ℓ − 1)` vectores: `rank Λ = C(k, 2)(ℓ − 1)` (`ColourStats/E2SwapRank.lean`,
    `finrank_Lam2`); los intercambios con `Γ = ω` son cero (`basisVec_self`). La base es más
    simple que la del paper y no necesita el argumento módulo 2 sobre `L_even`.
    Observación (verificada a mano, no en Lean): un intercambio alternante saca cuatro
    triángulos `{u, v, c}` (las aristas `u₁u₂, u₃u₄` con su color `c` y `u₂u₃, u₄u₁` con `c'`)
    y pone cuatro; el vector de tipos cambia en ocho unidades con signo. El paper dice "ocho
    triángulos por ocho"; conviene corregirlo a "cuatro por cuatro".
- A5. Proposición 1.3: `ColourStats/Prop13.lean` y `ColourStats/Prop13Bridge.lean`.
  **Probada** con error explícito:
  `|Φ(t) − (n²/6)(log n − 2 − D(Q‖P₀))| ≤ (n/6)|log n − 2| + n` (`prop_1_3`). La identidad
  exacta detrás es `Φ − (n²/6)(log n − 2 − D) = −(n/6)(log n − 2) + Σ t_XY log(1 − 1/c_X)`
  (`prop_1_3_exact`). Solo usa `c_X ≥ 2`, `t > 0`, las identidades de fila de (1.3), la
  admisibilidad y `n = Σ c_X`; no hacen falta `δ₀` ni `ζ`. `Phi_bicolTypes` identifica
  la tasa del enunciado `Theorem_1_2` de `Challenge.lean` con la de la proposición, y
  `prop_1_3_bicol` da la forma normal para ese enunciado.

**B. Cotas superiores (Sección 4).**
- (4.3) para STS, todos los tipos de bloque: **probada** (`ColourStats/TypedFinal.lean`,
  `typed_upper`). Si las clases tienen al menos `c₁ + 2` puntos (`c₁ ≥ 1`) y hay algún sistema
  con vector de tipos `t`, entonces
  `log N^all_t ≤ Φ(t) + n²((5 log n + 16)/n + 8 c₁^{−1/4})`, que es `O(n^{7/4})` con
  `c₁ = δ₀ n − 2`. No usa las identidades de pares (1.4): vale para todo `t`.
  `theorem_1_5_upper_exp` (`TypedThm.lean`) da la mitad superior del Teorema 1.5 en la forma
  `N^all_t ≤ exp(Φ(t) + ε n²)`; con `t = bicolTypes t'` es la mitad superior del Teorema 1.2.
  `Challenge.Theorem_1_5_upper` está escrito con `log`; con la convención `log 0 = 0` de Lean,
  el caso sin sistemas exige además `Φ(t) ≥ −ε n²`, que el paper no afirma. Ese caso no está
  probado; `upper_log` da la forma logarítmica cuando hay al menos un sistema.
  Estructura de la prueba (todo con axiomas estándar):
  - regla de la cadena exacta en forma de conteo y "condicionar reduce la entropía"
    (`TypedChain`), con un pasado más grueso para manejar los empates de las etiquetas
    (`TypedChain2.chain_typed`);
  - etiquetas `λ_e ∈ Fin L` por par y desempate por índice. El evento F⁻ ("ningún par del
    bloque tiene etiqueta menor") depende solo del pasado grueso, y cada sistema tiene el mismo
    número de etiquetados en él: es el Paso 2 del paper, ahora exacto (`TypedSTS.F_iff`,
    `TypedPair.card_box_eq`);
  - lema de revelado con los seis pares de los bloques `{a, z, ·}` y `{b, z, ·}`, que son
    distintos entre sí y de los del bloque de `p` (`good_of_mem`, `card_D9`); Jensen sobre la
    caja (`point_sum_le`);
  - parte de clases con concavidad (`class_sum_le`) y agregación por clase de par
    (`typed_agg_bound`);
  - `Ψ(c) ≤ 2·wsum 3 L √c` y la comparación suma–integral del corpus
    (`weighted_log_sum_le`), con `L = n` (`term_le`);
  - `M(π, X) = m_π(τ) t_τ` por doble conteo de banderas (`Mstat_eq`) y
    `w(τ, π) e_π = m_π(τ) N_τ` del Lema 5.12 (`compl_mul_typeNum`).
  Diferencia con el paper: el Paso 7 pasa por `D(Q‖P₀)`; aquí se llega directo a `Φ(t)`
  agrupando por tipos de bloque, sin la aproximación `Q(A,B) = γ_A γ_B + O(1/n)`.
- (1.1) para cuadrados latinos: pendiente. Necesita el Lema 4.1 (identidad finita) y el
  Lema 4.2, que usa el teorema de Brégman, que no está en el corpus ni en Mathlib.
- Mitad superior del Teorema 1.7: **probada** (`Typed1F*.lean`). Si cada clase de colores
  tiene al menos `h₁ + 1` colores (`h₁ ≥ 1`) y hay alguna 1-factorización de tipo `t`,
  `log N^{1F}_t ≤ Φ(t) + n²((log n + 4)/n + 7 h₁^{−1/4})` (`typed_upper_1F`);
  `theorem_1_7_upper_exp` da `N^{1F}_t ≤ exp(Φ(t) + ε n²)` con clases de colores de tamaño
  `≥ δ₀ n`, para todo `t` (no usa (1.5) ni las clases de vértices). Aquí el bloque de la arista
  `uv` es el triángulo `{u, v, c}`, cuyo único par vértice–vértice es la arista misma: no hay
  evento `F`, cada arista pesa `∫₀¹ dλ = 1`, y los colores candidatos dependen de dos aristas
  (las de color `c'` en `u` y en `v`), lo que da `∫₀¹ (log h + 2 log(1−λ)) dλ = log h − 2`.
- Mitad superior del Teorema 1.9(a): **probada** (`TypedG*.lean`). Para `G`
  `(η, 5)`-típico con `η ≤ 1/3` y aristas con al menos `c₁ ≥ 1` vecinos comunes en cada
  clase, si hay alguna descomposición de tipo `t`,
  `log N_t(G) ≤ Φ_G(t) + n²((5 log n + 16)/n + 8 c₁^{−1/4} + η)` (`typed_upper_G`);
  `theorem_1_9a_upper_exp` da `N_t(G) ≤ exp(Φ_G(t) + ε n²)` bajo `TypHyp`, para todo `t`
  (no usa (1.6) ni la divisibilidad). La maquinaria de STS se generaliza a cuasigrupos sobre
  las aristas de `G` (`IsSQG`); los candidatos son vecinos comunes, y la tipicidad para pares
  da `|E_π| m* ≤ ((1+η)/(1−η)) Σ_{ab∈E_π} |N(a)∩N(b)∩X| = ((1+η)/(1−η)) m_π(τ) N_τ(G)`
  (`card_mul_mstar_le`, `sum_cnb`).
- En los tres casos (1.5, 1.7, 1.9) los enunciados con `log` de `Statements.lean` y
  `Challenge.lean` tienen el artefacto de `log 0 = 0` cuando no hay objetos; las formas
  exponenciales probadas son las fieles al paper.

**C. Cotas inferiores (Sección 5, Ruta 3′).** Pendiente. Las piezas algebraicas que usa
(Lemas 5.12–5.20) están probadas. Falta la parte probabilística y de absorción: coloreo aleatorio y conteo de emparejamientos
(GJKKL; no está en el corpus), limpieza, cover-down con EGJ (en el corpus) y compleción en el
vórtice con T+ (en el corpus). H2 con Nash–Williams (en el corpus, TD1).

**D. Enunciados.** Todos los resultados numerados de la Sección 1 están enunciados como `Prop`:
Teoremas 1.2 y 1.5 en `ColourStats/Challenge.lean`; Teoremas 1.1, 1.7 (y su mitad superior),
1.9(a) (y su mitad superior), 1.9(b), 1.10 y Corolarios 1.4, 1.6, 1.8, 1.11 en
`ColourStats/Statements.lean`. Decisiones de redacción:
- En el Teorema 1.1, la cota inferior supone las identidades de márgenes del contorno
  (`OutlineMargins`); el paper las deja implícitas y sin ellas no hay cuadrados latinos.
- Los principios de grandes desviaciones se enuncian por conteo (`CountLDP`): para `F`
  cerrado y todo `r` bajo la tasa en `F`, a la larga `#{Q_n ∈ F} ≤ total · e^{−s r}`; para `U`
  abierto, `Q ∈ U` factible y `ε > 0`, a la larga `#{Q_n ∈ U} ≥ total · e^{−s(I(Q)+ε)}`.
- El Teorema 1.10 se enuncia para 1.1 (mitad inferior), 1.2, 1.5, 1.7 y 1.9(a). Lo que dice
  sobre los Corolarios 1.6 y 1.8 ("un entorno de un punto interior") no fija el entorno, así
  que no se enunció; conviene precisarlo en el paper.

Implicaciones probadas entre enunciados (axiomas estándar):
- `corollary_1_11_of : Theorem_1_10_typical → Corollary_1_11` (`ColourStats/Cor111.lean`). Las
  compleciones de `Q` con vector `t` están en biyección con las descomposiciones de
  `K_n − L_Q` con vector `t − t(Q)` (`completionEquiv`), y `K_n − L_Q` es divisible en
  triángulos para `n ≡ 1, 3 (mod 6)` (`triDivisible_leave`). Es la prueba de tres líneas del
  paper, completa.
- `theorem_1_5_of : Theorem_1_9a → Theorem_1_5` (`ColourStats/Thm15From19.lean`): `K_n` es
  `(n^{−1/2}, 5)`-típico con densidades 1 cuando las clases tienen al menos `5√n` puntos, sus
  descomposiciones son los sistemas triples, y `Φ_{K_n} = Φ`.

## Dependencia externa que falta

GJKKL (conteo de emparejamientos perfectos en hipergrafos casi regulares con codegrados
pequeños) no aparece en el corpus. Es la única pieza externa de la cota inferior que no está
formalizada.
