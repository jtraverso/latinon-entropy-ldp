/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.E3Gadget
public import ColourStats.Counting
public import ColourStats.E3Assembly

/-!
# The concrete operators of Lemma 5.19

For a graph `G` on `V` with classes `cls` and a fixed class `A₀`:
* `Edge G`, `Tri G`: the edges and the triangles of `G`;
* `Aop`: the edge–triangle incidence map `(A w)(e) = Σ_{t ∋ e} w(t)`;
* `P e`: the edges `f` inside the class `A₀` with `e ⊠ f` (the four endpoints span a `K₄`);
* `ν e`: the uniform law on `P e`; `gadget e f`: the `K₄` gadget `g(e, f)`;
* `Top r (f) = Σ_e r(e) ν_e(f)` and `Φ₁op r = Σ_e r(e) Σ_f ν_e(f) g(e, f)`.

Main results:
* `mulVec_gadget`: `A g(e, f) = 1_e − 1_f` for `f ∈ P e`;
* `A_comp_Phi₁`: `AΦ₁ = I − T` when every `P e` is nonempty.
-/

@[expose] public section

open Finset

noncomputable section

open Classical

namespace ColourStats.Host519

open Typical Counting

variable {V : Type*} [Fintype V] {k : ℕ}

/-- The edges of `G`. -/
abbrev Edge (G : SimpleGraph V) := {e : Sym2 V // e ∈ G.edgeFinset}

/-- Triangles: three mutually adjacent vertices. -/
def IsTri (G : SimpleGraph V) (t : Finset V) : Prop :=
  t.card = 3 ∧ ∀ x ∈ t, ∀ y ∈ t, x ≠ y → G.Adj x y

/-- The triangles of `G`. -/
abbrev Tri (G : SimpleGraph V) := {t : Finset V // IsTri G t}

/-- The incidence matrix: `1` if the edge lies in the triangle. -/
def MA (G : SimpleGraph V) : Matrix (Edge G) (Tri G) ℝ :=
  fun e t => (TypedTriangle.ind (TypedTriangle.triEdges t.1) e.1 : ℝ)

/-- The incidence map `A`. -/
def Aop (G : SimpleGraph V) : (Tri G → ℝ) →L[ℝ] (Edge G → ℝ) :=
  LinearMap.toContinuousLinearMap (MA G).mulVecLin

/-- `e ⊠ f`: every endpoint of `e` is adjacent to every endpoint of `f`. -/
def Boxed (G : SimpleGraph V) (e f : Sym2 V) : Prop := ∀ v ∈ e, ∀ w ∈ f, G.Adj v w

/-- `f` lies inside the class `A₀`. -/
def InClass (cls : V → Fin k) (A₀ : Fin k) (f : Sym2 V) : Prop := ∀ v ∈ f, cls v = A₀

/-- `P_e`: the edges of class `{A₀, A₀}` that are `⊠`-partners of `e`. -/
def P (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) (e : Edge G) : Finset (Edge G) :=
  univ.filter fun f => Boxed G e.1 f.1 ∧ InClass cls A₀ f.1

/-- `ν_e`: the uniform law on `P_e`. -/
def ν (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) (e f : Edge G) : ℝ :=
  if f ∈ P G cls A₀ e then 1 / (P G cls A₀ e).card else 0

/-- The indicator of the triangle with vertex set `S`. -/
def triInd (G : SimpleGraph V) (S : Finset V) (t : Tri G) : ℝ := if t.1 = S then 1 else 0

/-- The `K₄` gadget `g(e, f) = ½(1_{abx} + 1_{aby} − 1_{axy} − 1_{bxy})`, with `e = ab`,
`f = xy` read off chosen representatives. -/
def gadget (G : SimpleGraph V) (e f : Edge G) : Tri G → ℝ :=
  (1 / 2 : ℝ) • (triInd G {e.1.out.1, e.1.out.2, f.1.out.1} +
    triInd G {e.1.out.1, e.1.out.2, f.1.out.2} - triInd G {e.1.out.1, f.1.out.1, f.1.out.2} -
    triInd G {e.1.out.2, f.1.out.1, f.1.out.2})

omit [Fintype V] in
lemma out_eq (e : Sym2 V) : s(e.out.1, e.out.2) = e :=
  Quot.out_eq e

lemma adj_out (G : SimpleGraph V) (e : Edge G) : G.Adj e.1.out.1 e.1.out.2 := by
  have h := e.2
  rw [← out_eq e.1] at h
  exact G.mem_edgeSet.mp (SimpleGraph.mem_edgeFinset.mp h)

omit [Fintype V] in
lemma isTri_of_adj (G : SimpleGraph V) {u v w : V} (huv : G.Adj u v) (huw : G.Adj u w)
    (hvw : G.Adj v w) : IsTri G {u, v, w} := by
  refine ⟨?_, ?_⟩
  · rw [Finset.card_insert_of_notMem (by simp [G.ne_of_adj huv, G.ne_of_adj huw]),
      Finset.card_pair (G.ne_of_adj hvw)]
  · intro x hx y hy hxy
    simp only [Finset.mem_insert, Finset.mem_singleton] at hx hy
    rcases hx with rfl | rfl | rfl <;> rcases hy with rfl | rfl | rfl <;>
      first | exact absurd rfl hxy | assumption | exact G.adj_symm ‹_›

/-- `A 1_S` for a triangle `S`. -/
lemma mulVec_triInd (G : SimpleGraph V) {S : Finset V} (hS : IsTri G S) (h : Edge G) :
    (MA G).mulVec (triInd G S) h = (TypedTriangle.ind (TypedTriangle.triEdges S) h.1 : ℝ) := by
  simp only [Matrix.mulVec, dotProduct, triInd]
  rw [Finset.sum_eq_single ⟨S, hS⟩]
  · simp [MA]
  · intro t _ ht
    have : t.1 ≠ S := fun e => ht (Subtype.ext e)
    simp [this]
  · simp

/-- **The gadget identity** `A g(e, f) = 1_e − 1_f` for `f ∈ P_e`. -/
theorem mulVec_gadget (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) {e f : Edge G}
    (hf : f ∈ P G cls A₀ e) : (MA G).mulVec (gadget G e f) = Pi.single e 1 - Pi.single f 1 := by
  set a := e.1.out.1
  set b := e.1.out.2
  set x := f.1.out.1
  set y := f.1.out.2
  have hbox : Boxed G e.1 f.1 := (Finset.mem_filter.mp hf).2.1
  rw [← out_eq e.1, ← out_eq f.1] at hbox
  have hab : G.Adj a b := adj_out G e
  have hxy : G.Adj x y := adj_out G f
  have hax : G.Adj a x := hbox a (Sym2.mem_mk_left _ _) x (Sym2.mem_mk_left _ _)
  have hay : G.Adj a y := hbox a (Sym2.mem_mk_left _ _) y (Sym2.mem_mk_right _ _)
  have hbx : G.Adj b x := hbox b (Sym2.mem_mk_right _ _) x (Sym2.mem_mk_left _ _)
  have hby : G.Adj b y := hbox b (Sym2.mem_mk_right _ _) y (Sym2.mem_mk_right _ _)
  funext h
  have hid := congrFun (E3Gadget.gadget_identity (G.ne_of_adj hab) (G.ne_of_adj hax)
    (G.ne_of_adj hay) (G.ne_of_adj hbx) (G.ne_of_adj hby) (G.ne_of_adj hxy)) h.1
  simp only [Pi.add_apply, Pi.sub_apply, Pi.smul_apply] at hid
  simp only [nsmul_eq_mul] at hid
  have hidR := congrArg (fun z : ℤ => (z : ℝ)) hid
  push_cast at hidR
  have hea : s(a, b) = e.1 := out_eq e.1
  have hfx : s(x, y) = f.1 := out_eq f.1
  rw [hea, hfx] at hidR
  simp only [gadget, Matrix.mulVec_smul, Matrix.mulVec_add, Matrix.mulVec_sub, Pi.smul_apply,
    Pi.add_apply, Pi.sub_apply, smul_eq_mul]
  rw [mulVec_triInd G (isTri_of_adj G hab hax hbx), mulVec_triInd G (isTri_of_adj G hab hay hby),
    mulVec_triInd G (isTri_of_adj G hax hay hxy), mulVec_triInd G (isTri_of_adj G hbx hby hxy)]
  have key : (1 / 2 : ℝ) * ((TypedTriangle.ind (TypedTriangle.triEdges {a, b, x}) h.1 : ℝ) +
      (TypedTriangle.ind (TypedTriangle.triEdges {a, b, y}) h.1 : ℝ) -
      (TypedTriangle.ind (TypedTriangle.triEdges {a, x, y}) h.1 : ℝ) -
      (TypedTriangle.ind (TypedTriangle.triEdges {b, x, y}) h.1 : ℝ)) =
      (TypedTriangle.ind {e.1} h.1 : ℝ) - (TypedTriangle.ind {f.1} h.1 : ℝ) := by
    linarith [hidR]
  rw [key, Pi.single_apply, Pi.single_apply]
  simp only [TypedTriangle.ind, Finset.mem_singleton, Subtype.val_inj]
  split_ifs <;> simp

/-- `Φ₁` as a matrix: `Φ₁(t, e) = Σ_f ν_e(f) g(e, f)(t)`. -/
def MPhi (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) : Matrix (Tri G) (Edge G) ℝ :=
  fun t e => ∑ f, ν G cls A₀ e f * gadget G e f t

/-- `T` as a matrix: `T(f, e) = ν_e(f)`. -/
def MT (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) : Matrix (Edge G) (Edge G) ℝ :=
  fun f e => ν G cls A₀ e f

def Phiop (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) :
    (Edge G → ℝ) →L[ℝ] (Tri G → ℝ) :=
  LinearMap.toContinuousLinearMap (MPhi G cls A₀).mulVecLin

def Top (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) :
    (Edge G → ℝ) →L[ℝ] (Edge G → ℝ) :=
  LinearMap.toContinuousLinearMap (MT G cls A₀).mulVecLin

lemma sum_ν (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) (e : Edge G)
    (hne : (P G cls A₀ e).Nonempty) : ∑ f, ν G cls A₀ e f = 1 := by
  unfold ν
  rw [← Finset.sum_filter, Finset.filter_mem_eq_inter, Finset.univ_inter, Finset.sum_const,
    nsmul_eq_mul]
  have : ((P G cls A₀ e).card : ℝ) ≠ 0 := by exact_mod_cast hne.card_pos.ne'
  field_simp

/-- **`AΦ₁ = I − T`.** -/
theorem A_comp_Phi₁ (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k)
    (hne : ∀ e, (P G cls A₀ e).Nonempty) :
    (Aop G).comp (Phiop G cls A₀) = 1 - Top G cls A₀ := by
  ext1 r
  have h := E3Gadget.apply_Phi₁ (MA G).mulVecLin (ν G cls A₀) (gadget G)
    (fun e f hef => by
      have hf : f ∈ P G cls A₀ e := by
        by_contra hc; exact hef (by simp [ν, hc])
      exact mulVec_gadget G cls A₀ hf)
    (fun e => sum_ν G cls A₀ e (hne e)) r
  have hPhi : (Phiop G cls A₀) r = E3Gadget.Phi₁ (ν G cls A₀) (gadget G) r := by
    funext t
    simp only [Phiop, LinearMap.coe_toContinuousLinearMap', Matrix.mulVecLin_apply,
      Matrix.mulVec, dotProduct, MPhi, E3Gadget.Phi₁, Finset.sum_apply, Pi.smul_apply,
      smul_eq_mul, Finset.sum_mul, Finset.mul_sum]
    exact Finset.sum_congr rfl fun e _ => Finset.sum_congr rfl fun f _ => by ring
  have hT : (Top G cls A₀) r = E3Gadget.Tmap (ν G cls A₀) r := by
    funext f
    simp only [Top, LinearMap.coe_toContinuousLinearMap', Matrix.mulVecLin_apply,
      Matrix.mulVec, dotProduct, MT, E3Gadget.Tmap]
    exact Finset.sum_congr rfl fun e _ => by ring
  simp only [ContinuousLinearMap.comp_apply, ContinuousLinearMap.sub_apply,
    ContinuousLinearMap.one_apply, hPhi, hT]
  simpa [Aop] using h

end ColourStats.Host519
