/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedChain2
public import CountingCone.LL.STSReveal

/-!
# The revealing process for the typed bound (Section 4.2)

Steiner triple systems are encoded by their Steiner quasigroups `T` (`LinialLuria.IsSQ`):
`T a b` is the third point of the block through `a ≠ b`. The coordinates are the unordered
pairs, as ordered pairs `p = (a, b)` with `a < b` (`pairs`), and `coord p T = T a b`.

The pairs receive labels `lam : Pair n → Fin L`; the revealing order is `key1`, the label
with ties broken by a fixed index, and the coarser past is given by `key2 = lam`.

* `det_of_not_F`: if a pair of the block of `p` has a smaller label than `p`, every system
  agreeing with `T` on the pairs with smaller labels has the same third point at `p`.
* `good_of_mem`: if a system agreeing with `T` on the pairs with smaller labels has another
  third point `z` at `p = (a, b)`, then the six pairs of the blocks of `T` through `{a, z}` and
  `{b, z}` all have labels at least `lam p`.
* `F_iff`: the event "no pair of the block of `p` has a smaller label" is determined by the
  coarser past.
* `blockPairs`: the three pairs of a block; pairs of distinct blocks are distinct
  (`disjoint_blockPairs`), so the nine pairs met by `good_of_mem` are distinct.
-/

@[expose] public section

open Finset LinialLuria
open ColourStats.TypedChain

namespace ColourStats.TypedChain

lemma mem_before {α ι β : Type*} [DecidableEq α] [DecidableEq β] {S : Finset α} {I : Finset ι}
    {key : ι → ℕ} {f : ι → α → β} {s : ι} {x y : α} :
    y ∈ before S I key f s x ↔ y ∈ S ∧ ∀ t ∈ I, key t < key s → f t y = f t x :=
  Finset.mem_filter

end ColourStats.TypedChain

namespace ColourStats.TypedSTS

variable {n L : ℕ}

/-- Ordered pairs of points. -/
abbrev Pair (n : ℕ) := Fin n × Fin n

/-- The unordered pairs, as `(a, b)` with `a < b`. -/
def pairs (n : ℕ) : Finset (Pair n) := univ.filter fun p => p.1 < p.2

/-- The sorted pair. -/
def sp (u v : Fin n) : Pair n := (min u v, max u v)

/-- The coordinate at `p`: the third point of the block through `p`. -/
def coord (p : Pair n) (T : Fin n → Fin n → Fin n) : Fin n := T p.1 p.2

/-- An injective index of the pairs, below `n²`. -/
def idx (p : Pair n) : ℕ := p.2 + n * p.1

/-- The revealing order: the label, ties broken by the index. -/
def key1 (lam : Pair n → Fin L) (p : Pair n) : ℕ := idx p + (n * n) * lam p

/-- The coarser order: the label alone. -/
def key2 (lam : Pair n → Fin L) (p : Pair n) : ℕ := lam p

lemma idx_lt (p : Pair n) : idx p < n * n := by
  unfold idx
  have h1 := p.1.isLt
  have h2 := p.2.isLt
  nlinarith

lemma idx_inj {p q : Pair n} (h : idx p = idx q) : p = q := by
  unfold idx at h
  have hn : 0 < n := Nat.pos_of_ne_zero (fun h0 => by subst h0; exact p.1.elim0)
  have h2 : (p.2 : ℕ) = q.2 := by
    have := congrArg (· % n) h
    simpa [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt p.2.isLt,
      Nat.mod_eq_of_lt q.2.isLt] using this
  have h1 : (p.1 : ℕ) = q.1 := by
    have := congrArg (· / n) h
    simpa [Nat.add_mul_div_left _ _ hn, Nat.div_eq_of_lt p.2.isLt,
      Nat.div_eq_of_lt q.2.isLt] using this
  exact Prod.ext (Fin.ext h1) (Fin.ext h2)

lemma key1_injective (lam : Pair n → Fin L) : Function.Injective (key1 lam) := by
  intro p q h
  unfold key1 at h
  have := congrArg (· % (n * n)) h
  simp only [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt (idx_lt p),
    Nat.mod_eq_of_lt (idx_lt q)] at this
  exact idx_inj this

lemma key1_lt_of_key2_lt (lam : Pair n → Fin L) {p q : Pair n} (h : key2 lam p < key2 lam q) :
    key1 lam p < key1 lam q := by
  unfold key1
  unfold key2 at h
  have h1 := idx_lt p
  have h2 : (lam p : ℕ) + 1 ≤ lam q := h
  nlinarith

/-! ### Sorted pairs -/

lemma sp_set (u v : Fin n) : ({(sp u v).1, (sp u v).2} : Finset (Fin n)) = {u, v} := by
  unfold sp
  rcases le_total u v with h | h
  · rw [min_eq_left h, max_eq_right h]
  · rw [min_eq_right h, max_eq_left h, Finset.pair_comm]

lemma pair_eq_cases {u v u' v' : Fin n} (huv : u ≠ v)
    (h : ({u, v} : Finset (Fin n)) = {u', v'}) : (u = u' ∧ v = v') ∨ (u = v' ∧ v = u') := by
  have hu : u ∈ ({u', v'} : Finset (Fin n)) := h ▸ by simp
  have hv : v ∈ ({u', v'} : Finset (Fin n)) := h ▸ by simp
  have hu' : u' ∈ ({u, v} : Finset (Fin n)) := h.symm ▸ by simp
  simp only [Finset.mem_insert, Finset.mem_singleton] at hu hv hu'
  rcases hu with rfl | rfl <;> rcases hv with rfl | rfl
  · exact absurd rfl huv
  · exact Or.inl ⟨rfl, rfl⟩
  · exact Or.inr ⟨rfl, rfl⟩
  · exact absurd rfl huv

lemma sp_inj {u v u' v' : Fin n} (huv : u ≠ v) (h : sp u v = sp u' v') :
    (u = u' ∧ v = v') ∨ (u = v' ∧ v = u') := by
  apply pair_eq_cases huv
  rw [← sp_set, ← sp_set u' v', h]

lemma sp_mem {u v : Fin n} (huv : u ≠ v) : sp u v ∈ pairs n := by
  simp only [pairs, Finset.mem_filter, Finset.mem_univ, true_and, sp]
  rcases lt_or_gt_of_ne huv with h | h
  · rw [min_eq_left h.le, max_eq_right h.le]; exact h
  · rw [min_eq_right h.le, max_eq_left h.le]; exact h

lemma sp_of_lt {u v : Fin n} (h : u < v) : sp u v = (u, v) := by
  simp [sp, min_eq_left h.le, max_eq_right h.le]

section SQ

variable {T : Fin n → Fin n → Fin n}

lemma coord_sp (hT : IsSQ T) (u v : Fin n) : coord (sp u v) T = T u v := by
  unfold coord sp
  rcases le_total u v with h | h
  · rw [min_eq_left h, max_eq_right h]
  · rw [min_eq_right h, max_eq_left h, hT.comm]

/-- The block through `u` and `v`. -/
def blk (T : Fin n → Fin n → Fin n) (u v : Fin n) : Finset (Fin n) := {u, v, T u v}

lemma blk_comm (hT : IsSQ T) (u v : Fin n) : blk T v u = blk T u v := by
  unfold blk
  rw [hT.comm]
  ext x
  simp only [Finset.mem_insert, Finset.mem_singleton]
  tauto

lemma blk_left (hT : IsSQ T) (u v : Fin n) : blk T u (T u v) = blk T u v := by
  unfold blk
  rw [hT.invol]
  ext x
  simp only [Finset.mem_insert, Finset.mem_singleton]
  tauto

lemma blk_right (hT : IsSQ T) (u v : Fin n) : blk T v (T u v) = blk T u v := by
  have h : T v (T u v) = u := by rw [← hT.comm u v, hT.invol]
  unfold blk
  rw [h]
  ext x
  simp only [Finset.mem_insert, Finset.mem_singleton]
  tauto

lemma blk_of_sp (hT : IsSQ T) {u v u' v' : Fin n} (huv : u ≠ v) (h : sp u v = sp u' v') :
    blk T u v = blk T u' v' := by
  rcases sp_inj huv h with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
  · rfl
  · exact (blk_comm hT _ _).symm

/-- The three pairs of the block through `u` and `v`. -/
def blockPairs (T : Fin n → Fin n → Fin n) (u v : Fin n) : Finset (Pair n) :=
  {sp u v, sp u (T u v), sp v (T u v)}

lemma card_blockPairs (hT : IsSQ T) {u v : Fin n} (huv : u ≠ v) :
    (blockPairs T u v).card = 3 := by
  have h1 : T u v ≠ u := hT.ne_left huv
  have h2 : T u v ≠ v := hT.ne_right huv
  unfold blockPairs
  refine Finset.card_eq_three.mpr ⟨_, _, _, ?_, ?_, ?_, rfl⟩
  · intro h
    rcases sp_inj huv h with ⟨-, e⟩ | ⟨e, -⟩
    · exact h2 e.symm
    · exact h1 e.symm
  · intro h
    rcases sp_inj huv h with ⟨e, -⟩ | ⟨e, -⟩
    · exact huv e
    · exact h1 e.symm
  · intro h
    rcases sp_inj (Ne.symm h1) h with ⟨e, -⟩ | ⟨e, -⟩
    · exact huv e
    · exact h1 e.symm

lemma mem_blockPairs (hT : IsSQ T) {u v : Fin n} (huv : u ≠ v) {q : Pair n}
    (hq : q ∈ blockPairs T u v) : ∃ x y, x ≠ y ∧ q = sp x y ∧ blk T x y = blk T u v := by
  have h1 : T u v ≠ u := hT.ne_left huv
  have h2 : T u v ≠ v := hT.ne_right huv
  simp only [blockPairs, Finset.mem_insert, Finset.mem_singleton] at hq
  rcases hq with rfl | rfl | rfl
  · exact ⟨u, v, huv, rfl, rfl⟩
  · exact ⟨u, T u v, Ne.symm h1, rfl, blk_left hT u v⟩
  · exact ⟨v, T u v, Ne.symm h2, rfl, blk_right hT u v⟩

/-- Pairs of distinct blocks are distinct. -/
lemma disjoint_blockPairs (hT : IsSQ T) {u v u' v' : Fin n} (huv : u ≠ v) (hu'v' : u' ≠ v')
    (hne : blk T u v ≠ blk T u' v') : Disjoint (blockPairs T u v) (blockPairs T u' v') := by
  rw [Finset.disjoint_left]
  intro q hq hq'
  obtain ⟨x, y, hxy, rfl, hb⟩ := mem_blockPairs hT huv hq
  obtain ⟨x', y', -, he, hb'⟩ := mem_blockPairs hT hu'v' hq'
  exact hne (hb.symm.trans ((blk_of_sp hT hxy he).trans hb'))

lemma blockPairs_subset (hT : IsSQ T) {u v : Fin n} (huv : u ≠ v) :
    blockPairs T u v ⊆ pairs n := by
  intro q hq
  obtain ⟨x, y, hxy, rfl, -⟩ := mem_blockPairs hT huv hq
  exact sp_mem hxy

end SQ

/-! ### Agreement with the coarser past -/

variable {S : Finset (Fin n → Fin n → Fin n)}

lemma agree_of_mem (lam : Pair n → Fin L) (hS : ∀ T ∈ S, IsSQ T) {p : Pair n}
    {T T' : Fin n → Fin n → Fin n} (hT : T ∈ S) (hT' : T' ∈ before S (pairs n) (key2 lam) coord p T)
    {u v : Fin n} (huv : u ≠ v) (hlt : lam (sp u v) < lam p) : T' u v = T u v := by
  obtain ⟨hT'S, h⟩ := mem_before.mp hT'
  have := h (sp u v) (sp_mem huv) hlt
  rwa [coord_sp (hS T' hT'S), coord_sp (hS T hT)] at this

/-- **Determined coordinates.** -/
lemma det_of_not_F (lam : Pair n → Fin L) (hS : ∀ T ∈ S, IsSQ T) {a b : Fin n} (hab : a ≠ b)
    {T T' : Fin n → Fin n → Fin n} (hT : T ∈ S)
    (hT' : T' ∈ before S (pairs n) (key2 lam) coord (a, b) T)
    (hF : lam (sp a (T a b)) < lam (a, b) ∨ lam (sp b (T a b)) < lam (a, b)) :
    T' a b = T a b := by
  have hTq := hS T hT
  have hT'q := hS T' (mem_before.mp hT').1
  have hca : T a b ≠ a := hTq.ne_left hab
  have hcb : T a b ≠ b := hTq.ne_right hab
  rcases hF with h | h
  · have e := agree_of_mem lam hS hT hT' (Ne.symm hca) h
    rw [hTq.invol] at e
    calc T' a b = T' a (T' a (T a b)) := by rw [e]
      _ = T a b := hT'q.invol _ _
  · have e := agree_of_mem lam hS hT hT' (Ne.symm hcb) h
    have hTb : T b (T a b) = a := by rw [← hTq.comm a b, hTq.invol]
    rw [hTb] at e
    calc T' a b = T' b a := (hT'q.comm a b).symm
      _ = T' b (T' b (T a b)) := by rw [e]
      _ = T a b := hT'q.invol _ _

/-- `F⁻`: no pair of the block of `(a, b)` has a smaller label than `(a, b)`. -/
def Fm (lam : Pair n → Fin L) (a b : Fin n) (T : Fin n → Fin n → Fin n) : Prop :=
  lam (a, b) ≤ lam (sp a (T a b)) ∧ lam (a, b) ≤ lam (sp b (T a b))

/-- **`F⁻` is determined by the coarser past.** -/
lemma F_iff (lam : Pair n → Fin L) (hS : ∀ T ∈ S, IsSQ T) {a b : Fin n} (hab : a ≠ b)
    {T T' : Fin n → Fin n → Fin n} (hT : T ∈ S)
    (hT' : T' ∈ before S (pairs n) (key2 lam) coord (a, b) T) :
    Fm lam a b T' ↔ Fm lam a b T := by
  by_cases he : T' a b = T a b
  · unfold Fm; rw [he]
  · have hF : Fm lam a b T := by
      by_contra hF
      unfold Fm at hF
      rw [not_and_or, not_le, not_le] at hF
      exact he (det_of_not_F lam hS hab hT hT' hF)
    have hTmem : T ∈ before S (pairs n) (key2 lam) coord (a, b) T' := by
      rw [before_eq hT']
      exact mem_before_self hT
    have hF' : Fm lam a b T' := by
      by_contra hF'
      unfold Fm at hF'
      rw [not_and_or, not_le, not_le] at hF'
      exact he (det_of_not_F lam hS hab (mem_before.mp hT').1 hTmem hF').symm
    exact ⟨fun _ => hF, fun _ => hF'⟩

/-- **The revealing lemma.** If a system agreeing with `T` on the pairs with smaller labels
has another third point `z` at `(a, b)`, the six pairs of the blocks of `T` through `{a, z}`
and `{b, z}` all have labels at least `lam (a, b)`. -/
lemma good_of_mem (lam : Pair n → Fin L) (hS : ∀ T ∈ S, IsSQ T) {a b : Fin n} (hab : a ≠ b)
    {T T' : Fin n → Fin n → Fin n} (hT : T ∈ S)
    (hT' : T' ∈ before S (pairs n) (key2 lam) coord (a, b) T) (hz : T' a b ≠ T a b) :
    ∀ q ∈ blockPairs T a (T' a b) ∪ blockPairs T b (T' a b), lam (a, b) ≤ lam q := by
  have hTq := hS T hT
  have hT'q := hS T' (mem_before.mp hT').1
  set z := T' a b with hzdef
  have hza : z ≠ a := hT'q.ne_left hab
  have hzb : z ≠ b := hT'q.ne_right hab
  -- in `T'`, the block through `a, b` is `{a, b, z}`
  have h'az : T' a z = b := hT'q.invol a b
  have h'bz : T' b z = a := by rw [hzdef, ← hT'q.comm a b, hT'q.invol]
  -- a pair with a smaller label is agreed on
  have agree : ∀ u v, u ≠ v → lam (sp u v) < lam (a, b) → T' u v = T u v :=
    fun u v huv h => agree_of_mem lam hS hT hT' huv h
  have hTaz : T a z ≠ b := by
    intro h
    apply hz
    show z = T a b
    rw [← h, hTq.invol]
  have hTbz : T b z ≠ a := by
    intro h
    apply hz
    show z = T a b
    calc z = T b (T b z) := (hTq.invol b z).symm
      _ = T b a := by rw [h]
      _ = T a b := hTq.comm a b
  intro q hq
  by_contra hlt
  rw [not_le] at hlt
  rcases Finset.mem_union.mp hq with hq | hq <;>
    simp only [blockPairs, Finset.mem_insert, Finset.mem_singleton] at hq
  · rcases hq with rfl | rfl | rfl
    · -- the pair `{a, z}`
      have e := agree a z (Ne.symm hza) hlt
      exact hTaz (e ▸ h'az)
    · -- the pair `{a, T a z}`
      have hw : T a z ≠ a := hTq.ne_left (Ne.symm hza)
      have e := agree a (T a z) (Ne.symm hw) hlt
      rw [hTq.invol] at e
      -- `T' a (T a z) = z` forces `T a z = T' a z = b`
      have : T a z = b := by
        have := congrArg (T' a) e
        rw [hT'q.invol] at this
        rw [this, h'az]
      exact hTaz this
    · -- the pair `{z, T a z}`
      have hw : T a z ≠ z := hTq.ne_right (Ne.symm hza)
      have e := agree z (T a z) (Ne.symm hw) hlt
      have hTzw : T z (T a z) = a := by rw [← hTq.comm a z, hTq.invol]
      rw [hTzw] at e
      have : T a z = b := by
        have := congrArg (T' z) e
        rw [hT'q.invol, hT'q.comm a z] at this
        rw [this, h'az]
      exact hTaz this
  · rcases hq with rfl | rfl | rfl
    · have e := agree b z (Ne.symm hzb) hlt
      exact hTbz (e ▸ h'bz)
    · have hw : T b z ≠ b := hTq.ne_left (Ne.symm hzb)
      have e := agree b (T b z) (Ne.symm hw) hlt
      rw [hTq.invol] at e
      have : T b z = a := by
        have := congrArg (T' b) e
        rw [hT'q.invol] at this
        rw [this, h'bz]
      exact hTbz this
    · have hw : T b z ≠ z := hTq.ne_right (Ne.symm hzb)
      have e := agree z (T b z) (Ne.symm hw) hlt
      have hTzw : T z (T b z) = b := by rw [← hTq.comm b z, hTq.invol]
      rw [hTzw] at e
      have : T b z = a := by
        have := congrArg (T' z) e
        rw [hT'q.invol, hT'q.comm b z] at this
        rw [this, h'bz]
      exact hTbz this

/-- The blocks through `{a, b}`, `{a, z}` and `{b, z}` are distinct when `z` is not on the
block through `{a, b}`. -/
lemma blocks_distinct {T : Fin n → Fin n → Fin n} (hT : IsSQ T) {a b z : Fin n} (hab : a ≠ b)
    (hza : z ≠ a) (hzb : z ≠ b) (hzc : z ≠ T a b) :
    blk T a z ≠ blk T a b ∧ blk T b z ≠ blk T a b ∧ blk T a z ≠ blk T b z := by
  have hz1 : z ∈ blk T a z := by simp [blk]
  have hz2 : z ∈ blk T b z := by simp [blk]
  have hz0 : z ∉ blk T a b := by simp [blk, hza, hzb, hzc]
  refine ⟨fun h => hz0 (h ▸ hz1), fun h => hz0 (h ▸ hz2), fun h => ?_⟩
  have hb : b ∈ blk T a z := h ▸ (by simp [blk] : b ∈ blk T b z)
  simp only [blk, Finset.mem_insert, Finset.mem_singleton] at hb
  rcases hb with hb | hb | hb
  · exact hab hb.symm
  · exact hzb hb.symm
  · apply hzc
    rw [hb, hT.invol]

end ColourStats.TypedSTS
