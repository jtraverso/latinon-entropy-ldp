/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedFinal
public import CountingCone.LL.Analysis

/-!
# The upper halves of Theorems 1.2 and 1.5

`Theorem_1_5_upper_exp` is the upper half of Theorem 1.5 in the form
`N^all_t ≤ exp(Φ(t) + ε n²)`, for **every** type vector `t` (the pair identities (1.4) are not
needed). Since `bicolTypes` is a type vector, it contains the upper half of Theorem 1.2.

The form `log N ≤ Φ + ε n²` of `Challenge.Theorem_1_5_upper` agrees with it when `N > 0`
(`upper_log`). When `N = 0`, Lean's convention `log 0 = 0` turns that form into the extra
claim `Φ(t) ≥ −ε n²`, which is not part of the paper's statement.

Proof: `TypedSTS.typed_upper` with `c₁ = δ₀ n − 2`, `log n ≤ √n` and an explicit `n₀`
(`err_le`).
-/

@[expose] public section

open Finset Real

namespace ColourStats.TypedSTS

open ColourStats

/-- **Upper half of Theorem 1.5**, exponential form, for every type vector. -/
def Theorem_1_5_upper_exp : Prop :=
  ∀ k : ℕ, ∀ δ₀ ε : ℝ, 0 < δ₀ → 0 < ε → ∃ n₀ : ℕ,
    ∀ n : ℕ, n₀ ≤ n → ∀ lab : Fin n → Fin k,
      (∀ X, δ₀ * n ≤ classSize lab X) →
      ∀ t : Multiset (Fin k) → ℕ,
        (countAll lab t : ℝ) ≤ Real.exp (Phi lab t + ε * (n : ℝ) ^ 2)

lemma le_sqrt_sqrt {y z : ℝ} (hz : 0 ≤ z) (h : z ^ 4 ≤ y) : z ≤ Real.sqrt (Real.sqrt y) := by
  have h1 : z ^ 2 ≤ Real.sqrt y := by
    rw [show z ^ 4 = (z ^ 2) ^ 2 by ring] at h
    exact Real.le_sqrt_of_sq_le h
  exact Real.le_sqrt_of_sq_le h1

/-- The explicit threshold. -/
lemma err_le {δ₀ ε : ℝ} (hδ : 0 < δ₀) (hε : 0 < ε) {n : ℕ}
    (hn1 : (42 / ε) ^ 2 ≤ n) (hn2 : 4 / δ₀ ≤ n) (hn3 : 2 * (16 / ε) ^ 4 / δ₀ ≤ n) (hn : 1 ≤ n) :
    (5 * Real.log n + 16) / n + 8 / Real.sqrt (Real.sqrt (δ₀ * n - 2)) ≤ ε := by
  have hnr : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hnpos : (0 : ℝ) < n := by linarith
  set r := Real.sqrt n with hr
  have hr1 : 1 ≤ r := Real.one_le_sqrt.mpr hnr
  have hrr : r * r = n := Real.mul_self_sqrt hnpos.le
  -- `log n ≤ √n`
  have hlog : Real.log n ≤ r := by
    have h := LinialLuria.log_one_add_le_sqrt hnpos.le
    have : Real.log n ≤ Real.log (1 + n) := Real.log_le_log hnpos (by linarith)
    linarith
  -- first term `≤ 21/√n ≤ ε/2`
  have hr42 : 42 / ε ≤ r := by
    rw [hr]
    exact Real.le_sqrt_of_sq_le hn1
  have h1 : (5 * Real.log n + 16) / n ≤ ε / 2 := by
    rw [div_le_iff₀ hnpos]
    have : 21 * r ≤ ε / 2 * n := by
      rw [← hrr]
      have h42 : 42 ≤ ε * r := by rw [div_le_iff₀ hε] at hr42; linarith
      nlinarith
    nlinarith
  -- second term `≤ ε/2`
  have hc : δ₀ * n / 2 ≤ δ₀ * n - 2 := by
    have : 4 ≤ δ₀ * n := by rw [div_le_iff₀ hδ] at hn2; linarith
    linarith
  have hbig : (16 / ε) ^ 4 ≤ δ₀ * n - 2 := by
    have : 2 * (16 / ε) ^ 4 ≤ δ₀ * n := by rw [div_le_iff₀ hδ] at hn3; linarith
    linarith
  have hq : 16 / ε ≤ Real.sqrt (Real.sqrt (δ₀ * n - 2)) := le_sqrt_sqrt (by positivity) hbig
  have hqpos : 0 < Real.sqrt (Real.sqrt (δ₀ * n - 2)) := lt_of_lt_of_le (by positivity) hq
  have h2 : 8 / Real.sqrt (Real.sqrt (δ₀ * n - 2)) ≤ ε / 2 := by
    rw [div_le_iff₀ hqpos]
    have : 16 ≤ ε * Real.sqrt (Real.sqrt (δ₀ * n - 2)) := by
      rw [div_le_iff₀ hε] at hq; linarith
    linarith
  linarith

/-- **The upper half of Theorem 1.5** (and of Theorem 1.2), for every type vector. -/
theorem theorem_1_5_upper_exp : Theorem_1_5_upper_exp := by
  intro k δ₀ ε hδ hε
  refine ⟨⌈(42 / ε) ^ 2 + 4 / δ₀ + 2 * (16 / ε) ^ 4 / δ₀⌉₊ + 1, fun n hn lab hcls t => ?_⟩
  have hceil : (42 / ε) ^ 2 + 4 / δ₀ + 2 * (16 / ε) ^ 4 / δ₀ ≤ n := by
    have := Nat.le_ceil ((42 / ε) ^ 2 + 4 / δ₀ + 2 * (16 / ε) ^ 4 / δ₀)
    have h' : ((⌈(42 / ε) ^ 2 + 4 / δ₀ + 2 * (16 / ε) ^ 4 / δ₀⌉₊ : ℕ) : ℝ) ≤ n := by
      exact_mod_cast (Nat.le_succ _).trans hn
    linarith
  have p1 : 0 ≤ (42 / ε) ^ 2 := by positivity
  have p2 : 0 ≤ 4 / δ₀ := by positivity
  have p3 : 0 ≤ 2 * (16 / ε) ^ 4 / δ₀ := by positivity
  have hn1 : 1 ≤ n := by omega
  rcases Nat.eq_zero_or_pos (countAll lab t) with h0 | hpos
  · rw [h0, Nat.cast_zero]
    exact (Real.exp_pos _).le
  have hc₁ : 1 ≤ δ₀ * n - 2 := by
    have : 4 ≤ δ₀ * n := by
      have : 4 / δ₀ ≤ n := by linarith
      rw [div_le_iff₀ hδ] at this; linarith
    linarith
  have hc : ∀ X, δ₀ * n - 2 + 2 ≤ classSize lab X := fun X => by linarith [hcls X]
  have hup := typed_upper lab t hc₁ hc hn1 hpos
  have herr := err_le hδ hε (n := n) (by linarith) (by linarith) (by linarith) hn1
  have hcount : (0 : ℝ) < countAll lab t := by exact_mod_cast hpos
  rw [← Real.exp_log hcount]
  apply Real.exp_le_exp.mpr
  have : (n : ℝ) ^ 2 * ((5 * Real.log n + 16) / n + 8 / Real.sqrt (Real.sqrt (δ₀ * n - 2))) ≤
      ε * (n : ℝ) ^ 2 := by
    rw [mul_comm ε]
    exact mul_le_mul_of_nonneg_left herr (by positivity)
  linarith

/-- The logarithmic form, when there is at least one system. -/
theorem upper_log {k : ℕ} {δ₀ ε : ℝ} (hδ : 0 < δ₀) (hε : 0 < ε) :
    ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → ∀ lab : Fin n → Fin k,
      (∀ X, δ₀ * n ≤ classSize lab X) → ∀ t : Multiset (Fin k) → ℕ, 0 < countAll lab t →
        Real.log (countAll lab t) ≤ Phi lab t + ε * (n : ℝ) ^ 2 := by
  obtain ⟨n₀, h⟩ := theorem_1_5_upper_exp k δ₀ ε hδ hε
  refine ⟨n₀, fun n hn lab hcls t hpos => ?_⟩
  have hcount : (0 : ℝ) < countAll lab t := by exact_mod_cast hpos
  rw [Real.log_le_iff_le_exp hcount]
  exact h n hn lab hcls t

end ColourStats.TypedSTS
