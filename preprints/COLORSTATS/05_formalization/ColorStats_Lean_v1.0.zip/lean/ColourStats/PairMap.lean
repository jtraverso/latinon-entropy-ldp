/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.ColourFirst

/-!
# The pair map has an explicit right inverse (Lemma 5.19, constant vectors)

The complete-graph pair map sends type weights `w` to the pair loads
`(Mw)_π = Σ_τ m_π(τ) w_τ`. It is onto, with the explicit preimages
* `1_{XX} = M((1/3)·1_{XXX})`;
* `1_{XY} = M((1/2)·1_{XXY} − (1/6)·1_{XXX})` for `X ≠ Y`.

This is the full-row-rank statement used in the proof of Lemma 5.19 ("constant vectors on
one class"), before the substitution `w'_τ = w_τ Π_{π ⊂ τ} d_π`.
-/

@[expose] public section

open Finset

namespace ColourStats.PairMap

open ColourStats ColourFirst

variable {k : ℕ}

/-- The real indicator `1_T`. -/
def rind (T μ : Multiset (Fin k)) : ℝ := if μ = T then 1 else 0

lemma sum_mult_rind (ρ : Multiset (Fin k)) {T : Multiset (Fin k)} (hT : Multiset.card T = 3)
    (c : ℝ) :
    ∑ τ ∈ blockTypes k, (mult ρ τ : ℝ) * (c * rind T τ) = mult ρ T * c := by
  simp [rind, mul_ite, mem_blockTypes, hT]

lemma mult_XXX (ρ : Multiset (Fin k)) (X : Fin k) :
    (mult ρ ({X, X, X} : Multiset (Fin k)) : ℝ) = 3 * rind {X, X} ρ := by
  rw [mult, pairs_triple]
  simp only [Multiset.count_cons, Multiset.count_singleton, rind]
  push_cast
  ring

lemma mult_XXY (ρ : Multiset (Fin k)) (X Y : Fin k) :
    (mult ρ ({X, X, Y} : Multiset (Fin k)) : ℝ) = 2 * rind {X, Y} ρ + rind {X, X} ρ := by
  rw [mult, pairs_triple]
  simp only [Multiset.count_cons, Multiset.count_singleton, rind]
  push_cast
  ring

/-- `M((1/3)·1_{XXX}) = 1_{XX}`. -/
theorem pairMap_XX (X : Fin k) (ρ : Multiset (Fin k)) :
    ∑ τ ∈ blockTypes k, (mult ρ τ : ℝ) * ((1 / 3) * rind {X, X, X} τ) = rind {X, X} ρ := by
  rw [sum_mult_rind ρ (by simp), mult_XXX]
  ring

/-- `M((1/2)·1_{XXY} − (1/6)·1_{XXX}) = 1_{XY}`. -/
theorem pairMap_XY (X Y : Fin k) (ρ : Multiset (Fin k)) :
    ∑ τ ∈ blockTypes k, (mult ρ τ : ℝ) *
      ((1 / 2) * rind {X, X, Y} τ - (1 / 6) * rind {X, X, X} τ) = rind {X, Y} ρ := by
  simp only [mul_sub, Finset.sum_sub_distrib]
  rw [sum_mult_rind ρ (T := {X, X, Y}) (by simp), sum_mult_rind ρ (T := {X, X, X}) (by simp),
    mult_XXY, mult_XXX]
  ring

/-- Every `1_π` has an explicit preimage. -/
lemma exists_pre (π : Multiset (Fin k)) :
    ∃ w : Multiset (Fin k) → ℝ, Multiset.card π = 2 →
      ∀ ρ, ∑ τ ∈ blockTypes k, (mult ρ τ : ℝ) * w τ = rind π ρ := by
  by_cases h : Multiset.card π = 2
  · obtain ⟨X, Y, rfl⟩ := Multiset.card_eq_two.mp h
    by_cases hXY : X = Y
    · subst hXY
      exact ⟨fun τ => (1 / 3) * rind {X, X, X} τ, fun _ ρ => pairMap_XX X ρ⟩
    · exact ⟨fun τ => (1 / 2) * rind {X, X, Y} τ - (1 / 6) * rind {X, X, X} τ,
        fun _ ρ => pairMap_XY X Y ρ⟩
  · exact ⟨0, fun h' => absurd h' h⟩

/-- **The pair map is onto.** Every vector of pair loads is `Mw` for an explicit `w`. -/
theorem pairMap_surjective (v : Multiset (Fin k) → ℝ) :
    ∃ w : Multiset (Fin k) → ℝ, ∀ ρ ∈ pairTypes k,
      ∑ τ ∈ blockTypes k, (mult ρ τ : ℝ) * w τ = v ρ := by
  choose pre hpre using exists_pre (k := k)
  refine ⟨fun τ => ∑ π ∈ pairTypes k, v π * pre π τ, fun ρ hρ => ?_⟩
  simp only [Finset.mul_sum]
  rw [Finset.sum_comm]
  have : ∀ π ∈ pairTypes k, ∑ τ ∈ blockTypes k, (mult ρ τ : ℝ) * (v π * pre π τ) =
      v π * rind π ρ := by
    intro π hπ
    rw [← hpre π (mem_pairTypes.mp hπ) ρ, Finset.mul_sum]
    exact Finset.sum_congr rfl fun τ _ => by ring
  rw [Finset.sum_congr rfl this]
  simp [rind, mul_ite, hρ]

end ColourStats.PairMap
