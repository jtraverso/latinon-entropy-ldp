/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedGPair
public import ColourStats.TypedAggregate

/-!
# Assembly and aggregation on a graph

Adaptation of `ColourStats.TypedAssembly` and `ColourStats.TypedAggregate` to triangle
decompositions of `G`. The number of candidates at an edge `ab` depends on the edge; it is at
most the number `cnb` of common neighbours of `a` and `b` in the class of the third point,
and hence at most its maximum `mstar` over the edges of the class `π` (`candG_le_mstar`).

`typed_agg_boundG`: if all systems have the same pair statistics `M`,
`log |S| ≤ Σ_π Σ_X M(π, X) (W log(|E_π| / M(π, X)) + Ψ(m*(π, X)))`.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.TypedG

open ColourStats.TypedChain ColourStats.TypedSTS ColourStats

open Classical

variable {n L k : ℕ} {G : SimpleGraph (Fin n)} {S : Finset (Fin n → Fin n → Fin n)}

lemma det_pairsG (hS : ∀ T ∈ S, IsSQG G T) :
    ∀ T ∈ S, ∀ T' ∈ S, (∀ p ∈ pairsG G, coord p T = coord p T') → T = T' := by
  intro T hT T' hT' h
  have hTq := hS T hT
  have hT'q := hS T' hT'
  funext a b
  by_cases hab : G.Adj a b
  · rcases lt_or_gt_of_ne hab.ne with hlt | hlt
    · exact h (a, b) (Finset.mem_filter.mpr ⟨by simp [TypedSTS.pairs, hlt], hab⟩)
    · rw [← hTq.comm hab, ← hT'q.comm hab]
      exact h (b, a) (Finset.mem_filter.mpr ⟨by simp [TypedSTS.pairs, hlt], hab.symm⟩)
  · rw [hTq.2 a b hab, hT'q.2 a b hab]

/-- The edges of class `π`. -/
noncomputable def EpiG (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k) (π : Multiset (Fin k)) :
    Finset (Pair n) :=
  (pairsG G).filter fun p => ({lab p.1, lab p.2} : Multiset (Fin k)) = π

/-- The pair statistics on `G`. -/
noncomputable def MstatG (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k)
    (T : Fin n → Fin n → Fin n) (π : Multiset (Fin k)) (X : Fin k) : ℕ :=
  ((EpiG G lab π).filter fun p => lab (T p.1 p.2) = X).card

/-- The common neighbours of `a` and `b` in the class `X`. -/
noncomputable def cnb (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k) (a b : Fin n) (X : Fin k) :
    ℕ :=
  (univ.filter fun z => lab z = X ∧ G.Adj a z ∧ G.Adj b z).card

/-- The largest number of common neighbours in `X` of an edge of class `π`. -/
noncomputable def mstar (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k) (π : Multiset (Fin k))
    (X : Fin k) : ℕ :=
  (EpiG G lab π).sup fun p => cnb G lab p.1 p.2 X

lemma candG_le_mstar {lab : Fin n → Fin k} {π : Multiset (Fin k)} {p : Pair n}
    (hp : p ∈ EpiG G lab π) (T : Fin n → Fin n → Fin n) :
    (candG G lab T p.1 p.2).card ≤ mstar G lab π (lab (T p.1 p.2)) := by
  set X := lab (T p.1 p.2) with hX
  unfold mstar
  refine le_trans (Finset.card_le_card fun z hz => ?_)
    (Finset.le_sup (f := fun q : Pair n => cnb G lab q.1 q.2 X) hp)
  obtain ⟨-, h1, -, -, -, h2, h3⟩ := Finset.mem_filter.mp hz
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, h1, h2, h3⟩

theorem typed_raw_boundG (hS : ∀ T ∈ S, IsSQG G T) (lab : Fin n → Fin k) (hL : 0 < L) :
    (S.card : ℝ) * Real.log S.card ≤
      ∑ p ∈ pairsG G, ∑ r : Fin L, wr L r * ∑ T ∈ S,
        ((Real.log S.card - Real.log (Scl S lab p.1 p.2 (lab (T p.1 p.2))).card) +
          Real.log (1 + (candG G lab T p.1 p.2).card * (((L : ℝ) - r) / L) ^ 6)) := by
  have hLpos : (0 : ℝ) < L := by exact_mod_cast hL
  have hN : (0 : ℝ) < (L : ℝ) ^ (n * n) := by positivity
  -- the chain bound for each labelling
  have hchain : ∀ lam : Pair n → Fin L, (S.card : ℝ) * Real.log S.card ≤
      ∑ p ∈ pairsG G, ∑ T ∈ S,
        ((Real.log (before S (pairsG G) (key2 lam) coord p T).card -
          Real.log (sameClass S (pairsG G) (key2 lam) coord lab p T).card) +
        Real.log ((sameClass S (pairsG G) (key2 lam) coord lab p T).image (coord p)).card) := by
    intro lam
    exact chain_typed (key1 lam) (key2 lam) coord lab S (pairsG G)
      ((key1_injective lam).injOn) (det_pairsG hS)
      (fun s _ t _ h => key1_lt_of_key2_lt lam h)
  have hsum := Finset.sum_le_sum (s := (univ : Finset (Pair n → Fin L))) fun lam _ => hchain lam
  rw [Finset.sum_const, Finset.card_univ, Fintype.card_fun, Fintype.card_prod,
    Fintype.card_fin, Fintype.card_fin, nsmul_eq_mul, Finset.sum_comm] at hsum
  have hpairs : ∑ p ∈ pairsG G, ∑ lam : Pair n → Fin L, ∑ T ∈ S,
        ((Real.log (before S (pairsG G) (key2 lam) coord p T).card -
          Real.log (sameClass S (pairsG G) (key2 lam) coord lab p T).card) +
        Real.log ((sameClass S (pairsG G) (key2 lam) coord lab p T).image (coord p)).card) ≤
      ∑ p ∈ pairsG G, ∑ r : Fin L, Bv n L r * ∑ T ∈ S,
        ((Real.log S.card - Real.log (Scl S lab p.1 p.2 (lab (T p.1 p.2))).card) +
          Real.log (1 + (candG G lab T p.1 p.2).card * (((L : ℝ) - r) / L) ^ 6)) := by
    refine Finset.sum_le_sum fun p hp => ?_
    obtain ⟨a, b⟩ := p
    have hab : a < b := by simpa [TypedSTS.pairs] using (Finset.mem_filter.mp hp).1
    have hadj : G.Adj a b := (Finset.mem_filter.mp hp).2
    exact pair_boundG hS lab hab hadj hL
  have htot := hsum.trans hpairs
  simp only [Bv_eq hL, mul_assoc, ← Finset.mul_sum] at htot
  push_cast at htot
  exact le_of_mul_le_mul_left htot hN


lemma sum_pairs_by_classG (lab : Fin n → Fin k) (F : Pair n → ℝ) :
    ∑ p ∈ pairsG G, F p = ∑ π ∈ pairTypes k, ∑ p ∈ EpiG G lab π, F p := by
  refine (Finset.sum_fiberwise_of_maps_to (g := fun p : Pair n =>
    ({lab p.1, lab p.2} : Multiset (Fin k))) (fun p _ => ?_) F).symm
  rw [mem_pairTypes]
  simp

/-- Summing a function of the class of the third point. -/
lemma sum_by_thirdG (lab : Fin n → Fin k) (T : Fin n → Fin n → Fin n) (π : Multiset (Fin k))
    (Gf : Fin k → ℝ) :
    ∑ p ∈ EpiG G lab π, Gf (lab (T p.1 p.2)) = ∑ X, (MstatG G lab T π X : ℝ) * Gf X := by
  rw [← Finset.sum_fiberwise (s := EpiG G lab π) (g := fun p => lab (T p.1 p.2))]
  refine Finset.sum_congr rfl fun X _ => ?_
  rw [Finset.sum_congr rfl fun p hp => by rw [(Finset.mem_filter.mp hp).2], Finset.sum_const,
    nsmul_eq_mul]
  rfl

/-- **The class part, aggregated over the pairs of one class.** -/
theorem class_aggG (lab : Fin n → Fin k) (π : Multiset (Fin k)) (M : Fin k → ℕ)
    (hM : ∀ T ∈ S, ∀ X, MstatG G lab T π X = M X) (hne : S.Nonempty) :
    ∑ p ∈ EpiG G lab π, ∑ T ∈ S,
        (Real.log S.card - Real.log (Scl S lab p.1 p.2 (lab (T p.1 p.2))).card) ≤
      S.card * ∑ X, (M X : ℝ) * (Real.log (EpiG G lab π).card - Real.log (M X)) := by
  set U := EpiG G lab π ×ˢ S
  have h := cond_le U (fun y => y.1) (fun y => lab (y.2 y.1.1 y.1.2))
  have hS0 : (0 : ℝ) < S.card := by exact_mod_cast hne.card_pos
  have hinj : ∀ p : Pair n, Function.Injective (fun T : Fin n → Fin n → Fin n => (p, T)) :=
    fun p _ _ e => (Prod.mk.inj e).2
  have hb : ∀ y ∈ U, (U.filter fun z => z.1 = y.1) = S.image (fun T => (y.1, T)) := by
    intro y hy
    ext ⟨p, T⟩
    simp only [U, Finset.mem_filter, Finset.mem_product, Finset.mem_image, Prod.mk.injEq]
    constructor
    · rintro ⟨⟨-, hT⟩, rfl⟩
      exact ⟨T, hT, rfl, rfl⟩
    · rintro ⟨T', hT', rfl, rfl⟩
      exact ⟨⟨(Finset.mem_product.mp hy).1, hT'⟩, rfl⟩
  have hbc : ∀ y ∈ U, (U.filter fun z => z.1 = y.1 ∧
      lab (z.2 z.1.1 z.1.2) = lab (y.2 y.1.1 y.1.2)) =
      (Scl S lab y.1.1 y.1.2 (lab (y.2 y.1.1 y.1.2))).image (fun T => (y.1, T)) := by
    intro y hy
    ext ⟨p, T⟩
    simp only [U, Scl, Finset.mem_filter, Finset.mem_product, Finset.mem_image, Prod.mk.injEq]
    constructor
    · rintro ⟨⟨-, hT⟩, rfl, hc⟩
      exact ⟨T, ⟨hT, hc⟩, rfl, rfl⟩
    · rintro ⟨T', ⟨hT', hc⟩, rfl, rfl⟩
      exact ⟨⟨(Finset.mem_product.mp hy).1, hT'⟩, rfl, hc⟩
  have hc : ∀ X, ((U.filter fun z => lab (z.2 z.1.1 z.1.2) = X).card : ℝ) = S.card * M X := by
    intro X
    have : (U.filter fun z => lab (z.2 z.1.1 z.1.2) = X).card =
        ∑ T ∈ S, MstatG G lab T π X := by
      rw [Finset.card_filter, Finset.sum_product_right]
      refine Finset.sum_congr rfl fun T _ => ?_
      rw [MstatG, Finset.card_filter]
    rw [this, Finset.sum_congr rfl fun T hT => hM T hT X, Finset.sum_const, nsmul_eq_mul]
    push_cast
    ring
  have hL1 : ∀ y ∈ U, Real.log (U.filter fun z => z.1 = y.1).card -
      Real.log (U.filter fun z => z.1 = y.1 ∧
        lab (z.2 z.1.1 z.1.2) = lab (y.2 y.1.1 y.1.2)).card =
      Real.log S.card - Real.log (Scl S lab y.1.1 y.1.2 (lab (y.2 y.1.1 y.1.2))).card := by
    intro y hy
    rw [hb y hy, hbc y hy, Finset.card_image_of_injective _ (hinj y.1),
      Finset.card_image_of_injective _ (hinj y.1)]
  have hR1 : ∀ y ∈ U, Real.log U.card - Real.log (U.filter fun z =>
      lab (z.2 z.1.1 z.1.2) = lab (y.2 y.1.1 y.1.2)).card =
      Real.log (EpiG G lab π).card - Real.log (M (lab (y.2 y.1.1 y.1.2))) := by
    intro y hy
    obtain ⟨hp, hT⟩ := Finset.mem_product.mp hy
    have hE0 : (0 : ℝ) < (EpiG G lab π).card := by exact_mod_cast Finset.card_pos.mpr ⟨_, hp⟩
    have hmem : y.1 ∈ (EpiG G lab π).filter (fun p => lab (y.2 p.1 p.2) = lab (y.2 y.1.1 y.1.2)) :=
      Finset.mem_filter.mpr ⟨hp, rfl⟩
    have hMs : 0 < MstatG G lab y.2 π (lab (y.2 y.1.1 y.1.2)) := Finset.card_pos.mpr ⟨_, hmem⟩
    have hM0 : (0 : ℝ) < M (lab (y.2 y.1.1 y.1.2)) := by
      rw [← hM y.2 hT]
      exact_mod_cast hMs
    rw [hc, Finset.card_product, Nat.cast_mul, Real.log_mul hE0.ne' hS0.ne',
      Real.log_mul hS0.ne' hM0.ne']
    ring
  rw [Finset.sum_congr rfl hL1, Finset.sum_congr rfl hR1] at h
  rw [← Finset.sum_product (s := EpiG G lab π) (t := S)
    (f := fun y => Real.log S.card - Real.log (Scl S lab y.1.1 y.1.2 (lab (y.2 y.1.1 y.1.2))).card)]
  refine h.trans (le_of_eq ?_)
  rw [Finset.sum_product_right]
  rw [Finset.sum_congr rfl fun T hT => sum_by_thirdG lab T π
    (fun X => Real.log (EpiG G lab π).card - Real.log (M X))]
  rw [Finset.sum_congr rfl fun T hT => Finset.sum_congr rfl fun X _ => by rw [hM T hT X],
    Finset.sum_const, nsmul_eq_mul]

/-- **The aggregated typed bound.** -/
theorem typed_agg_boundG (hS : ∀ T ∈ S, IsSQG G T) (hne : S.Nonempty) (lab : Fin n → Fin k)
    (hL : 0 < L) (M : Multiset (Fin k) → Fin k → ℕ)
    (hM : ∀ T ∈ S, ∀ π X, MstatG G lab T π X = M π X) :
    Real.log S.card ≤ ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) *
      (Wsum L * (Real.log (EpiG G lab π).card - Real.log (M π X)) + Psi L (mstar G lab π X)) := by
  have hS0 : (0 : ℝ) < S.card := by exact_mod_cast hne.card_pos
  have h0 := typed_raw_boundG (L := L) hS lab hL
  -- rearrange the raw bound
  have hre : ∀ p ∈ pairsG G, ∑ r : Fin L, wr L r * ∑ T ∈ S,
      ((Real.log S.card - Real.log (Scl S lab p.1 p.2 (lab (T p.1 p.2))).card) +
        Real.log (1 + (candG G lab T p.1 p.2).card * (((L : ℝ) - r) / L) ^ 6)) =
      Wsum L * ∑ T ∈ S, (Real.log S.card - Real.log (Scl S lab p.1 p.2 (lab (T p.1 p.2))).card) +
        ∑ T ∈ S, Psi L (candG G lab T p.1 p.2).card := by
    intro p _
    have hc : ∑ T ∈ S, ∑ r : Fin L, wr L r * Real.log (1 + ((candG G lab T p.1 p.2).card : ℝ) *
        (((L : ℝ) - r) / L) ^ 6) = ∑ r : Fin L, ∑ T ∈ S, wr L r *
        Real.log (1 + ((candG G lab T p.1 p.2).card : ℝ) * (((L : ℝ) - r) / L) ^ 6) :=
      Finset.sum_comm
    unfold Wsum Psi
    rw [Finset.sum_mul, hc, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun r _ => ?_
    rw [Finset.sum_add_distrib, mul_add]
    simp only [Finset.mul_sum]
  rw [Finset.sum_congr rfl hre, Finset.sum_add_distrib, ← Finset.mul_sum] at h0
  -- the class part
  have hW : 0 ≤ Wsum L := Finset.sum_nonneg fun r _ => wr_nonneg L r
  have hA : ∑ p ∈ pairsG G, ∑ T ∈ S,
      (Real.log S.card - Real.log (Scl S lab p.1 p.2 (lab (T p.1 p.2))).card) ≤
      S.card * ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) *
        (Real.log (EpiG G lab π).card - Real.log (M π X)) := by
    rw [sum_pairs_by_classG lab, Finset.mul_sum]
    exact Finset.sum_le_sum fun π _ => class_aggG lab π (M π) (fun T hT X => hM T hT π X) hne
  -- the point part
  have hB : ∑ p ∈ pairsG G, ∑ T ∈ S, Psi L (candG G lab T p.1 p.2).card ≤
      S.card * ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) * Psi L (mstar G lab π X) := by
    rw [sum_pairs_by_classG lab, Finset.mul_sum]
    refine Finset.sum_le_sum fun π _ => ?_
    have h1 : ∀ p ∈ EpiG G lab π, ∀ T ∈ S, Psi L (candG G lab T p.1 p.2).card ≤
        Psi L (mstar G lab π (lab (T p.1 p.2))) := by
      intro p hp T _
      refine Psi_mono L (Nat.cast_nonneg _) ?_
      exact_mod_cast candG_le_mstar hp T
    refine (Finset.sum_le_sum fun p hp => Finset.sum_le_sum fun T hT => h1 p hp T hT).trans
      (le_of_eq ?_)
    rw [Finset.sum_comm]
    rw [Finset.sum_congr rfl fun T hT => sum_by_thirdG lab T π
      (fun X => Psi L (mstar G lab π X))]
    rw [Finset.sum_congr rfl fun T hT => Finset.sum_congr rfl fun X _ => by rw [hM T hT π X],
      Finset.sum_const, nsmul_eq_mul]
  have htot : (S.card : ℝ) * Real.log S.card ≤ S.card * ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) *
      (Wsum L * (Real.log (EpiG G lab π).card - Real.log (M π X)) + Psi L (mstar G lab π X)) := by
    have hWA := mul_le_mul_of_nonneg_left hA hW
    have : (S.card : ℝ) * ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) *
        (Wsum L * (Real.log (EpiG G lab π).card - Real.log (M π X)) + Psi L (mstar G lab π X)) =
        Wsum L * (S.card * ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) *
          (Real.log (EpiG G lab π).card - Real.log (M π X))) +
        S.card * ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) * Psi L (mstar G lab π X) := by
      simp only [mul_add, Finset.sum_add_distrib, Finset.mul_sum]
      congr 1
      refine Finset.sum_congr rfl fun π _ => Finset.sum_congr rfl fun X _ => ?_
      ring
    rw [this]
    linarith
  exact le_of_mul_le_mul_left htot hS0

end ColourStats.TypedG
