/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Typed1FAgg
public import ColourStats.TypedThm

/-!
# The upper half of Theorem 1.7

**Theorem** (`typed_upper_1F`). If every colour class has at least `h₁ + 1` colours
(`h₁ ≥ 1`) and some 1-factorization of `K_n` has type vector `t`, then

  `log N^{1F}_t ≤ Φ(t) + n² ((log n + 4)/n + 7 / h₁^{1/4})`.

`theorem_1_7_upper_exp`: for every `δ₀, ε > 0` there is `n₀` such that for `n ≥ n₀`, colour
classes of size at least `δ₀ n` and every type vector `t`,
`N^{1F}_t ≤ exp(Φ(t) + ε n²)`. Neither the vertex classes nor the identities (1.5) are used.

The proof follows the one for Steiner triple systems: chain rule over random labels with
`L = n`, concavity over the edges of each class (`TypedChain.cond_le`), and
`Ψ₁(c) ≤ log c − 2 + (log c + 4)/L + 7/c^{1/4}` from the corpus sum–integral comparison
(`term1F_le`). The statistics are the type vector itself, and each term gives
`t (log(e_π (h_Γ − 1)/t) − 2) ≤ t (log(e_π h_Γ / t) − 2)`.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.Typed1F

open ColourStats ColourStats.Statements ColourStats.TypedChain ColourStats.TypedSTS

open Classical

variable {n L k ℓ : ℕ} {S : Finset (KEdge n → Fin (n - 1))}

/-! ### Analysis -/

/-- `Ψ₁(c) = Σ_r (1/L) log(1 + c u_r²)`. -/
noncomputable def Psi1 (L : ℕ) (c : ℝ) : ℝ :=
  ∑ r : Fin L, (1 / (L : ℝ)) * Real.log (1 + c * (((L : ℝ) - r) / L) ^ 2)

lemma Psi1_le (hL : 1 ≤ L) {c : ℝ} (hc : 0 ≤ c) : Psi1 L c ≤ 2 * wsum 1 L (Real.sqrt c) := by
  have hLpos : (0 : ℝ) < L := by exact_mod_cast hL
  unfold Psi1 wsum
  rw [Fin.sum_univ_eq_sum_range (fun j : ℕ => (1 / (L : ℝ)) *
    Real.log (1 + c * (((L : ℝ) - j) / L) ^ 2)) L, ← Finset.sum_range_reflect, Finset.mul_sum]
  refine Finset.sum_le_sum fun j hj => ?_
  rw [reflect_cast hj]
  norm_num
  set y : ℝ := ((j : ℝ) + 1) / L with hy
  have hy0 : 0 ≤ y := by positivity
  have hsq : 1 + c * y ^ 2 ≤ (1 + Real.sqrt c * y) ^ 2 := by
    have hs := Real.sq_sqrt hc
    nlinarith [Real.sqrt_nonneg c]
  have hlog : Real.log (1 + c * y ^ 2) ≤ 2 * Real.log (1 + Real.sqrt c * y) := by
    rw [← Real.log_rpow (by positivity)]
    apply Real.log_le_log (by positivity)
    rw [show (1 + Real.sqrt c * y) ^ (2 : ℝ) = (1 + Real.sqrt c * y) ^ 2 by norm_cast]
    exact hsq
  have hw : (0 : ℝ) ≤ (L : ℝ)⁻¹ := by positivity
  calc (L : ℝ)⁻¹ * Real.log (1 + c * y ^ 2) ≤ (L : ℝ)⁻¹ * (2 * Real.log (1 + Real.sqrt c * y)) :=
        mul_le_mul_of_nonneg_left hlog hw
    _ = 2 * ((L : ℝ)⁻¹ * Real.log (1 + Real.sqrt c * y)) := by ring

/-- **The per-unit estimate for 1-factorizations.** -/
theorem term1F_le (hL : 1 ≤ L) {c x : ℝ} (hc : 1 ≤ c) (hx : 1 ≤ x) :
    Real.log x + Psi1 L c ≤ Real.log x + Real.log c - 2 +
      ((Real.log c + 4) / L + 7 / Real.sqrt (Real.sqrt c)) := by
  have hL1 : (1 : ℝ) ≤ L := by exact_mod_cast hL
  have hLpos : (0 : ℝ) < L := by linarith
  have hlc : 0 ≤ Real.log c := Real.log_nonneg hc
  set q := Real.sqrt c with hq
  set q2 := Real.sqrt q with hq2
  have hq1 : 1 ≤ q := Real.one_le_sqrt.mpr hc
  have hq21 : 1 ≤ q2 := Real.one_le_sqrt.mpr hq1
  have hqq : q2 * q2 = q := Real.mul_self_sqrt (by linarith)
  have hq2le : q2 ≤ q := by nlinarith
  have hinv : 1 / q ≤ 1 / q2 := one_div_le_one_div_of_le (by linarith) hq2le
  have hlogq : Real.log q = (1 / 2) * Real.log c := by
    rw [hq, Real.log_sqrt (by linarith)]
    ring
  set s : ℝ := ((L : ℝ) + 1) / L with hs
  have hs1 : 1 ≤ s := by rw [hs, le_div_iff₀ hLpos]; linarith
  have hsm : s = 1 + 1 / L := by rw [hs]; field_simp
  have hLinv : 1 / (L : ℝ) ≤ 1 := by rw [div_le_one hLpos]; exact hL1
  have hLinv0 : 0 ≤ 1 / (L : ℝ) := by positivity
  have hs2 : s ≤ 2 := by linarith
  have hlogs : Real.log s ≤ 1 / L := by
    have := Real.log_le_sub_one_of_pos (by linarith : (0 : ℝ) < s)
    linarith
  -- `log(1 + q s) ≤ (1/2) log c + 1/L + 1/q`
  have hA : Real.log (1 + q * s) ≤ (1 / 2) * Real.log c + 1 / L + 1 / q := by
    have hqs : 1 ≤ q * s := by nlinarith
    have hpos : 0 < q * s := by linarith
    have hsplit : 1 + q * s = (q * s) * (1 + 1 / (q * s)) := by
      rw [mul_add, mul_one, mul_one_div_cancel hpos.ne']
      ring
    rw [hsplit, Real.log_mul hpos.ne' (by positivity), Real.log_mul (by linarith) (by linarith),
      hlogq]
    have h1 : Real.log (1 + 1 / (q * s)) ≤ 1 / (q * s) := by
      have := Real.log_le_sub_one_of_pos (by positivity : (0 : ℝ) < 1 + 1 / (q * s))
      linarith
    have h2 : 1 / (q * s) ≤ 1 / q := one_div_le_one_div_of_le (by linarith) (by nlinarith)
    linarith
  have hwl := weighted_log_sum_le 1 L (le_refl 1) hL q (by linarith)
  have hP : Psi1 L c ≤ 2 * (s * (Real.log (1 + q * s) - 1) + Real.sqrt (s / q)) := by
    have h := Psi1_le hL (by linarith : (0 : ℝ) ≤ c)
    unfold wsum at h
    norm_num at h hwl
    try rw [← hq] at h
    have : (((L : ℝ) + 1) / L) = s := rfl
    rw [this] at hwl
    linarith
  have hsqrt : Real.sqrt (s / q) ≤ (3 / 2) / q2 := by
    have h8 : s / q ≤ 2 / q := div_le_div_of_nonneg_right hs2 (by linarith)
    have h9 : (2 : ℝ) / q ≤ ((3 / 2) / q2) ^ 2 := by
      rw [div_pow, ← hqq, div_le_div_iff₀ (by linarith) (by positivity)]
      nlinarith
    calc Real.sqrt (s / q) ≤ Real.sqrt (((3 / 2) / q2) ^ 2) := Real.sqrt_le_sqrt (h8.trans h9)
      _ = (3 / 2) / q2 := Real.sqrt_sq (by positivity)
  have hA0 : 0 ≤ (1 / 2) * Real.log c + 1 / L + 1 / q := by positivity
  have hmain : 2 * (s * (Real.log (1 + q * s) - 1)) ≤
      2 * (1 + 1 / L) * ((1 / 2) * Real.log c + 1 / L + 1 / q) - 2 := by
    have e1 := mul_le_mul_of_nonneg_left (sub_le_sub_right hA 1) (by linarith : (0 : ℝ) ≤ s)
    have e3 := mul_le_mul_of_nonneg_right (le_of_eq hsm) hA0
    nlinarith
  have hfin : 2 * (1 + 1 / L) * ((1 / 2) * Real.log c + 1 / L + 1 / q) ≤
      Real.log c + Real.log c / L + 4 / L + 4 * (1 / q) := by
    have i1 : (1 / (L : ℝ)) * (1 / L) ≤ 1 / L := mul_le_of_le_one_left hLinv0 hLinv
    have i2 : (1 / (L : ℝ)) * (1 / q) ≤ 1 / q := mul_le_of_le_one_left (by positivity) hLinv
    have e : 2 * (1 + 1 / (L : ℝ)) * ((1 / 2) * Real.log c + 1 / L + 1 / q) =
        Real.log c + Real.log c * (1 / L) + 2 * (1 / L) + 2 * ((1 / L) * (1 / L)) +
          2 * (1 / q) + 2 * ((1 / L) * (1 / q)) := by ring
    have e2 : Real.log c / L = Real.log c * (1 / L) := by ring
    have e3 : (4 : ℝ) / L = 4 * (1 / L) := by ring
    rw [e, e2, e3]
    linarith
  have hgoal : (Real.log c + 4) / L = Real.log c / L + 4 / L := by ring
  have hq7 : 4 * (1 / q) + 2 * ((3 / 2) / q2) ≤ 7 / q2 := by
    have hq2p : 0 < 1 / q2 := by positivity
    have e : 4 * (1 / q2) + 2 * ((3 / 2) / q2) = 7 * (1 / q2) := by ring
    have e2 : (7 : ℝ) / q2 = 7 * (1 / q2) := by ring
    linarith
  rw [hgoal]
  linarith

/-! ### Aggregation -/

/-- The edges of class `π`. -/
def Epi1 (lab : Fin n → Fin k) (π : Multiset (Fin k)) : Finset (KEdge n) :=
  univ.filter fun e => edgeClass lab e = π

lemma edgeClass_mem (lab : Fin n → Fin k) (e : KEdge n) : edgeClass lab e ∈ pairTypes k := by
  rw [mem_pairTypes, edgeClass, Sym2.card_toMultiset]

lemma sum_edges_by_class (lab : Fin n → Fin k) (F : KEdge n → ℝ) :
    ∑ e : KEdge n, F e = ∑ π ∈ pairTypes k, ∑ e ∈ Epi1 lab π, F e :=
  (Finset.sum_fiberwise_of_maps_to (g := edgeClass lab) (fun e _ => edgeClass_mem lab e) F).symm

lemma sum_by_colour (col : Fin (n - 1) → Fin ℓ) (lab : Fin n → Fin k)
    (f : KEdge n → Fin (n - 1)) (π : Multiset (Fin k)) (G : Fin ℓ → ℝ) :
    ∑ e ∈ Epi1 lab π, G (col (f e)) = ∑ Γ, (edgeTypeCount lab col f π Γ : ℝ) * G Γ := by
  rw [← Finset.sum_fiberwise (s := Epi1 lab π) (g := fun e => col (f e))]
  refine Finset.sum_congr rfl fun Γ _ => ?_
  rw [Finset.sum_congr rfl fun e he => by rw [(Finset.mem_filter.mp he).2], Finset.sum_const,
    nsmul_eq_mul]
  congr 2
  unfold edgeTypeCount Epi1
  rw [Finset.filter_filter]

/-- **Concavity over the edges of one class.** -/
theorem class_agg (col : Fin (n - 1) → Fin ℓ) (lab : Fin n → Fin k) (π : Multiset (Fin k))
    (M : Fin ℓ → ℕ) (hM : ∀ f ∈ S, ∀ Γ, edgeTypeCount lab col f π Γ = M Γ) (hne : S.Nonempty) :
    ∑ e ∈ Epi1 lab π, ∑ f ∈ S,
        (Real.log S.card - Real.log (Scl S col e (col (f e))).card) ≤
      S.card * ∑ Γ, (M Γ : ℝ) * (Real.log (Epi1 lab π).card - Real.log (M Γ)) := by
  set U := Epi1 lab π ×ˢ S
  have h := cond_le U (fun y => y.1) (fun y => col (y.2 y.1))
  have hS0 : (0 : ℝ) < S.card := by exact_mod_cast hne.card_pos
  have hinj : ∀ e : KEdge n, Function.Injective (fun f : KEdge n → Fin (n - 1) => (e, f)) :=
    fun e _ _ h => (Prod.mk.inj h).2
  have hb : ∀ y ∈ U, (U.filter fun z => z.1 = y.1) = S.image (fun f => (y.1, f)) := by
    intro y hy
    ext ⟨e, f⟩
    simp only [U, Finset.mem_filter, Finset.mem_product, Finset.mem_image, Prod.mk.injEq]
    constructor
    · rintro ⟨⟨-, hf⟩, rfl⟩
      exact ⟨f, hf, rfl, rfl⟩
    · rintro ⟨f', hf', rfl, rfl⟩
      exact ⟨⟨(Finset.mem_product.mp hy).1, hf'⟩, rfl⟩
  have hbc : ∀ y ∈ U, (U.filter fun z => z.1 = y.1 ∧ col (z.2 z.1) = col (y.2 y.1)) =
      (Scl S col y.1 (col (y.2 y.1))).image (fun f => (y.1, f)) := by
    intro y hy
    ext ⟨e, f⟩
    simp only [U, Scl, Finset.mem_filter, Finset.mem_product, Finset.mem_image, Prod.mk.injEq]
    constructor
    · rintro ⟨⟨-, hf⟩, rfl, hc⟩
      exact ⟨f, ⟨hf, hc⟩, rfl, rfl⟩
    · rintro ⟨f', ⟨hf', hc⟩, rfl, rfl⟩
      exact ⟨⟨(Finset.mem_product.mp hy).1, hf'⟩, rfl, hc⟩
  have hc : ∀ Γ, ((U.filter fun z => col (z.2 z.1) = Γ).card : ℝ) = S.card * M Γ := by
    intro Γ
    have : (U.filter fun z => col (z.2 z.1) = Γ).card = ∑ f ∈ S, edgeTypeCount lab col f π Γ := by
      rw [Finset.card_filter, Finset.sum_product_right]
      refine Finset.sum_congr rfl fun f _ => ?_
      unfold edgeTypeCount Epi1
      rw [Finset.card_filter, Finset.sum_filter]
      refine Finset.sum_congr rfl fun e _ => ?_
      by_cases h1 : edgeClass lab e = π <;> by_cases h2 : col (f e) = Γ <;> simp [h1, h2]
    rw [this, Finset.sum_congr rfl fun f hf => hM f hf Γ, Finset.sum_const, nsmul_eq_mul]
    push_cast
    ring
  have hL1 : ∀ y ∈ U, Real.log (U.filter fun z => z.1 = y.1).card -
      Real.log (U.filter fun z => z.1 = y.1 ∧ col (z.2 z.1) = col (y.2 y.1)).card =
      Real.log S.card - Real.log (Scl S col y.1 (col (y.2 y.1))).card := by
    intro y hy
    rw [hb y hy, hbc y hy, Finset.card_image_of_injective _ (hinj y.1),
      Finset.card_image_of_injective _ (hinj y.1)]
  have hR1 : ∀ y ∈ U, Real.log U.card - Real.log (U.filter fun z =>
      col (z.2 z.1) = col (y.2 y.1)).card =
      Real.log (Epi1 lab π).card - Real.log (M (col (y.2 y.1))) := by
    intro y hy
    obtain ⟨he, hf⟩ := Finset.mem_product.mp hy
    have hE0 : (0 : ℝ) < (Epi1 lab π).card := by exact_mod_cast Finset.card_pos.mpr ⟨_, he⟩
    have hmem : y.1 ∈ (Epi1 lab π).filter (fun e => col (y.2 e) = col (y.2 y.1)) :=
      Finset.mem_filter.mpr ⟨he, rfl⟩
    have hMs : 0 < edgeTypeCount lab col y.2 π (col (y.2 y.1)) := by
      unfold edgeTypeCount
      refine Finset.card_pos.mpr ⟨y.1, ?_⟩
      simpa using (Finset.mem_filter.mp he).2
    have hM0 : (0 : ℝ) < M (col (y.2 y.1)) := by
      rw [← hM y.2 hf]
      exact_mod_cast hMs
    rw [hc, Finset.card_product, Nat.cast_mul, Real.log_mul hE0.ne' hS0.ne',
      Real.log_mul hS0.ne' hM0.ne']
    ring
  rw [Finset.sum_congr rfl hL1, Finset.sum_congr rfl hR1] at h
  rw [← Finset.sum_product (s := Epi1 lab π) (t := S)
    (f := fun y => Real.log S.card - Real.log (Scl S col y.1 (col (y.2 y.1))).card)]
  refine h.trans (le_of_eq ?_)
  rw [Finset.sum_product_right]
  rw [Finset.sum_congr rfl fun f hf => sum_by_colour col lab f π
    (fun Γ => Real.log (Epi1 lab π).card - Real.log (M Γ))]
  rw [Finset.sum_congr rfl fun f hf => Finset.sum_congr rfl fun Γ _ => by rw [hM f hf Γ],
    Finset.sum_const, nsmul_eq_mul]

end ColourStats.Typed1F
