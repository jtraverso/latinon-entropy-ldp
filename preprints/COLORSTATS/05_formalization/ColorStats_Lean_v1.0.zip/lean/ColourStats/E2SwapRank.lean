/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.E2Swap
public import ColourStats.PaschRank

/-!
# Rank of the pair-preserving lattice of 1-factorizations (Lemma 5.18)

Complements to `ColourStats.E2Swap`. `Lam2 k ℓ` is the lattice `Λ` of pair-preserving
changes of type counts, as a submodule of the functions on (pair class, colour class).
For a class `o` and a colour class `ω`, the coordinates `d(π, Γ)` with `π ∌ o` and `Γ ≠ ω`
identify `Λ` with `ℤ^{C(k,2)(ℓ−1)}` (`lam2Equiv`), so `rank Λ = C(k, 2)(ℓ − 1)`
(`finrank_Lam2`). The basis swaps with `Γ = ω` are zero (`basisVec_self`), so the basis of
`inLambda_repr` has exactly `C(k, 2)(ℓ − 1)` nonzero members.
-/

@[expose] public section

open Finset

namespace ColourStats.E2Swap

open ColourStats

variable {k ℓ : ℕ}

/-- The basis swap with `Γ = ω` is zero. -/
lemma basisVec_self (o : Fin k) (ω : Fin ℓ) (π : Multiset (Fin k)) :
    basisVec o ω π ω = 0 := by
  funext ρ Δ
  unfold basisVec
  split_ifs <;> simp [swapVec]

/-- The pair classes avoiding `o`. -/
def pairAvoid (o : Fin k) : Finset (Multiset (Fin k)) := (pairTypes k).filter (fun π => o ∉ π)

/-- The coordinate set: pair classes avoiding `o` and colour classes other than `ω`. -/
abbrev Idx (o : Fin k) (ω : Fin ℓ) := pairAvoid o × {Γ : Fin ℓ // Γ ≠ ω}

lemma card_Idx (o : Fin k) (ω : Fin ℓ) : Fintype.card (Idx o ω) = k.choose 2 * (ℓ - 1) := by
  rw [Fintype.card_prod, Fintype.card_coe, card_ne, pairAvoid, card_pairAvoid]

/-- The pair-preserving lattice `Λ` of 1-factorizations. -/
def Lam2 (k ℓ : ℕ) : Submodule ℤ (pairTypes k → Fin ℓ → ℤ) where
  carrier := {d | (∀ π : pairTypes k, ∑ Γ, d π Γ = 0) ∧
    ∀ X Γ, ∑ π : pairTypes k, ((π : Multiset (Fin k)).count X : ℤ) * d π Γ = 0}
  add_mem' := by
    intro d e hd he
    refine ⟨fun π => ?_, fun X Γ => ?_⟩
    · simp only [Pi.add_apply, Finset.sum_add_distrib, hd.1 π, he.1 π, add_zero]
    · simp only [Pi.add_apply, mul_add, Finset.sum_add_distrib, hd.2 X Γ, he.2 X Γ, add_zero]
  zero_mem' := ⟨fun _ => by simp, fun _ _ => by simp⟩
  smul_mem' := by
    intro c d hd
    refine ⟨fun π => ?_, fun X Γ => ?_⟩
    · simp only [Pi.smul_apply, smul_eq_mul, ← Finset.mul_sum, hd.1 π, mul_zero]
    · simp only [Pi.smul_apply, smul_eq_mul]
      rw [show ∑ π : pairTypes k, ((π : Multiset (Fin k)).count X : ℤ) * (c * d π Γ) =
          c * ∑ π : pairTypes k, ((π : Multiset (Fin k)).count X : ℤ) * d π Γ by
        rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun π _ => by ring, hd.2 X Γ, mul_zero]

/-- Extension by zero. -/
noncomputable def extend2 (d : pairTypes k → Fin ℓ → ℤ) (π : Multiset (Fin k)) (Γ : Fin ℓ) :
    ℤ :=
  if h : π ∈ pairTypes k then d ⟨π, h⟩ Γ else 0

lemma extend2_coe (d : pairTypes k → Fin ℓ → ℤ) (π : pairTypes k) (Γ : Fin ℓ) :
    extend2 d π Γ = d π Γ := by
  simp [extend2, π.2]

lemma inLambda_extend2 {d : pairTypes k → Fin ℓ → ℤ} (hd : d ∈ Lam2 k ℓ) :
    InLambda (extend2 d) := by
  refine ⟨fun π hπ => ?_, fun X Γ => ?_⟩
  · simpa [extend2, hπ] using hd.1 ⟨π, hπ⟩
  · rw [← Finset.sum_coe_sort]
    simpa [extend2_coe] using hd.2 X Γ

/-- The coordinates of `Λ`. -/
noncomputable def lam2Coord (o : Fin k) (ω : Fin ℓ) : Lam2 k ℓ →ₗ[ℤ] (Idx o ω → ℤ) where
  toFun d i := d.1 ⟨i.1.1, (Finset.mem_filter.mp i.1.2).1⟩ i.2.1
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

lemma lam2Coord_injective (o : Fin k) (ω : Fin ℓ) : Function.Injective (lam2Coord o ω) := by
  rw [← LinearMap.ker_eq_bot, LinearMap.ker_eq_bot']
  intro d hd
  have he := inLambda_extend2 d.2
  have hne : ∀ π (hπ : π ∈ pairTypes k), o ∉ π → ∀ Γ, Γ ≠ ω → extend2 d.1 π Γ = 0 := by
    intro π hπ hoπ Γ hΓ
    have := congrFun hd ⟨⟨π, Finset.mem_filter.mpr ⟨hπ, hoπ⟩⟩, ⟨Γ, hΓ⟩⟩
    simpa [lam2Coord, extend2, hπ] using this
  have h0 : ∀ π ∈ pairTypes k, o ∉ π → ∀ Γ, extend2 d.1 π Γ = 0 := by
    intro π hπ hoπ Γ
    by_cases hΓ : Γ = ω
    · subst hΓ
      have hs := he.1 π hπ
      rwa [Finset.sum_eq_single Γ (fun Δ _ hΔ => hne π hπ hoπ Δ hΔ) (by simp)] at hs
    · exact hne π hπ hoπ Γ hΓ
  have hz := inLambda_unique he o h0
  ext π Γ
  simpa [extend2_coe] using hz π π.2 Γ

/-- The element of `Λ` with prescribed coordinates. -/
noncomputable def lam2Of (o : Fin k) (ω : Fin ℓ) (c : Idx o ω → ℤ) : pairTypes k → Fin ℓ → ℤ :=
  fun π Δ => ∑ i : Idx o ω, c i * basisVec o ω i.1 i.2 π Δ

lemma lam2Of_mem (o : Fin k) (ω : Fin ℓ) (c : Idx o ω → ℤ) : lam2Of o ω c ∈ Lam2 k ℓ := by
  refine ⟨fun π => ?_, fun X Δ => ?_⟩
  · simp only [lam2Of]
    rw [Finset.sum_comm]
    refine Finset.sum_eq_zero fun i _ => ?_
    rw [← Finset.mul_sum, (basisVec_inLambda o ω i.1 i.2).1 π π.2, mul_zero]
  · simp only [lam2Of, Finset.mul_sum]
    rw [Finset.sum_comm]
    refine Finset.sum_eq_zero fun i _ => ?_
    have h := (basisVec_inLambda o ω i.1 i.2).2 X Δ
    rw [← Finset.sum_coe_sort] at h
    rw [show ∑ π : pairTypes k, ((π : Multiset (Fin k)).count X : ℤ) *
          (c i * basisVec o ω i.1 i.2 π Δ) =
        c i * ∑ π : pairTypes k, ((π : Multiset (Fin k)).count X : ℤ) *
          basisVec o ω i.1 i.2 π Δ by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun π _ => by ring, h, mul_zero]

lemma lam2Coord_lam2Of (o : Fin k) (ω : Fin ℓ) (c : Idx o ω → ℤ) :
    lam2Coord o ω ⟨lam2Of o ω c, lam2Of_mem o ω c⟩ = c := by
  funext j
  obtain ⟨⟨ρ, hρA⟩, ⟨Δ, hΔ⟩⟩ := j
  have hρ := (Finset.mem_filter.mp hρA).1
  have hoρ := (Finset.mem_filter.mp hρA).2
  simp only [lam2Coord, LinearMap.coe_mk, AddHom.coe_mk, lam2Of]
  have happ : ∀ i : Idx o ω, basisVec o ω i.1 i.2 ρ Δ =
      if i = (⟨⟨ρ, hρA⟩, ⟨Δ, hΔ⟩⟩ : Idx o ω) then 1 else 0 := by
    intro i
    rw [basisVec_apply o ω (Finset.mem_filter.mp i.1.2).1 hρ hoρ, if_neg hΔ]
    simp only [ind, sub_zero]
    by_cases hi : i = (⟨⟨ρ, hρA⟩, ⟨Δ, hΔ⟩⟩ : Idx o ω)
    · subst hi
      simp
    · rw [if_neg hi]
      have hnot : ¬ (ρ = (i.1 : Multiset (Fin k)) ∧ Δ = (i.2 : Fin ℓ)) := by
        rintro ⟨h1, h2⟩
        apply hi
        obtain ⟨⟨a, ha⟩, ⟨b, hb⟩⟩ := i
        simp only at h1 h2
        subst h1
        subst h2
        rfl
      by_cases h1 : ρ = (i.1 : Multiset (Fin k))
      · rw [if_pos h1, if_neg (fun h2 => hnot ⟨h1, h2⟩)]
        simp
      · rw [if_neg h1]
        simp
  simp only [happ, mul_ite, mul_one, mul_zero]
  rw [Finset.sum_ite_eq']
  simp

/-- `Λ ≅ ℤ^{C(k,2)(ℓ−1)}`. -/
noncomputable def lam2Equiv (o : Fin k) (ω : Fin ℓ) : Lam2 k ℓ ≃ₗ[ℤ] (Idx o ω → ℤ) :=
  LinearEquiv.ofBijective (lam2Coord o ω)
    ⟨lam2Coord_injective o ω, fun c => ⟨⟨lam2Of o ω c, lam2Of_mem o ω c⟩,
      lam2Coord_lam2Of o ω c⟩⟩

/-- **Rank of the pair-preserving lattice of 1-factorizations.**
`rank Λ = C(k, 2)(ℓ − 1)` for `k, ℓ ≥ 1`. -/
theorem finrank_Lam2 (hk : 1 ≤ k) (hℓ : 1 ≤ ℓ) :
    Module.finrank ℤ (Lam2 k ℓ) = k.choose 2 * (ℓ - 1) := by
  let o : Fin k := ⟨0, hk⟩
  let ω : Fin ℓ := ⟨0, hℓ⟩
  rw [(lam2Equiv o ω).finrank_eq, Module.finrank_fintype_fun_eq_card, card_Idx]

end ColourStats.E2Swap
