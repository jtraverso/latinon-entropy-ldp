/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedSTS
public import CountingCone.LL.Analysis

/-!
# Label boxes and the point part (Section 4.2, Steps 2, 3 and 5)

Fix a pair `p = (a, b)` with `a < b` and a Steiner quasigroup `T` with `c = T a b`. The labels
with `lam p = r` and no pair of the block of `p` below `r` form a box (`box`); its size does
not depend on `T` (`card_box`). On this box, the number of values still possible at `p` is
at most `1 + X`, where `X` counts the points `z` of the class of `c` whose two blocks
`{a, z, ·}` and `{b, z, ·}` have all six pairs with labels `≥ r` (`aval_le`). The nine pairs
involved are distinct, so the average of `X` over the box is at most
`m · ((L − r)/L)^6` (`sum_X_le`), and Jensen's inequality gives the point part
(`point_sum_le`):

  `Σ_lam log a(lam) ≤ Σ_r |box_r| log(1 + m ((L − r)/L)^6)`.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.TypedSTS

open ColourStats.TypedChain

variable {n L k : ℕ}

/-- The constraint sets: `{r}` at `p` and `[r, L)` elsewhere. -/
def Acon (p : Pair n) (r : Fin L) (q : Pair n) : Finset (Fin L) :=
  if q = p then {r} else Finset.Ici r

lemma prod_Acon {D : Finset (Pair n)} {p : Pair n} (hp : p ∈ D) (r : Fin L) :
    ∏ q ∈ D, (Acon p r q).card = (L - r) ^ (D.card - 1) := by
  rw [← Finset.mul_prod_erase D _ hp]
  rw [Finset.prod_congr rfl (fun q hq => by
    rw [Acon, if_neg (Finset.ne_of_mem_erase hq)])]
  rw [Finset.prod_const, Fin.card_Ici, Finset.card_erase_of_mem hp]
  simp [Acon]

/-- Box counting in real form: `|box| = L^{N} (L − r)^{|D| − 1} / L^{|D|}`. -/
lemma card_boxF_real (D : Finset (Pair n)) {p : Pair n} (hp : p ∈ D) (r : Fin L) (hL : 0 < L) :
    ((boxF D (Acon p r)).card : ℝ) =
      (L : ℝ) ^ (n * n) * ((L : ℝ) - r) ^ (D.card - 1) / (L : ℝ) ^ D.card := by
  have h := card_boxF D (Acon p r)
  rw [prod_Acon hp, Fintype.card_fin, Fintype.card_prod, Fintype.card_fin] at h
  have hLpos : (0 : ℝ) < L := by exact_mod_cast hL
  have hcast : ((L - (r : ℕ) : ℕ) : ℝ) = (L : ℝ) - r := by
    rw [Nat.cast_sub r.isLt.le]
  have h' : ((boxF D (Acon p r)).card : ℝ) * (L : ℝ) ^ D.card =
      (L : ℝ) ^ (n * n) * ((L : ℝ) - r) ^ (D.card - 1) := by
    rw [← hcast]
    exact_mod_cast h
  field_simp
  linarith

variable {T : Fin n → Fin n → Fin n}

instance (lam : Pair n → Fin L) (a b : Fin n) (T : Fin n → Fin n → Fin n) :
    Decidable (Fm lam a b T) :=
  inferInstanceAs (Decidable (_ ∧ _))

lemma sp_ne_of_ne {a b c : Fin n} (hab : a < b) (hcb : c ≠ b) (hca : c ≠ a) :
    sp a c ≠ (a, b) ∧ sp b c ≠ (a, b) := by
  rw [← sp_of_lt hab]
  constructor
  · intro h
    rcases sp_inj (Ne.symm hca) h with ⟨-, e⟩ | ⟨e, -⟩
    · exact hcb e
    · exact hab.ne e
  · intro h
    rcases sp_inj (Ne.symm hcb) h with ⟨e, -⟩ | ⟨-, e⟩
    · exact hab.ne e.symm
    · exact hca e

lemma p_mem_blockPairs {a b : Fin n} (hab : a < b) : (a, b) ∈ blockPairs T a b := by
  rw [← sp_of_lt hab]
  simp [blockPairs]

/-- The box `{lam | lam p = r, F⁻}`. -/
lemma mem_box (hT : IsSQ T) {a b : Fin n} (hab : a < b) (r : Fin L) (lam : Pair n → Fin L) :
    lam ∈ boxF (blockPairs T a b) (Acon (a, b) r) ↔ lam (a, b) = r ∧ Fm lam a b T := by
  have hca : T a b ≠ a := hT.ne_left hab.ne
  have hcb : T a b ≠ b := hT.ne_right hab.ne
  obtain ⟨h1, h2⟩ := sp_ne_of_ne hab hcb hca
  simp only [boxF, Finset.mem_filter, Finset.mem_univ, true_and, blockPairs, sp_of_lt hab,
    Finset.forall_mem_insert, Finset.mem_singleton, forall_eq, Acon, if_true, if_neg h1,
    if_neg h2, Finset.mem_singleton, Finset.mem_Ici, Fm]
  constructor
  · rintro ⟨e, h1', h2'⟩
    exact ⟨e, e ▸ h1', e ▸ h2'⟩
  · rintro ⟨e, h1', h2'⟩
    exact ⟨e, e ▸ h1', e ▸ h2'⟩

/-- The six pairs of the blocks through `{a, z}` and `{b, z}`. -/
def six (T : Fin n → Fin n → Fin n) (a b z : Fin n) : Finset (Pair n) :=
  blockPairs T a z ∪ blockPairs T b z

/-- The candidates for the third point at `(a, b)`: points of the class of `T a b`. -/
def cand (lab : Fin n → Fin k) (T : Fin n → Fin n → Fin n) (a b : Fin n) : Finset (Fin n) :=
  univ.filter fun z => lab z = lab (T a b) ∧ z ≠ a ∧ z ≠ b ∧ z ≠ T a b

/-- `X`: the candidates whose six pairs all have labels at least `lam (a, b)`. -/
def Xset (lab : Fin n → Fin k) (T : Fin n → Fin n → Fin n) (a b : Fin n)
    (lam : Pair n → Fin L) : Finset (Fin n) :=
  (cand lab T a b).filter fun z => ∀ q ∈ six T a b z, lam (a, b) ≤ lam q

lemma card_D9 {lab : Fin n → Fin k} (hT : IsSQ T) {a b z : Fin n} (hab : a < b) (hz : z ∈ cand lab T a b) :
    (blockPairs T a b ∪ six T a b z).card = 9 := by
  obtain ⟨-, hza, hzb, hzc⟩ := (Finset.mem_filter.mp hz).2
  obtain ⟨d1, d2, d3⟩ := blocks_distinct hT hab.ne hza hzb hzc
  have hd6 : Disjoint (blockPairs T a z) (blockPairs T b z) :=
    disjoint_blockPairs hT (Ne.symm hza) (Ne.symm hzb) d3
  have hd0 : Disjoint (blockPairs T a b) (six T a b z) := by
    rw [six, Finset.disjoint_union_right]
    exact ⟨disjoint_blockPairs hT hab.ne (Ne.symm hza) (Ne.symm d1),
      disjoint_blockPairs hT hab.ne (Ne.symm hzb) (Ne.symm d2)⟩
  rw [Finset.card_union_of_disjoint hd0, six, Finset.card_union_of_disjoint hd6,
    card_blockPairs hT hab.ne, card_blockPairs hT (Ne.symm hza), card_blockPairs hT (Ne.symm hzb)]

lemma mem_box9 {lab : Fin n → Fin k} (hT : IsSQ T) {a b z : Fin n} (hab : a < b)
    (hz : z ∈ cand lab T a b) (r : Fin L) (lam : Pair n → Fin L) :
    lam ∈ boxF (blockPairs T a b ∪ six T a b z) (Acon (a, b) r) ↔
      lam ∈ boxF (blockPairs T a b) (Acon (a, b) r) ∧ ∀ q ∈ six T a b z, lam (a, b) ≤ lam q := by
  obtain ⟨-, hza, hzb, hzc⟩ := (Finset.mem_filter.mp hz).2
  obtain ⟨d1, d2, -⟩ := blocks_distinct hT hab.ne hza hzb hzc
  have hp6 : ∀ q ∈ six T a b z, q ≠ (a, b) := by
    intro q hq e
    rw [six, Finset.mem_union] at hq
    have hp := p_mem_blockPairs (T := T) hab
    rcases hq with hq | hq
    · exact Finset.disjoint_left.mp (disjoint_blockPairs hT hab.ne (Ne.symm hza) (Ne.symm d1))
        hp (e ▸ hq)
    · exact Finset.disjoint_left.mp (disjoint_blockPairs hT hab.ne (Ne.symm hzb) (Ne.symm d2))
        hp (e ▸ hq)
  simp only [boxF, Finset.mem_filter, Finset.mem_univ, true_and, Finset.forall_mem_union]
  constructor
  · rintro ⟨h0, h6⟩
    refine ⟨h0, fun q hq => ?_⟩
    have hpr : lam (a, b) = r := by
      have := h0 (a, b) (p_mem_blockPairs hab)
      simpa [Acon] using this
    have := h6 q hq
    rw [Acon, if_neg (hp6 q hq), Finset.mem_Ici] at this
    rw [hpr]; exact this
  · rintro ⟨h0, h6⟩
    refine ⟨h0, fun q hq => ?_⟩
    have hpr : lam (a, b) = r := by
      have := h0 (a, b) (p_mem_blockPairs hab)
      simpa [Acon] using this
    rw [Acon, if_neg (hp6 q hq), Finset.mem_Ici, ← hpr]
    exact h6 q hq

/-- **The average of `X` over the box.** -/
lemma sum_X_le (hT : IsSQ T) (lab : Fin n → Fin k) {a b : Fin n} (hab : a < b) (r : Fin L)
    (hL : 0 < L) :
    ∑ lam ∈ boxF (blockPairs T a b) (Acon (a, b) r), ((Xset lab T a b lam).card : ℝ) ≤
      ((boxF (blockPairs T a b) (Acon (a, b) r)).card : ℝ) *
        ((cand lab T a b).card * (((L : ℝ) - r) / L) ^ 6) := by
  set B := boxF (blockPairs T a b) (Acon (a, b) r)
  have hswap : ∑ lam ∈ B, ((Xset lab T a b lam).card : ℝ) =
      ∑ z ∈ cand lab T a b, ((B.filter fun lam =>
        ∀ q ∈ six T a b z, lam (a, b) ≤ lam q).card : ℝ) := by
    simp only [Xset, Finset.card_filter, Nat.cast_sum]
    rw [Finset.sum_comm]
  rw [hswap]
  have hLpos : (0 : ℝ) < L := by exact_mod_cast hL
  have hz : ∀ z ∈ cand lab T a b, ((B.filter fun lam =>
      ∀ q ∈ six T a b z, lam (a, b) ≤ lam q).card : ℝ) =
      (B.card : ℝ) * (((L : ℝ) - r) / L) ^ 6 := by
    intro z hz
    have heq : (B.filter fun lam => ∀ q ∈ six T a b z, lam (a, b) ≤ lam q) =
        boxF (blockPairs T a b ∪ six T a b z) (Acon (a, b) r) := by
      ext lam
      rw [Finset.mem_filter, mem_box9 hT hab hz]
    rw [heq, card_boxF_real _ (Finset.mem_union_left _ (p_mem_blockPairs hab)) r hL,
      card_D9 hT hab hz, card_boxF_real _ (p_mem_blockPairs hab) r hL,
      card_blockPairs hT hab.ne]
    field_simp
    ring
  rw [Finset.sum_congr rfl hz, Finset.sum_const, nsmul_eq_mul]
  exact le_of_eq (by ring)

/-- **The values still possible at `(a, b)`.** -/
lemma aval_le {S : Finset (Fin n → Fin n → Fin n)} (hS : ∀ T ∈ S, IsSQ T) (lab : Fin n → Fin k)
    {a b : Fin n} (hab : a < b) (hT : T ∈ S) (lam : Pair n → Fin L) :
    ((sameClass S (pairs n) (key2 lam) coord lab (a, b) T).image (coord (a, b))).card ≤
      if Fm lam a b T then 1 + (Xset lab T a b lam).card else 1 := by
  set C := sameClass S (pairs n) (key2 lam) coord lab (a, b) T
  have hmemC : ∀ T' ∈ C, T' ∈ before S (pairs n) (key2 lam) coord (a, b) T ∧
      lab (T' a b) = lab (T a b) := fun T' hT' => Finset.mem_filter.mp hT'
  split_ifs with hF
  · have hsub : C.image (coord (a, b)) ⊆ insert (T a b) (Xset lab T a b lam) := by
      intro z hz
      obtain ⟨T', hT', rfl⟩ := Finset.mem_image.mp hz
      obtain ⟨hb, hcl⟩ := hmemC T' hT'
      simp only [coord]
      by_cases he : T' a b = T a b
      · rw [he]; exact Finset.mem_insert_self _ _
      · refine Finset.mem_insert_of_mem (Finset.mem_filter.mpr ⟨?_, ?_⟩)
        · have hT'q := hS T' (mem_before.mp hb).1
          exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hcl, hT'q.ne_left hab.ne,
            hT'q.ne_right hab.ne, he⟩
        · exact good_of_mem lam hS hab.ne hT hb he
    calc (C.image (coord (a, b))).card ≤ (insert (T a b) (Xset lab T a b lam)).card :=
          Finset.card_le_card hsub
      _ ≤ (Xset lab T a b lam).card + 1 := Finset.card_insert_le _ _
      _ = 1 + (Xset lab T a b lam).card := by ring
  · have hsub : C.image (coord (a, b)) ⊆ {T a b} := by
      intro z hz
      obtain ⟨T', hT', rfl⟩ := Finset.mem_image.mp hz
      obtain ⟨hb, -⟩ := hmemC T' hT'
      have hF' : lam (sp a (T a b)) < lam (a, b) ∨ lam (sp b (T a b)) < lam (a, b) := by
        unfold Fm at hF
        rw [not_and_or, not_le, not_le] at hF
        exact hF
      simp only [coord, Finset.mem_singleton]
      exact det_of_not_F lam hS hab.ne hT hb hF'
    exact (Finset.card_le_card hsub).trans (by simp)

lemma one_le_aval {S : Finset (Fin n → Fin n → Fin n)} (lab : Fin n → Fin k) {a b : Fin n}
    (hT : T ∈ S) (lam : Pair n → Fin L) :
    1 ≤ ((sameClass S (pairs n) (key2 lam) coord lab (a, b) T).image (coord (a, b))).card := by
  refine Finset.card_pos.mpr ⟨coord (a, b) T, Finset.mem_image.mpr ⟨T, ?_, rfl⟩⟩
  exact Finset.mem_filter.mpr ⟨mem_before_self hT, rfl⟩

/-- **The point part for one system.** -/
theorem point_sum_le {S : Finset (Fin n → Fin n → Fin n)} (hS : ∀ T ∈ S, IsSQ T)
    (lab : Fin n → Fin k) {a b : Fin n} (hab : a < b) (hT : T ∈ S) (hL : 0 < L) :
    ∑ lam : Pair n → Fin L, Real.log
        ((sameClass S (pairs n) (key2 lam) coord lab (a, b) T).image (coord (a, b))).card ≤
      ∑ r : Fin L, ((boxF (blockPairs T a b) (Acon (a, b) r)).card : ℝ) *
        Real.log (1 + (cand lab T a b).card * (((L : ℝ) - r) / L) ^ 6) := by
  have hTq := hS T hT
  -- pointwise bound
  have hpt : ∀ lam : Pair n → Fin L, Real.log
      ((sameClass S (pairs n) (key2 lam) coord lab (a, b) T).image (coord (a, b))).card ≤
      if Fm lam a b T then Real.log (1 + (Xset lab T a b lam).card) else 0 := by
    intro lam
    have h1 := aval_le hS lab hab hT lam
    have h0 := one_le_aval lab (a := a) (b := b) hT lam
    have h0' : (0 : ℝ) < ((sameClass S (pairs n) (key2 lam) coord lab (a, b) T).image
        (coord (a, b))).card := by exact_mod_cast h0
    split_ifs at h1 ⊢ with hF
    · exact Real.log_le_log h0' (by exact_mod_cast h1)
    · have : ((sameClass S (pairs n) (key2 lam) coord lab (a, b) T).image
          (coord (a, b))).card = 1 := le_antisymm h1 h0
      rw [this]; simp
  refine (Finset.sum_le_sum fun lam _ => hpt lam).trans ?_
  -- split by the label of `p`
  rw [← Finset.sum_fiberwise (s := univ) (g := fun lam : Pair n → Fin L => lam (a, b))]
  refine Finset.sum_le_sum fun r _ => ?_
  have hbox : ∑ lam ∈ univ.filter (fun lam : Pair n → Fin L => lam (a, b) = r),
      (if Fm lam a b T then Real.log (1 + (Xset lab T a b lam).card) else 0) =
      ∑ lam ∈ boxF (blockPairs T a b) (Acon (a, b) r),
        Real.log (1 + (Xset lab T a b lam).card) := by
    rw [← Finset.sum_filter, Finset.filter_filter]
    refine Finset.sum_congr ?_ fun _ _ => rfl
    ext lam
    rw [Finset.mem_filter, mem_box hTq hab]
    simp
  rw [hbox]
  set B := boxF (blockPairs T a b) (Acon (a, b) r)
  have hJ := log_jensen B (fun lam => ((Xset lab T a b lam).card : ℝ)) (fun _ _ => by positivity)
  refine hJ.trans ?_
  rcases B.eq_empty_or_nonempty with hB | hB
  · rw [hB]; simp
  have hBpos : (0 : ℝ) < B.card := by exact_mod_cast hB.card_pos
  refine mul_le_mul_of_nonneg_left ?_ hBpos.le
  have hX := sum_X_le hTq lab hab r hL
  have hsum0 : 0 ≤ (∑ lam ∈ B, ((Xset lab T a b lam).card : ℝ)) / B.card :=
    div_nonneg (Finset.sum_nonneg fun _ _ => Nat.cast_nonneg _) hBpos.le
  have hle : (∑ lam ∈ B, ((Xset lab T a b lam).card : ℝ)) / B.card ≤
      ((cand lab T a b).card : ℝ) * (((L : ℝ) - r) / L) ^ 6 := by
    rw [div_le_iff₀ hBpos]
    linarith
  exact Real.log_le_log (by linarith) (by linarith)

end ColourStats.TypedSTS
