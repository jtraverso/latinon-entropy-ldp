/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import RequestProject.TypedTriangle.Absorb

/-!
# The triangle lattice of rich graphs (Lemma 5.20)

Write `ab ⊠ pq` if the four endpoints of the edges `ab` and `pq` span a `K₄`. A graph `G`
is *rich* (`Rich`) if
* every two edges have a common `⊠`-partner;
* every three vertices (not necessarily distinct) have a common neighbour;
* any two common neighbours of two distinct vertices are joined by a path inside their
  common neighbourhood.

Main results:
* `sum_eq_zero_of_rich`: if `G` is rich, every degree is even and `3 ∣ e(G)`, then every
  map `χ` from the edges to an abelian group that sums to zero on every triangle sums to
  zero on `E(G)`;
* `isPhysical_of_rich`: under the same hypotheses `1_{E(G)}` is an integer sum of
  triangles of `G`, i.e. `E(G)` is physical in the sense of the corpus
  (`TypedTriangle.IsPhysical`, with every triangle allowed).

The proof is the one of the paper: `2χ` is constant, `6c = 0`, and `χ − 4c` is a
2-torsion cocycle of the form `φ(u) + φ(v)`.
-/

@[expose] public section

open Finset

namespace ColourStats.E3Lattice

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- `ab ⊠ pq`: the edges `ab` and `pq` span a `K₄`. -/
def Boxed (G : SimpleGraph V) (a b p q : V) : Prop :=
  G.Adj a b ∧ G.Adj p q ∧ G.Adj a p ∧ G.Adj a q ∧ G.Adj b p ∧ G.Adj b q

/-- The richness hypotheses of Lemma 5.20. -/
structure Rich (G : SimpleGraph V) : Prop where
  partner : ∀ a b x y, G.Adj a b → G.Adj x y → ∃ p q, Boxed G a b p q ∧ Boxed G x y p q
  common : ∀ u v w, ∃ x, G.Adj u x ∧ G.Adj v x ∧ G.Adj w x
  path : ∀ u o, u ≠ o → ∀ w w', G.Adj u w → G.Adj o w → G.Adj u w' → G.Adj o w' →
    Relation.ReflTransGen (fun x y => G.Adj x y ∧ G.Adj u y ∧ G.Adj o y) w w'

section Group

variable {A : Type*} [AddCommGroup A]

lemma tri_split {a b d : A} (h : a + b + d = 0) (hb : 2 • b = 0) (hd : 2 • d = 0) :
    a = b + d := by
  have e : a = b + d - 2 • b - 2 • d := by
    have : a = a + b + d - b - d := by abel
    rw [this, h]
    abel
  rw [e, hb, hd]
  abel

/-- **Lemma 5.20, dual form.** -/
theorem sum_eq_zero_of_rich (G : SimpleGraph V) [DecidableRel G.Adj] (hG : Rich G)
    (heven : ∀ v, Even (G.degree v)) (h3 : 3 ∣ G.edgeFinset.card) (χ : Sym2 V → A)
    (htri : ∀ a b c, G.Adj a b → G.Adj a c → G.Adj b c →
      χ s(a, b) + χ s(a, c) + χ s(b, c) = 0) :
    ∑ e ∈ G.edgeFinset, χ e = 0 := by
  by_cases hE : G.edgeFinset = ∅
  · simp [hE]
  obtain ⟨e₀, he₀⟩ := Finset.nonempty_iff_ne_empty.mpr hE
  obtain ⟨a₀, b₀⟩ := e₀
  have hab₀ : G.Adj a₀ b₀ := by simpa using he₀
  -- step 1: `2χ` is constant
  have hbox : ∀ a b p q, Boxed G a b p q → 2 • χ s(a, b) = 2 • χ s(p, q) := by
    rintro a b p q ⟨hab, hpq, hap, haq, hbp, hbq⟩
    have t1 := htri a b p hab hap hbp
    have t2 := htri a b q hab haq hbq
    have t3 := htri a p q hap haq hpq
    have t4 := htri b p q hbp hbq hpq
    have key : 2 • χ s(a, b) - 2 • χ s(p, q) =
        (χ s(a, b) + χ s(a, p) + χ s(b, p)) + (χ s(a, b) + χ s(a, q) + χ s(b, q)) -
          (χ s(a, p) + χ s(a, q) + χ s(p, q)) - (χ s(b, p) + χ s(b, q) + χ s(p, q)) := by
      abel
    rw [t1, t2, t3, t4] at key
    exact sub_eq_zero.mp (by rw [key]; abel)
  set c := χ s(a₀, b₀) with hc
  have h2c : ∀ a b, G.Adj a b → 2 • χ s(a, b) = 2 • c := by
    intro a b hab
    obtain ⟨p, q, h1, h2⟩ := hG.partner a b a₀ b₀ hab hab₀
    rw [hbox a b p q h1, hbox a₀ b₀ p q h2]
  have h6 : 6 • c = 0 := by
    obtain ⟨x, hax, hbx, -⟩ := hG.common a₀ b₀ b₀
    have t := htri a₀ b₀ x hab₀ hax hbx
    have := congrArg (fun z => 2 • z) t
    simp only [smul_add, smul_zero, h2c a₀ b₀ hab₀, h2c a₀ x hax, h2c b₀ x hbx] at this
    rw [← this]
    abel
  -- step 2: the 2-torsion cocycle `δ = χ − 4c`
  set δ : Sym2 V → A := fun e => χ e - 4 • c with hδ
  have hδ2 : ∀ a b, G.Adj a b → 2 • δ s(a, b) = 0 := by
    intro a b hab
    simp only [hδ, smul_sub, h2c a b hab]
    have : (2 : ℕ) • c - (2 : ℕ) • (4 : ℕ) • c = -((6 : ℕ) • c) := by abel
    rw [this, h6, neg_zero]
  have hδtri : ∀ a b d, G.Adj a b → G.Adj a d → G.Adj b d →
      δ s(a, b) + δ s(a, d) + δ s(b, d) = 0 := by
    intro a b d hab had hbd
    have t := htri a b d hab had hbd
    have : δ s(a, b) + δ s(a, d) + δ s(b, d) =
        (χ s(a, b) + χ s(a, d) + χ s(b, d)) - 2 • 6 • c := by
      simp only [hδ]; abel
    rw [this, t, h6, smul_zero, sub_zero]
  -- step 3: the potential `φ`
  set o := a₀ with ho
  let w : V → V := fun u => Classical.choose (hG.common u o o)
  have hw : ∀ u, G.Adj u (w u) ∧ G.Adj o (w u) := fun u =>
    ⟨(Classical.choose_spec (hG.common u o o)).1, (Classical.choose_spec (hG.common u o o)).2.1⟩
  let φ : V → A := fun u => if u = o then 0 else δ s(u, w u) + δ s(o, w u)
  have step : ∀ u x y, G.Adj u x → G.Adj o x → G.Adj u y → G.Adj o y → G.Adj x y →
      δ s(u, x) + δ s(o, x) = δ s(u, y) + δ s(o, y) := by
    intro u x y hux hox huy hoy hxy
    have t1 := hδtri u x y hux huy hxy
    have t2 := hδtri o x y hox hoy hxy
    have key : (δ s(u, x) + δ s(o, x)) - (δ s(u, y) + δ s(o, y)) =
        (δ s(u, x) + δ s(u, y) + δ s(x, y)) + (δ s(o, x) + δ s(o, y) + δ s(x, y)) -
          2 • δ s(u, y) - 2 • δ s(o, y) - 2 • δ s(x, y) := by
      abel
    rw [t1, t2, hδ2 u y huy, hδ2 o y hoy, hδ2 x y hxy] at key
    exact sub_eq_zero.mp (by rw [key]; abel)
  have hφo : φ o = 0 := by simp [φ]
  have hφspec : ∀ u, u ≠ o → ∀ y, G.Adj u y → G.Adj o y → φ u = δ s(u, y) + δ s(o, y) := by
    intro u hu y huy hoy
    have hpath := hG.path u o hu (w u) y (hw u).1 (hw u).2 huy hoy
    have claim : ∀ z, Relation.ReflTransGen
        (fun x y => G.Adj x y ∧ G.Adj u y ∧ G.Adj o y) (w u) z →
        (G.Adj u z ∧ G.Adj o z) ∧
          δ s(u, w u) + δ s(o, w u) = δ s(u, z) + δ s(o, z) := by
      intro z hz
      induction hz with
      | refl => exact ⟨hw u, rfl⟩
      | tail _ hbc ih =>
        exact ⟨⟨hbc.2.1, hbc.2.2⟩,
          ih.2.trans (step u _ _ ih.1.1 ih.1.2 hbc.2.1 hbc.2.2 hbc.1)⟩
    simp only [φ, if_neg hu]
    exact (claim y hpath).2
  have hφ2 : ∀ u, 2 • φ u = 0 := by
    intro u
    by_cases hu : u = o
    · rw [hu, hφo, smul_zero]
    · simp only [φ, if_neg hu, smul_add, hδ2 u (w u) (hw u).1, hδ2 o (w u) (hw u).2, add_zero]
  have hedge : ∀ u v, G.Adj u v → δ s(u, v) = φ u + φ v := by
    intro u v huv
    obtain ⟨x, hux, hvx, hox⟩ := hG.common u v o
    by_cases hu : u = o
    · subst hu
      have hv : v ≠ u := (G.ne_of_adj huv).symm
      rw [hφo, zero_add, hφspec v hv x hvx hux]
      rw [tri_split (hδtri _ v x huv hux hvx) (hδ2 _ x hux) (hδ2 v x hvx)]
      abel
    by_cases hv : v = o
    · subst hv
      rw [hφo, add_zero, hφspec u hu x hux hvx]
      rw [Sym2.eq_swap, tri_split (hδtri _ u x huv.symm hvx hux) (hδ2 _ x hvx) (hδ2 u x hux)]
      abel
    rw [hφspec u hu x hux hox, hφspec v hv x hvx hox,
      tri_split (hδtri u v x huv hux hvx) (hδ2 u x hux) (hδ2 v x hvx)]
    have : δ s(u, x) + δ s(o, x) + (δ s(v, x) + δ s(o, x)) =
        δ s(u, x) + δ s(v, x) + 2 • δ s(o, x) := by abel
    rw [this, hδ2 o x hox, add_zero]
  -- step 4: summing over the edges
  have hsumδ : ∑ e ∈ G.edgeFinset, δ e = ∑ d : G.Dart, φ d.fst := by
    rw [← Finset.sum_fiberwise_of_maps_to (s := univ) (t := G.edgeFinset)
      (g := SimpleGraph.Dart.edge) (fun d _ => by simp)]
    refine Finset.sum_congr rfl fun e he => ?_
    obtain ⟨a, b⟩ := e
    have hab : G.Adj a b := by simpa using he
    let d : G.Dart := ⟨(a, b), hab⟩
    have hfib : (univ.filter fun d' : G.Dart => d'.edge = s(a, b)) = {d, d.symm} :=
      SimpleGraph.Dart.edge_fiber d
    rw [hfib, Finset.sum_pair d.symm_ne.symm, hedge a b hab]
    rfl
  have hdeg : ∑ d : G.Dart, φ d.fst = 0 := by
    rw [← Finset.sum_fiberwise (s := univ) (g := fun d : G.Dart => d.fst)]
    refine Finset.sum_eq_zero fun v _ => ?_
    have : ∑ d ∈ univ.filter (fun d : G.Dart => d.fst = v), φ d.fst =
        ∑ d ∈ univ.filter (fun d : G.Dart => d.fst = v), φ v :=
      Finset.sum_congr rfl fun d hd => by rw [(Finset.mem_filter.mp hd).2]
    rw [this, Finset.sum_const, SimpleGraph.dart_fst_fiber_card_eq_degree]
    obtain ⟨j, hj⟩ := heven v
    rw [hj, add_nsmul, ← nsmul_add, ← two_nsmul, hφ2, nsmul_zero]
  have hχ : ∀ e, χ e = δ e + 4 • c := fun e => by simp [hδ]
  obtain ⟨j, hj⟩ := h3
  rw [Finset.sum_congr rfl fun e _ => hχ e, Finset.sum_add_distrib, hsumδ, hdeg, zero_add,
    Finset.sum_const, hj, smul_smul, show 3 * j * 4 = 2 * j * 6 by ring, ← smul_smul, h6,
    smul_zero]

end Group

omit [DecidableEq V] in
/-- **Lemma 5.20.** If `G` is rich, every degree is even and `3 ∣ e(G)`, then `1_{E(G)}` is
an integer sum of triangles of `G`. -/
theorem isPhysical_of_rich (G : SimpleGraph V) [DecidableRel G.Adj] (hG : Rich G)
    (heven : ∀ v, Even (G.degree v)) (h3 : 3 ∣ G.edgeFinset.card) :
    TypedTriangle.IsPhysical (⟨G, fun _ => ()⟩ : TypedTriangle.Host V Unit) Set.univ
      (TypedTriangle.edges (⟨G, fun _ => ()⟩ : TypedTriangle.Host V Unit)) := by
  classical
  set H : TypedTriangle.Host V Unit := ⟨G, fun _ => ()⟩
  set L := TypedTriangle.lattice H Set.univ
  let χ : Sym2 V → (Sym2 V → ℤ) ⧸ L := fun e => Submodule.Quotient.mk (TypedTriangle.ind {e})
  have hind : ∀ J : Finset (Sym2 V), ∑ e ∈ J, TypedTriangle.ind {e} = TypedTriangle.ind J := by
    intro J
    funext x
    simp [TypedTriangle.ind, Finset.sum_apply]
  have htri : ∀ a b c, G.Adj a b → G.Adj a c → G.Adj b c →
      χ s(a, b) + χ s(a, c) + χ s(b, c) = 0 := by
    intro a b c hab hac hbc
    have hT : TypedTriangle.IsAllowed H Set.univ {a, b, c} := by
      refine ⟨?_, ?_, Set.mem_univ _⟩
      · rw [Finset.card_insert_of_notMem (by simp [G.ne_of_adj hab, G.ne_of_adj hac]),
          Finset.card_pair (G.ne_of_adj hbc)]
      · intro x hx y hy hxy
        simp only [Finset.mem_insert, Finset.mem_singleton] at hx hy
        rcases hx with rfl | rfl | rfl <;> rcases hy with rfl | rfl | rfl <;>
          first | exact absurd rfl hxy | assumption | exact G.adj_symm ‹_›
    have hmem : TypedTriangle.ind (TypedTriangle.triEdges ({a, b, c} : Finset V)) ∈ L :=
      Submodule.subset_span ⟨_, hT, rfl⟩
    rw [TypedTriangle.triEdges_eq_insert_wedge (G.ne_of_adj hab) (G.ne_of_adj hac)
      (G.ne_of_adj hbc), ← hind, Finset.sum_insert (TypedTriangle.not_mem_wedge
      (G.ne_of_adj hab) (G.ne_of_adj hac) (G.ne_of_adj hbc))] at hmem
    have hne : s(a, c) ≠ s(b, c) := by
      simp [G.ne_of_adj hab, G.ne_of_adj hac]
    simp only [TypedTriangle.wedge] at hmem
    rw [Finset.sum_pair hne] at hmem
    have := (Submodule.Quotient.mk_eq_zero L).mpr hmem
    simpa [χ, add_assoc] using this
  have hsum := sum_eq_zero_of_rich G hG heven h3 χ htri
  have hE : TypedTriangle.edges H = G.edgeFinset := by
    ext e; simp [TypedTriangle.edges, H]
  unfold TypedTriangle.IsPhysical
  rw [hE, ← hind, ← Submodule.Quotient.mk_eq_zero, ← Submodule.mkQ_apply, map_sum]
  simpa [χ] using hsum

end ColourStats.E3Lattice
