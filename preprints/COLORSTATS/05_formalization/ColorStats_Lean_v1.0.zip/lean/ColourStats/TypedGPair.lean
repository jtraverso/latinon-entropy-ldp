/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedGBox
public import ColourStats.TypedPair

/-!
# The bound for one edge of `G`

Adaptation of `ColourStats.TypedPair`: for an edge `(a, b)` of `G` with `a < b`,
`pair_boundG` bounds the class and point parts summed over labellings and systems by
`Σ_r B_r Σ_T [log(|S| / |S_{cl(T a b)}|) + log(1 + |candG| u_r^6)]`.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.TypedG

open ColourStats.TypedChain ColourStats.TypedSTS

open Classical

variable {n L k : ℕ} {G : SimpleGraph (Fin n)} {S : Finset (Fin n → Fin n → Fin n)}

lemma card_box_eqG {T : Fin n → Fin n → Fin n} (hT : IsSQG G T) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b)
    (r : Fin L) (hL : 0 < L) :
    ((boxF (blockPairs T a b) (Acon (a, b) r)).card : ℝ) = Bv n L r := by
  rw [card_boxF_real _ (p_mem_blockPairs hab) r hL, card_blockPairsG hT hadj, Bv]

lemma box_filter_eqG {T : Fin n → Fin n → Fin n} (hT : IsSQG G T) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b)
    (r : Fin L) :
    (univ.filter fun lam : Pair n → Fin L => lam (a, b) = r ∧ Fm lam a b T) =
      boxF (blockPairs T a b) (Acon (a, b) r) := by
  ext lam
  rw [Finset.mem_filter, mem_boxG hT hab hadj]
  simp

lemma sum_UsetG (hS : ∀ T ∈ S, IsSQG G T) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b) (r : Fin L) (hL : 0 < L)
    (G : (Fin n → Fin n → Fin n) → ℝ) :
    ∑ y ∈ Uset S a b r, G y.2 = Bv n L r * ∑ T ∈ S, G T := by
  unfold Uset
  rw [sum_filter_prod (fun lam T => lam (a, b) = r ∧ Fm lam a b T) G, Finset.mul_sum]
  refine Finset.sum_congr rfl fun T hT => ?_
  rw [box_filter_eqG (hS T hT) hab hadj, card_box_eqG (hS T hT) hab hadj r hL]

lemma card_Uset_classG (hS : ∀ T ∈ S, IsSQG G T) (lab : Fin n → Fin k) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b)
    (r : Fin L) (hL : 0 < L) (X : Fin k) :
    (((Uset S a b r).filter fun z => lab (z.2 a b) = X).card : ℝ) =
      Bv n L r * (Scl S lab a b X).card := by
  have h := sum_UsetG hS hab hadj r hL (fun T => if lab (T a b) = X then (1 : ℝ) else 0)
  rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul, mul_one] at h
  rw [Finset.sum_boole] at h
  simp only [Scl]
  convert h using 2

lemma card_UsetG (hS : ∀ T ∈ S, IsSQG G T) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b) (r : Fin L) (hL : 0 < L) :
    ((Uset S a b r).card : ℝ) = Bv n L r * S.card := by
  have h := sum_UsetG hS hab hadj r hL (fun _ => (1 : ℝ))
  simpa using h

/-- The block map of the coarser past at `(a, b)`. -/
noncomputable def bmapG (G : SimpleGraph (Fin n)) (S : Finset (Fin n → Fin n → Fin n)) (a b : Fin n)
    (y : (Pair n → Fin L) × (Fin n → Fin n → Fin n)) :
    (Pair n → Fin L) × Finset (Fin n → Fin n → Fin n) :=
  (y.1, before S (pairsG G) (key2 y.1) coord (a, b) y.2)

lemma Uset_blockG (hS : ∀ T ∈ S, IsSQG G T) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b) (r : Fin L)
    {y : (Pair n → Fin L) × (Fin n → Fin n → Fin n)} (hy : y ∈ Uset S a b r) :
    ((Uset S a b r).filter fun z => bmapG G S a b z = bmapG G S a b y) =
      (before S (pairsG G) (key2 y.1) coord (a, b) y.2).image (fun T' => (y.1, T')) := by
  obtain ⟨hyS, hyr, hyF⟩ : y.2 ∈ S ∧ y.1 (a, b) = r ∧ Fm y.1 a b y.2 := by
    simp only [Uset, Finset.mem_filter, Finset.mem_product, Finset.mem_univ, true_and] at hy
    exact ⟨hy.1, hy.2.1, hy.2.2⟩
  ext ⟨lam', T'⟩
  simp only [Finset.mem_filter, Finset.mem_image, Uset, Finset.mem_product, Finset.mem_univ,
    true_and, bmapG, Prod.mk.injEq]
  constructor
  · rintro ⟨⟨hT'S, -, -⟩, rfl, hbe⟩
    refine ⟨T', ?_, rfl, rfl⟩
    rw [← hbe]
    exact mem_before_self hT'S
  · rintro ⟨T'', hT'', rfl, rfl⟩
    refine ⟨⟨(mem_before.mp hT'').1, hyr, (F_iffG y.1 hS hadj hyS hT'').mpr hyF⟩, rfl,
      before_eq hT''⟩

lemma Uset_block_classG (hS : ∀ T ∈ S, IsSQG G T) (lab : Fin n → Fin k) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b)
    (r : Fin L) {y : (Pair n → Fin L) × (Fin n → Fin n → Fin n)} (hy : y ∈ Uset S a b r) :
    ((Uset S a b r).filter fun z => bmapG G S a b z = bmapG G S a b y ∧
        lab (z.2 a b) = lab (y.2 a b)) =
      (sameClass S (pairsG G) (key2 y.1) coord lab (a, b) y.2).image (fun T' => (y.1, T')) := by
  rw [← Finset.filter_filter, Uset_blockG hS hab hadj r hy]
  ext ⟨lam', T'⟩
  simp only [Finset.mem_filter, Finset.mem_image, Prod.mk.injEq]
  constructor
  · rintro ⟨⟨T'', hT'', rfl, rfl⟩, hcl⟩
    exact ⟨T'', mem_sameClass.mpr ⟨hT'', hcl⟩, rfl, rfl⟩
  · rintro ⟨T'', hT'', rfl, rfl⟩
    obtain ⟨hb, hcl⟩ := mem_sameClass.mp hT''
    exact ⟨⟨T'', hb, rfl, rfl⟩, hcl⟩

/-- **The class part on `U_r`.** -/
theorem class_sum_leG (hS : ∀ T ∈ S, IsSQG G T) (lab : Fin n → Fin k) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b)
    (r : Fin L) (hL : 0 < L) :
    ∑ y ∈ Uset S a b r, (Real.log (before S (pairsG G) (key2 y.1) coord (a, b) y.2).card -
        Real.log (sameClass S (pairsG G) (key2 y.1) coord lab (a, b) y.2).card) ≤
      Bv n L r * ∑ T ∈ S, (Real.log S.card - Real.log (Scl S lab a b (lab (T a b))).card) := by
  have h := cond_le (Uset S a b r) (bmapG G S a b) (fun z => lab (z.2 a b))
  have hinj : ∀ lam : Pair n → Fin L, Function.Injective
      (fun T' : Fin n → Fin n → Fin n => (lam, T')) := fun lam _ _ e => (Prod.mk.inj e).2
  have hL1 : ∀ y ∈ Uset S a b r, Real.log ((Uset S a b r).filter
      fun z => bmapG G S a b z = bmapG G S a b y).card -
      Real.log ((Uset S a b r).filter fun z => bmapG G S a b z = bmapG G S a b y ∧
        lab (z.2 a b) = lab (y.2 a b)).card =
      Real.log (before S (pairsG G) (key2 y.1) coord (a, b) y.2).card -
        Real.log (sameClass S (pairsG G) (key2 y.1) coord lab (a, b) y.2).card := by
    intro y hy
    rw [Uset_blockG hS hab hadj r hy, Uset_block_classG hS lab hab hadj r hy,
      Finset.card_image_of_injective _ (hinj y.1), Finset.card_image_of_injective _ (hinj y.1)]
  have hBv := Bv_pos (n := n) hL r
  have hR1 : ∀ y ∈ Uset S a b r, Real.log (Uset S a b r).card -
      Real.log ((Uset S a b r).filter fun z => lab (z.2 a b) = lab (y.2 a b)).card =
      Real.log S.card - Real.log (Scl S lab a b (lab (y.2 a b))).card := by
    intro y hy
    have hyS : y.2 ∈ S := by
      simp only [Uset, Finset.mem_filter, Finset.mem_product] at hy
      exact hy.1.2
    have hS0 : (0 : ℝ) < S.card := by exact_mod_cast Finset.card_pos.mpr ⟨_, hyS⟩
    have hmem : y.2 ∈ Scl S lab a b (lab (y.2 a b)) := Finset.mem_filter.mpr ⟨hyS, rfl⟩
    have hc0 : (0 : ℝ) < (Scl S lab a b (lab (y.2 a b))).card := by
      exact_mod_cast Finset.card_pos.mpr ⟨_, hmem⟩
    rw [card_UsetG hS hab hadj r hL, card_Uset_classG hS lab hab hadj r hL,
      Real.log_mul hBv.ne' hS0.ne', Real.log_mul hBv.ne' hc0.ne']
    ring
  rw [Finset.sum_congr rfl hL1, Finset.sum_congr rfl hR1] at h
  refine h.trans (le_of_eq ?_)
  exact sum_UsetG hS hab hadj r hL
    (fun T => Real.log S.card - Real.log (Scl S lab a b (lab (T a b))).card)

/-- The class part vanishes off `F⁻`. -/
lemma class_zeroG (hS : ∀ T ∈ S, IsSQG G T) (lab : Fin n → Fin k) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b)
    {T : Fin n → Fin n → Fin n} (hT : T ∈ S) (lam : Pair n → Fin L) (hF : ¬ Fm lam a b T) :
    Real.log (before S (pairsG G) (key2 lam) coord (a, b) T).card -
      Real.log (sameClass S (pairsG G) (key2 lam) coord lab (a, b) T).card = 0 := by
  have hF' : lam (sp a (T a b)) < lam (a, b) ∨ lam (sp b (T a b)) < lam (a, b) := by
    unfold Fm at hF
    rw [not_and_or, not_le, not_le] at hF
    exact hF
  have : sameClass S (pairsG G) (key2 lam) coord lab (a, b) T =
      before S (pairsG G) (key2 lam) coord (a, b) T := by
    unfold sameClass
    refine Finset.filter_true_of_mem fun T' hT' => ?_
    simp only [coord]
    rw [det_of_not_FG lam hS hadj hT hT' hF']
  rw [this, sub_self]

/-- **The bound for one pair.** -/
theorem pair_boundG (hS : ∀ T ∈ S, IsSQG G T) (lab : Fin n → Fin k) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b)
    (hL : 0 < L) :
    ∑ lam : Pair n → Fin L, ∑ T ∈ S,
        ((Real.log (before S (pairsG G) (key2 lam) coord (a, b) T).card -
          Real.log (sameClass S (pairsG G) (key2 lam) coord lab (a, b) T).card) +
        Real.log ((sameClass S (pairsG G) (key2 lam) coord lab (a, b) T).image
          (coord (a, b))).card) ≤
      ∑ r : Fin L, Bv n L r * ∑ T ∈ S,
        ((Real.log S.card - Real.log (Scl S lab a b (lab (T a b))).card) +
          Real.log (1 + (candG G lab T a b).card * (((L : ℝ) - r) / L) ^ 6)) := by
  simp only [Finset.sum_add_distrib, mul_add]
  -- the point part
  have hP : ∑ lam : Pair n → Fin L, ∑ T ∈ S, Real.log
      ((sameClass S (pairsG G) (key2 lam) coord lab (a, b) T).image (coord (a, b))).card ≤
      ∑ r : Fin L, Bv n L r * ∑ T ∈ S,
        Real.log (1 + (candG G lab T a b).card * (((L : ℝ) - r) / L) ^ 6) := by
    rw [Finset.sum_comm]
    simp only [Finset.mul_sum]
    rw [Finset.sum_comm (s := (univ : Finset (Fin L)))]
    refine Finset.sum_le_sum fun T hT => ?_
    refine (point_sum_leG hS lab hab hadj hT hL).trans (le_of_eq ?_)
    refine Finset.sum_congr rfl fun r _ => ?_
    rw [card_box_eqG (hS T hT) hab hadj r hL]
  -- the class part
  have hC : ∑ lam : Pair n → Fin L, ∑ T ∈ S,
      (Real.log (before S (pairsG G) (key2 lam) coord (a, b) T).card -
        Real.log (sameClass S (pairsG G) (key2 lam) coord lab (a, b) T).card) ≤
      ∑ r : Fin L, Bv n L r * ∑ T ∈ S,
        (Real.log S.card - Real.log (Scl S lab a b (lab (T a b))).card) := by
    set A : (Pair n → Fin L) × (Fin n → Fin n → Fin n) → ℝ := fun y =>
      Real.log (before S (pairsG G) (key2 y.1) coord (a, b) y.2).card -
        Real.log (sameClass S (pairsG G) (key2 y.1) coord lab (a, b) y.2).card
    have h1 : ∑ lam : Pair n → Fin L, ∑ T ∈ S,
        (Real.log (before S (pairsG G) (key2 lam) coord (a, b) T).card -
          Real.log (sameClass S (pairsG G) (key2 lam) coord lab (a, b) T).card) =
        ∑ y ∈ (univ ×ˢ S).filter (fun y => Fm y.1 a b y.2), A y := by
      rw [← Finset.sum_product (s := univ) (t := S) (f := A), Finset.sum_filter]
      refine Finset.sum_congr rfl fun y hy => ?_
      split_ifs with hF
      · rfl
      · exact class_zeroG hS lab hab hadj (Finset.mem_product.mp hy).2 y.1 hF
    rw [h1, ← Finset.sum_fiberwise (s := (univ ×ˢ S).filter (fun y => Fm y.1 a b y.2))
      (g := fun y => y.1 (a, b))]
    refine Finset.sum_le_sum fun r _ => ?_
    have hU : ((univ ×ˢ S).filter (fun y => Fm y.1 a b y.2)).filter
        (fun y => y.1 (a, b) = r) = Uset S a b r := by
      unfold Uset
      rw [Finset.filter_filter]
      congr 1
      ext y
      exact and_comm
    rw [hU]
    exact class_sum_leG hS lab hab hadj r hL
  linarith

end ColourStats.TypedG
