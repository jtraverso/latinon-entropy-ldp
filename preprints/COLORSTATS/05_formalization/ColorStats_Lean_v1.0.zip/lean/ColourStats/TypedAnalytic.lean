/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedAggregate
public import CountingCone.LL.Estimates

/-!
# The analytic estimates (Section 4.2, Steps 5–6)

With `w_r = (L − r)²/L³` and `u_r = (L − r)/L`:

* `Wsum_eq`: `W = Σ_r w_r = (L + 1)(2L + 1)/(6L²)`, so `W ≤ 1/3 + 1/L`;
* `Psi_le`: `Ψ(c) = Σ_r w_r log(1 + c u_r^6) ≤ 2 · wsum 3 L √c`, since
  `1 + c y² ≤ (1 + √c y)²`; the corpus sum–integral comparison
  (`LinialLuria.weighted_log_sum_le`) then applies;
* `term_le`: for `L ≥ 1`, `c ≥ 1` and `x ≥ 1`,
  `W log x + Ψ(c) ≤ (1/3)(log x + log c) − 2/3 + (log x + 3 log c + 16)/L + 8/√√c`.

The main term `(1/3) log c − 2/3` is the contribution `∫₀¹ u² (log c + 6 log u) du` of one
pair; the `−2/3` is the `−2` of `log n − 2` after the weight `1/3`.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.TypedSTS

variable {L : ℕ}

lemma reflect_cast {L j : ℕ} (hj : j ∈ range L) :
    (L : ℝ) - ((L - 1 - j : ℕ) : ℝ) = (j : ℝ) + 1 := by
  have h : L - 1 - j + (j + 1) = L := by
    have := Finset.mem_range.mp hj
    omega
  have h' : ((L - 1 - j : ℕ) : ℝ) + ((j : ℝ) + 1) = L := by exact_mod_cast h
  linarith

/-- `W = (L + 1)(2L + 1)/(6L²)`. -/
lemma Wsum_eq (hL : 0 < L) : Wsum L = ((L : ℝ) + 1) * (2 * L + 1) / (6 * (L : ℝ) ^ 2) := by
  have hLpos : (0 : ℝ) < L := by exact_mod_cast hL
  unfold Wsum wr
  rw [Fin.sum_univ_eq_sum_range (fun j : ℕ => ((L : ℝ) - j) ^ 2 / (L : ℝ) ^ 3) L,
    ← Finset.sum_range_reflect]
  rw [Finset.sum_congr rfl fun j hj => by rw [reflect_cast hj], ← Finset.sum_div]
  have h := sum_sq_range L
  rw [show ∑ j ∈ range L, ((j : ℝ) + 1) ^ 2 = ∑ r ∈ range L, ((r + 1 : ℝ)) ^ 2 from rfl, h]
  field_simp

lemma Wsum_le (hL : 1 ≤ L) : Wsum L ≤ 1 / 3 + 1 / L := by
  have hLpos : (1 : ℝ) ≤ L := by exact_mod_cast hL
  rw [Wsum_eq (by omega)]
  rw [div_le_iff₀ (by positivity)]
  field_simp
  nlinarith

/-- `Ψ(c) ≤ 2 · wsum 3 L √c`. -/
lemma Psi_le (hL : 1 ≤ L) {c : ℝ} (hc : 0 ≤ c) : Psi L c ≤ 2 * wsum 3 L (Real.sqrt c) := by
  have hLpos : (0 : ℝ) < L := by exact_mod_cast hL
  unfold Psi wr wsum
  rw [Fin.sum_univ_eq_sum_range (fun j : ℕ => ((L : ℝ) - j) ^ 2 / (L : ℝ) ^ 3 *
    Real.log (1 + c * (((L : ℝ) - j) / L) ^ 6)) L, ← Finset.sum_range_reflect, Finset.mul_sum]
  refine Finset.sum_le_sum fun j hj => ?_
  rw [reflect_cast hj]
  norm_num
  set y : ℝ := (((j : ℝ) + 1) / L) ^ 3 with hy
  have hy0 : 0 ≤ y := by positivity
  have h6 : (((j : ℝ) + 1) / L) ^ 6 = y ^ 2 := by rw [hy]; ring
  rw [h6]
  have hsq : 1 + c * y ^ 2 ≤ (1 + Real.sqrt c * y) ^ 2 := by
    have hs := Real.sq_sqrt hc
    nlinarith [Real.sqrt_nonneg c]
  have hlog : Real.log (1 + c * y ^ 2) ≤ 2 * Real.log (1 + Real.sqrt c * y) := by
    rw [← Real.log_rpow (by positivity)]
    apply Real.log_le_log (by positivity)
    rw [show (1 + Real.sqrt c * y) ^ (2 : ℝ) = (1 + Real.sqrt c * y) ^ 2 by norm_cast]
    exact hsq
  have hw : (0 : ℝ) ≤ ((j : ℝ) + 1) ^ 2 / (L : ℝ) ^ 3 := by positivity
  calc ((j : ℝ) + 1) ^ 2 / (L : ℝ) ^ 3 * Real.log (1 + c * y ^ 2)
      ≤ ((j : ℝ) + 1) ^ 2 / (L : ℝ) ^ 3 * (2 * Real.log (1 + Real.sqrt c * y)) :=
        mul_le_mul_of_nonneg_left hlog hw
    _ = 2 * (((j : ℝ) + 1) ^ 2 / (L : ℝ) ^ 3 * Real.log (1 + Real.sqrt c * y)) := by ring

/-- **The per-unit estimate.** -/
theorem term_le (hL : 1 ≤ L) {c x : ℝ} (hc : 1 ≤ c) (hx : 1 ≤ x) :
    Wsum L * Real.log x + Psi L c ≤
      (1 / 3) * (Real.log x + Real.log c) - 2 / 3 +
        ((Real.log x + 3 * Real.log c + 16) / L + 8 / Real.sqrt (Real.sqrt c)) := by
  have hL1 : (1 : ℝ) ≤ L := by exact_mod_cast hL
  have hLpos : (0 : ℝ) < L := by linarith
  have hlx : 0 ≤ Real.log x := Real.log_nonneg hx
  have hlc : 0 ≤ Real.log c := Real.log_nonneg hc
  -- the weight
  have hWx : Wsum L * Real.log x ≤ (1 / 3 + 1 / L) * Real.log x :=
    mul_le_mul_of_nonneg_right (Wsum_le hL) hlx
  -- the square roots
  set q := Real.sqrt c with hq
  set q2 := Real.sqrt q with hq2
  have hq1 : 1 ≤ q := Real.one_le_sqrt.mpr hc
  have hq21 : 1 ≤ q2 := Real.one_le_sqrt.mpr hq1
  have hqq : q2 * q2 = q := Real.mul_self_sqrt (by linarith)
  have hq2le : q2 ≤ q := by nlinarith
  have hinv : 1 / q ≤ 1 / q2 := one_div_le_one_div_of_le (by linarith) hq2le
  have hlogq : Real.log q = (1 / 2) * Real.log c := by
    rw [hq, Real.log_sqrt (by linarith)]
    ring
  -- `s = (L + 1)/L`
  set s : ℝ := ((L : ℝ) + 1) / L with hs
  have hs1 : 1 ≤ s := by rw [hs, le_div_iff₀ hLpos]; linarith
  have hsm : s - 1 = 1 / L := by rw [hs]; field_simp; ring
  have hs2 : s ≤ 2 := by
    have : 1 / (L : ℝ) ≤ 1 := by rw [div_le_one hLpos]; exact hL1
    linarith
  have hs3 : s ^ 3 ≤ 1 + 7 / L := by
    have h1 : 1 / (L : ℝ) ≤ 1 := by rw [div_le_one hLpos]; exact hL1
    have hs' : s = 1 + 1 / L := by linarith
    rw [hs']
    have hd : 0 ≤ 1 / (L : ℝ) := by positivity
    have : (1 + 1 / (L : ℝ)) ^ 3 = 1 + 3 * (1 / L) + 3 * (1 / L) ^ 2 + (1 / L) ^ 3 := by ring
    rw [this, show (7 : ℝ) / L = 7 * (1 / L) by ring]
    nlinarith
  have hlogs : Real.log s ≤ 1 / L := by
    have := Real.log_le_sub_one_of_pos (by linarith : (0 : ℝ) < s)
    linarith
  have hlogs0 : 0 ≤ Real.log s := Real.log_nonneg hs1
  -- `log(1 + q s³) ≤ (1/2) log c + 3/L + 1/q`
  have hA : Real.log (1 + q * s ^ 3) ≤ (1 / 2) * Real.log c + 3 / L + 1 / q := by
    have hqs : 1 ≤ q * s ^ 3 := by nlinarith [pow_le_pow_left₀ (by linarith : (0 : ℝ) ≤ 1) hs1 3]
    have hpos : 0 < q * s ^ 3 := by linarith
    have hsplit : 1 + q * s ^ 3 = (q * s ^ 3) * (1 + 1 / (q * s ^ 3)) := by
      rw [mul_add, mul_one, mul_one_div_cancel hpos.ne']
      ring
    rw [hsplit, Real.log_mul hpos.ne' (by positivity), Real.log_mul (by linarith) (by positivity),
      Real.log_pow, hlogq]
    have h1 : Real.log (1 + 1 / (q * s ^ 3)) ≤ 1 / (q * s ^ 3) := by
      have := Real.log_le_sub_one_of_pos (by positivity : (0 : ℝ) < 1 + 1 / (q * s ^ 3))
      linarith
    have h2 : 1 / (q * s ^ 3) ≤ 1 / q := by
      apply one_div_le_one_div_of_le (by linarith)
      have : (1 : ℝ) ≤ s ^ 3 := one_le_pow₀ hs1
      nlinarith
    have h3 : (3 : ℕ) * Real.log s ≤ 3 / L := by
      push_cast
      have : 3 * Real.log s ≤ 3 * (1 / L) := by linarith
      linarith [show 3 * (1 / (L : ℝ)) = 3 / L by ring]
    linarith
  -- the corpus sum–integral comparison
  have hwl := weighted_log_sum_le 3 L (by norm_num) hL q (by linarith)
  have hP : Psi L c ≤ 2 * ((s ^ 3 / 3) * (Real.log (1 + q * s ^ 3) - 1) +
      Real.sqrt (s ^ 3 / q) / 3) := by
    have h := Psi_le hL (by linarith : (0 : ℝ) ≤ c)
    unfold wsum at h
    norm_num at hwl
    have : (((L : ℝ) + 1) / L) = s := rfl
    rw [this] at hwl
    linarith
  -- the square-root term
  have hsqrt : Real.sqrt (s ^ 3 / q) ≤ 3 / q2 := by
    have h8 : s ^ 3 / q ≤ 8 / q := by
      apply div_le_div_of_nonneg_right _ (by linarith)
      nlinarith [pow_le_pow_left₀ (by linarith : (0 : ℝ) ≤ s) hs2 3]
    have h9 : (8 : ℝ) / q ≤ (3 / q2) ^ 2 := by
      rw [div_pow, ← hqq]
      rw [div_le_div_iff₀ (by linarith) (by positivity)]
      nlinarith
    calc Real.sqrt (s ^ 3 / q) ≤ Real.sqrt ((3 / q2) ^ 2) := Real.sqrt_le_sqrt (h8.trans h9)
      _ = 3 / q2 := Real.sqrt_sq (by positivity)
  -- assemble
  have hA0 : 0 ≤ (1 / 2) * Real.log c + 3 / L + 1 / q := by positivity
  have hmain : 2 * ((s ^ 3 / 3) * (Real.log (1 + q * s ^ 3) - 1)) ≤
      (2 / 3) * (1 + 7 / L) * ((1 / 2) * Real.log c + 3 / L + 1 / q) - 2 / 3 := by
    have hs30 : 0 ≤ s ^ 3 := by positivity
    have hs31 : 1 ≤ s ^ 3 := one_le_pow₀ hs1
    have e1 : 2 * ((s ^ 3 / 3) * (Real.log (1 + q * s ^ 3) - 1)) ≤
        2 * ((s ^ 3 / 3) * ((1 / 2) * Real.log c + 3 / L + 1 / q - 1)) := by
      have := mul_le_mul_of_nonneg_left (sub_le_sub_right hA 1) (by positivity : 0 ≤ s ^ 3 / 3)
      linarith
    have e2 : 2 * ((s ^ 3 / 3) * ((1 / 2) * Real.log c + 3 / L + 1 / q - 1)) =
        (2 / 3) * s ^ 3 * ((1 / 2) * Real.log c + 3 / L + 1 / q) - (2 / 3) * s ^ 3 := by ring
    have e3 : (2 / 3) * s ^ 3 * ((1 / 2) * Real.log c + 3 / L + 1 / q) ≤
        (2 / 3) * (1 + 7 / L) * ((1 / 2) * Real.log c + 3 / L + 1 / q) := by
      have := mul_le_mul_of_nonneg_right hs3 hA0
      linarith
    linarith
  -- the leftover terms
  have hfin : (2 / 3) * (1 + 7 / L) * ((1 / 2) * Real.log c + 3 / L + 1 / q) ≤
      (1 / 3) * Real.log c + (7 / 3) * Real.log c / L + 16 / L + (16 / 3) * (1 / q) := by
    have hLinv : 1 / (L : ℝ) ≤ 1 := by rw [div_le_one hLpos]; exact hL1
    have hLinv0 : 0 ≤ 1 / (L : ℝ) := by positivity
    have hqinv0 : 0 ≤ 1 / q := by positivity
    have e : (2 / 3) * (1 + 7 / L) * ((1 / 2) * Real.log c + 3 / L + 1 / q) =
        (1 / 3) * Real.log c + (7 / 3) * Real.log c * (1 / L) + 2 * (1 / L) +
          14 * (1 / L) * (1 / L) + (2 / 3) * (1 / q) + (14 / 3) * (1 / L) * (1 / q) := by
      ring
    rw [e]
    have : (7 / 3) * Real.log c / L = (7 / 3) * Real.log c * (1 / L) := by ring
    rw [this]
    have : (16 : ℝ) / L = 16 * (1 / L) := by ring
    rw [this]
    have i1 : (1 / (L : ℝ)) * (1 / L) ≤ 1 / L := mul_le_of_le_one_left hLinv0 hLinv
    have i2 : (1 / (L : ℝ)) * (1 / q) ≤ 1 / q := mul_le_of_le_one_left hqinv0 hLinv
    linarith
  have hx' : (1 / 3 + 1 / L) * Real.log x = (1 / 3) * Real.log x + Real.log x / L := by ring
  have hgoal : (Real.log x + 3 * Real.log c + 16) / L =
      Real.log x / L + 3 * Real.log c / L + 16 / L := by ring
  rw [hgoal]
  have hlc3 : (7 / 3) * Real.log c / L ≤ 3 * Real.log c / L := by
    apply div_le_div_of_nonneg_right _ hLpos.le
    linarith
  have hq8 : (16 / 3) * (1 / q) + 2 * (3 / q2) / 3 ≤ 8 / q2 := by
    have : (16 / 3) * (1 / q) ≤ (16 / 3) * (1 / q2) := by linarith
    have hq2p : 0 < 1 / q2 := by positivity
    have e : (16 / 3) * (1 / q2) + 2 * (3 / q2) / 3 = (22 / 3) * (1 / q2) := by ring
    have e2 : (8 : ℝ) / q2 = 8 * (1 / q2) := by ring
    linarith
  linarith

end ColourStats.TypedSTS
