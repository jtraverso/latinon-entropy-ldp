/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import Mathlib

/-!
# An explicit inverse for the triangles of `K_m` (Lemma 5.13)

Let `A` be the incidence map from the triangles of `K_m` to its edges. An edge vector is a
symmetric function `x : Fin m → Fin m → ℝ` with zero diagonal. Put

    X(u) = Σ_v x(uv),   S = Σ_u X(u)/(3m − 6),   Y(u) = (X(u) − S)/(2m − 6),
    y(uv) = (x(uv) − Y(u) − Y(v))/(m − 4),   (Φx)(uvw) = y(uv) + y(uw) + y(vw).

Main results:
* `apply_inverse`: `(AΦx)(uv) = Σ_{w ≠ u, v} (Φx)(uvw) = x(uv)` for `m ≥ 5`;
* `inverse_bound`: `|(Φx)(uvw)| ≤ 24‖x‖_∞/m` for `m ≥ 8`.
-/

@[expose] public section

open Finset

namespace ColourStats.TriangleInverse

variable {m : ℕ}

/-- `X(u) = Σ_v x(uv)`. -/
noncomputable def X (x : Fin m → Fin m → ℝ) (u : Fin m) : ℝ := ∑ v, x u v

/-- `S = Σ_u X(u)/(3m − 6)`. -/
noncomputable def S (x : Fin m → Fin m → ℝ) : ℝ := (∑ u, X x u) / (3 * (m : ℝ) - 6)

/-- `Y(u) = (X(u) − S)/(2m − 6)`. -/
noncomputable def Y (x : Fin m → Fin m → ℝ) (u : Fin m) : ℝ :=
  (X x u - S x) / (2 * (m : ℝ) - 6)

/-- The edge weights `y(uv) = (x(uv) − Y(u) − Y(v))/(m − 4)`; `(Φx)(uvw)` is
`y(uv) + y(uw) + y(vw)`. -/
noncomputable def y (x : Fin m → Fin m → ℝ) (u v : Fin m) : ℝ :=
  (x u v - Y x u - Y x v) / ((m : ℝ) - 4)

lemma sum_Y (hm : 5 ≤ m) (x : Fin m → Fin m → ℝ) : ∑ u, Y x u = S x := by
  have hmR : (5 : ℝ) ≤ m := by exact_mod_cast hm
  have h1 : 3 * (m : ℝ) - 6 ≠ 0 := by linarith
  have h2 : 2 * (m : ℝ) - 6 ≠ 0 := by linarith
  have hS : ∑ u, X x u = (3 * (m : ℝ) - 6) * S x := by
    unfold S; field_simp
  simp only [Y]
  rw [← Finset.sum_div, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ,
    Fintype.card_fin, nsmul_eq_mul, hS, div_eq_iff h2]
  ring

lemma sum_y (hm : 5 ≤ m) (x : Fin m → Fin m → ℝ) (u : Fin m) :
    ∑ w, y x u w = (X x u - m * Y x u - S x) / ((m : ℝ) - 4) := by
  simp only [y]
  rw [← Finset.sum_div, Finset.sum_sub_distrib, Finset.sum_sub_distrib, sum_Y hm x,
    Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  rfl

lemma sum_y_erase (hm : 5 ≤ m) (x : Fin m → Fin m → ℝ) (hdiag : ∀ u, x u u = 0)
    (u : Fin m) : ∑ w, y x u w - y x u u = Y x u := by
  have hmR : (5 : ℝ) ≤ m := by exact_mod_cast hm
  have hm4 : (m : ℝ) - 4 ≠ 0 := by linarith
  have hm6 : 2 * (m : ℝ) - 6 ≠ 0 := by linarith
  have hY : X x u - S x = (2 * m - 6) * Y x u := by
    unfold Y; field_simp
  rw [sum_y hm x u]
  simp only [y, hdiag]
  rw [div_sub_div_same, div_eq_iff hm4]
  linear_combination hY

/-- **`AΦ = id`.** For an edge `uv`, the triangles `uvw` carry total weight `x(uv)`. -/
theorem apply_inverse (hm : 5 ≤ m) (x : Fin m → Fin m → ℝ) (hsym : ∀ u v, x u v = x v u)
    (hdiag : ∀ u, x u u = 0) {u v : Fin m} (huv : u ≠ v) :
    ∑ w ∈ (univ.erase u).erase v, (y x u v + y x u w + y x v w) = x u v := by
  have hmR : (5 : ℝ) ≤ m := by exact_mod_cast hm
  have hm4 : (m : ℝ) - 4 ≠ 0 := by linarith
  have hm6 : 2 * (m : ℝ) - 6 ≠ 0 := by linarith
  have hv : v ∈ univ.erase u := mem_erase.mpr ⟨huv.symm, mem_univ v⟩
  rw [sum_erase_eq_sub hv, sum_erase_eq_sub (mem_univ u)]
  simp only [sum_add_distrib, sum_const, card_univ, Fintype.card_fin, nsmul_eq_mul]
  have e1 := sum_y_erase hm x hdiag u
  have e2 := sum_y_erase hm x hdiag v
  have hyvu : y x v u = y x u v := by simp only [y, hsym v u]; ring
  have hyuv : ((m : ℝ) - 4) * y x u v = x u v - Y x u - Y x v := by
    unfold y; field_simp
  linear_combination e1 + e2 + hyuv - hyvu

/-- **The norm bound.** `|(Φx)(uvw)| ≤ 24 B/m` whenever `|x| ≤ B` and `m ≥ 8`. -/
theorem inverse_bound (hm : 8 ≤ m) (x : Fin m → Fin m → ℝ) {B : ℝ}
    (hB : ∀ u v, |x u v| ≤ B) (u v w : Fin m) :
    |y x u v + y x u w + y x v w| ≤ 24 * B / m := by
  have hmR : (8 : ℝ) ≤ m := by exact_mod_cast hm
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hB ⟨0, by omega⟩ ⟨0, by omega⟩)
  have hX : ∀ u, |X x u| ≤ m * B := by
    intro u
    calc |X x u| ≤ ∑ v, |x u v| := abs_sum_le_sum_abs _ _
      _ ≤ ∑ _v : Fin m, B := sum_le_sum fun v _ => hB u v
      _ = m * B := by simp
  have hS : |S x| ≤ m * B / 2 := by
    unfold S
    rw [abs_div, abs_of_pos (by linarith : (0 : ℝ) < 3 * m - 6),
      div_le_iff₀ (by linarith : (0 : ℝ) < 3 * m - 6)]
    calc |∑ u, X x u| ≤ ∑ u, |X x u| := abs_sum_le_sum_abs _ _
      _ ≤ ∑ _u : Fin m, (m * B) := sum_le_sum fun u _ => hX u
      _ = m * (m * B) := by simp
      _ ≤ m * B / 2 * (3 * m - 6) := by
        nlinarith [mul_nonneg (mul_nonneg (by linarith : (0 : ℝ) ≤ m) hB0)
          (by linarith : (0 : ℝ) ≤ m - 6)]
  have hY : ∀ u, |Y x u| ≤ 3 * B / 2 := by
    intro u
    unfold Y
    rw [abs_div, abs_of_pos (by linarith : (0 : ℝ) < 2 * m - 6),
      div_le_iff₀ (by linarith : (0 : ℝ) < 2 * m - 6)]
    have h1 := abs_le.mp (hX u)
    have h2 := abs_le.mp hS
    have h3 : |X x u - S x| ≤ 3 * (m * B) / 2 := abs_le.mpr ⟨by linarith, by linarith⟩
    nlinarith [mul_nonneg hB0 (by linarith : (0 : ℝ) ≤ m - 6)]
  have hy : ∀ a b, |y x a b| ≤ 4 * B / (m - 4) := by
    intro a b
    unfold y
    rw [abs_div, abs_of_pos (by linarith : (0 : ℝ) < m - 4)]
    apply div_le_div_of_nonneg_right _ (by linarith)
    have h1 := abs_le.mp (hB a b)
    have h2 := abs_le.mp (hY a)
    have h3 := abs_le.mp (hY b)
    exact abs_le.mpr ⟨by linarith, by linarith⟩
  have h1 := abs_le.mp (hy u v)
  have h2 := abs_le.mp (hy u w)
  have h3 := abs_le.mp (hy v w)
  have hsum : |y x u v + y x u w + y x v w| ≤ 12 * B / (m - 4) := by
    have : 12 * B / (m - 4) = 3 * (4 * B / (m - 4)) := by ring
    rw [this]
    exact abs_le.mpr ⟨by linarith, by linarith⟩
  refine hsum.trans ?_
  rw [div_le_div_iff₀ (by linarith) (by linarith)]
  nlinarith

end ColourStats.TriangleInverse
