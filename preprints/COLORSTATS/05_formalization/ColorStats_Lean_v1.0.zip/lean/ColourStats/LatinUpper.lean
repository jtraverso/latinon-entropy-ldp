/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Bregman
public import ColourStats.Statements
public import Mathlib.NumberTheory.Harmonic.Bounds

/-!
# The upper bound (1.1) of Theorem 1.1 (Section 4.1)

`theorem_1_1_upper`: for fixed numbers of classes, `log #LS(M) ≤ n²(log n − 2 − TC(Q)) +
K n log² n` with `K = 8c`, for every outline `M`, as stated in `Statements.Theorem_1_1`
(including `#LS(M) = 0`).

The proof follows Lemmas 4.1–4.2, organised as one application of the corpus chain rule
(`LinialLuria.chain_bound`) to the Latin squares with outline `M`. The coordinates are the
class pattern `P(r, c) = S(L(r, c))`, revealed first, and then, for each symbol `s` in
increasing order, the permutation `colOf L s` sending a row to the column of `s`.

* The pattern takes at most `#Patt(M) ≤ exp(Σ M log(|R_i||C_j|/M))` values
  (`log_card_Patt_le`, by the weight argument `#Patt · Π q^M ≤ Σ_P Π q = 1`).
* Given the pattern and the earlier symbols, `colOf L s` is a perfect matching of the cells of
  the class of `s` not used by earlier symbols of that class: a `d_s`-regular bipartite graph.
  Brégman's theorem (`Bregman.bregman`) bounds the number of choices by `(d_s!)^{n/d_s}`.
* `Σ_{d ≤ s} log(d!)/d ≤ s log s − 2s + 2(1 + log s)²` (`bregman_sum_le`), from
  `log d! ≤ d log d − d + 1 + log d` and the harmonic bound.
* Under the margins of an actual outline, the main terms add up to exactly
  `n²(log n − 2 − TC(Q))` (`TC_identity`).
* If there is no Latin square, `TC(Q) ≤ a + b` (`TC_le`) makes the right side nonnegative.
-/

@[expose] public section

open Finset

namespace ColourStats.LatinUpper

open ColourStats ColourStats.Statements

/-! ### Analytic bounds -/

lemma log_factorial_le (m : ℕ) (hm : 1 ≤ m) :
    Real.log (m.factorial : ℝ) ≤ m * Real.log m - m + 1 + Real.log m := by
  induction m, hm using Nat.le_induction with
  | base => simp
  | succ m hm ih =>
    have hm0 : (0 : ℝ) < m := by exact_mod_cast hm
    have hm1 : (0 : ℝ) < (m : ℝ) + 1 := by positivity
    have key : 1 ≤ ((m : ℝ) + 1) * (Real.log ((m : ℝ) + 1) - Real.log m) := by
      have h := Real.log_le_sub_one_of_pos (show (0 : ℝ) < m / ((m : ℝ) + 1) by positivity)
      rw [Real.log_div hm0.ne' hm1.ne'] at h
      have e : ((m : ℝ) / ((m : ℝ) + 1) - 1) * ((m : ℝ) + 1) = -1 := by
        rw [sub_mul, div_mul_cancel₀ _ hm1.ne']; ring
      have h2 := mul_le_mul_of_nonneg_right h hm1.le
      rw [e] at h2
      nlinarith
    rw [Nat.factorial_succ, Nat.cast_mul, Real.log_mul (by positivity) (by positivity)]
    push_cast
    nlinarith [ih, key]

lemma term_le (x : ℕ) (hx : 1 ≤ x) :
    Real.log (x.factorial : ℝ) / x ≤ Real.log x - 1 + (1 + Real.log x) / x := by
  have hx0 : (0 : ℝ) < x := by exact_mod_cast hx
  rw [div_le_iff₀ hx0]
  have h := log_factorial_le x hx
  have : (Real.log x - 1 + (1 + Real.log x) / x) * x = x * Real.log x - x + 1 + Real.log x := by
    rw [add_mul, div_mul_cancel₀ _ hx0.ne']; ring
  linarith

/-- `Σ_{d=1}^{s} log(d!)/d ≤ s log s − 2s + 2(1 + log s)²`. -/
lemma bregman_sum_le (s : ℕ) :
    ∑ d ∈ range s, Real.log ((d + 1).factorial : ℝ) / ((d + 1 : ℕ) : ℝ) ≤
      s * Real.log s - 2 * s + 2 * (1 + Real.log s) ^ 2 := by
  rcases Nat.eq_zero_or_pos s with rfl | hs
  · simp
  have hs1 : (1 : ℝ) ≤ s := by exact_mod_cast hs
  have hlogs : 0 ≤ Real.log s := Real.log_nonneg hs1
  have h1 : ∀ d ∈ range s, Real.log ((d + 1).factorial : ℝ) / ((d + 1 : ℕ) : ℝ) ≤
      (Real.log ((d + 1 : ℕ) : ℝ) - 1) + (1 + Real.log s) * (1 / ((d + 1 : ℕ) : ℝ)) := by
    intro d hd
    have hd' := Finset.mem_range.mp hd
    have hle := term_le (d + 1) (by omega)
    have hpos : (0 : ℝ) < ((d + 1 : ℕ) : ℝ) := by positivity
    have hlog : Real.log ((d + 1 : ℕ) : ℝ) ≤ Real.log s :=
      Real.log_le_log hpos (by exact_mod_cast (show d + 1 ≤ s by omega))
    have : (1 + Real.log ((d + 1 : ℕ) : ℝ)) / ((d + 1 : ℕ) : ℝ) ≤
        (1 + Real.log s) * (1 / ((d + 1 : ℕ) : ℝ)) := by
      rw [mul_one_div]
      exact div_le_div_of_nonneg_right (by linarith) hpos.le
    linarith
  refine (Finset.sum_le_sum h1).trans ?_
  have hfac : ∑ d ∈ range s, Real.log ((d + 1 : ℕ) : ℝ) = Real.log (s.factorial : ℝ) := by
    rw [← Real.log_prod (fun m _ => by positivity), ← Nat.cast_prod,
      Finset.prod_range_add_one_eq_factorial]
  have hharm : ∑ d ∈ range s, (1 / ((d + 1 : ℕ) : ℝ)) ≤ 1 + Real.log s := by
    have := harmonic_le_one_add_log s
    simp only [harmonic, Rat.cast_sum, Rat.cast_inv, Rat.cast_natCast] at this
    simpa [one_div] using this
  have hlf := log_factorial_le s hs
  rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum, hfac]
  have hone : ∑ _d ∈ range s, (1 : ℝ) = s := by simp
  rw [hone]
  have hm := mul_le_mul_of_nonneg_left hharm (by linarith : (0 : ℝ) ≤ 1 + Real.log s)
  nlinarith [hlf, hm, hlogs]

/-! ### Total correlation -/

lemma negMulLog_le_one {x : ℝ} (hx : 0 ≤ x) : Real.negMulLog x ≤ 1 := by
  rcases hx.eq_or_lt with h0 | hpos
  · rw [← h0]; simp
  rw [Real.negMulLog]
  have h := Real.one_sub_inv_le_log_of_pos hpos
  have h2 : x * (1 - x⁻¹) = x - 1 := by rw [mul_sub, mul_one, mul_inv_cancel₀ hpos.ne']
  nlinarith [mul_le_mul_of_nonneg_left h hpos.le]

lemma negMulLog_sum_le {ι : Type*} (s : Finset ι) (x : ι → ℝ) (hx : ∀ i ∈ s, 0 ≤ x i) :
    Real.negMulLog (∑ i ∈ s, x i) ≤ ∑ i ∈ s, Real.negMulLog (x i) := by
  simp only [Real.negMulLog]
  rw [neg_mul, Finset.sum_mul, ← Finset.sum_neg_distrib]
  refine Finset.sum_le_sum fun i hi => ?_
  rw [neg_mul, neg_le_neg_iff]
  rcases (hx i hi).eq_or_lt with h0 | hpos
  · rw [← h0]; simp
  exact mul_le_mul_of_nonneg_left (Real.log_le_log hpos (Finset.single_le_sum hx hi)) hpos.le

variable {n a b c : ℕ}

/-- `TC(Q) ≤ a + b` for every nonnegative array. -/
lemma TC_le (Q : Fin a → Fin b → Fin c → ℝ) (hQ : ∀ i j l, 0 ≤ Q i j l) : TC Q ≤ a + b := by
  unfold TC
  have h1 : ∑ i, Real.negMulLog (∑ j, ∑ l, Q i j l) ≤ a := by
    calc _ ≤ ∑ _i : Fin a, (1 : ℝ) := Finset.sum_le_sum fun i _ =>
          negMulLog_le_one (Finset.sum_nonneg fun j _ => Finset.sum_nonneg fun l _ => hQ i j l)
      _ = a := by simp
  have h2 : ∑ j, Real.negMulLog (∑ i, ∑ l, Q i j l) ≤ b := by
    calc _ ≤ ∑ _j : Fin b, (1 : ℝ) := Finset.sum_le_sum fun j _ =>
          negMulLog_le_one (Finset.sum_nonneg fun i _ => Finset.sum_nonneg fun l _ => hQ i j l)
      _ = b := by simp
  have h3 : ∑ l, Real.negMulLog (∑ i, ∑ j, Q i j l) ≤
      ∑ i, ∑ j, ∑ l, Real.negMulLog (Q i j l) := by
    calc _ ≤ ∑ l, ∑ i, ∑ j, Real.negMulLog (Q i j l) := Finset.sum_le_sum fun l _ =>
          (negMulLog_sum_le _ _ fun i _ => Finset.sum_nonneg fun j _ => hQ i j l).trans
            (Finset.sum_le_sum fun i _ => negMulLog_sum_le _ _ fun j _ => hQ i j l)
      _ = _ := by
          rw [Finset.sum_comm]
          exact Finset.sum_congr rfl fun i _ => Finset.sum_comm
  linarith

lemma negMulLog_div' {x N : ℝ} (hx : 0 ≤ x) (hN : 0 < N) :
    Real.negMulLog (x / N) = -(x * Real.log x) / N + x / N * Real.log N := by
  rcases hx.eq_or_lt with h0 | hpos
  · rw [← h0]; simp
  rw [Real.negMulLog, Real.log_div hpos.ne' hN.ne']
  ring

/-- Under the margins, `n² TC(M/n²) = n² log n − n Σ ρ log ρ − n Σ κ log κ − n Σ σ log σ +
Σ M log M`, where `ρ, κ, σ` are the class sizes. -/
lemma TC_identity (M : Fin a → Fin b → Fin c → ℕ) (ρ : Fin a → ℝ) (κ : Fin b → ℝ)
    (σ : Fin c → ℝ) (hn : 0 < n) (hρ : ∀ i, 0 ≤ ρ i) (hκ : ∀ j, 0 ≤ κ j) (hσ : ∀ l, 0 ≤ σ l)
    (hr : ∀ i, ∑ j, ∑ l, (M i j l : ℝ) = n * ρ i) (hc : ∀ j, ∑ i, ∑ l, (M i j l : ℝ) = n * κ j)
    (hs : ∀ l, ∑ i, ∑ j, (M i j l : ℝ) = n * σ l)
    (hρs : ∑ i, ρ i = n) (hκs : ∑ j, κ j = n) (hσs : ∑ l, σ l = n) :
    (n : ℝ) ^ 2 * TC (fun i j l => (M i j l : ℝ) / (n : ℝ) ^ 2) =
      (n : ℝ) ^ 2 * Real.log n - n * ∑ i, ρ i * Real.log (ρ i) -
        n * ∑ j, κ j * Real.log (κ j) - n * ∑ l, σ l * Real.log (σ l) +
          ∑ i, ∑ j, ∑ l, (M i j l : ℝ) * Real.log (M i j l) := by
  have hn0 : (0 : ℝ) < n := by exact_mod_cast hn
  have hn2 : (0 : ℝ) < (n : ℝ) ^ 2 := by positivity
  have hdiv : ∀ x : ℝ, x / (n : ℝ) ^ 2 * n = x / n := fun x => by
    field_simp
  have e1 : ∀ i, ∑ j, ∑ l, (M i j l : ℝ) / (n : ℝ) ^ 2 = ρ i / n := by
    intro i
    simp_rw [← Finset.sum_div]
    rw [hr i]; field_simp
  have e2 : ∀ j, ∑ i, ∑ l, (M i j l : ℝ) / (n : ℝ) ^ 2 = κ j / n := by
    intro j
    simp_rw [← Finset.sum_div]
    rw [hc j]; field_simp
  have e3 : ∀ l, ∑ i, ∑ j, (M i j l : ℝ) / (n : ℝ) ^ 2 = σ l / n := by
    intro l
    simp_rw [← Finset.sum_div]
    rw [hs l]; field_simp
  have htot : ∑ i, ∑ j, ∑ l, (M i j l : ℝ) = (n : ℝ) ^ 2 := by
    calc ∑ i, ∑ j, ∑ l, (M i j l : ℝ) = ∑ i, (n : ℝ) * ρ i := Finset.sum_congr rfl fun i _ => hr i
      _ = (n : ℝ) ^ 2 := by rw [← Finset.mul_sum, hρs]; ring
  unfold TC
  simp only [e1, e2, e3]
  simp only [negMulLog_div' (hρ _) hn0, negMulLog_div' (hκ _) hn0, negMulLog_div' (hσ _) hn0,
    negMulLog_div' (Nat.cast_nonneg _) hn2]
  simp only [Finset.sum_add_distrib, ← Finset.sum_div, ← Finset.sum_mul, Finset.sum_neg_distrib]
  rw [hρs, hκs, hσs, htot, Real.log_pow]
  field_simp
  ring

/-! ### Patterns -/

/-- The class pattern of a square. -/
def pat (Sy : Fin n → Fin c) (L : Fin n → Fin n → Fin n) : Fin n × Fin n → Fin c :=
  fun rc => Sy (L rc.1 rc.2)

/-- The number of cells of class `l` in the block `R_i × C_j` of a pattern. -/
noncomputable def blockCount (R : Fin n → Fin a) (C : Fin n → Fin b) (P : Fin n × Fin n → Fin c)
    (i : Fin a) (j : Fin b) (l : Fin c) : ℕ := by
  classical
  exact (univ.filter fun rc : Fin n × Fin n => R rc.1 = i ∧ C rc.2 = j ∧ P rc = l).card

lemma outline_eq (R : Fin n → Fin a) (C : Fin n → Fin b) (Sy : Fin n → Fin c)
    (L : Fin n → Fin n → Fin n) : outline R C Sy L = blockCount R C (pat Sy L) := rfl

/-- The patterns with block counts `M`. -/
noncomputable def Patt (R : Fin n → Fin a) (C : Fin n → Fin b) (M : Fin a → Fin b → Fin c → ℕ) :
    Finset (Fin n × Fin n → Fin c) := by
  classical
  exact univ.filter fun P => ∀ i j l, blockCount R C P i j l = M i j l

lemma mem_Patt {R : Fin n → Fin a} {C : Fin n → Fin b} {M : Fin a → Fin b → Fin c → ℕ}
    {P : Fin n × Fin n → Fin c} : P ∈ Patt R C M ↔ ∀ i j l, blockCount R C P i j l = M i j l := by
  classical
  unfold Patt
  simp

/-- The weight `q(i, j, l) = M(i, j, l)/(|R_i||C_j|)`. -/
noncomputable def qf (R : Fin n → Fin a) (C : Fin n → Fin b) (M : Fin a → Fin b → Fin c → ℕ)
    (t : Fin a × Fin b × Fin c) : ℝ :=
  (M t.1 t.2.1 t.2.2 : ℝ) / ((csize R t.1 * csize C t.2.1 : ℕ) : ℝ)

/-- **The number of patterns.** `log #Patt(M) ≤ Σ_{i,j,l} M log(|R_i||C_j| / M)`. -/
theorem log_card_Patt_le (R : Fin n → Fin a) (C : Fin n → Fin b)
    (M : Fin a → Fin b → Fin c → ℕ) (hB : ∀ i j, 0 < csize R i * csize C j)
    (hM : ∀ i j l, 0 < M i j l) (hmarg : ∀ i j, ∑ l, M i j l = csize R i * csize C j)
    (hne : (Patt R C M).Nonempty) :
    Real.log (Patt R C M).card ≤
      ∑ i, ∑ j, ∑ l, (M i j l : ℝ) * Real.log ((csize R i * csize C j : ℕ) / (M i j l : ℝ)) := by
  have hq : ∀ t, 0 < qf R C M t := fun t =>
    div_pos (by exact_mod_cast hM _ _ _) (by exact_mod_cast hB _ _)
  have htot : ∏ rc : Fin n × Fin n, ∑ l, qf R C M (R rc.1, C rc.2, l) = 1 :=
    Finset.prod_eq_one fun rc _ => by
      simp only [qf]
      rw [← Finset.sum_div, ← Nat.cast_sum, hmarg]
      exact div_self (by exact_mod_cast (hB _ _).ne')
  rw [Fintype.prod_sum] at htot
  set W : ℝ := ∏ t : Fin a × Fin b × Fin c, qf R C M t ^ (M t.1 t.2.1 t.2.2) with hWdef
  have hW : ∀ P ∈ Patt R C M, ∏ rc, qf R C M (R rc.1, C rc.2, P rc) = W := by
    intro P hP
    have hP' := mem_Patt.mp hP
    calc ∏ rc, qf R C M (R rc.1, C rc.2, P rc)
        = ∏ t : Fin a × Fin b × Fin c,
            ∏ rc ∈ (univ : Finset (Fin n × Fin n)) with (R rc.1, C rc.2, P rc) = t,
              qf R C M t :=
          (Finset.prod_fiberwise_of_maps_to' (s := univ) (t := univ)
            (g := fun rc => (R rc.1, C rc.2, P rc)) (fun _ _ => mem_univ _) (qf R C M)).symm
      _ = W := by
          refine Finset.prod_congr rfl fun t _ => ?_
          rw [Finset.prod_const]
          congr 1
          obtain ⟨i, j, l⟩ := t
          rw [← hP' i j l]
          unfold blockCount
          congr 1
  have hWpos : 0 < W := Finset.prod_pos fun t _ => pow_pos (hq t) _
  have hle : ((Patt R C M).card : ℝ) * W ≤ 1 := by
    rw [← htot]
    calc ((Patt R C M).card : ℝ) * W = ∑ P ∈ Patt R C M, W := by
          rw [Finset.sum_const, nsmul_eq_mul]
      _ = ∑ P ∈ Patt R C M, ∏ rc, qf R C M (R rc.1, C rc.2, P rc) :=
          Finset.sum_congr rfl fun P hP => (hW P hP).symm
      _ ≤ _ :=
          Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) fun P _ _ =>
            Finset.prod_nonneg fun rc _ => (hq _).le
  have hcard : (0 : ℝ) < (Patt R C M).card := by exact_mod_cast hne.card_pos
  have hlog := Real.log_le_log (mul_pos hcard hWpos) hle
  rw [Real.log_mul hcard.ne' hWpos.ne', Real.log_one] at hlog
  have hlogW : Real.log W = ∑ i, ∑ j, ∑ l, (M i j l : ℝ) * Real.log (qf R C M (i, j, l)) := by
    rw [hWdef, Real.log_prod (fun t _ => (pow_pos (hq t) _).ne')]
    simp only [Real.log_pow, Fintype.sum_prod_type]
  have hrel : ∀ i j l, (M i j l : ℝ) * Real.log ((csize R i * csize C j : ℕ) / (M i j l : ℝ)) =
      -((M i j l : ℝ) * Real.log (qf R C M (i, j, l))) := by
    intro i j l
    have h1 : (0 : ℝ) < M i j l := by exact_mod_cast hM i j l
    have h2 : (0 : ℝ) < ((csize R i * csize C j : ℕ) : ℝ) := by exact_mod_cast hB i j
    simp only [qf]
    rw [Real.log_div h2.ne' h1.ne', Real.log_div h1.ne' h2.ne']
    ring
  simp only [hrel, Finset.sum_neg_distrib]
  linarith

/-! ### The chain rule over symbols -/

open Classical in
/-- The column of the symbol `s` in the row `r`. -/
noncomputable def colOf (L : Fin n → Fin n → Fin n) (s r : Fin n) : Fin n :=
  if h : ∃ c, L r c = s then h.choose else r

lemma colOf_spec {L : Fin n → Fin n → Fin n} (hL : STS.IsLatin L) (s r : Fin n) :
    L r (colOf L s r) = s := by
  have h : ∃ c, L r c = s := (hL.1 r).2 s
  unfold colOf
  rw [dif_pos h]
  exact h.choose_spec

lemma colOf_eq {L : Fin n → Fin n → Fin n} (hL : STS.IsLatin L) {s r c : Fin n}
    (h : L r c = s) : colOf L s r = c :=
  (hL.1 r).1 ((colOf_spec hL s r).trans h.symm)

lemma colOf_inj {L : Fin n → Fin n → Fin n} (hL : STS.IsLatin L) (s : Fin n) :
    Function.Injective (colOf L s) := by
  intro r r' h
  have h1 := colOf_spec hL s r
  have h2 := colOf_spec hL s r'
  rw [h] at h1
  exact (hL.2 (colOf L s r')).1 (h1.trans h2.symm)

/-- The reveal order: the pattern first, then the symbols in increasing order. -/
def keyO : Option (Fin n) → ℕ
  | none => 0
  | some s => s.val + 1

/-- The coordinates: the pattern, and the permutation of each symbol. -/
noncomputable def coord (Sy : Fin n → Fin c) :
    Option (Fin n) → (Fin n → Fin n → Fin n) → ((Fin n × Fin n → Fin c) ⊕ (Fin n → Fin n))
  | none, L => Sum.inl (pat Sy L)
  | some s, L => Sum.inr (colOf L s)

open Classical in
/-- The Latin squares with outline `M`. -/
noncomputable def LSset (R : Fin n → Fin a) (C : Fin n → Fin b) (Sy : Fin n → Fin c)
    (M : Fin a → Fin b → Fin c → ℕ) : Finset (Fin n → Fin n → Fin n) :=
  univ.filter fun L => STS.IsLatin L ∧ outline R C Sy L = M

lemma mem_LSset {R : Fin n → Fin a} {C : Fin n → Fin b} {Sy : Fin n → Fin c}
    {M : Fin a → Fin b → Fin c → ℕ} {L : Fin n → Fin n → Fin n} :
    L ∈ LSset R C Sy M ↔ STS.IsLatin L ∧ outline R C Sy L = M := by
  classical
  unfold LSset
  simp

lemma numLS_eq (R : Fin n → Fin a) (C : Fin n → Fin b) (Sy : Fin n → Fin c)
    (M : Fin a → Fin b → Fin c → ℕ) : numLS R C Sy M = (LSset R C Sy M).card := by
  unfold numLS
  exact Nat.subtype_card _ fun L => mem_LSset

/-- The cells available to the symbol `s`: of the class of `s`, and not used by an earlier
symbol. -/
def Aset (Sy : Fin n → Fin c) (L : Fin n → Fin n → Fin n) (s r : Fin n) : Finset (Fin n) :=
  univ.filter fun c => Sy (L r c) = Sy s ∧ s ≤ L r c

/-- `d_s`: the number of symbols of the class of `s` not before `s`. -/
def dcount (Sy : Fin n → Fin c) (s : Fin n) : ℕ :=
  (univ.filter fun s' => Sy s' = Sy s ∧ s ≤ s').card

lemma card_Aset {Sy : Fin n → Fin c} {L : Fin n → Fin n → Fin n} (hL : STS.IsLatin L)
    (s r : Fin n) : (Aset Sy L s r).card = dcount Sy s := by
  rw [← Finset.card_image_of_injective _ (hL.1 r).1]
  congr 1
  ext s'
  simp only [Aset, Finset.mem_image, Finset.mem_filter, mem_univ, true_and]
  constructor
  · rintro ⟨c, hc, rfl⟩; exact hc
  · intro hs'
    obtain ⟨c, rfl⟩ := (hL.1 r).2 s'
    exact ⟨c, hs', rfl⟩

/-- **The chain rule bound for Latin squares with outline `M`.** -/
theorem log_LSset_le (R : Fin n → Fin a) (C : Fin n → Fin b) (Sy : Fin n → Fin c)
    (M : Fin a → Fin b → Fin c → ℕ) (hne : (LSset R C Sy M).Nonempty) :
    Real.log (LSset R C Sy M).card ≤ Real.log (Patt R C M).card +
      ∑ s : Fin n, (n : ℝ) * (Real.log ((dcount Sy s).factorial : ℝ) / dcount Sy s) := by
  classical
  set S := LSset R C Sy M with hSdef
  have hSpos : (0 : ℝ) < S.card := by exact_mod_cast hne.card_pos
  have hkey : Set.InjOn (keyO (n := n)) (univ : Finset (Option (Fin n))) := by
    intro o _ o' _ h
    cases o <;> cases o' <;> simp_all [keyO, Fin.ext_iff]
  have hdet : ∀ x ∈ S, ∀ y ∈ S, (∀ o ∈ (univ : Finset (Option (Fin n))),
      coord Sy o x = coord Sy o y) → x = y := by
    intro x hx y hy h
    have hxL := (mem_LSset.mp hx).1
    have hyL := (mem_LSset.mp hy).1
    funext r c
    have h1 : coord Sy (some (x r c)) x = coord Sy (some (x r c)) y := h _ (mem_univ _)
    simp only [coord, Sum.inr.injEq] at h1
    have h2 : colOf y (x r c) r = c := by rw [← h1]; exact colOf_eq hxL rfl
    have h3 := colOf_spec hyL (x r c) r
    rw [h2] at h3
    exact h3.symm
  have hchain := LinialLuria.chain_bound keyO (coord Sy) univ S hkey hdet
  set B : ℝ := Real.log (Patt R C M).card +
    ∑ s : Fin n, (n : ℝ) * (Real.log ((dcount Sy s).factorial : ℝ) / dcount Sy s)
  have hx : ∀ x ∈ S, ∑ o ∈ (univ : Finset (Option (Fin n))),
      Real.log ((LinialLuria.agreeSet S univ keyO (coord Sy) o x).image (coord Sy o)).card ≤ B := by
    intro x hxS
    have hxL := (mem_LSset.mp hxS).1
    have hself : ∀ o, x ∈ LinialLuria.agreeSet S univ keyO (coord Sy) o x := fun o =>
      LinialLuria.mem_agreeSet.mpr ⟨hxS, fun _ _ _ => rfl⟩
    have hpos : ∀ o, (0 : ℝ) <
        ((LinialLuria.agreeSet S univ keyO (coord Sy) o x).image (coord Sy o)).card := fun o => by
      exact_mod_cast (Finset.Nonempty.image ⟨x, hself o⟩ _).card_pos
    rw [Fintype.sum_option]
    refine add_le_add ?_ (Finset.sum_le_sum fun s _ => ?_)
    · -- the pattern
      refine Real.log_le_log (hpos none) ?_
      have hsub : (LinialLuria.agreeSet S univ keyO (coord Sy) none x).image (coord Sy none) ⊆
          (Patt R C M).image Sum.inl := by
        intro v hv
        obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hv
        have hyS := (LinialLuria.mem_agreeSet.mp hy).1
        refine Finset.mem_image.mpr ⟨pat Sy y, mem_Patt.mpr fun i j l => ?_, rfl⟩
        rw [← outline_eq, (mem_LSset.mp hyS).2]
      exact_mod_cast (Finset.card_le_card hsub).trans Finset.card_image_le
    · -- the symbol `s`
      have hsub : (LinialLuria.agreeSet S univ keyO (coord Sy) (some s) x).image
          (coord Sy (some s)) ⊆ (Bregman.PM (Aset Sy x s)).image Sum.inr := by
        intro v hv
        obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hv
        obtain ⟨hyS, hagree⟩ := LinialLuria.mem_agreeSet.mp hy
        have hyL := (mem_LSset.mp hyS).1
        have hpat : pat Sy y = pat Sy x := by
          have := hagree none (mem_univ _) (by simp [keyO])
          simpa [coord] using this
        have hcol : ∀ s', s' < s → colOf y s' = colOf x s' := by
          intro s' hs'
          have := hagree (some s') (mem_univ _) (by simp [keyO]; exact hs')
          simpa [coord] using this
        refine Finset.mem_image.mpr ⟨colOf y s, Bregman.mem_PM.mpr ⟨colOf_inj hyL s, ?_⟩, rfl⟩
        intro r
        have hyc : y r (colOf y s r) = s := colOf_spec hyL s r
        have hP : Sy (y r (colOf y s r)) = Sy (x r (colOf y s r)) :=
          congrFun hpat (r, colOf y s r)
        refine Finset.mem_filter.mpr ⟨mem_univ _, by rw [← hP, hyc], ?_⟩
        by_contra hlt
        rw [not_le] at hlt
        have h1 : colOf x (x r (colOf y s r)) r = colOf y s r := colOf_eq hxL rfl
        have h2 : y r (colOf y (x r (colOf y s r)) r) = x r (colOf y s r) :=
          colOf_spec hyL (x r (colOf y s r)) r
        rw [hcol _ hlt, h1, hyc] at h2
        rw [← h2] at hlt
        exact lt_irrefl _ hlt
      have hcard := (Finset.card_le_card hsub).trans Finset.card_image_le
      have hbreg := Bregman.bregman (Aset Sy x s)
      simp only [card_Aset hxL, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
        nsmul_eq_mul] at hbreg
      have hPMpos : (0 : ℝ) < (Bregman.PM (Aset Sy x s)).card :=
        (hpos (some s)).trans_le (by exact_mod_cast hcard)
      exact (Real.log_le_log (hpos (some s)) (by exact_mod_cast hcard)).trans hbreg
  have hsum : (S.card : ℝ) * Real.log S.card ≤ S.card * B := by
    refine hchain.trans ?_
    calc _ ≤ ∑ x ∈ S, B := Finset.sum_le_sum hx
      _ = S.card * B := by rw [Finset.sum_const, nsmul_eq_mul]
  exact le_of_mul_le_mul_left hsum hSpos

/-! ### Regrouping the symbols by class -/

lemma csize_eq {m : ℕ} (P : Fin n → Fin m) (i : Fin m) :
    csize P i = (univ.filter fun v => P v = i).card := by
  unfold csize; rfl

lemma sum_csize {m : ℕ} (P : Fin n → Fin m) : ∑ i, csize P i = n := by
  simp only [csize_eq]
  rw [← Finset.card_eq_sum_card_fiberwise (fun _ _ => mem_univ _)]
  simp

lemma sum_dcount (Sy : Fin n → Fin c) (h : ℕ → ℝ) :
    ∑ s, h (dcount Sy s) = ∑ l, ∑ d ∈ range (csize Sy l), h (d + 1) := by
  rw [← Finset.sum_fiberwise (univ : Finset (Fin n)) Sy fun s => h (dcount Sy s)]
  refine Finset.sum_congr rfl fun l _ => ?_
  set A := (univ : Finset (Fin n)).filter fun s => Sy s = l with hA
  have hd : ∀ s ∈ A, dcount Sy s = A.card - Bregman.rank A 1 s := by
    intro s hs
    have hsl : Sy s = l := (Finset.mem_filter.mp hs).2
    have hsplit := Finset.card_filter_add_card_filter_not (s := A)
      (fun j => (1 : Equiv.Perm (Fin n)) j < (1 : Equiv.Perm (Fin n)) s)
    have : dcount Sy s =
        (A.filter fun j => ¬ (1 : Equiv.Perm (Fin n)) j < (1 : Equiv.Perm (Fin n)) s).card := by
      unfold dcount
      congr 1
      ext j
      simp [hA, hsl]
    have hr : Bregman.rank A 1 s =
        (A.filter fun j => (1 : Equiv.Perm (Fin n)) j < (1 : Equiv.Perm (Fin n)) s).card := rfl
    omega
  calc ∑ s ∈ A, h (dcount Sy s) = ∑ s ∈ A, (fun m => h (A.card - m)) (Bregman.rank A 1 s) :=
        Finset.sum_congr rfl fun s hs => by rw [hd s hs]
    _ = ∑ m ∈ range A.card, h (A.card - m) := Bregman.sum_rank_on A 1 (fun m => h (A.card - m))
    _ = ∑ m ∈ range A.card, h (A.card - 1 - m + 1) := by
        refine Finset.sum_congr rfl fun m hm => ?_
        have := Finset.mem_range.mp hm
        rw [show A.card - m = A.card - 1 - m + 1 by omega]
    _ = ∑ d ∈ range A.card, h (d + 1) := Finset.sum_range_reflect (fun d => h (d + 1)) A.card
    _ = _ := by rw [csize_eq]

/-! ### Margins of an outline -/

lemma margin_rc (R : Fin n → Fin a) (C : Fin n → Fin b) (Sy : Fin n → Fin c)
    (L : Fin n → Fin n → Fin n) (i : Fin a) (j : Fin b) :
    ∑ l, outline R C Sy L i j l = csize R i * csize C j := by
  classical
  rw [outline_eq]
  unfold blockCount
  have : ((univ : Finset (Fin n × Fin n)).filter fun rc => R rc.1 = i ∧ C rc.2 = j).card =
      csize R i * csize C j := by
    rw [csize_eq, csize_eq, ← Finset.card_product]
    congr 1
    ext ⟨r, c⟩
    simp
  rw [← this, Finset.card_eq_sum_card_fiberwise (f := pat Sy L) (t := univ)
    (fun _ _ => mem_univ _)]
  refine Finset.sum_congr rfl fun l _ => ?_
  rw [Finset.filter_filter]
  congr 1
  apply Finset.filter_congr
  intro rc _
  tauto

lemma margin_s (R : Fin n → Fin a) (C : Fin n → Fin b) (Sy : Fin n → Fin c)
    {L : Fin n → Fin n → Fin n} (hL : STS.IsLatin L) (l : Fin c) :
    ∑ i, ∑ j, outline R C Sy L i j l = n * csize Sy l := by
  classical
  rw [outline_eq]
  unfold blockCount
  have h1 : ∑ i, ∑ j, ((univ : Finset (Fin n × Fin n)).filter fun rc =>
      R rc.1 = i ∧ C rc.2 = j ∧ pat Sy L rc = l).card =
      ((univ : Finset (Fin n × Fin n)).filter fun rc => pat Sy L rc = l).card := by
    rw [eq_comm, Finset.card_eq_sum_card_fiberwise (f := fun rc : Fin n × Fin n => (R rc.1, C rc.2))
      (t := univ) (fun _ _ => mem_univ _), Fintype.sum_prod_type]
    refine Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ => ?_
    rw [Finset.filter_filter]
    congr 1
    apply Finset.filter_congr
    intro rc _
    simp only [Prod.mk.injEq]
    tauto
  rw [h1]
  have h2 : ((univ : Finset (Fin n × Fin n)).filter fun rc => pat Sy L rc = l).card =
      ∑ r : Fin n, ((univ : Finset (Fin n)).filter fun c => Sy (L r c) = l).card := by
    rw [Finset.card_filter, Fintype.sum_prod_type]
    refine Finset.sum_congr rfl fun r _ => ?_
    rw [Finset.card_filter]
    rfl
  rw [h2]
  have h3 : ∀ r, ((univ : Finset (Fin n)).filter fun c => Sy (L r c) = l).card = csize Sy l := by
    intro r
    rw [csize_eq, ← Finset.card_image_of_injective _ (hL.1 r).1]
    congr 1
    ext s
    simp only [Finset.mem_image, Finset.mem_filter, mem_univ, true_and]
    constructor
    · rintro ⟨c, hc, rfl⟩; exact hc
    · intro hs
      obtain ⟨c, rfl⟩ := (hL.1 r).2 s
      exact ⟨c, hs, rfl⟩
  simp only [h3, Finset.sum_const, Finset.card_univ, Fintype.card_fin, smul_eq_mul]

/-! ### The upper bound (1.1) -/

/-- The upper half (1.1) of Theorem 1.1, as stated there. -/
def Theorem_1_1_upper : Prop :=
  ∀ a b c : ℕ, ∀ δ₀ ζ : ℝ, 0 < δ₀ → 0 < ζ →
    ∃ K : ℝ, ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → ∀ (R : Fin n → Fin a) (C : Fin n → Fin b)
        (S : Fin n → Fin c) (M : Fin a → Fin b → Fin c → ℕ), LSHyp δ₀ ζ R C S M →
        Real.log (numLS R C S M) ≤ (n : ℝ) ^ 2 *
          (Real.log n - 2 - TC (fun i j l => (M i j l : ℝ) / (n : ℝ) ^ 2)) +
            K * n * (Real.log n) ^ 2

/-- **The upper bound (1.1).** -/
theorem theorem_1_1_upper : Theorem_1_1_upper := by
  intro a b c δ₀ ζ hδ hζ
  refine ⟨8 * c, max 3 ⌈Real.exp (2 + a + b)⌉₊, fun n hn R C Sy M hyp => ?_⟩
  have hn3 : 3 ≤ n := le_of_max_le_left hn
  have hn0 : (0 : ℝ) < n := by exact_mod_cast (show 0 < n by omega)
  have hlog1 : 1 ≤ Real.log n := by
    rw [Real.le_log_iff_exp_le hn0]
    have := Real.exp_one_lt_d9
    have : (3 : ℝ) ≤ n := by exact_mod_cast hn3
    linarith
  have hlog2 : 2 + a + b ≤ Real.log n := by
    rw [Real.le_log_iff_exp_le hn0]
    exact (Nat.le_ceil _).trans (by exact_mod_cast le_of_max_le_right hn)
  have hKnn : 0 ≤ (8 * c : ℝ) * n * Real.log n ^ 2 := by positivity
  rw [numLS_eq]
  rcases (LSset R C Sy M).eq_empty_or_nonempty with h0 | hne
  · rw [h0, Finset.card_empty, Nat.cast_zero, Real.log_zero]
    have hTC := TC_le (fun i j l => (M i j l : ℝ) / (n : ℝ) ^ 2) fun _ _ _ => by positivity
    have : 0 ≤ Real.log n - 2 - TC (fun i j l => (M i j l : ℝ) / (n : ℝ) ^ 2) := by linarith
    have := mul_nonneg (sq_nonneg (n : ℝ)) this
    linarith
  obtain ⟨x, hx⟩ := hne
  obtain ⟨hxL, hxM⟩ := mem_LSset.mp hx
  obtain ⟨hR, hC, hS, hQ⟩ := hyp
  -- positivity
  have hRpos : ∀ i, 0 < csize R i := fun i => by
    have : (0 : ℝ) < csize R i := lt_of_lt_of_le (by positivity) (hR i)
    exact_mod_cast this
  have hCpos : ∀ j, 0 < csize C j := fun j => by
    have : (0 : ℝ) < csize C j := lt_of_lt_of_le (by positivity) (hC j)
    exact_mod_cast this
  have hSpos : ∀ l, 0 < csize Sy l := fun l => by
    have : (0 : ℝ) < csize Sy l := lt_of_lt_of_le (by positivity) (hS l)
    exact_mod_cast this
  have hMpos : ∀ i j l, 0 < M i j l := fun i j l => by
    have h := hQ i j l
    have : (0 : ℝ) < (M i j l : ℝ) / (n : ℝ) ^ 2 := lt_of_lt_of_le hζ h
    have : (0 : ℝ) < M i j l := by
      by_contra hc
      push_neg at hc
      have : (M i j l : ℝ) / (n : ℝ) ^ 2 ≤ 0 := div_nonpos_of_nonpos_of_nonneg hc (by positivity)
      linarith
    exact_mod_cast this
  -- margins
  have m1 : ∀ i j, ∑ l, M i j l = csize R i * csize C j := fun i j => by
    rw [← hxM]; exact margin_rc R C Sy x i j
  have m3 : ∀ l, ∑ i, ∑ j, M i j l = n * csize Sy l := fun l => by
    rw [← hxM]; exact margin_s R C Sy hxL l
  -- the two bounds
  have hPne : (Patt R C M).Nonempty := ⟨pat Sy x, mem_Patt.mpr fun i j l => by
    rw [← outline_eq, hxM]⟩
  have hchain := log_LSset_le R C Sy M ⟨x, hx⟩
  have hpatt := log_card_Patt_le R C M (fun i j => Nat.mul_pos (hRpos i) (hCpos j)) hMpos m1 hPne
  have hbreg : ∑ s : Fin n, (n : ℝ) * (Real.log ((dcount Sy s).factorial : ℝ) / dcount Sy s) ≤
      n * ∑ l, ((csize Sy l : ℝ) * Real.log (csize Sy l) - 2 * csize Sy l +
        2 * (1 + Real.log (csize Sy l)) ^ 2) := by
    rw [← Finset.mul_sum]
    refine mul_le_mul_of_nonneg_left ?_ hn0.le
    rw [sum_dcount Sy (fun d => Real.log (d.factorial : ℝ) / d)]
    exact Finset.sum_le_sum fun l _ => bregman_sum_le (csize Sy l)
  -- the identity
  have hρs : ∑ i, (csize R i : ℝ) = n := by exact_mod_cast sum_csize R
  have hκs : ∑ j, (csize C j : ℝ) = n := by exact_mod_cast sum_csize C
  have hσs : ∑ l, (csize Sy l : ℝ) = n := by exact_mod_cast sum_csize Sy
  have hm1R : ∀ i j, ∑ l, (M i j l : ℝ) = (csize R i : ℝ) * csize C j := fun i j => by
    exact_mod_cast m1 i j
  have hr : ∀ i, ∑ j, ∑ l, (M i j l : ℝ) = n * (csize R i : ℝ) := fun i => by
    simp only [hm1R]; rw [← Finset.mul_sum, hκs]; ring
  have hc : ∀ j, ∑ i, ∑ l, (M i j l : ℝ) = n * (csize C j : ℝ) := fun j => by
    simp only [hm1R]; rw [← Finset.sum_mul, hρs]
  have hs : ∀ l, ∑ i, ∑ j, (M i j l : ℝ) = n * (csize Sy l : ℝ) := fun l => by
    exact_mod_cast m3 l
  have hTC := TC_identity M (fun i => (csize R i : ℝ)) (fun j => (csize C j : ℝ))
    (fun l => (csize Sy l : ℝ)) (by omega) (fun _ => Nat.cast_nonneg _)
    (fun _ => Nat.cast_nonneg _) (fun _ => Nat.cast_nonneg _) hr hc hs hρs hκs hσs
  beta_reduce at hTC
  have hA : ∑ i, ∑ j, ∑ l, (M i j l : ℝ) * Real.log ((csize R i * csize C j : ℕ) / (M i j l : ℝ)) =
      n * ∑ i, (csize R i : ℝ) * Real.log (csize R i) +
        n * ∑ j, (csize C j : ℝ) * Real.log (csize C j) -
          ∑ i, ∑ j, ∑ l, (M i j l : ℝ) * Real.log (M i j l) := by
    have hterm : ∀ i j l,
        (M i j l : ℝ) * Real.log ((csize R i * csize C j : ℕ) / (M i j l : ℝ)) =
          (M i j l : ℝ) * Real.log (csize R i) + (M i j l : ℝ) * Real.log (csize C j) -
            (M i j l : ℝ) * Real.log (M i j l) := by
      intro i j l
      have h1 : (0 : ℝ) < M i j l := by exact_mod_cast hMpos i j l
      have h2 : (0 : ℝ) < csize R i := by exact_mod_cast hRpos i
      have h3 : (0 : ℝ) < csize C j := by exact_mod_cast hCpos j
      rw [Nat.cast_mul, Real.log_div (by positivity) h1.ne', Real.log_mul h2.ne' h3.ne']
      ring
    simp only [hterm, Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.sum_mul, hm1R]
    have e1 : ∑ i, (∑ j, (csize R i : ℝ) * csize C j) * Real.log (csize R i) =
        n * ∑ i, (csize R i : ℝ) * Real.log (csize R i) := by
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun i _ => ?_
      rw [← Finset.mul_sum, hκs]
      ring
    have e2 : ∑ i, ∑ j, (csize R i : ℝ) * csize C j * Real.log (csize C j) =
        n * ∑ j, (csize C j : ℝ) * Real.log (csize C j) := by
      rw [Finset.sum_comm, Finset.mul_sum]
      refine Finset.sum_congr rfl fun j _ => ?_
      rw [← Finset.sum_mul, ← Finset.sum_mul, hρs]
      ring
    rw [e1, e2]
  -- the error term
  have herr : 2 * ∑ l, (1 + Real.log (csize Sy l)) ^ 2 ≤ c * (8 * Real.log n ^ 2) := by
    rw [Finset.mul_sum]
    calc _ ≤ ∑ _l : Fin c, 8 * Real.log n ^ 2 := Finset.sum_le_sum fun l _ => by
          have hσ1 : (1 : ℝ) ≤ csize Sy l := by exact_mod_cast hSpos l
          have hσn : (csize Sy l : ℝ) ≤ n := by
            rw [← hσs]
            exact Finset.single_le_sum (f := fun l => (csize Sy l : ℝ))
              (fun l _ => Nat.cast_nonneg _) (mem_univ l)
          have h0 : 0 ≤ Real.log (csize Sy l) := Real.log_nonneg hσ1
          have h1 : Real.log (csize Sy l) ≤ Real.log n := Real.log_le_log (by linarith) hσn
          have h2 : 1 + Real.log (csize Sy l) ≤ 2 * Real.log n := by linarith
          have h3 := pow_le_pow_left₀ (by linarith) h2 2
          nlinarith [h3]
      _ = c * (8 * Real.log n ^ 2) := by simp
  -- assembly
  have hbreg' : ∑ s : Fin n, (n : ℝ) * (Real.log ((dcount Sy s).factorial : ℝ) / dcount Sy s) ≤
      n * ∑ l, (csize Sy l : ℝ) * Real.log (csize Sy l) - 2 * (n : ℝ) ^ 2 +
        8 * c * n * Real.log n ^ 2 := by
    refine hbreg.trans ?_
    simp only [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum]
    rw [hσs]
    have hn' : (0 : ℝ) ≤ n := hn0.le
    nlinarith [mul_le_mul_of_nonneg_left herr hn']
  have hgoal : (n : ℝ) ^ 2 * (Real.log n - 2 - TC (fun i j l => (M i j l : ℝ) / (n : ℝ) ^ 2)) =
      (n : ℝ) ^ 2 * Real.log n - 2 * n ^ 2 - (n : ℝ) ^ 2 *
        TC (fun i j l => (M i j l : ℝ) / (n : ℝ) ^ 2) := by ring
  rw [hgoal, hTC]
  linarith [hchain, hpatt, hA, hbreg']

/-- Theorem 1.1 follows from its lower half (1.2). -/
theorem theorem_1_1_of_lower
    (hlow : ∀ a b c : ℕ, ∀ δ₀ ζ : ℝ, 0 < δ₀ → 0 < ζ →
      ∀ ε : ℝ, 0 < ε → ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → ∀ (R : Fin n → Fin a) (C : Fin n → Fin b)
        (S : Fin n → Fin c) (M : Fin a → Fin b → Fin c → ℕ), LSHyp δ₀ ζ R C S M →
        OutlineMargins R C S M →
        (n : ℝ) ^ 2 * (Real.log n - 2 - TC (fun i j l => (M i j l : ℝ) / (n : ℝ) ^ 2)) -
          ε * (n : ℝ) ^ 2 ≤ Real.log (numLS R C S M)) :
    Theorem_1_1 := fun a b c δ₀ ζ hδ hζ =>
  ⟨theorem_1_1_upper a b c δ₀ ζ hδ hζ, hlow a b c δ₀ ζ hδ hζ⟩

end ColourStats.LatinUpper
