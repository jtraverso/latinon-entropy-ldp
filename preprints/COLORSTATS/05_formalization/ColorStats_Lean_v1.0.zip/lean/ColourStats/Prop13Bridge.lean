/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Prop13
public import ColourStats.TypeCount

/-!
# Proposition 1.3 for the rate of Theorem 1.2

`Challenge.Phi lab (bicolTypes t)`, the rate in the statement `Theorem_1_2`, is the rate
`Prop13.Phi` of the class sizes (`Phi_bicolTypes`). With Proposition 1.3 this gives the
normalised form of the rate of Theorem 1.2 (`prop_1_3_bicol`).
-/

@[expose] public section

open Finset Real

namespace ColourStats

variable {n k : ℕ}

lemma count_XXY {X Y Z : Fin k} :
    ({X, X, Y} : Multiset (Fin k)).count Z = 2 * (if Z = X then 1 else 0) +
      (if Z = Y then 1 else 0) := by
  simp only [Multiset.insert_eq_cons, Multiset.count_cons, Multiset.count_singleton]
  split_ifs <;> omega

lemma XXY_inj {X Y X' Y' : Fin k} (hXY : X ≠ Y) (_hX'Y' : X' ≠ Y')
    (h : ({X, X, Y} : Multiset (Fin k)) = {X', X', Y'}) : X = X' ∧ Y = Y' := by
  have c1 := congrArg (Multiset.count X) h
  rw [count_XXY, count_XXY] at c1
  by_cases h1 : X = X'
  · subst h1
    refine ⟨rfl, ?_⟩
    have h' := h
    simp only [Multiset.insert_eq_cons] at h'
    exact Multiset.singleton_inj.mp
      ((Multiset.cons_inj_right _).mp ((Multiset.cons_inj_right _).mp h'))
  · exfalso
    by_cases h3 : X = Y'
    · subst h3; simp [hXY, h1] at c1
    · simp [h1, h3, hXY] at c1

lemma bicolTypes_XXY (t : Fin k → Fin k → ℕ) {A B : Fin k} (hAB : A ≠ B) :
    bicolTypes t {A, A, B} = t A B := by
  unfold bicolTypes
  rw [Finset.sum_eq_single A]
  · rw [Finset.sum_eq_single B]
    · simp [hAB]
    · intro Y _ hY
      rw [if_neg]
      rintro ⟨hAY, h⟩
      exact hY (XXY_inj hAB hAY h).2.symm
    · simp
  · intro X _ hX
    refine Finset.sum_eq_zero fun Y _ => ?_
    rw [if_neg]
    rintro ⟨hXY', h⟩
    exact hX (XXY_inj hAB hXY' h).1.symm
  · simp

lemma typeNum_XXY (c : Fin k → ℕ) {X Y : Fin k} (hXY : X ≠ Y) :
    (ColourFirst.typeNum c {X, X, Y} : ℝ) = (c X : ℝ) * (c X - 1) / 2 * c Y := by
  unfold ColourFirst.typeNum
  rw [← Finset.mul_prod_erase _ _ (Finset.mem_univ X),
    ← Finset.mul_prod_erase _ _ (Finset.mem_erase.mpr ⟨hXY.symm, Finset.mem_univ Y⟩)]
  have hrest : ∏ Z ∈ (univ.erase X).erase Y, (c Z).choose (({X, X, Y} : Multiset (Fin k)).count Z)
      = 1 := by
    refine Finset.prod_eq_one fun Z hZ => ?_
    simp only [Finset.mem_erase] at hZ
    rw [count_XXY, if_neg hZ.2.1, if_neg hZ.1]
    simp
  rw [hrest, count_XXY, count_XXY, if_pos rfl, if_neg hXY, if_neg hXY.symm, if_pos rfl]
  push_cast
  rw [Nat.cast_choose_two]
  simp

/-- `Φ(bicolTypes t)` is the rate of Proposition 1.3. -/
theorem Phi_bicolTypes (lab : Fin n → Fin k) (t : Fin k → Fin k → ℕ) :
    Phi lab (bicolTypes t) =
      Prop13.Phi (classSize lab) (fun X Y => (t X Y : ℝ)) := by
  set f : Fin k × Fin k → Multiset (Fin k) := fun p => {p.1, p.1, p.2}
  set S : Finset (Fin k × Fin k) := univ.filter fun p => p.1 ≠ p.2
  set G : Multiset (Fin k) → ℝ := fun τ =>
    (bicolTypes t τ : ℝ) * (log ((numTriples lab τ : ℝ) / bicolTypes t τ) - 2)
  have hinj : Set.InjOn f S := by
    intro p hp q hq h
    have h1 := (Finset.mem_filter.mp hp).2
    have h2 := (Finset.mem_filter.mp hq).2
    obtain ⟨e1, e2⟩ := XXY_inj h1 h2 h
    exact Prod.ext e1 e2
  have hsub : S.image f ⊆ blockTypes k := by
    intro τ hτ
    obtain ⟨p, -, rfl⟩ := Finset.mem_image.mp hτ
    rw [mem_blockTypes]; simp [f]
  have hzero : ∀ τ ∈ blockTypes k, τ ∉ S.image f → G τ = 0 := by
    intro τ _ hτ
    have : bicolTypes t τ = 0 := by
      unfold bicolTypes
      refine Finset.sum_eq_zero fun X _ => Finset.sum_eq_zero fun Y _ => ?_
      rw [if_neg]
      rintro ⟨hXY, rfl⟩
      exact hτ (Finset.mem_image.mpr ⟨(X, Y), Finset.mem_filter.mpr ⟨Finset.mem_univ _, hXY⟩,
        rfl⟩)
    simp [G, this]
  have h1 : Phi lab (bicolTypes t) = ∑ τ ∈ S.image f, G τ :=
    (Finset.sum_subset hsub hzero).symm
  rw [h1, Finset.sum_image hinj]
  unfold Prop13.Phi
  rw [Finset.sum_filter, Fintype.sum_prod_type]
  refine Finset.sum_congr rfl fun X _ => ?_
  rw [← Finset.sum_filter]
  have hfil : (univ.filter fun Y : Fin k => X ≠ Y) = univ.erase X := by
    ext Y; simp [eq_comm]
  rw [hfil]
  refine Finset.sum_congr rfl fun Y hY => ?_
  have hXY : X ≠ Y := (Finset.ne_of_mem_erase hY).symm
  simp only [G, f]
  rw [bicolTypes_XXY t hXY, numTriples_eq lab (by simp), typeNum_XXY _ hXY]
  rfl

/-- **Proposition 1.3 for the rate of Theorem 1.2.** For an admissible partition and `t`
satisfying the row identities of (1.3) with positive entries,
`|Φ(t) − (n²/6)(log n − 2 − D(Q‖P₀))| ≤ (n/6)|log n − 2| + n`. -/
theorem prop_1_3_bicol (lab : Fin n → Fin k) (hn : 0 < n)
    (hc : ∀ X, 2 ≤ classSize lab X) (t : Fin k → Fin k → ℕ)
    (ht : ∀ X Y, X ≠ Y → 0 < t X Y) (hrow : ∀ X, ∑ Y ∈ univ.erase X, t X Y =
      (classSize lab X).choose 2)
    (hadm : 3 * ∑ X, classSize lab X * (classSize lab X - 1) = n * (n - 1)) :
    |Phi lab (bicolTypes t) - (n : ℝ) ^ 2 / 6 *
        (log n - 2 - Prop13.KL n (classSize lab) (fun X Y => (t X Y : ℝ)))| ≤
      (n : ℝ) / 6 * |log n - 2| + n := by
  rw [Phi_bicolTypes]
  have hsize : ∑ X, classSize lab X = n := by
    unfold classSize
    rw [← Finset.card_eq_sum_card_fiberwise (fun v _ => Finset.mem_univ (lab v))]
    simp
  refine Prop13.prop_1_3 hn hsize hc (fun X Y h => by exact_mod_cast ht X Y h) (fun X => ?_) ?_
  · have := congrArg (fun z : ℕ => (z : ℝ)) (hrow X)
    push_cast at this
    rw [this, Nat.cast_choose_two]
  · have h := congrArg (fun z : ℕ => (z : ℝ)) hadm
    simp only [Nat.cast_mul, Nat.cast_ofNat, Nat.cast_sum] at h
    have hsub : ∀ X, ((classSize lab X - 1 : ℕ) : ℝ) = (classSize lab X : ℝ) - 1 := fun X => by
      have := hc X; push_cast [Nat.cast_sub (by omega : 1 ≤ classSize lab X)]; ring
    have hn1 : ((n - 1 : ℕ) : ℝ) = (n : ℝ) - 1 := by push_cast [Nat.cast_sub hn]; ring
    simp only [hsub, hn1] at h
    exact h

end ColourStats
