/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Typical

/-!
# Approximate counting on typical graphs (Lemma 5.19)

* `Approx ε X x` means `|x − X| ≤ ε X`, with closure rules for products, inverses, sums and
  positive multiples.
* `two_mul_card_edgesIn`: twice the number of edges inside a vertex set `U` is
  `Σ_{z ∈ U} |N(z) ∩ U|`.
* `card_edgesIn_commonIn`: on an `(η, 5)`-typical graph, for `|S| ≤ 4`, the number of edges
  inside the common neighbourhood of `S` in a class `A` is
  `(1 ± (2η + η²)) · ½ I(S)² d(A, A)`, where `I(S) = |A| Π_{s ∈ S} d(cl s, A)`.
-/

@[expose] public section

open Finset

namespace ColourStats.Counting

open Typical

/-- `x` approximates `X` with relative error `ε`. -/
def Approx (ε X x : ℝ) : Prop := |x - X| ≤ ε * X

lemma Approx.lower {ε X x : ℝ} (h : Approx ε X x) : (1 - ε) * X ≤ x := by
  have := (abs_le.mp h).1; linarith

lemma Approx.upper {ε X x : ℝ} (h : Approx ε X x) : x ≤ (1 + ε) * X := by
  have := (abs_le.mp h).2; linarith

lemma approx_of_bounds {ε X x : ℝ} (h1 : (1 - ε) * X ≤ x) (h2 : x ≤ (1 + ε) * X) :
    Approx ε X x :=
  abs_le.mpr ⟨by linarith, by linarith⟩

lemma Approx.mono {ε ε' X x : ℝ} (h : Approx ε X x) (hε : ε ≤ ε') (hX : 0 ≤ X) :
    Approx ε' X x :=
  h.trans (mul_le_mul_of_nonneg_right hε hX)

lemma Approx.mul {ε δ X Y x y : ℝ} (hx : Approx ε X x) (hy : Approx δ Y y) (hX : 0 ≤ X)
    (hY : 0 ≤ Y) (hε : 0 ≤ ε) (_hδ : 0 ≤ δ) :
    Approx (ε + δ + ε * δ) (X * Y) (x * y) := by
  unfold Approx at *
  have hyabs : |y| ≤ (1 + δ) * Y :=
    abs_le.mpr ⟨by linarith [(abs_le.mp hy).1], by linarith [(abs_le.mp hy).2]⟩
  have : x * y - X * Y = (x - X) * y + X * (y - Y) := by ring
  rw [this]
  calc |(x - X) * y + X * (y - Y)| ≤ |x - X| * |y| + X * |y - Y| := by
        refine (abs_add_le _ _).trans ?_
        rw [abs_mul, abs_mul, abs_of_nonneg hX]
    _ ≤ (ε * X) * ((1 + δ) * Y) + X * (δ * Y) :=
        add_le_add (mul_le_mul hx hyabs (abs_nonneg _) (mul_nonneg hε hX))
          (mul_le_mul_of_nonneg_left hy hX)
    _ = (ε + δ + ε * δ) * (X * Y) := by ring

lemma Approx.inv {ε X x : ℝ} (h : Approx ε X x) (hX : 0 < X) (hε : ε ≤ 1 / 2) :
    Approx (2 * ε) (1 / X) (1 / x) := by
  have hε0 : 0 ≤ ε :=
    (mul_nonneg_iff_of_pos_right hX).mp ((abs_nonneg (x - X)).trans h)
  have hx : X / 2 ≤ x := by have := h.lower; nlinarith
  have hxpos : 0 < x := by linarith
  have hXx : |X - x| ≤ ε * X := by rw [abs_sub_comm]; exact h
  unfold Approx
  have e : 1 / x - 1 / X = (X - x) / (x * X) := by field_simp
  rw [e, abs_div, abs_of_pos (mul_pos hxpos hX), div_le_iff₀ (mul_pos hxpos hX)]
  calc |X - x| ≤ ε * X := hXx
    _ ≤ 2 * ε * (1 / X) * (x * X) := by
        have e2 : 2 * ε * (1 / X) * (x * X) = 2 * ε * x := by field_simp
        rw [e2]; nlinarith

lemma Approx.smul {ε X x c : ℝ} (h : Approx ε X x) (hc : 0 ≤ c) :
    Approx ε (c * X) (c * x) := by
  unfold Approx at *
  rw [← mul_sub, abs_mul, abs_of_nonneg hc]
  nlinarith [mul_le_mul_of_nonneg_left h hc]

lemma approx_sum {ι : Type*} {s : Finset ι} {f : ι → ℝ} {ε T : ℝ}
    (h : ∀ i ∈ s, Approx ε T (f i)) : Approx ε (s.card * T) (∑ i ∈ s, f i) := by
  unfold Approx at *
  rw [show (s.card : ℝ) * T = ∑ _i ∈ s, T by simp, ← Finset.sum_sub_distrib, Finset.mul_sum]
  exact (abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum h)

variable {V : Type*} [Fintype V] [DecidableEq V] {k : ℕ}

/-- The edges of `G` inside a vertex set `U`. -/
def edgesIn (G : SimpleGraph V) [DecidableRel G.Adj] (U : Finset V) : Finset (Sym2 V) :=
  G.edgeFinset.filter fun e => ∀ v ∈ e, v ∈ U

/-- **Handshake inside `U`.** -/
theorem two_mul_card_edgesIn (G : SimpleGraph V) [DecidableRel G.Adj] (U : Finset V) :
    2 * (edgesIn G U).card = ∑ z ∈ U, (U.filter fun w => G.Adj z w).card := by
  set P := (U ×ˢ U).filter fun p : V × V => G.Adj p.1 p.2 with hP
  have h1 : P.card = ∑ z ∈ U, (U.filter fun w => G.Adj z w).card := by
    rw [Finset.card_filter, Finset.sum_product]
    refine Finset.sum_congr rfl fun z _ => ?_
    rw [Finset.card_filter]
  have h2 : P.card = ∑ e ∈ edgesIn G U, (P.filter fun p => s(p.1, p.2) = e).card := by
    refine Finset.card_eq_sum_card_fiberwise fun p hp => ?_
    rw [hP] at hp
    obtain ⟨hpU, hadj⟩ := Finset.mem_filter.mp hp
    obtain ⟨hp1, hp2⟩ := Finset.mem_product.mp hpU
    refine Finset.mem_filter.mpr
      ⟨SimpleGraph.mem_edgeFinset.mpr (G.mem_edgeSet.mpr hadj), fun v hv => ?_⟩
    rcases Sym2.mem_iff.mp hv with rfl | rfl
    · exact hp1
    · exact hp2
  have h3 : ∀ e ∈ edgesIn G U, (P.filter fun p => s(p.1, p.2) = e).card = 2 := by
    intro e he
    induction e using Sym2.ind with
    | _ a b =>
      obtain ⟨hE, hall⟩ := Finset.mem_filter.mp he
      have hadj : G.Adj a b := G.mem_edgeSet.mp (SimpleGraph.mem_edgeFinset.mp hE)
      have hab : a ≠ b := G.ne_of_adj hadj
      have ha : a ∈ U := hall a (Sym2.mem_mk_left a b)
      have hb : b ∈ U := hall b (Sym2.mem_mk_right a b)
      have : (P.filter fun p => s(p.1, p.2) = s(a, b)) = {(a, b), (b, a)} := by
        ext ⟨p, q⟩
        simp only [hP, Finset.mem_filter, Finset.mem_product, Sym2.eq_iff, Finset.mem_insert,
          Finset.mem_singleton, Prod.mk.injEq]
        constructor
        · rintro ⟨-, h⟩; exact h
        · rintro (⟨rfl, rfl⟩ | ⟨rfl, rfl⟩)
          · exact ⟨⟨⟨ha, hb⟩, hadj⟩, Or.inl ⟨rfl, rfl⟩⟩
          · exact ⟨⟨⟨hb, ha⟩, hadj.symm⟩, Or.inr ⟨rfl, rfl⟩⟩
      rw [this, Finset.card_pair]
      simp [hab]
  rw [← h1, h2, Finset.sum_congr rfl h3, Finset.sum_const, smul_eq_mul, mul_comm]

lemma filter_adj_commonIn (G : SimpleGraph V) [DecidableRel G.Adj] (cls : V → Fin k)
    (S : Finset V) (A : Fin k) (z : V) :
    (commonIn G cls S A).filter (fun w => G.Adj z w) = commonIn G cls (insert z S) A := by
  ext w
  simp only [commonIn, Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert,
    forall_eq_or_imp]
  tauto

lemma not_mem_of_mem_commonIn {G : SimpleGraph V} [DecidableRel G.Adj] {cls : V → Fin k}
    {S : Finset V} {A : Fin k} {z : V} (hz : z ∈ commonIn G cls S A) : z ∉ S := by
  intro hzS
  simp only [commonIn, Finset.mem_filter, Finset.mem_univ, true_and] at hz
  exact G.irrefl (hz.2 z hzS)

lemma cls_of_mem_commonIn {G : SimpleGraph V} [DecidableRel G.Adj] {cls : V → Fin k}
    {S : Finset V} {A : Fin k} {z : V} (hz : z ∈ commonIn G cls S A) : cls z = A := by
  simp only [commonIn, Finset.mem_filter, Finset.mem_univ, true_and] at hz
  exact hz.1

omit [DecidableEq V] in
lemma ideal_nonneg {cls : V → Fin k} {d : Fin k → Fin k → ℝ} (hd : ∀ X Y, 0 ≤ d X Y)
    (S : Finset V) (A : Fin k) : 0 ≤ ideal cls d S A := by
  unfold ideal
  exact mul_nonneg (by positivity) (Finset.prod_nonneg fun v _ => hd _ _)

/-- **Edges inside a common neighbourhood.** -/
theorem card_edgesIn_commonIn {G : SimpleGraph V} [DecidableRel G.Adj] {cls : V → Fin k}
    {d : Fin k → Fin k → ℝ} {η : ℝ} (hT : IsTypical G cls d η 5) (hη : 0 ≤ η) (hη1 : η ≤ 1)
    (hd : ∀ X Y, 0 ≤ d X Y) {S : Finset V} (hS : S.card ≤ 4) (A : Fin k) :
    Approx (2 * η + η ^ 2) (1 / 2 * (ideal cls d S A ^ 2 * d A A))
      ((edgesIn G (commonIn G cls S A)).card) := by
  have hI := ideal_nonneg (cls := cls) hd S A
  have hU : Approx η (ideal cls d S A) ((commonIn G cls S A).card) :=
    hT S (by omega) A
  have hW : ∀ z ∈ commonIn G cls S A, Approx η (ideal cls d S A * d A A)
      (((commonIn G cls S A).filter fun w => G.Adj z w).card : ℝ) := by
    intro z hz
    rw [filter_adj_commonIn]
    have hzS := not_mem_of_mem_commonIn hz
    have hcard : (insert z S).card ≤ 5 := by
      rw [Finset.card_insert_of_notMem hzS]; omega
    have hid : ideal cls d (insert z S) A = ideal cls d S A * d A A := by
      unfold ideal
      rw [Finset.prod_insert hzS, cls_of_mem_commonIn hz]
      ring
    have := hT (insert z S) hcard A
    rw [hid] at this
    exact this
  have hsum := approx_sum hW
  -- combine: Σ_z |W_z| ≈ |U| · I d ≈ I · I d
  have hsum' : Approx (2 * η + η ^ 2) (ideal cls d S A * (ideal cls d S A * d A A))
      (∑ z ∈ commonIn G cls S A, (((commonIn G cls S A).filter fun w => G.Adj z w).card : ℝ)) := by
    have hId : 0 ≤ ideal cls d S A * d A A := mul_nonneg hI (hd A A)
    have a1 := hsum.upper
    have a2 := hsum.lower
    have b1 := hU.upper
    have b2 := hU.lower
    have c1 : (1 + η) * ((commonIn G cls S A).card * (ideal cls d S A * d A A)) ≤
        (1 + η) * ((1 + η) * ideal cls d S A * (ideal cls d S A * d A A)) :=
      mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right b1 hId) (by linarith)
    have c2 : (1 - η) * ((1 - η) * ideal cls d S A * (ideal cls d S A * d A A)) ≤
        (1 - η) * ((commonIn G cls S A).card * (ideal cls d S A * d A A)) :=
      mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right b2 hId) (by linarith)
    have hII : 0 ≤ ideal cls d S A * (ideal cls d S A * d A A) := mul_nonneg hI hId
    refine approx_of_bounds ?_ ?_
    · nlinarith [mul_nonneg (sq_nonneg η) hII]
    · nlinarith [mul_nonneg (sq_nonneg η) hII]
  have h2 : (2 : ℝ) * (edgesIn G (commonIn G cls S A)).card =
      ∑ z ∈ commonIn G cls S A, (((commonIn G cls S A).filter fun w => G.Adj z w).card : ℝ) := by
    exact_mod_cast two_mul_card_edgesIn G (commonIn G cls S A)
  have := hsum'.smul (by norm_num : (0 : ℝ) ≤ 1 / 2)
  rw [← h2] at this
  convert this using 1 <;> ring

end ColourStats.Counting
