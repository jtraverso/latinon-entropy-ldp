/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.PaschHub

/-!
# The colour-first identity for all types (Lemma 5.12)

Let `O` be a vertex set whose class `X` has `o X` points. For a multiset `μ` of classes,
`typeNum o μ = Π_X C(o_X, μ_X)` is the number of sets of points of `O` of type `μ`: for a
pair class `π` it is `e_π`, for a block type `τ` it is `N^O_τ`.

Given availability densities `ν_π` and weights `t'_τ`, a pair of class `π` gets type `τ`
with probability `P(τ | π) = m_π(τ) t'_τ / (ν_π e_π)`. For a type `τ = {a, b, c}` with apex
`a`, put `π₁ = {b, c}`, `π₂ = {a, c}`, `π₃ = {a, b}` and

    D_τ = w(τ, π₁) · ν_{π₂} P(τ | π₂) · ν_{π₃} P(τ | π₃),

where `w(τ, π₁) = o_a − [a ∈ π₁]` is the number of points completing a pair of class `π₁`
to a triple of type `τ`.

Main results:
* `compl_mul_typeNum`: the double count `w(τ, π) e_π = m_π(τ) N^O_τ`;
* `apex_eq`, `apex_indep`: Lemma 5.12(a), `D_τ` does not depend on the apex; it equals
  the symmetric expression `D o t τ = Π_π m_π(τ) · N^O_τ · t'_τ² / Π_π e_π`;
* `entropy_identity`: Lemma 5.12(b),
  `Σ_π ν_π e_π H(P(·|π)) + Σ_τ t'_τ (log D_τ − 2)
     = Σ_τ t'_τ (log(N^O_τ/t'_τ) − 2) + Σ_τ t'_τ log(ν_{π₁}ν_{π₂}ν_{π₃})`;
* `sum_P`: under the pair identities, `P(· | π)` is a probability vector.

The identity in (b) is purely algebraic: it holds for all positive `ν` and `t'`, without
the pair identities.
-/

@[expose] public section

open Finset

namespace ColourStats.ColourFirst

open ColourStats

variable {k : ℕ}

/-- `Π_X C(o_X, μ_X)`: the number of sets of points of type `μ` when class `X` has `o X`
points. -/
def typeNum (o : Fin k → ℕ) (μ : Multiset (Fin k)) : ℕ := ∏ X, (o X).choose (μ.count X)

/-- `w(Z ::ₘ π, π)`: the points of class `Z` outside a pair of class `π`. -/
def compl (o : Fin k → ℕ) (Z : Fin k) (π : Multiset (Fin k)) : ℕ := o Z - π.count Z

lemma typeNum_pos {o : Fin k → ℕ} {μ : Multiset (Fin k)} (h : ∀ X, μ.count X ≤ o X) :
    0 < typeNum o μ :=
  Finset.prod_pos fun X _ => Nat.choose_pos (h X)

lemma typeNum_pos_of_card {o : Fin k → ℕ} {μ : Multiset (Fin k)} {j : ℕ}
    (ho : ∀ X, j ≤ o X) (hμ : Multiset.card μ = j) : 0 < typeNum o μ :=
  typeNum_pos fun X => (hμ ▸ Multiset.count_le_card X μ).trans (ho X)

lemma typeNum_cons (o : Fin k → ℕ) (Z : Fin k) (μ : Multiset (Fin k)) :
    typeNum o (Z ::ₘ μ) * (μ.count Z + 1) = typeNum o μ * (o Z - μ.count Z) := by
  unfold typeNum
  rw [← Finset.mul_prod_erase _ _ (mem_univ Z), ← Finset.mul_prod_erase _ _ (mem_univ Z)]
  have hrest : ∏ X ∈ univ.erase Z, (o X).choose ((Z ::ₘ μ).count X) =
      ∏ X ∈ univ.erase Z, (o X).choose (μ.count X) :=
    Finset.prod_congr rfl fun X hX => by
      rw [Multiset.count_cons_of_ne (ne_of_mem_erase hX)]
  rw [hrest, Multiset.count_cons_self, mul_right_comm, Nat.choose_succ_right_eq,
    mul_right_comm]

lemma pairs_triple (a b c : Fin k) :
    pairs ({a, b, c} : Multiset (Fin k)) = {b, c} ::ₘ {a, c} ::ₘ {{a, b}} := by
  simp [pairs, Multiset.insert_eq_cons, Multiset.powersetCard_one, Multiset.powersetCard_cons]
  exact Multiset.cons_swap _ _ _

lemma mult_triple (a b c : Fin k) :
    mult ({b, c} : Multiset (Fin k)) {a, b, c} = Multiset.count a {b, c} + 1 := by
  rw [mult, pairs_triple]
  simp only [Multiset.insert_eq_cons]
  have e1 : ((b ::ₘ {c} : Multiset (Fin k)) = a ::ₘ {c}) ↔ a = b := by
    rw [Multiset.cons_inj_left]; exact eq_comm
  have e2 : ((b ::ₘ {c} : Multiset (Fin k)) = a ::ₘ {b}) ↔ a = c := by
    rw [show (a ::ₘ {b} : Multiset (Fin k)) = b ::ₘ {a} from Multiset.cons_swap a b 0,
      Multiset.cons_inj_right, Multiset.singleton_inj]; exact eq_comm
  simp only [Multiset.count_cons, Multiset.count_singleton, e1, e2, ite_true]

lemma mem_pairs_triple (a b c : Fin k) :
    ({b, c} : Multiset (Fin k)) ∈ pairs {a, b, c} ∧ ({a, c} : Multiset (Fin k)) ∈ pairs {a, b, c} ∧
      ({a, b} : Multiset (Fin k)) ∈ pairs {a, b, c} := by
  rw [pairs_triple]
  simp

/-- **The double count** `w(τ, π) e_π = m_π(τ) N^O_τ`: every triple of type `τ` contains
`m_π(τ)` pairs of class `π`, and every such pair has `w(τ, π)` completions. -/
theorem compl_mul_typeNum (o : Fin k → ℕ) (a b c : Fin k) :
    compl o a {b, c} * typeNum o {b, c} = mult {b, c} {a, b, c} * typeNum o {a, b, c} := by
  have h := typeNum_cons o a {b, c}
  rw [mult_triple, compl]
  rw [show ({a, b, c} : Multiset (Fin k)) = a ::ₘ {b, c} from rfl]
  linarith

/-! ### Real-valued quantities -/

/-- `P(τ | π) = m_π(τ) t'_τ / (ν_π e_π)`. -/
noncomputable def P (o : Fin k → ℕ) (ν t : Multiset (Fin k) → ℝ) (τ π : Multiset (Fin k)) :
    ℝ :=
  mult π τ * t τ / (ν π * typeNum o π)

/-- `D_τ` for `τ = {a, b, c}`, computed from the apex `a`:
`w(τ, {b, c}) · ν_{ac} P(τ | ac) · ν_{ab} P(τ | ab)`. -/
noncomputable def DApex (o : Fin k → ℕ) (ν t : Multiset (Fin k) → ℝ) (a b c : Fin k) : ℝ :=
  compl o a {b, c} * (ν {a, c} * P o ν t {a, b, c} {a, c}) *
    (ν {a, b} * P o ν t {a, b, c} {a, b})

/-- The symmetric form of `D_τ`: `Π_π m_π(τ) · N^O_τ · t'_τ² / Π_π e_π`, the products over
the three pairs of `τ`. -/
noncomputable def D (o : Fin k → ℕ) (t : Multiset (Fin k) → ℝ) (τ : Multiset (Fin k)) : ℝ :=
  ((pairs τ).map fun π => (mult π τ : ℝ)).prod * typeNum o τ * t τ ^ 2 /
    ((pairs τ).map fun π => (typeNum o π : ℝ)).prod

lemma typeNum_pair_ne_zero {o : Fin k → ℕ} (ho : ∀ X, 2 ≤ o X) (x y : Fin k) :
    (typeNum o {x, y} : ℝ) ≠ 0 :=
  Nat.cast_ne_zero.mpr (typeNum_pos_of_card ho (by simp)).ne'

/-- **Lemma 5.12(a), apex form.** The apex form of `D_τ` equals the symmetric form. -/
theorem apex_eq (o : Fin k → ℕ) (ho : ∀ X, 2 ≤ o X) (ν t : Multiset (Fin k) → ℝ)
    (a b c : Fin k) (hν₂ : ν {a, c} ≠ 0) (hν₃ : ν {a, b} ≠ 0) :
    DApex o ν t a b c = D o t {a, b, c} := by
  have h1 := typeNum_pair_ne_zero ho b c
  have h2 := typeNum_pair_ne_zero ho a c
  have h3 := typeNum_pair_ne_zero ho a b
  have hdc : (compl o a {b, c} : ℝ) * typeNum o {b, c} =
      mult {b, c} {a, b, c} * typeNum o {a, b, c} := by
    exact_mod_cast compl_mul_typeNum o a b c
  have hw : (compl o a {b, c} : ℝ) =
      mult {b, c} {a, b, c} * typeNum o {a, b, c} / typeNum o {b, c} := by
    rw [eq_div_iff h1]; exact hdc
  unfold DApex D P
  rw [hw, pairs_triple]
  simp only [Multiset.map_cons, Multiset.map_singleton, Multiset.prod_cons,
    Multiset.prod_singleton]
  field_simp

lemma triple_swap₁ (a b c : Fin k) : ({b, a, c} : Multiset (Fin k)) = {a, b, c} :=
  Multiset.cons_swap b a {c}

lemma triple_swap₂ (a b c : Fin k) : ({c, a, b} : Multiset (Fin k)) = {a, b, c} := by
  show c ::ₘ a ::ₘ {b} = a ::ₘ ({b, c} : Multiset (Fin k))
  rw [Multiset.cons_swap, Multiset.pair_comm]
  rfl

/-- **Lemma 5.12(a).** `D_τ` does not depend on the choice of the apex. -/
theorem apex_indep (o : Fin k → ℕ) (ho : ∀ X, 2 ≤ o X) (ν t : Multiset (Fin k) → ℝ)
    (hν : ∀ π ∈ pairTypes k, 0 < ν π) (a b c : Fin k) :
    DApex o ν t b a c = DApex o ν t a b c ∧ DApex o ν t c a b = DApex o ν t a b c := by
  have hp : ∀ x y : Fin k, ν {x, y} ≠ 0 := fun x y => (hν _ (mem_pairTypes.mpr (by simp))).ne'
  refine ⟨?_, ?_⟩
  · rw [apex_eq o ho ν t b a c (hp _ _) (hp _ _), apex_eq o ho ν t a b c (hp _ _) (hp _ _),
      triple_swap₁]
  · rw [apex_eq o ho ν t c a b (hp _ _) (hp _ _), apex_eq o ho ν t a b c (hp _ _) (hp _ _),
      triple_swap₂]

/-- Under the pair identities `Σ_τ m_π(τ) t'_τ = ν_π e_π`, `P(· | π)` sums to one. -/
theorem sum_P (o : Fin k → ℕ) (ν t : Multiset (Fin k) → ℝ) {π : Multiset (Fin k)}
    (hsum : ∑ τ ∈ blockTypes k, (mult π τ : ℝ) * t τ = ν π * typeNum o π)
    (hne : ν π * (typeNum o π : ℝ) ≠ 0) :
    ∑ τ ∈ blockTypes k, P o ν t τ π = 1 := by
  simp only [P]
  rw [← Finset.sum_div, hsum, div_self hne]

lemma sum_count_mul {α : Type*} [DecidableEq α] (S : Finset α) (M : Multiset α)
    (hM : ∀ x ∈ M, x ∈ S) (f : α → ℝ) :
    ∑ x ∈ S, (M.count x : ℝ) * f x = (M.map f).sum := by
  rw [Finset.sum_multiset_map_count]
  simp only [nsmul_eq_mul]
  refine (Finset.sum_subset (fun x hx => hM x (Multiset.mem_toFinset.mp hx)) ?_).symm
  intro x _ hx
  rw [Multiset.count_eq_zero.mpr (fun h => hx (Multiset.mem_toFinset.mpr h))]
  simp

/-- **Lemma 5.12(b), the entropy identity.** For positive `ν` and `t'`,

    Σ_π ν_π e_π H(P(·|π)) + Σ_τ t'_τ (log D_τ − 2)
      = Σ_τ t'_τ (log(N^O_τ / t'_τ) − 2) + Σ_τ t'_τ log(ν_{π₁} ν_{π₂} ν_{π₃}). -/
theorem entropy_identity (o : Fin k → ℕ) (ho : ∀ X, 3 ≤ o X) (ν t : Multiset (Fin k) → ℝ)
    (hν : ∀ π ∈ pairTypes k, 0 < ν π) (ht : ∀ τ ∈ blockTypes k, 0 < t τ) :
    ∑ π ∈ pairTypes k, ν π * typeNum o π *
        ∑ τ ∈ blockTypes k, Real.negMulLog (P o ν t τ π) +
      ∑ τ ∈ blockTypes k, t τ * (Real.log (D o t τ) - 2) =
    ∑ τ ∈ blockTypes k, t τ * (Real.log (typeNum o τ / t τ) - 2) +
      ∑ τ ∈ blockTypes k, t τ * Real.log ((pairs τ).map ν).prod := by
  have ho2 : ∀ X, 2 ≤ o X := fun X => le_trans (by norm_num) (ho X)
  have he : ∀ π ∈ pairTypes k, (0 : ℝ) < typeNum o π := fun π hπ =>
    Nat.cast_pos.mpr (typeNum_pos_of_card ho2 (mem_pairTypes.mp hπ))
  -- the weighted conditional entropies
  have h1 : ∀ π ∈ pairTypes k, ν π * typeNum o π *
      ∑ τ ∈ blockTypes k, Real.negMulLog (P o ν t τ π) =
      ∑ τ ∈ blockTypes k, -(t τ * ((mult π τ : ℝ) * Real.log (P o ν t τ π))) := by
    intro π hπ
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun τ _ => ?_
    have hν' : ν π ≠ 0 := (hν π hπ).ne'
    have he' : (typeNum o π : ℝ) ≠ 0 := (he π hπ).ne'
    have hx : ν π * typeNum o π * P o ν t τ π = mult π τ * t τ := by
      unfold P; field_simp
    simp only [Real.negMulLog]
    linear_combination (-Real.log (P o ν t τ π)) * hx
  -- collect the pairs of each type
  have h2 : ∀ τ ∈ blockTypes k, ∑ π ∈ pairTypes k,
      -(t τ * ((mult π τ : ℝ) * Real.log (P o ν t τ π))) =
      -(t τ * ((pairs τ).map fun π => Real.log (P o ν t τ π)).sum) := by
    intro τ _
    rw [Finset.sum_neg_distrib, ← Finset.mul_sum]
    congr 2
    exact sum_count_mul (pairTypes k) (pairs τ)
      (fun π hπ => mem_pairTypes.mpr (Multiset.mem_powersetCard.mp hπ).2) _
  -- the identity for one type
  have h3 : ∀ τ ∈ blockTypes k,
      -(t τ * ((pairs τ).map fun π => Real.log (P o ν t τ π)).sum) +
        t τ * (Real.log (D o t τ) - 2) =
      t τ * (Real.log (typeNum o τ / t τ) - 2) + t τ * Real.log ((pairs τ).map ν).prod := by
    intro τ hτ
    obtain ⟨a, b, c, rfl⟩ := Multiset.card_eq_three.mp (mem_blockTypes.mp hτ)
    have htp := ht _ hτ
    have hN : (0 : ℝ) < typeNum o {a, b, c} :=
      Nat.cast_pos.mpr (typeNum_pos_of_card ho (by simp))
    have hpair : ∀ x y : Fin k, ({x, y} : Multiset (Fin k)) ∈ pairTypes k :=
      fun x y => mem_pairTypes.mpr (by simp)
    obtain ⟨m1, m2, m3⟩ := mem_pairs_triple a b c
    have hm1 : (0 : ℝ) < mult {b, c} {a, b, c} := by exact_mod_cast Multiset.count_pos.mpr m1
    have hm2 : (0 : ℝ) < mult {a, c} {a, b, c} := by exact_mod_cast Multiset.count_pos.mpr m2
    have hm3 : (0 : ℝ) < mult {a, b} {a, b, c} := by exact_mod_cast Multiset.count_pos.mpr m3
    have hν1 := hν _ (hpair b c)
    have hν2 := hν _ (hpair a c)
    have hν3 := hν _ (hpair a b)
    have he1 := he _ (hpair b c)
    have he2 := he _ (hpair a c)
    have he3 := he _ (hpair a b)
    have hP1 : 0 < P o ν t {a, b, c} {b, c} := div_pos (mul_pos hm1 htp) (mul_pos hν1 he1)
    have hP2 : 0 < P o ν t {a, b, c} {a, c} := div_pos (mul_pos hm2 htp) (mul_pos hν2 he2)
    have hP3 : 0 < P o ν t {a, b, c} {a, b} := div_pos (mul_pos hm3 htp) (mul_pos hν3 he3)
    have hkey : D o t {a, b, c} =
        ((typeNum o {a, b, c} : ℝ) / t {a, b, c} * (ν {b, c} * (ν {a, c} * ν {a, b}))) *
          (P o ν t {a, b, c} {b, c} *
            (P o ν t {a, b, c} {a, c} * P o ν t {a, b, c} {a, b})) := by
      unfold D P
      rw [pairs_triple]
      simp only [Multiset.map_cons, Multiset.map_singleton, Multiset.prod_cons,
        Multiset.prod_singleton]
      field_simp
    have hlog : Real.log (D o t {a, b, c}) =
        Real.log ((typeNum o {a, b, c} : ℝ) / t {a, b, c}) +
          Real.log (ν {b, c} * (ν {a, c} * ν {a, b})) +
          (Real.log (P o ν t {a, b, c} {b, c}) +
            (Real.log (P o ν t {a, b, c} {a, c}) + Real.log (P o ν t {a, b, c} {a, b}))) := by
      rw [hkey, Real.log_mul (by positivity) (by positivity), Real.log_mul (by positivity)
        (by positivity), Real.log_mul hP1.ne' (by positivity), Real.log_mul hP2.ne' hP3.ne']
    rw [pairs_triple]
    simp only [Multiset.map_cons, Multiset.map_singleton, Multiset.sum_cons,
      Multiset.sum_singleton, Multiset.prod_cons, Multiset.prod_singleton]
    rw [hlog]
    ring
  rw [Finset.sum_congr rfl h1, Finset.sum_comm, Finset.sum_congr rfl h2,
    ← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  exact Finset.sum_congr rfl h3

/-- **Lemma 5.12(b) with `ν ≡ 1`.** `Σ_π e_π H(P(·|π)) + Σ_τ t_τ (log D_τ − 2)
= Σ_τ t_τ (log(N^O_τ / t_τ) − 2)`; the right side is `Φ(t)` when `N^O_τ` counts the
triples of type `τ`. -/
theorem entropy_identity_one (o : Fin k → ℕ) (ho : ∀ X, 3 ≤ o X) (t : Multiset (Fin k) → ℝ)
    (ht : ∀ τ ∈ blockTypes k, 0 < t τ) :
    ∑ π ∈ pairTypes k, (typeNum o π : ℝ) *
        ∑ τ ∈ blockTypes k, Real.negMulLog (P o (fun _ => 1) t τ π) +
      ∑ τ ∈ blockTypes k, t τ * (Real.log (D o t τ) - 2) =
    ∑ τ ∈ blockTypes k, t τ * (Real.log (typeNum o τ / t τ) - 2) := by
  have h := entropy_identity o ho (fun _ => 1) t (fun _ _ => one_pos) ht
  simp only [one_mul, Multiset.map_const', Multiset.prod_replicate, one_pow, Real.log_one,
    mul_zero, Finset.sum_const_zero, add_zero] at h
  exact h

end ColourStats.ColourFirst
