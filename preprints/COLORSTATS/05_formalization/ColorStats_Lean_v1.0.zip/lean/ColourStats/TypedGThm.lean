/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedGFinal

/-!
# The upper half of Theorem 1.9(a), asymptotic form

`theorem_1_9a_upper_exp`: under the hypotheses of Theorem 1.9 (`TypHyp c₀ δ₀ d₀`), for every
type vector `t`, `N_t(G) ≤ exp(Φ_G(t) + ε n²)` once `n ≥ n₀(c₀, δ₀, d₀, ε)`. Neither the
pair identities (1.6) nor triangle-divisibility are used.
-/

@[expose] public section

open Finset Real

namespace ColourStats.TypedG

open ColourStats ColourStats.Statements ColourStats.TypedSTS

open Classical

/-- **Upper half of Theorem 1.9(a)**, exponential form, for every type vector. -/
def Theorem_1_9a_upper_exp : Prop :=
  ∀ k : ℕ, ∀ c₀ δ₀ d₀ ε : ℝ, 0 < c₀ → 0 < δ₀ → 0 < d₀ → 0 < ε → ∃ n₀ : ℕ,
    ∀ n : ℕ, n₀ ≤ n → ∀ (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k),
      TypHyp c₀ δ₀ d₀ G lab → ∀ t : Multiset (Fin k) → ℕ,
        (countDecomp G lab t : ℝ) ≤ Real.exp (PhiG G lab (fun τ => (t τ : ℝ)) + ε * (n : ℝ) ^ 2)

lemma rpow_neg_le {c₀ m : ℝ} (hc : 0 < c₀) (hm : 0 < m) {n : ℕ}
    (hn : (1 / m) ^ c₀⁻¹ ≤ n) : (n : ℝ) ^ (-c₀) ≤ m := by
  have hbase : 0 ≤ (1 / m) ^ c₀⁻¹ := by positivity
  have hnpos : (0 : ℝ) < n := lt_of_lt_of_le (by positivity) hn
  have h1 : 1 / m ≤ (n : ℝ) ^ c₀ := by
    have := Real.rpow_le_rpow hbase hn hc.le
    rwa [Real.rpow_inv_rpow (by positivity) hc.ne'] at this
  rw [Real.rpow_neg hnpos.le]
  have h2 : ((n : ℝ) ^ c₀)⁻¹ ≤ (1 / m)⁻¹ := inv_anti₀ (by positivity) h1
  simpa using h2

/-- **The upper half of Theorem 1.9(a)**, for every type vector. -/
theorem theorem_1_9a_upper_exp : Theorem_1_9a_upper_exp := by
  intro k c₀ δ₀ d₀ ε hc₀ hδ₀ hd₀ hε
  set m : ℝ := min (1 / 3) (ε / 2) with hmdef
  have hm : 0 < m := lt_min (by norm_num) (by linarith)
  set δ' : ℝ := (2 / 3) * δ₀ * d₀ ^ 2 with hδ'
  have hδ'pos : 0 < δ' := by positivity
  set ε' : ℝ := ε / 2 with hε'
  have hε'pos : 0 < ε' := by positivity
  set N₁ : ℝ := (1 / m) ^ c₀⁻¹
  refine ⟨⌈N₁ + (42 / ε') ^ 2 + 4 / δ' + 2 * (16 / ε') ^ 4 / δ'⌉₊ + 1,
    fun n hn G lab hyp t => ?_⟩
  have hceil : N₁ + (42 / ε') ^ 2 + 4 / δ' + 2 * (16 / ε') ^ 4 / δ' ≤ n := by
    have := Nat.le_ceil (N₁ + (42 / ε') ^ 2 + 4 / δ' + 2 * (16 / ε') ^ 4 / δ')
    have h' : ((⌈N₁ + (42 / ε') ^ 2 + 4 / δ' + 2 * (16 / ε') ^ 4 / δ'⌉₊ : ℕ) : ℝ) ≤ n := by
      exact_mod_cast (Nat.le_succ _).trans hn
    linarith
  have p0 : 0 ≤ N₁ := by positivity
  have p1 : 0 ≤ (42 / ε') ^ 2 := by positivity
  have p2 : 0 ≤ 4 / δ' := by positivity
  have p3 : 0 ≤ 2 * (16 / ε') ^ 4 / δ' := by positivity
  have hn1 : 1 ≤ n := by omega
  have hnr : (1 : ℝ) ≤ n := by exact_mod_cast hn1
  rcases Nat.eq_zero_or_pos (countDecomp G lab t) with h0 | hpos
  · rw [h0, Nat.cast_zero]
    exact (Real.exp_pos _).le
  obtain ⟨-, hcls, d, hd, htyp⟩ := hyp
  set η : ℝ := (n : ℝ) ^ (-c₀) with hη
  have hη0 : 0 ≤ η := by positivity
  have hηm : η ≤ m := rpow_neg_le hc₀ hm (by linarith)
  have hη3 : η ≤ 1 / 3 := hηm.trans (min_le_left _ _)
  have hηε : η ≤ ε / 2 := hηm.trans (min_le_right _ _)
  -- common neighbourhoods are large
  have hcnb : ∀ a b X, G.Adj a b → δ' * n - 2 ≤ (cnb G lab a b X : ℝ) := by
    intro a b X hab
    have h := htyp {a, b} (by rw [Finset.card_pair hab.ne]; norm_num) X
    rw [card_commonIn_pair, Typical.ideal_pair lab d hab.ne] at h
    have hlow := (abs_le.mp h).1
    have hX : δ₀ * n ≤ ((Typical.classSet lab X).card : ℝ) := hcls X
    have hd1 := hd (lab a) X
    have hd2 := hd (lab b) X
    have hdd : d₀ ^ 2 ≤ d (lab a) X * d (lab b) X := by
      have : 0 ≤ d₀ := hd₀.le
      nlinarith
    have hI : δ₀ * n * d₀ ^ 2 ≤
        ((Typical.classSet lab X).card : ℝ) * (d (lab a) X * d (lab b) X) := by
      have h0 : 0 ≤ δ₀ * n := by positivity
      calc δ₀ * n * d₀ ^ 2 ≤ ((Typical.classSet lab X).card : ℝ) * d₀ ^ 2 :=
            mul_le_mul_of_nonneg_right hX (by positivity)
        _ ≤ _ := mul_le_mul_of_nonneg_left hdd (Nat.cast_nonneg _)
    have : (1 - η) * (((Typical.classSet lab X).card : ℝ) * (d (lab a) X * d (lab b) X)) ≤
        cnb G lab a b X := by linarith
    have h23 : (2 / 3) * (δ₀ * n * d₀ ^ 2) ≤
        (1 - η) * (((Typical.classSet lab X).card : ℝ) * (d (lab a) X * d (lab b) X)) := by
      have h1η : 2 / 3 ≤ 1 - η := by linarith
      have hIpos : 0 ≤ δ₀ * n * d₀ ^ 2 := by positivity
      nlinarith
    have : δ' * n = (2 / 3) * (δ₀ * n * d₀ ^ 2) := by rw [hδ']; ring
    linarith
  have hc₁ : 1 ≤ δ' * n - 2 := by
    have : 4 ≤ δ' * n := by
      have : 4 / δ' ≤ n := by linarith
      rw [div_le_iff₀ hδ'pos] at this; linarith
    linarith
  have hup := typed_upper_G lab t d hη0 hη3 htyp hc₁ hcnb hn1 hpos
  have herr := err_le hδ'pos hε'pos (n := n) (by linarith) (by linarith) (by linarith) hn1
  have hcount : (0 : ℝ) < countDecomp G lab t := by exact_mod_cast hpos
  rw [← Real.exp_log hcount]
  apply Real.exp_le_exp.mpr
  have : (n : ℝ) ^ 2 * ((5 * Real.log n + 16) / n + 8 / Real.sqrt (Real.sqrt (δ' * n - 2)) + η) ≤
      ε * (n : ℝ) ^ 2 := by
    have h1 : (5 * Real.log n + 16) / n + 8 / Real.sqrt (Real.sqrt (δ' * n - 2)) + η ≤ ε := by
      have : ε' + ε / 2 = ε := by rw [hε']; ring
      linarith
    rw [mul_comm ε]
    exact mul_le_mul_of_nonneg_left h1 (by positivity)
  linarith

end ColourStats.TypedG
