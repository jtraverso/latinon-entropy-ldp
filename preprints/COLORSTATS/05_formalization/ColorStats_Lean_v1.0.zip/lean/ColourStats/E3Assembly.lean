/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Neumann

/-!
# Lemma 5.19 from its four estimates

The proof of Lemma 5.19 builds `Φ̃ r = Φ₁ r + Φ₁ T r + (σ r) w` and corrects it with a
Neumann series. This file proves that step from the four estimates that typicality supplies,
stated as hypotheses:

* `AΦ₁ = I − T`, with `‖Φ₁‖ ≤ a/m` and `‖T‖ ≤ τ` (the gadget average);
* `T² = σ ⊗ u + E₁` with `‖E₁‖ ≤ ε₁`, where `u = 1_{π₀}` and `σ r = Σ_e r(e)/|E_{π₀}|`,
  `‖σ‖ ≤ s` (two steps make `T²r` almost constant on the class `π₀`);
* `A w = u + e₂` with `‖e₂‖ ≤ ε₂` and `‖w‖ ≤ b/m` (the type weighting `W_1`);
* `ε₁ + s ε₂ ≤ 1/2`.

Conclusion (`right_inverse_of_estimates`): `A` has a right inverse `Φ` with
`‖Φ‖ ≤ 2(a + aτ + sb)/m`.

Also: `opNorm_le_of_rowSum`, the bound of an operator norm on sup-norm spaces by the
largest absolute row sum, used to bound `‖T‖` and `‖Φ₁‖`.
-/

@[expose] public section

open Finset

namespace ColourStats.E3Assembly

variable {E Tri : Type*} [Fintype E] [Fintype Tri]

/-- **Lemma 5.19, assembly.** -/
theorem right_inverse_of_estimates
    (A : (Tri → ℝ) →L[ℝ] (E → ℝ)) (Φ₁ : (E → ℝ) →L[ℝ] (Tri → ℝ))
    (T : (E → ℝ) →L[ℝ] (E → ℝ)) (hΦ₁ : A.comp Φ₁ = 1 - T)
    (σ : (E → ℝ) →L[ℝ] ℝ) (u : E → ℝ) (E₁ : (E → ℝ) →L[ℝ] (E → ℝ))
    (hT2 : T.comp T = σ.smulRight u + E₁)
    (w : Tri → ℝ) (e₂ : E → ℝ) (hw : A w = u + e₂)
    {m a τ b s ε₁ ε₂ : ℝ} (hm : 0 < m)
    (ha : ‖Φ₁‖ ≤ a / m) (hτ : ‖T‖ ≤ τ) (hσ : ‖σ‖ ≤ s) (hwn : ‖w‖ ≤ b / m)
    (hE₁ : ‖E₁‖ ≤ ε₁) (he₂ : ‖e₂‖ ≤ ε₂) (hsmall : ε₁ + s * ε₂ ≤ 1 / 2) :
    ∃ Φ : (E → ℝ) →L[ℝ] (Tri → ℝ), A.comp Φ = 1 ∧ ‖Φ‖ ≤ 2 * ((a + a * τ + s * b) / m) := by
  set Φt : (E → ℝ) →L[ℝ] (Tri → ℝ) := Φ₁ + Φ₁.comp T + σ.smulRight w
  set Err : (E → ℝ) →L[ℝ] (E → ℝ) := E₁ - σ.smulRight e₂
  have hA : A.comp Φt = 1 - Err := by
    ext1 r
    have h1 : A (Φ₁ r) = r - T r := by
      have := congrArg (fun L : (E → ℝ) →L[ℝ] (E → ℝ) => L r) hΦ₁
      simpa using this
    have h1' : A (Φ₁ (T r)) = T r - T (T r) := by
      have := congrArg (fun L : (E → ℝ) →L[ℝ] (E → ℝ) => L (T r)) hΦ₁
      simpa using this
    have h2 : T (T r) = σ r • u + E₁ r := by
      have := congrArg (fun L : (E → ℝ) →L[ℝ] (E → ℝ) => L r) hT2
      simpa using this
    simp only [Φt, Err, ContinuousLinearMap.comp_apply, ContinuousLinearMap.add_apply,
      ContinuousLinearMap.sub_apply, ContinuousLinearMap.one_apply,
      ContinuousLinearMap.smulRight_apply, map_add, map_smul, h1, h1', h2, hw]
    rw [smul_add]
    abel
  have hs0 : 0 ≤ s := (norm_nonneg _).trans hσ
  have hErr : ‖Err‖ ≤ 1 / 2 := by
    calc ‖Err‖ ≤ ‖E₁‖ + ‖σ.smulRight e₂‖ := norm_sub_le _ _
      _ = ‖E₁‖ + ‖σ‖ * ‖e₂‖ := by rw [ContinuousLinearMap.norm_smulRight_apply]
      _ ≤ ε₁ + s * ε₂ := add_le_add hE₁ (mul_le_mul hσ he₂ (norm_nonneg _) hs0)
      _ ≤ 1 / 2 := hsmall
  have ham : 0 ≤ a / m := (norm_nonneg _).trans ha
  have hΦt : ‖Φt‖ ≤ (a + a * τ + s * b) / m := by
    have hτ0 : 0 ≤ τ := (norm_nonneg _).trans hτ
    calc ‖Φt‖ ≤ ‖Φ₁‖ + ‖Φ₁‖ * ‖T‖ + ‖σ‖ * ‖w‖ := by
          refine (norm_add_le _ _).trans (add_le_add ((norm_add_le _ _).trans
            (add_le_add le_rfl (ContinuousLinearMap.opNorm_comp_le _ _))) ?_)
          rw [ContinuousLinearMap.norm_smulRight_apply]
      _ ≤ a / m + a / m * τ + s * (b / m) := by
          gcongr
      _ = (a + a * τ + s * b) / m := by field_simp
  obtain ⟨Φ, hΦ, hΦn⟩ := Neumann.exists_right_inverse A Φt Err hA hErr
  exact ⟨Φ, hΦ, hΦn.trans (by linarith)⟩

variable {F : Type*} [Fintype F]

/-- **Row sums.** If `(M r)(f) = Σ_e c(f, e) r(e)` and every absolute row sum is at most `K`,
then `‖M‖_{∞→∞} ≤ K`. -/
theorem opNorm_le_of_rowSum (M : (E → ℝ) →L[ℝ] (F → ℝ)) (c : F → E → ℝ)
    (hM : ∀ r f, M r f = ∑ e, c f e * r e) {K : ℝ} (hK0 : 0 ≤ K)
    (hK : ∀ f, ∑ e, |c f e| ≤ K) : ‖M‖ ≤ K := by
  refine ContinuousLinearMap.opNorm_le_bound M hK0 fun r => ?_
  refine (pi_norm_le_iff_of_nonneg (by positivity)).mpr fun f => ?_
  rw [hM, Real.norm_eq_abs]
  calc |∑ e, c f e * r e| ≤ ∑ e, |c f e * r e| := abs_sum_le_sum_abs _ _
    _ = ∑ e, |c f e| * ‖r e‖ := by simp [abs_mul, Real.norm_eq_abs]
    _ ≤ ∑ e, |c f e| * ‖r‖ :=
        sum_le_sum fun e _ => mul_le_mul_of_nonneg_left (norm_le_pi_norm r e) (abs_nonneg _)
    _ = (∑ e, |c f e|) * ‖r‖ := by rw [Finset.sum_mul]
    _ ≤ K * ‖r‖ := mul_le_mul_of_nonneg_right (hK f) (norm_nonneg _)

end ColourStats.E3Assembly
