/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedPair

/-!
# The typed Linial–Luria bound before aggregation

For every finite set `S` of Steiner quasigroups on `Fin n`, every class map `lab` and every
`L ≥ 1`, with `w_r = (L − r)²/L³` and `u_r = (L − r)/L` (`typed_raw_bound`):

  `log |S| ≤ Σ_{p} Σ_r w_r · (1/|S|) Σ_{T ∈ S} [log(|S| / |S^p_{cl(T p)}|) + log(1 + m_{p,T} u_r^6)]`,

where `p` runs over the unordered pairs, `S^p_X` is the set of systems whose third point at
`p` has class `X`, and `m_{p,T}` is the number of candidates of the class of that point.
This is Steps 1–5 of Section 4.2 of the paper, for the discretised orders.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.TypedSTS

open ColourStats.TypedChain

variable {n L k : ℕ} {S : Finset (Fin n → Fin n → Fin n)}

lemma det_pairs (hS : ∀ T ∈ S, IsSQ T) :
    ∀ T ∈ S, ∀ T' ∈ S, (∀ p ∈ pairs n, coord p T = coord p T') → T = T' := by
  intro T hT T' hT' h
  have hTq := hS T hT
  have hT'q := hS T' hT'
  funext a b
  rcases lt_trichotomy a b with hab | rfl | hab
  · exact h (a, b) (by simp [pairs, hab])
  · rw [hTq.diag, hT'q.diag]
  · rw [← hTq.comm, ← hT'q.comm]
    exact h (b, a) (by simp [pairs, hab])

/-- The weight `w_r = (L − r)²/L³`. -/
noncomputable def wr (L : ℕ) (r : Fin L) : ℝ := ((L : ℝ) - r) ^ 2 / (L : ℝ) ^ 3

lemma Bv_eq (hL : 0 < L) (r : Fin L) : Bv n L r = (L : ℝ) ^ (n * n) * wr L r := by
  unfold Bv wr
  ring

/-- **The typed chain bound, summed over the labellings.** -/
theorem typed_raw_bound (hS : ∀ T ∈ S, IsSQ T) (lab : Fin n → Fin k) (hL : 0 < L) :
    (S.card : ℝ) * Real.log S.card ≤
      ∑ p ∈ pairs n, ∑ r : Fin L, wr L r * ∑ T ∈ S,
        ((Real.log S.card - Real.log (Scl S lab p.1 p.2 (lab (T p.1 p.2))).card) +
          Real.log (1 + (cand lab T p.1 p.2).card * (((L : ℝ) - r) / L) ^ 6)) := by
  have hLpos : (0 : ℝ) < L := by exact_mod_cast hL
  have hN : (0 : ℝ) < (L : ℝ) ^ (n * n) := by positivity
  -- the chain bound for each labelling
  have hchain : ∀ lam : Pair n → Fin L, (S.card : ℝ) * Real.log S.card ≤
      ∑ p ∈ pairs n, ∑ T ∈ S,
        ((Real.log (before S (pairs n) (key2 lam) coord p T).card -
          Real.log (sameClass S (pairs n) (key2 lam) coord lab p T).card) +
        Real.log ((sameClass S (pairs n) (key2 lam) coord lab p T).image (coord p)).card) := by
    intro lam
    exact chain_typed (key1 lam) (key2 lam) coord lab S (pairs n)
      ((key1_injective lam).injOn) (det_pairs hS)
      (fun s _ t _ h => key1_lt_of_key2_lt lam h)
  have hsum := Finset.sum_le_sum (s := (univ : Finset (Pair n → Fin L))) fun lam _ => hchain lam
  rw [Finset.sum_const, Finset.card_univ, Fintype.card_fun, Fintype.card_prod,
    Fintype.card_fin, Fintype.card_fin, nsmul_eq_mul, Finset.sum_comm] at hsum
  have hpairs : ∑ p ∈ pairs n, ∑ lam : Pair n → Fin L, ∑ T ∈ S,
        ((Real.log (before S (pairs n) (key2 lam) coord p T).card -
          Real.log (sameClass S (pairs n) (key2 lam) coord lab p T).card) +
        Real.log ((sameClass S (pairs n) (key2 lam) coord lab p T).image (coord p)).card) ≤
      ∑ p ∈ pairs n, ∑ r : Fin L, Bv n L r * ∑ T ∈ S,
        ((Real.log S.card - Real.log (Scl S lab p.1 p.2 (lab (T p.1 p.2))).card) +
          Real.log (1 + (cand lab T p.1 p.2).card * (((L : ℝ) - r) / L) ^ 6)) := by
    refine Finset.sum_le_sum fun p hp => ?_
    obtain ⟨a, b⟩ := p
    have hab : a < b := by simpa [pairs] using hp
    exact pair_bound hS lab hab hL
  have htot := hsum.trans hpairs
  simp only [Bv_eq hL, mul_assoc, ← Finset.mul_sum] at htot
  push_cast at htot
  exact le_of_mul_le_mul_left htot hN

end ColourStats.TypedSTS
