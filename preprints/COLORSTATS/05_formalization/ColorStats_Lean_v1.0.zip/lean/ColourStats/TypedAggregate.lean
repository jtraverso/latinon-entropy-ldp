/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedAssembly
public import ColourStats.PaschHub

/-!
# Aggregation over pair classes (Section 4.2, Step 4)

Group the pairs by their class `π` (`Epi`). Suppose every system of `S` has the same pair
statistics: for every `π` and every class `X`, exactly `M(π, X)` pairs of class `π` have their
third point in `X` (`Mstat`). Concavity of entropy over the pairs of each class (again
`TypedChain.cond_le`) and the bound `m ≤ c_X − π.count X` on the number of candidates give
(`typed_agg_bound`):

  `log |S| ≤ Σ_π Σ_X M(π, X) · (W · log(|E_π| / M(π, X)) + Ψ(c_X − π.count X))`,

where `W = Σ_r w_r` and `Ψ(c) = Σ_r w_r log(1 + c u_r^6)`.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.TypedSTS

open ColourStats.TypedChain ColourStats

variable {n L k : ℕ} {S : Finset (Fin n → Fin n → Fin n)}

/-- The pairs of class `π`. -/
def Epi (lab : Fin n → Fin k) (π : Multiset (Fin k)) : Finset (Pair n) :=
  (pairs n).filter fun p => ({lab p.1, lab p.2} : Multiset (Fin k)) = π

/-- The number of pairs of class `π` whose third point in `T` has class `X`. -/
def Mstat (lab : Fin n → Fin k) (T : Fin n → Fin n → Fin n) (π : Multiset (Fin k)) (X : Fin k) :
    ℕ :=
  ((Epi lab π).filter fun p => lab (T p.1 p.2) = X).card

/-- The number of points of class `X` outside a pair of class `π`. -/
def compl (lab : Fin n → Fin k) (π : Multiset (Fin k)) (X : Fin k) : ℕ :=
  (univ.filter fun z => lab z = X).card - π.count X

/-- `W = Σ_r w_r`. -/
noncomputable def Wsum (L : ℕ) : ℝ := ∑ r : Fin L, wr L r

/-- `Ψ(c) = Σ_r w_r log(1 + c u_r^6)`. -/
noncomputable def Psi (L : ℕ) (c : ℝ) : ℝ :=
  ∑ r : Fin L, wr L r * Real.log (1 + c * (((L : ℝ) - r) / L) ^ 6)

lemma wr_nonneg (L : ℕ) (r : Fin L) : 0 ≤ wr L r := by
  unfold wr
  positivity

lemma Psi_mono (L : ℕ) {c c' : ℝ} (hc : 0 ≤ c) (hcc : c ≤ c') : Psi L c ≤ Psi L c' := by
  unfold Psi
  refine Finset.sum_le_sum fun r _ => mul_le_mul_of_nonneg_left ?_ (wr_nonneg L r)
  have hr : (r : ℝ) ≤ L := by exact_mod_cast r.isLt.le
  have hu : 0 ≤ (((L : ℝ) - r) / L) ^ 6 := by
    rcases Nat.eq_zero_or_pos L with h | h
    · subst h; simp
    · have : (0 : ℝ) < L := by exact_mod_cast h
      exact pow_nonneg (div_nonneg (by linarith) this.le) 6
  exact Real.log_le_log (by positivity) (by nlinarith)

lemma cand_le (lab : Fin n → Fin k) (T : Fin n → Fin n → Fin n) {a b : Fin n} (hab : a ≠ b) :
    (cand lab T a b).card ≤ compl lab {lab a, lab b} (lab (T a b)) := by
  unfold compl
  set X := lab (T a b) with hXdef
  set A := univ.filter fun z : Fin n => lab z = X
  set Bf := ({a, b} : Finset (Fin n)).filter fun z => lab z = X
  have hdisj : Disjoint (cand lab T a b) Bf := by
    rw [Finset.disjoint_left]
    intro z hz hzB
    obtain ⟨-, -, hza, hzb, -⟩ := Finset.mem_filter.mp hz
    have := (Finset.mem_filter.mp hzB).1
    simp only [Finset.mem_insert, Finset.mem_singleton] at this
    rcases this with rfl | rfl
    · exact hza rfl
    · exact hzb rfl
  have hsub : cand lab T a b ∪ Bf ⊆ A := by
    intro z hz
    rcases Finset.mem_union.mp hz with hz | hz
    · exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hz).2.1⟩
    · exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hz).2⟩
  have h1 := Finset.card_le_card hsub
  rw [Finset.card_union_of_disjoint hdisj] at h1
  have hcount : ({lab a, lab b} : Multiset (Fin k)).count X = Bf.card := by
    simp only [Bf, Finset.filter_insert, Finset.filter_singleton, Multiset.insert_eq_cons,
      Multiset.count_cons, Multiset.count_singleton]
    by_cases ha : lab a = X <;> by_cases hb : lab b = X
    · simp [ha, hb, Finset.card_pair hab]
    · simp [ha, hb]
      exact fun h => hb h.symm
    · simp [ha, hb]
      exact fun h => ha h.symm
    · simp [ha, hb]
      exact ⟨fun h => hb h.symm, fun h => ha h.symm⟩
  rw [hcount]
  omega

/-- Summing over pairs by class. -/
lemma sum_pairs_by_class (lab : Fin n → Fin k) (F : Pair n → ℝ) :
    ∑ p ∈ pairs n, F p = ∑ π ∈ pairTypes k, ∑ p ∈ Epi lab π, F p := by
  refine (Finset.sum_fiberwise_of_maps_to (g := fun p : Pair n =>
    ({lab p.1, lab p.2} : Multiset (Fin k))) (fun p _ => ?_) F).symm
  rw [mem_pairTypes]
  simp

/-- Summing a function of the class of the third point. -/
lemma sum_by_third (lab : Fin n → Fin k) (T : Fin n → Fin n → Fin n) (π : Multiset (Fin k))
    (G : Fin k → ℝ) :
    ∑ p ∈ Epi lab π, G (lab (T p.1 p.2)) = ∑ X, (Mstat lab T π X : ℝ) * G X := by
  rw [← Finset.sum_fiberwise (s := Epi lab π) (g := fun p => lab (T p.1 p.2))]
  refine Finset.sum_congr rfl fun X _ => ?_
  rw [Finset.sum_congr rfl fun p hp => by rw [(Finset.mem_filter.mp hp).2], Finset.sum_const,
    nsmul_eq_mul]
  rfl

/-- **The class part, aggregated over the pairs of one class.** -/
theorem class_agg (lab : Fin n → Fin k) (π : Multiset (Fin k)) (M : Fin k → ℕ)
    (hM : ∀ T ∈ S, ∀ X, Mstat lab T π X = M X) (hne : S.Nonempty) :
    ∑ p ∈ Epi lab π, ∑ T ∈ S,
        (Real.log S.card - Real.log (Scl S lab p.1 p.2 (lab (T p.1 p.2))).card) ≤
      S.card * ∑ X, (M X : ℝ) * (Real.log (Epi lab π).card - Real.log (M X)) := by
  set U := Epi lab π ×ˢ S
  have h := cond_le U (fun y => y.1) (fun y => lab (y.2 y.1.1 y.1.2))
  have hS0 : (0 : ℝ) < S.card := by exact_mod_cast hne.card_pos
  have hinj : ∀ p : Pair n, Function.Injective (fun T : Fin n → Fin n → Fin n => (p, T)) :=
    fun p _ _ e => (Prod.mk.inj e).2
  have hb : ∀ y ∈ U, (U.filter fun z => z.1 = y.1) = S.image (fun T => (y.1, T)) := by
    intro y hy
    ext ⟨p, T⟩
    simp only [U, Finset.mem_filter, Finset.mem_product, Finset.mem_image, Prod.mk.injEq]
    constructor
    · rintro ⟨⟨-, hT⟩, rfl⟩
      exact ⟨T, hT, rfl, rfl⟩
    · rintro ⟨T', hT', rfl, rfl⟩
      exact ⟨⟨(Finset.mem_product.mp hy).1, hT'⟩, rfl⟩
  have hbc : ∀ y ∈ U, (U.filter fun z => z.1 = y.1 ∧
      lab (z.2 z.1.1 z.1.2) = lab (y.2 y.1.1 y.1.2)) =
      (Scl S lab y.1.1 y.1.2 (lab (y.2 y.1.1 y.1.2))).image (fun T => (y.1, T)) := by
    intro y hy
    ext ⟨p, T⟩
    simp only [U, Scl, Finset.mem_filter, Finset.mem_product, Finset.mem_image, Prod.mk.injEq]
    constructor
    · rintro ⟨⟨-, hT⟩, rfl, hc⟩
      exact ⟨T, ⟨hT, hc⟩, rfl, rfl⟩
    · rintro ⟨T', ⟨hT', hc⟩, rfl, rfl⟩
      exact ⟨⟨(Finset.mem_product.mp hy).1, hT'⟩, rfl, hc⟩
  have hc : ∀ X, ((U.filter fun z => lab (z.2 z.1.1 z.1.2) = X).card : ℝ) = S.card * M X := by
    intro X
    have : (U.filter fun z => lab (z.2 z.1.1 z.1.2) = X).card =
        ∑ T ∈ S, Mstat lab T π X := by
      rw [Finset.card_filter, Finset.sum_product_right]
      refine Finset.sum_congr rfl fun T _ => ?_
      rw [Mstat, Finset.card_filter]
    rw [this, Finset.sum_congr rfl fun T hT => hM T hT X, Finset.sum_const, nsmul_eq_mul]
    push_cast
    ring
  have hL1 : ∀ y ∈ U, Real.log (U.filter fun z => z.1 = y.1).card -
      Real.log (U.filter fun z => z.1 = y.1 ∧
        lab (z.2 z.1.1 z.1.2) = lab (y.2 y.1.1 y.1.2)).card =
      Real.log S.card - Real.log (Scl S lab y.1.1 y.1.2 (lab (y.2 y.1.1 y.1.2))).card := by
    intro y hy
    rw [hb y hy, hbc y hy, Finset.card_image_of_injective _ (hinj y.1),
      Finset.card_image_of_injective _ (hinj y.1)]
  have hR1 : ∀ y ∈ U, Real.log U.card - Real.log (U.filter fun z =>
      lab (z.2 z.1.1 z.1.2) = lab (y.2 y.1.1 y.1.2)).card =
      Real.log (Epi lab π).card - Real.log (M (lab (y.2 y.1.1 y.1.2))) := by
    intro y hy
    obtain ⟨hp, hT⟩ := Finset.mem_product.mp hy
    have hE0 : (0 : ℝ) < (Epi lab π).card := by exact_mod_cast Finset.card_pos.mpr ⟨_, hp⟩
    have hmem : y.1 ∈ (Epi lab π).filter (fun p => lab (y.2 p.1 p.2) = lab (y.2 y.1.1 y.1.2)) :=
      Finset.mem_filter.mpr ⟨hp, rfl⟩
    have hMs : 0 < Mstat lab y.2 π (lab (y.2 y.1.1 y.1.2)) := Finset.card_pos.mpr ⟨_, hmem⟩
    have hM0 : (0 : ℝ) < M (lab (y.2 y.1.1 y.1.2)) := by
      rw [← hM y.2 hT]
      exact_mod_cast hMs
    rw [hc, Finset.card_product, Nat.cast_mul, Real.log_mul hE0.ne' hS0.ne',
      Real.log_mul hS0.ne' hM0.ne']
    ring
  rw [Finset.sum_congr rfl hL1, Finset.sum_congr rfl hR1] at h
  rw [← Finset.sum_product (s := Epi lab π) (t := S)
    (f := fun y => Real.log S.card - Real.log (Scl S lab y.1.1 y.1.2 (lab (y.2 y.1.1 y.1.2))).card)]
  refine h.trans (le_of_eq ?_)
  rw [Finset.sum_product_right]
  rw [Finset.sum_congr rfl fun T hT => sum_by_third lab T π
    (fun X => Real.log (Epi lab π).card - Real.log (M X))]
  rw [Finset.sum_congr rfl fun T hT => Finset.sum_congr rfl fun X _ => by rw [hM T hT X],
    Finset.sum_const, nsmul_eq_mul]

/-- **The aggregated typed bound.** -/
theorem typed_agg_bound (hS : ∀ T ∈ S, IsSQ T) (hne : S.Nonempty) (lab : Fin n → Fin k)
    (hL : 0 < L) (M : Multiset (Fin k) → Fin k → ℕ)
    (hM : ∀ T ∈ S, ∀ π X, Mstat lab T π X = M π X) :
    Real.log S.card ≤ ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) *
      (Wsum L * (Real.log (Epi lab π).card - Real.log (M π X)) + Psi L (compl lab π X)) := by
  have hS0 : (0 : ℝ) < S.card := by exact_mod_cast hne.card_pos
  have h0 := typed_raw_bound (L := L) hS lab hL
  -- rearrange the raw bound
  have hre : ∀ p ∈ pairs n, ∑ r : Fin L, wr L r * ∑ T ∈ S,
      ((Real.log S.card - Real.log (Scl S lab p.1 p.2 (lab (T p.1 p.2))).card) +
        Real.log (1 + (cand lab T p.1 p.2).card * (((L : ℝ) - r) / L) ^ 6)) =
      Wsum L * ∑ T ∈ S, (Real.log S.card - Real.log (Scl S lab p.1 p.2 (lab (T p.1 p.2))).card) +
        ∑ T ∈ S, Psi L (cand lab T p.1 p.2).card := by
    intro p _
    have hc : ∑ T ∈ S, ∑ r : Fin L, wr L r * Real.log (1 + ((cand lab T p.1 p.2).card : ℝ) *
        (((L : ℝ) - r) / L) ^ 6) = ∑ r : Fin L, ∑ T ∈ S, wr L r *
        Real.log (1 + ((cand lab T p.1 p.2).card : ℝ) * (((L : ℝ) - r) / L) ^ 6) :=
      Finset.sum_comm
    unfold Wsum Psi
    rw [Finset.sum_mul, hc, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun r _ => ?_
    rw [Finset.sum_add_distrib, mul_add]
    simp only [Finset.mul_sum]
  rw [Finset.sum_congr rfl hre, Finset.sum_add_distrib, ← Finset.mul_sum] at h0
  -- the class part
  have hW : 0 ≤ Wsum L := Finset.sum_nonneg fun r _ => wr_nonneg L r
  have hA : ∑ p ∈ pairs n, ∑ T ∈ S,
      (Real.log S.card - Real.log (Scl S lab p.1 p.2 (lab (T p.1 p.2))).card) ≤
      S.card * ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) *
        (Real.log (Epi lab π).card - Real.log (M π X)) := by
    rw [sum_pairs_by_class lab, Finset.mul_sum]
    exact Finset.sum_le_sum fun π _ => class_agg lab π (M π) (fun T hT X => hM T hT π X) hne
  -- the point part
  have hB : ∑ p ∈ pairs n, ∑ T ∈ S, Psi L (cand lab T p.1 p.2).card ≤
      S.card * ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) * Psi L (compl lab π X) := by
    rw [sum_pairs_by_class lab, Finset.mul_sum]
    refine Finset.sum_le_sum fun π _ => ?_
    have h1 : ∀ p ∈ Epi lab π, ∀ T ∈ S, Psi L (cand lab T p.1 p.2).card ≤
        Psi L (compl lab π (lab (T p.1 p.2))) := by
      intro p hp T _
      have hπ : ({lab p.1, lab p.2} : Multiset (Fin k)) = π := (Finset.mem_filter.mp hp).2
      refine Psi_mono L (Nat.cast_nonneg _) ?_
      rw [← hπ]
      have hpq : p.1 ≠ p.2 := by
        have := (Finset.mem_filter.mp (Finset.mem_filter.mp hp).1).2
        exact this.ne
      exact_mod_cast cand_le lab T hpq
    refine (Finset.sum_le_sum fun p hp => Finset.sum_le_sum fun T hT => h1 p hp T hT).trans
      (le_of_eq ?_)
    rw [Finset.sum_comm]
    rw [Finset.sum_congr rfl fun T hT => sum_by_third lab T π
      (fun X => Psi L (compl lab π X))]
    rw [Finset.sum_congr rfl fun T hT => Finset.sum_congr rfl fun X _ => by rw [hM T hT π X],
      Finset.sum_const, nsmul_eq_mul]
  have htot : (S.card : ℝ) * Real.log S.card ≤ S.card * ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) *
      (Wsum L * (Real.log (Epi lab π).card - Real.log (M π X)) + Psi L (compl lab π X)) := by
    have hWA := mul_le_mul_of_nonneg_left hA hW
    have : (S.card : ℝ) * ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) *
        (Wsum L * (Real.log (Epi lab π).card - Real.log (M π X)) + Psi L (compl lab π X)) =
        Wsum L * (S.card * ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) *
          (Real.log (Epi lab π).card - Real.log (M π X))) +
        S.card * ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) * Psi L (compl lab π X) := by
      simp only [mul_add, Finset.sum_add_distrib, Finset.mul_sum]
      congr 1
      refine Finset.sum_congr rfl fun π _ => Finset.sum_congr rfl fun X _ => ?_
      ring
    rw [this]
    linarith
  exact le_of_mul_le_mul_left htot hS0

end ColourStats.TypedSTS
