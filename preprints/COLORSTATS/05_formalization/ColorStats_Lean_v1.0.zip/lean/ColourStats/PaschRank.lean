/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.PaschHub

/-!
# Rank of the pair-preserving lattice and the Pasch configuration (Lemma 5.14)

Complements to `ColourStats.PaschHub`.

* `card_symTypes_avoid`: there are `C(k − 1 + r − 1, r)` multisets of `r` classes avoiding a
  fixed class; so `C(k + 1, 3)` block types and `C(k, 2)` pair classes avoid it
  (`card_avoid`, `card_pairAvoid`).
* `Lam k`: the pair-preserving lattice, as a `ℤ`-submodule of the functions on block types.
  `lamEquiv` identifies it with `ℤ^{types avoiding o}`, and `finrank_Lam` gives
  `rank Λ = C(k + 1, 3)`.
* The Pasch configuration on six points: two families `paschA`, `paschB` of four triples,
  each a partial Steiner triple system, covering the same twelve pairs
  (`pasch_card`, `pasch_partial`, `pasch_same_pairs`, `pasch_disjoint`). If points `0, 1, 2`
  carry the classes `a, b, c` and points `3, 4, 5` carry `o`, replacing the blocks of
  `paschA` by those of `paschB` changes the type counts by `hub o {a, b, c}`
  (`hub_eq_pasch`). This is the switch of the paper's hub trade.
-/

@[expose] public section

open Finset

namespace ColourStats

variable {k : ℕ}

/-! ### Counting the types that avoid a class -/

/-- Multisets of `r` classes in `Fin k`. -/
def symTypes (k r : ℕ) : Finset (Multiset (Fin k)) :=
  (Finset.univ : Finset (Sym (Fin k) r)).map ⟨Sym.toMultiset, Sym.coe_injective⟩

lemma blockTypes_eq : blockTypes k = symTypes k 3 := rfl

lemma pairTypes_eq : pairTypes k = symTypes k 2 := rfl

lemma mem_symTypes {r : ℕ} {σ : Multiset (Fin k)} : σ ∈ symTypes k r ↔ Multiset.card σ = r := by
  constructor
  · intro h
    obtain ⟨s, -, rfl⟩ := Finset.mem_map.mp h
    exact s.2
  · intro h
    exact Finset.mem_map.mpr ⟨⟨σ, h⟩, Finset.mem_univ _, rfl⟩

lemma card_ne (o : Fin k) : Fintype.card {x : Fin k // x ≠ o} = k - 1 := by
  rw [Fintype.card_subtype, Finset.filter_ne', Finset.card_erase_of_mem (Finset.mem_univ o),
    Finset.card_univ, Fintype.card_fin]

/-- There are `C(k − 1 + r − 1, r)` multisets of `r` classes avoiding `o`. -/
theorem card_symTypes_avoid (o : Fin k) (r : ℕ) :
    ((symTypes k r).filter (fun σ => o ∉ σ)).card = (k - 1 + r - 1).choose r := by
  let f : Sym {x : Fin k // x ≠ o} r ↪ Multiset (Fin k) :=
    ⟨fun s => (s : Multiset {x : Fin k // x ≠ o}).map Subtype.val, fun s t h =>
      Sym.coe_injective (Multiset.map_injective Subtype.val_injective h)⟩
  have he : (symTypes k r).filter (fun σ => o ∉ σ) =
      (Finset.univ : Finset (Sym {x : Fin k // x ≠ o} r)).map f := by
    ext σ
    simp only [mem_filter, mem_symTypes, mem_map, mem_univ, true_and]
    constructor
    · rintro ⟨hr, ho⟩
      refine ⟨⟨σ.attach.map fun x => ⟨x.1, fun h => ho (h ▸ x.2)⟩, by simp [hr]⟩, ?_⟩
      simp [f, Multiset.map_map]
    · rintro ⟨s, rfl⟩
      refine ⟨by simp [f], fun hx => ?_⟩
      change o ∈ Multiset.map Subtype.val (s : Multiset {x : Fin k // x ≠ o}) at hx
      obtain ⟨x, _, hx⟩ := Multiset.mem_map.mp hx
      exact x.2 hx
  rw [he, card_map, card_univ, Sym.card_sym_eq_choose, card_ne]

/-- The block types avoiding `o`. -/
def avoid (o : Fin k) : Finset (Multiset (Fin k)) := (blockTypes k).filter (fun σ => o ∉ σ)

/-- `C(k + 1, 3)` block types avoid a class. -/
theorem card_avoid (o : Fin k) : (avoid o).card = (k + 1).choose 3 := by
  have hk : 1 ≤ k := o.pos
  rw [avoid, blockTypes_eq, card_symTypes_avoid]
  congr 1
  omega

/-- `C(k, 2)` pair classes avoid a class. -/
theorem card_pairAvoid (o : Fin k) :
    ((pairTypes k).filter (fun π => o ∉ π)).card = k.choose 2 := by
  have hk : 1 ≤ k := o.pos
  rw [pairTypes_eq, card_symTypes_avoid]
  congr 1
  omega

/-! ### The rank of `Λ` -/

/-- The pair-preserving lattice `Λ`, as a submodule of the functions on block types. -/
def Lam (k : ℕ) : Submodule ℤ (blockTypes k → ℤ) where
  carrier := {d | ∀ π ∈ pairTypes k, ∑ τ : blockTypes k, (mult π τ : ℤ) * d τ = 0}
  add_mem' := by
    intro d e hd he π hπ
    simp only [Set.mem_ofPred_eq] at hd he ⊢
    simp only [Pi.add_apply, mul_add, Finset.sum_add_distrib, hd π hπ, he π hπ, add_zero]
  zero_mem' := by
    intro π _
    simp
  smul_mem' := by
    intro c d hd π hπ
    simp only [Set.mem_ofPred_eq] at hd
    simp only [Pi.smul_apply, smul_eq_mul]
    rw [show ∑ τ : blockTypes k, (mult π τ : ℤ) * (c * d τ) =
        c * ∑ τ : blockTypes k, (mult π τ : ℤ) * d τ by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun τ _ => by ring, hd π hπ, mul_zero]

/-- Extension by zero of a function on block types. -/
noncomputable def extend (d : blockTypes k → ℤ) (τ : Multiset (Fin k)) : ℤ :=
  if h : τ ∈ blockTypes k then d ⟨τ, h⟩ else 0

lemma extend_coe (d : blockTypes k → ℤ) (τ : blockTypes k) : extend d τ = d τ := by
  simp [extend, τ.2]

lemma sum_extend (f : Multiset (Fin k) → ℤ) (d : blockTypes k → ℤ) :
    ∑ τ ∈ blockTypes k, f τ * extend d τ = ∑ τ : blockTypes k, f τ * d τ := by
  rw [← Finset.sum_coe_sort]
  exact Finset.sum_congr rfl fun τ _ => by rw [extend_coe]

lemma mem_Lam_iff (d : blockTypes k → ℤ) : d ∈ Lam k ↔ PairPreserving (extend d) := by
  show (∀ π ∈ pairTypes k, _) ↔ ∀ π ∈ pairTypes k, _
  simp only [sum_extend]

/-- The coordinates of `Λ`: the values on the types avoiding `o`. -/
noncomputable def lamCoord (o : Fin k) : Lam k →ₗ[ℤ] (avoid o → ℤ) where
  toFun d σ := d.1 ⟨σ.1, (Finset.mem_filter.mp σ.2).1⟩
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

lemma lamCoord_injective (o : Fin k) : Function.Injective (lamCoord o) := by
  rw [← LinearMap.ker_eq_bot, LinearMap.ker_eq_bot']
  intro d hd
  have hpp := (mem_Lam_iff d.1).mp d.2
  have h0 : ∀ τ ∈ blockTypes k, o ∉ τ → extend d.1 τ = 0 := by
    intro τ hτ ho
    have := congrFun hd ⟨τ, Finset.mem_filter.mpr ⟨hτ, ho⟩⟩
    simpa [lamCoord, extend, hτ] using this
  have hz := hub_unique hpp o h0
  ext τ
  simpa [extend_coe] using hz τ τ.2

/-- The element of `Λ` with prescribed values `c` on the types avoiding `o`. -/
noncomputable def lamOf (o : Fin k) (c : avoid o → ℤ) : blockTypes k → ℤ :=
  fun τ => ∑ σ : avoid o, c σ * hub o σ τ

lemma lamOf_mem (o : Fin k) (c : avoid o → ℤ) : lamOf o c ∈ Lam k := by
  intro π hπ
  simp only [lamOf, Finset.mul_sum]
  rw [Finset.sum_comm]
  refine Finset.sum_eq_zero fun σ _ => ?_
  have hσ3 := mem_blockTypes.mp (Finset.mem_filter.mp σ.2).1
  have h := hub_pairPreserving o hσ3 π hπ
  calc ∑ τ : blockTypes k, (mult π τ : ℤ) * (c σ * hub o σ τ)
      = c σ * ∑ τ : blockTypes k, (mult π (τ : Multiset (Fin k)) : ℤ) * hub o σ τ := by
        rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun τ _ => by ring
    _ = c σ * ∑ τ ∈ blockTypes k, (mult π τ : ℤ) * hub o σ τ := by
        rw [Finset.sum_coe_sort (blockTypes k) (fun τ => (mult π τ : ℤ) * hub o σ τ)]
    _ = 0 := by rw [h, mul_zero]

lemma lamCoord_lamOf (o : Fin k) (c : avoid o → ℤ) :
    lamCoord o ⟨lamOf o c, lamOf_mem o c⟩ = c := by
  funext σ
  have hoσ : o ∉ (σ : Multiset (Fin k)) := (Finset.mem_filter.mp σ.2).2
  simp only [lamCoord, LinearMap.coe_mk, AddHom.coe_mk, lamOf, hub_apply_of_not_mem hoσ]
  rw [Finset.sum_eq_single σ]
  · simp
  · intro σ' _ hne
    rw [if_neg (fun h => hne (Subtype.ext h).symm), mul_zero]
  · simp

/-- `Λ ≅ ℤ^{types avoiding o}`. -/
noncomputable def lamEquiv (o : Fin k) : Lam k ≃ₗ[ℤ] (avoid o → ℤ) :=
  LinearEquiv.ofBijective (lamCoord o)
    ⟨lamCoord_injective o, fun c => ⟨⟨lamOf o c, lamOf_mem o c⟩, lamCoord_lamOf o c⟩⟩

/-- **Rank of the pair-preserving lattice.** `rank Λ = C(k + 1, 3)` for `k ≥ 1` classes. -/
theorem finrank_Lam (hk : 1 ≤ k) : Module.finrank ℤ (Lam k) = (k + 1).choose 3 := by
  let o : Fin k := ⟨0, hk⟩
  rw [(lamEquiv o).finrank_eq, Module.finrank_fintype_fun_eq_card, Fintype.card_coe,
    card_avoid]

/-! ### The Pasch configuration -/

/-- First family of the Pasch configuration on six points. -/
def paschA : Finset (Finset (Fin 6)) := {{0, 1, 2}, {0, 3, 4}, {1, 3, 5}, {2, 4, 5}}

/-- Second family of the Pasch configuration on six points. -/
def paschB : Finset (Finset (Fin 6)) := {{3, 4, 5}, {0, 1, 3}, {0, 2, 4}, {1, 2, 5}}

lemma pasch_card : paschA.card = 4 ∧ paschB.card = 4 ∧
    (∀ B ∈ paschA, B.card = 3) ∧ ∀ B ∈ paschB, B.card = 3 := by
  decide

/-- Each family is a partial Steiner triple system: two blocks share at most one point. -/
lemma pasch_partial :
    (∀ B ∈ paschA, ∀ C ∈ paschA, B ≠ C → (B ∩ C).card ≤ 1) ∧
      ∀ B ∈ paschB, ∀ C ∈ paschB, B ≠ C → (B ∩ C).card ≤ 1 := by
  decide

/-- Both families cover the same twelve pairs. -/
lemma pasch_same_pairs :
    paschA.biUnion (fun B => B.powersetCard 2) = paschB.biUnion (fun B => B.powersetCard 2) ∧
      (paschA.biUnion (fun B => B.powersetCard 2)).card = 12 := by
  decide

lemma pasch_disjoint : Disjoint paschA paschB := by
  decide

/-- The labelling `0, 1, 2 ↦ 0, 1, 2` and `3, 4, 5 ↦ 3` of the six points. -/
def paschLab : Fin 6 → Fin 4 := ![0, 1, 2, 3, 3, 3]

lemma pasch_types_generic :
    paschA.val.map (fun B => B.val.map paschLab) = hubPos 3 {0, 1, 2} ∧
      paschB.val.map (fun B => B.val.map paschLab) = hubNeg 3 {0, 1, 2} := by
  decide

/-- The types of the two Pasch families when points `0, 1, 2` carry `a, b, c` and points
`3, 4, 5` carry `o` are the two sides of the hub trade. -/
theorem pasch_types (lab : Fin 6 → Fin k) {a b c o : Fin k} (h0 : lab 0 = a) (h1 : lab 1 = b)
    (h2 : lab 2 = c) (h3 : lab 3 = o) (h4 : lab 4 = o) (h5 : lab 5 = o) :
    paschA.val.map (fun B => B.val.map lab) = hubPos o {a, b, c} ∧
      paschB.val.map (fun B => B.val.map lab) = hubNeg o {a, b, c} := by
  let g : Fin 4 → Fin k := ![a, b, c, o]
  have hlab : lab = g ∘ paschLab := by
    funext i
    fin_cases i <;> simp [g, paschLab, h0, h1, h2, h3, h4, h5]
  have habc : ({a, b, c} : Multiset (Fin k)) = ({0, 1, 2} : Multiset (Fin 4)).map g := by
    simp [g]
  have hog : o = g 3 := rfl
  have hmap : ∀ F : Finset (Finset (Fin 6)), F.val.map (fun B => B.val.map lab) =
      (F.val.map (fun B => B.val.map paschLab)).map (Multiset.map g) := by
    intro F
    rw [Multiset.map_map]
    congr 1
    funext B
    simp [hlab, Multiset.map_map]
  obtain ⟨hA, hB⟩ := pasch_types_generic
  rw [hmap, hmap, hA, hB, habc, hog, hubPos_map, hubNeg_map]
  exact ⟨rfl, rfl⟩

/-- **The hub trade is a Pasch switch.** Replacing the blocks of `paschA` by those of
`paschB` changes the number of blocks of type `τ` by `hub o {a, b, c} τ`. -/
theorem hub_eq_pasch (lab : Fin 6 → Fin k) {a b c o : Fin k} (h0 : lab 0 = a) (h1 : lab 1 = b)
    (h2 : lab 2 = c) (h3 : lab 3 = o) (h4 : lab 4 = o) (h5 : lab 5 = o)
    (τ : Multiset (Fin k)) :
    hub o {a, b, c} τ = ((paschA.val.map (fun B => B.val.map lab)).count τ : ℤ) -
      ((paschB.val.map (fun B => B.val.map lab)).count τ : ℤ) := by
  obtain ⟨hA, hB⟩ := pasch_types lab h0 h1 h2 h3 h4 h5
  rw [hA, hB]
  rfl

end ColourStats
