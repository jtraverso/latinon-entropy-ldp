/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import RequestProject.TypedTriangle.Absorb

/-!
# The `K₄` gadget and the first-order correction of Lemma 5.19

For disjoint edges `e = ab` and `f = xy` spanning a `K₄`, the gadget
`g(e, f) = ½(1_{abx} + 1_{aby} − 1_{axy} − 1_{bxy})` satisfies `A g(e, f) = 1_e − 1_f`,
where `A` sends a triangle to its three edges. In integer form (`gadget_identity`):

    1_{E(abx)} + 1_{E(aby)} − 1_{E(axy)} − 1_{E(bxy)} = 2·1_{ab} − 2·1_{xy}.

Averaging gadgets over a law `ν_e` on the partners of `e` gives
`Φ₁ r = Σ_e r(e) Σ_f ν_e(f) g(e, f)` with `AΦ₁ r = r − T r`, where
`(T r)(f) = Σ_e r(e) ν_e(f)` (`apply_Phi₁`). This is a statement about any linear map `A`
and any family of gadgets with `A g(e, f) = 1_e − 1_f` on the support of `ν_e`.
-/

@[expose] public section

open Finset

namespace ColourStats.E3Gadget

open TypedTriangle

variable {V : Type*}

lemma ind_singleton_sum (J : Finset (Sym2 V)) :
    ∑ e ∈ J, ind ({e} : Finset (Sym2 V)) = ind J := by
  classical
  funext x
  simp [ind, Finset.sum_apply]

open Classical in
/-- The edge indicator of a triangle is the sum of its three edge indicators. -/
lemma ind_triEdges_three {u v w : V} (huv : u ≠ v) (huw : u ≠ w)
    (hvw : v ≠ w) :
    ind (triEdges ({u, v, w} : Finset V)) =
      ind {s(u, v)} + ind {s(u, w)} + ind {s(v, w)} := by
  classical
  rw [triEdges_eq_insert_wedge huv huw hvw, ← ind_singleton_sum,
    Finset.sum_insert (not_mem_wedge huv huw hvw)]
  have hne : s(u, w) ≠ s(v, w) := by simp [huv, huw]
  simp only [wedge]
  rw [Finset.sum_pair hne, add_assoc]

open Classical in
/-- **The `K₄` gadget identity** (Lemma 5.19), in integer form. -/
theorem gadget_identity {a b x y : V} (hab : a ≠ b) (hax : a ≠ x)
    (hay : a ≠ y) (hbx : b ≠ x) (hby : b ≠ y) (hxy : x ≠ y) :
    ind (triEdges ({a, b, x} : Finset V)) + ind (triEdges ({a, b, y} : Finset V)) -
        ind (triEdges ({a, x, y} : Finset V)) - ind (triEdges ({b, x, y} : Finset V)) =
      2 • ind {s(a, b)} - 2 • ind {s(x, y)} := by
  rw [ind_triEdges_three hab hax hbx, ind_triEdges_three hab hay hby,
    ind_triEdges_three hax hay hxy, ind_triEdges_three hbx hby hxy]
  abel

section Correction

variable {E Tri : Type*} [Fintype E] [DecidableEq E]

/-- `Φ₁ r = Σ_e r(e) Σ_f ν_e(f) g(e, f)`. -/
noncomputable def Phi₁ (ν : E → E → ℝ) (g : E → E → Tri → ℝ) (r : E → ℝ) : Tri → ℝ :=
  ∑ e, r e • ∑ f, ν e f • g e f

/-- `(T r)(f) = Σ_e r(e) ν_e(f)`. -/
noncomputable def Tmap (ν : E → E → ℝ) (r : E → ℝ) : E → ℝ := fun f => ∑ e, r e * ν e f

/-- **First-order correction.** If `A g(e, f) = 1_e − 1_f` whenever `ν_e(f) ≠ 0` and every
`ν_e` sums to one, then `A Φ₁ r = r − T r`. -/
theorem apply_Phi₁ (A : (Tri → ℝ) →ₗ[ℝ] (E → ℝ)) (ν : E → E → ℝ) (g : E → E → Tri → ℝ)
    (hg : ∀ e f, ν e f ≠ 0 → A (g e f) = Pi.single e 1 - Pi.single f 1)
    (hν : ∀ e, ∑ f, ν e f = 1) (r : E → ℝ) :
    A (Phi₁ ν g r) = r - Tmap ν r := by
  have h1 : ∀ e f, ν e f • A (g e f) = ν e f • (Pi.single e 1 - Pi.single f 1 : E → ℝ) := by
    intro e f
    by_cases h : ν e f = 0
    · simp [h]
    · rw [hg e f h]
  unfold Phi₁
  simp only [map_sum, map_smul, h1]
  funext x
  simp only [Finset.sum_apply, Pi.smul_apply, Pi.sub_apply, smul_eq_mul, Pi.single_apply,
    Tmap]
  have hrow : ∀ e, ∑ f, ν e f * ((if x = e then (1 : ℝ) else 0) - (if x = f then 1 else 0)) =
      (if x = e then 1 else 0) - ν e x := by
    intro e
    rw [Finset.sum_congr rfl fun f _ => mul_sub _ _ _, Finset.sum_sub_distrib,
      ← Finset.sum_mul, hν e, one_mul]
    simp [mul_ite]
  simp only [hrow]
  simp [mul_sub, Finset.sum_sub_distrib, mul_ite]

end Correction

end ColourStats.E3Gadget
