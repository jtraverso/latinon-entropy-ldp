/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import Mathlib

/-!
# The Pasch hub basis (Lemma 5.14)

Block types are multisets of three classes in `Fin k`, and pair classes are multisets of
two classes. `mult π τ` is the number of pairs of class `π` inside a triple of type `τ`.
A change of type counts `d` is *pair-preserving* if it does not change the number of
pairs of any class. For a fixed class `o` and a type `σ` avoiding `o`, the hub trade
`hub o σ` is the change of types produced by switching a Pasch configuration whose points
`0, 1, 2` carry the classes of `σ` and whose points `3, 4, 5` carry the class `o`:

    hub o σ = 1_σ + Σ_i 1_{σ_i o o} − Σ_{i<j} 1_{σ_i σ_j o} − 1_{o o o}.

Main results:
* `hub_pairPreserving`: every hub trade is pair-preserving;
* `hub_unique`: a pair-preserving change vanishing on the types avoiding `o` is zero;
* `hub_basis`: every pair-preserving change is `Σ_{σ ∌ o} d σ • hub o σ`.

Together these say that the hub trades form a `ℤ`-basis of the pair-preserving lattice
(the coefficients are forced to be the values `d σ`).
-/

@[expose] public section

open Finset

namespace ColourStats

variable {k : ℕ}

/-- The pairs inside a block type, as a multiset of pair classes. -/
def pairs (τ : Multiset (Fin k)) : Multiset (Multiset (Fin k)) := τ.powersetCard 2

/-- `mult π τ`: the number of pairs of class `π` inside a triple of type `τ`. -/
def mult (π τ : Multiset (Fin k)) : ℕ := (pairs τ).count π

/-- The block types: multisets of three classes. -/
def blockTypes (k : ℕ) : Finset (Multiset (Fin k)) :=
  (Finset.univ : Finset (Sym (Fin k) 3)).map ⟨Sym.toMultiset, Sym.coe_injective⟩

/-- The pair classes: multisets of two classes. -/
def pairTypes (k : ℕ) : Finset (Multiset (Fin k)) :=
  (Finset.univ : Finset (Sym (Fin k) 2)).map ⟨Sym.toMultiset, Sym.coe_injective⟩

lemma mem_blockTypes {τ : Multiset (Fin k)} : τ ∈ blockTypes k ↔ Multiset.card τ = 3 := by
  constructor
  · intro h
    obtain ⟨s, -, rfl⟩ := Finset.mem_map.mp h
    exact s.2
  · intro h
    exact Finset.mem_map.mpr ⟨⟨τ, h⟩, Finset.mem_univ _, rfl⟩

lemma mem_pairTypes {π : Multiset (Fin k)} : π ∈ pairTypes k ↔ Multiset.card π = 2 := by
  constructor
  · intro h
    obtain ⟨s, -, rfl⟩ := Finset.mem_map.mp h
    exact s.2
  · intro h
    exact Finset.mem_map.mpr ⟨⟨π, h⟩, Finset.mem_univ _, rfl⟩

/-- A change of type counts is *pair-preserving* if it does not change the number of pairs
of any class. -/
def PairPreserving (d : Multiset (Fin k) → ℤ) : Prop :=
  ∀ π ∈ pairTypes k, ∑ τ ∈ blockTypes k, (mult π τ : ℤ) * d τ = 0

lemma eq_cons_of_mult_ne_zero {π τ : Multiset (Fin k)} (hτ : Multiset.card τ = 3)
    (h : mult π τ ≠ 0) : ∃ C, τ = C ::ₘ π := by
  have hmem : π ∈ pairs τ := Multiset.count_pos.mp (Nat.pos_of_ne_zero h)
  obtain ⟨hle, hcard⟩ := Multiset.mem_powersetCard.mp hmem
  obtain ⟨u, rfl⟩ := Multiset.le_iff_exists_add.mp hle
  have hu : Multiset.card u = 1 := by
    rw [Multiset.card_add, hcard] at hτ
    omega
  obtain ⟨C, rfl⟩ := Multiset.card_eq_one.mp hu
  exact ⟨C, by rw [add_comm, Multiset.singleton_add]⟩

lemma mult_cons_ne_zero {π : Multiset (Fin k)} (hπ : Multiset.card π = 2) (C : Fin k) :
    mult π (C ::ₘ π) ≠ 0 :=
  Nat.pos_iff_ne_zero.mp (Multiset.count_pos.mpr
    (Multiset.mem_powersetCard.mpr ⟨Multiset.le_cons_self _ _, hπ⟩))

/-- If the only type through the pair class `π` on which `d` can be nonzero is `C₀ π`,
then pair preservation at `π` forces `d (C₀ π) = 0`. -/
lemma eq_zero_of_single {d : Multiset (Fin k) → ℤ} (hd : PairPreserving d)
    {π : Multiset (Fin k)} (hπ : Multiset.card π = 2) (C₀ : Fin k)
    (h : ∀ C, C ≠ C₀ → d (C ::ₘ π) = 0) : d (C₀ ::ₘ π) = 0 := by
  have hsum := hd π (mem_pairTypes.mpr hπ)
  have hτ₀ : C₀ ::ₘ π ∈ blockTypes k := mem_blockTypes.mpr (by simp [hπ])
  rw [Finset.sum_eq_single_of_mem _ hτ₀] at hsum
  · rcases mul_eq_zero.mp hsum with h1 | h1
    · exact absurd (by exact_mod_cast h1) (mult_cons_ne_zero hπ C₀)
    · exact h1
  · intro τ hτ hne
    by_cases hm : mult π τ = 0
    · simp [hm]
    · obtain ⟨C, rfl⟩ := eq_cons_of_mult_ne_zero (mem_blockTypes.mp hτ) hm
      have hC : C ≠ C₀ := fun hC => hne (by rw [hC])
      simp [h C hC]

lemma cons_pair_rotate (C A o : Fin k) :
    C ::ₘ ({A, o} : Multiset (Fin k)) = o ::ₘ ({C, A} : Multiset (Fin k)) := by
  simp only [Multiset.insert_eq_cons, ← Multiset.cons_zero]
  rw [Multiset.cons_swap A o, Multiset.cons_swap C o]

/-- **Uniqueness.** A pair-preserving change that vanishes on every type avoiding `o`
vanishes on every type. -/
theorem hub_unique {d : Multiset (Fin k) → ℤ} (hd : PairPreserving d) (o : Fin k)
    (h0 : ∀ τ ∈ blockTypes k, o ∉ τ → d τ = 0) : ∀ τ ∈ blockTypes k, d τ = 0 := by
  have s1 : ∀ A B : Fin k, A ≠ o → B ≠ o → d (o ::ₘ {A, B}) = 0 := by
    intro A B hA hB
    apply eq_zero_of_single hd (by simp) o
    intro C hC
    apply h0 _ (mem_blockTypes.mpr (by simp))
    simp [Ne.symm hC, Ne.symm hA, Ne.symm hB]
  have s2 : ∀ A : Fin k, A ≠ o → d (o ::ₘ {A, o}) = 0 := by
    intro A hA
    apply eq_zero_of_single hd (by simp) o
    intro C hC
    rw [cons_pair_rotate]
    exact s1 C A hC hA
  have s3 : d (o ::ₘ {o, o}) = 0 := by
    apply eq_zero_of_single hd (by simp) o
    intro C hC
    rw [cons_pair_rotate]
    exact s2 C hC
  intro τ hτ
  by_cases ho : o ∈ τ
  · obtain ⟨r, rfl⟩ := Multiset.exists_cons_of_mem ho
    have hr : Multiset.card r = 2 := by
      have := mem_blockTypes.mp hτ
      simp only [Multiset.card_cons] at this
      omega
    obtain ⟨A, B, rfl⟩ := Multiset.card_eq_two.mp hr
    by_cases hA : A = o <;> by_cases hB : B = o
    · rw [hA, hB]; exact s3
    · rw [hA, Multiset.pair_comm]; exact s2 B hB
    · rw [hB]; exact s2 A hA
    · exact s1 A B hA hB
  · exact h0 τ hτ ho

/-! ### The hub trades -/

/-- The blocks removed by the hub trade: `σ` and `σ_i o o`. -/
def hubPos (o : Fin k) (σ : Multiset (Fin k)) : Multiset (Multiset (Fin k)) :=
  σ ::ₘ σ.map (fun x => {x, o, o})

/-- The blocks added by the hub trade: `σ_i σ_j o` and `o o o`. -/
def hubNeg (o : Fin k) (σ : Multiset (Fin k)) : Multiset (Multiset (Fin k)) :=
  {o, o, o} ::ₘ (pairs σ).map (fun p => o ::ₘ p)

/-- The hub trade as a change of type counts. -/
def hub (o : Fin k) (σ : Multiset (Fin k)) (τ : Multiset (Fin k)) : ℤ :=
  ((hubPos o σ).count τ : ℤ) - ((hubNeg o σ).count τ : ℤ)

/-- The generic hub on four classes `0, 1, 2` and hub `3`: both families cover the same
twelve pairs. -/
lemma hub_pairs_generic :
    (hubPos (3 : Fin 4) {0, 1, 2}).bind pairs = (hubNeg (3 : Fin 4) {0, 1, 2}).bind pairs := by
  decide

lemma pairs_map {k' : ℕ} (g : Fin k' → Fin k) (s : Multiset (Fin k')) :
    pairs (s.map g) = (pairs s).map (Multiset.map g) := by
  simp [pairs, Multiset.powersetCard_map]

lemma hubPos_map {k' : ℕ} (g : Fin k' → Fin k) (o : Fin k') (s : Multiset (Fin k')) :
    hubPos (g o) (s.map g) = (hubPos o s).map (Multiset.map g) := by
  simp [hubPos, Multiset.map_map]

lemma hubNeg_map {k' : ℕ} (g : Fin k' → Fin k) (o : Fin k') (s : Multiset (Fin k')) :
    hubNeg (g o) (s.map g) = (hubNeg o s).map (Multiset.map g) := by
  simp [hubNeg, pairs_map, Multiset.map_map]

lemma bind_pairs_map {k' : ℕ} (g : Fin k' → Fin k) (M : Multiset (Multiset (Fin k'))) :
    (M.map (Multiset.map g)).bind pairs = ((M.bind pairs).map (Multiset.map g)) := by
  rw [Multiset.bind_map, Multiset.map_bind]
  congr 1
  funext s
  exact pairs_map g s

/-- Both families of the hub trade cover the same multiset of pair classes. -/
theorem hub_pairs (o : Fin k) {σ : Multiset (Fin k)} (hσ : Multiset.card σ = 3) :
    (hubPos o σ).bind pairs = (hubNeg o σ).bind pairs := by
  obtain ⟨a, b, c, rfl⟩ := Multiset.card_eq_three.mp hσ
  let g : Fin 4 → Fin k := ![a, b, c, o]
  have hσg : ({a, b, c} : Multiset (Fin k)) = ({0, 1, 2} : Multiset (Fin 4)).map g := by
    simp [g]
  have hog : o = g 3 := rfl
  rw [hσg, hog, hubPos_map, hubNeg_map, bind_pairs_map, bind_pairs_map, hub_pairs_generic]

lemma sum_mul_count {M : Multiset (Multiset (Fin k))} (hM : ∀ τ ∈ M, τ ∈ blockTypes k)
    (f : Multiset (Fin k) → ℤ) :
    ∑ τ ∈ blockTypes k, f τ * (M.count τ : ℤ) = (M.map f).sum := by
  induction M using Multiset.induction_on with
  | empty => simp
  | cons a M ih =>
    have ha := hM a (Multiset.mem_cons_self _ _)
    rw [Multiset.map_cons, Multiset.sum_cons,
      ← ih (fun τ h => hM τ (Multiset.mem_cons_of_mem h))]
    simp only [Multiset.count_cons, Nat.cast_add, mul_add, Finset.sum_add_distrib]
    rw [add_comm]
    congr 1
    rw [Finset.sum_eq_single_of_mem a ha (fun b _ hb => by simp [hb])]
    simp

lemma hubPos_mem {o : Fin k} {σ : Multiset (Fin k)} (hσ : Multiset.card σ = 3) :
    ∀ τ ∈ hubPos o σ, τ ∈ blockTypes k := by
  intro τ hτ
  rw [mem_blockTypes]
  simp only [hubPos, Multiset.mem_cons, Multiset.mem_map] at hτ
  rcases hτ with rfl | ⟨x, -, rfl⟩
  · exact hσ
  · simp

lemma hubNeg_mem {o : Fin k} {σ : Multiset (Fin k)} :
    ∀ τ ∈ hubNeg o σ, τ ∈ blockTypes k := by
  intro τ hτ
  rw [mem_blockTypes]
  simp only [hubNeg, Multiset.mem_cons, Multiset.mem_map] at hτ
  rcases hτ with rfl | ⟨p, hp, rfl⟩
  · simp
  · simp [(Multiset.mem_powersetCard.mp hp).2]

lemma sum_mult_eq_count_bind (π : Multiset (Fin k)) (M : Multiset (Multiset (Fin k))) :
    (M.map fun τ => (mult π τ : ℤ)).sum = ((M.bind pairs).count π : ℤ) := by
  rw [Multiset.count_bind, Nat.cast_multiset_sum, Multiset.map_map]
  rfl

/-- Every hub trade is pair-preserving. -/
theorem hub_pairPreserving (o : Fin k) {σ : Multiset (Fin k)} (hσ : Multiset.card σ = 3) :
    PairPreserving (hub o σ) := by
  intro π _
  have hP := sum_mul_count (hubPos_mem (o := o) hσ) (fun τ => (mult π τ : ℤ))
  have hN := sum_mul_count (hubNeg_mem (o := o) (σ := σ)) (fun τ => (mult π τ : ℤ))
  simp only [hub, mul_sub, Finset.sum_sub_distrib]
  rw [hP, hN, sum_mult_eq_count_bind, sum_mult_eq_count_bind, hub_pairs o hσ, sub_self]

/-- On a type avoiding `o`, the hub trade of `σ` is the indicator of `σ`. -/
lemma hub_apply_of_not_mem {o : Fin k} {σ τ : Multiset (Fin k)} (hτ : o ∉ τ) :
    hub o σ τ = if τ = σ then 1 else 0 := by
  have hP : (σ.map (fun x => ({x, o, o} : Multiset (Fin k)))).count τ = 0 := by
    rw [Multiset.count_eq_zero]
    intro h
    obtain ⟨x, -, rfl⟩ := Multiset.mem_map.mp h
    exact hτ (by simp)
  have hN : (hubNeg o σ).count τ = 0 := by
    rw [Multiset.count_eq_zero]
    intro h
    simp only [hubNeg, Multiset.mem_cons, Multiset.mem_map] at h
    rcases h with rfl | ⟨p, -, rfl⟩
    · exact hτ (by simp)
    · exact hτ (Multiset.mem_cons_self _ _)
  simp only [hub, hubPos, Multiset.count_cons, hP, hN]
  split_ifs <;> simp

/-- **The Pasch hub basis.** Every pair-preserving change of type counts is the
combination of the hub trades of the types avoiding `o`, with coefficients its own values
on those types. -/
theorem hub_basis (o : Fin k) {d : Multiset (Fin k) → ℤ} (hd : PairPreserving d) :
    ∀ τ ∈ blockTypes k,
      d τ = ∑ σ ∈ (blockTypes k).filter (fun σ => o ∉ σ), d σ * hub o σ τ := by
  set A := (blockTypes k).filter (fun σ => o ∉ σ)
  let e : Multiset (Fin k) → ℤ := fun τ => d τ - ∑ σ ∈ A, d σ * hub o σ τ
  have he : PairPreserving e := by
    intro π hπ
    simp only [e, mul_sub, Finset.sum_sub_distrib, Finset.mul_sum]
    rw [hd π hπ, Finset.sum_comm]
    have : ∀ σ ∈ A, ∑ τ ∈ blockTypes k, (mult π τ : ℤ) * (d σ * hub o σ τ) = 0 := by
      intro σ hσ
      have hσ3 := mem_blockTypes.mp (Finset.mem_filter.mp hσ).1
      have := hub_pairPreserving o hσ3 π hπ
      calc ∑ τ ∈ blockTypes k, (mult π τ : ℤ) * (d σ * hub o σ τ)
          = d σ * ∑ τ ∈ blockTypes k, (mult π τ : ℤ) * hub o σ τ := by
            rw [Finset.mul_sum]; congr 1; funext τ; ring
        _ = 0 := by rw [this, mul_zero]
    rw [Finset.sum_eq_zero this, sub_zero]
  have h0 : ∀ τ ∈ blockTypes k, o ∉ τ → e τ = 0 := by
    intro τ hτ ho
    simp only [e, hub_apply_of_not_mem ho, mul_ite, mul_one, mul_zero]
    have hA : τ ∈ A := Finset.mem_filter.mpr ⟨hτ, ho⟩
    rw [Finset.sum_ite_eq]
    simp [hA]
  intro τ hτ
  have := hub_unique he o h0 τ hτ
  simp only [e] at this
  linarith

end ColourStats
