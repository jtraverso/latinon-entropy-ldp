/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedGStats
public import ColourStats.TypedThm

/-!
# The upper half of Theorem 1.9(a)

**Theorem** (`typed_upper_G`). Let `G` be `(η, 5)`-typical with densities `d`, `η ≤ 1/3`, and
suppose every edge `ab` has at least `c₁ ≥ 1` common neighbours in every class. If some
triangle decomposition of `G` has type vector `t`, then

  `log N_t(G) ≤ Φ_G(t) + n² ((5 log n + 16)/n + 8 / c₁^{1/4} + η)`.

The new ingredient compared with Steiner triple systems is typicality: on the edges of a
class `π`, the number of common neighbours in `X` is `(1 ± η) I(π, X)`, so its maximum `m*`
satisfies `|E_π| m* ≤ ((1 + η)/(1 − η)) Σ_{ab ∈ E_π} |N(a) ∩ N(b) ∩ X|
= ((1 + η)/(1 − η)) m_π(τ) N_τ(G)` (`card_mul_mstar_le`, `sum_cnb`).

`theorem_1_9a_upper_exp`: under the hypotheses of Theorem 1.9 (`TypHyp`), for every type
vector `t`, `N_t(G) ≤ exp(Φ_G(t) + ε n²)` for `n ≥ n₀`.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.TypedG

open ColourStats ColourStats.Statements ColourStats.TypedChain ColourStats.TypedSTS

open Classical

variable {n k : ℕ} {G : SimpleGraph (Fin n)}

lemma card_commonIn_pair (lab : Fin n → Fin k) {a b : Fin n} (X : Fin k) :
    (Typical.commonIn G lab {a, b} X).card = cnb G lab a b X := by
  have h : Typical.commonIn G lab {a, b} X =
      univ.filter (fun z => lab z = X ∧ G.Adj a z ∧ G.Adj b z) := by
    ext z
    simp [Typical.commonIn]
  rw [h]
  rfl

/-- The predicted number of common neighbours in `X` of an edge of class `π`. -/
noncomputable def Ival (lab : Fin n → Fin k) (d : Fin k → Fin k → ℝ) (π : Multiset (Fin k))
    (X : Fin k) : ℝ :=
  (Typical.classSet lab X).card * (π.map fun A => d A X).prod

lemma cnb_near (lab : Fin n → Fin k) (d : Fin k → Fin k → ℝ) {η : ℝ}
    (htyp : Typical.IsTypical G lab d η 5) {π : Multiset (Fin k)} {p : Pair n}
    (hp : p ∈ EpiG G lab π) (X : Fin k) :
    |(cnb G lab p.1 p.2 X : ℝ) - Ival lab d π X| ≤ η * Ival lab d π X := by
  obtain ⟨hpp, hπ⟩ := Finset.mem_filter.mp hp
  obtain ⟨hlt, -⟩ := mem_pairsG.mp hpp
  have h := htyp {p.1, p.2} (by rw [Finset.card_pair hlt.ne]; norm_num) X
  rw [card_commonIn_pair, Typical.ideal_pair lab d hlt.ne] at h
  have hI : Ival lab d π X =
      (Typical.classSet lab X).card * (d (lab p.1) X * d (lab p.2) X) := by
    unfold Ival
    rw [← hπ]
    simp
  rw [hI]
  exact h

/-- **Typicality controls the maximum.** `|E_π| m* ≤ ((1 + η)/(1 − η)) Σ_{E_π} cnb`. -/
lemma card_mul_mstar_le (lab : Fin n → Fin k) (d : Fin k → Fin k → ℝ) {η : ℝ} (hη0 : 0 ≤ η)
    (hη : η ≤ 1 / 3) (htyp : Typical.IsTypical G lab d η 5) (π : Multiset (Fin k)) (X : Fin k)
    (hne : (EpiG G lab π).Nonempty) :
    ((EpiG G lab π).card : ℝ) * mstar G lab π X ≤
      ((1 + η) / (1 - η)) * ∑ p ∈ EpiG G lab π, (cnb G lab p.1 p.2 X : ℝ) := by
  set I := Ival lab d π X
  obtain ⟨p₀, hp₀, hsup⟩ := Finset.exists_mem_eq_sup (EpiG G lab π) hne
    (fun p => cnb G lab p.1 p.2 X)
  have hm : (mstar G lab π X : ℝ) = cnb G lab p₀.1 p₀.2 X := by
    unfold mstar; rw [hsup]
  have hup : (mstar G lab π X : ℝ) ≤ (1 + η) * I := by
    rw [hm]
    have := cnb_near lab d htyp hp₀ X
    have := (abs_le.mp this).2
    linarith
  have hlow : ∀ p ∈ EpiG G lab π, (1 - η) * I ≤ cnb G lab p.1 p.2 X := by
    intro p hp
    have := (abs_le.mp (cnb_near lab d htyp hp X)).1
    linarith
  have h1η : 0 < 1 - η := by linarith
  calc ((EpiG G lab π).card : ℝ) * mstar G lab π X
      ≤ ((EpiG G lab π).card : ℝ) * ((1 + η) * I) :=
        mul_le_mul_of_nonneg_left hup (Nat.cast_nonneg _)
    _ = ((1 + η) / (1 - η)) * ∑ p ∈ EpiG G lab π, (1 - η) * I := by
        rw [Finset.sum_const, nsmul_eq_mul]
        field_simp
    _ ≤ ((1 + η) / (1 - η)) * ∑ p ∈ EpiG G lab π, (cnb G lab p.1 p.2 X : ℝ) := by
        apply mul_le_mul_of_nonneg_left (Finset.sum_le_sum hlow)
        positivity

lemma log_ratio_le {η : ℝ} (hη0 : 0 ≤ η) (hη : η ≤ 1 / 3) :
    Real.log ((1 + η) / (1 - η)) ≤ 3 * η := by
  have h1 : 0 < 1 - η := by linarith
  have := Real.log_le_sub_one_of_pos (by positivity : (0 : ℝ) < (1 + η) / (1 - η))
  have h2 : (1 + η) / (1 - η) - 1 = 2 * η / (1 - η) := by field_simp; ring
  have h3 : 2 * η / (1 - η) ≤ 3 * η := by
    rw [div_le_iff₀ h1]
    nlinarith
  linarith

/-- `N_t(G)` is the size of any finset listing the decompositions of type `t`. -/
lemma countDecomp_eq_card (lab : Fin n → Fin k) (t : Multiset (Fin k) → ℕ)
    (Dset : Finset (Finset (Finset (Fin n))))
    (hD : ∀ D, D ∈ Dset ↔ IsTriDecomp G D ∧ ∀ τ ∈ blockTypes k, typeCount lab D τ = t τ) :
    countDecomp G lab t = Dset.card := by
  unfold countDecomp
  have e : {D : Finset (Finset (Fin n)) // IsTriDecomp G D ∧
      ∀ τ ∈ blockTypes k, typeCount lab D τ = t τ} ≃ {D // D ∈ Dset} :=
    { toFun := fun x => ⟨x.1, (hD _).mpr x.2⟩
      invFun := fun y => ⟨y.1, (hD _).mp y.2⟩
      left_inv := fun x => rfl
      right_inv := fun y => rfl }
  rw [Nat.card_congr e, Nat.card_eq_fintype_card, Fintype.card_coe]

lemma card_pairsG_le (G : SimpleGraph (Fin n)) : (pairsG G).card ≤ n * n :=
  (Finset.card_le_card (Finset.filter_subset _ _)).trans (card_pairs_le n)

lemma sum_EpiG (lab : Fin n → Fin k) :
    ∑ π ∈ pairTypes k, (EpiG G lab π).card = (pairsG G).card := by
  have h := sum_pairs_by_classG (G := G) lab (fun _ => (1 : ℝ))
  simp only [Finset.sum_const, nsmul_eq_mul, mul_one] at h
  exact_mod_cast h.symm

lemma sum_MstatG (lab : Fin n → Fin k) (T : Fin n → Fin n → Fin n) (π : Multiset (Fin k)) :
    ∑ X, MstatG G lab T π X = (EpiG G lab π).card :=
  (Finset.card_eq_sum_card_fiberwise (fun _ _ => Finset.mem_univ _)).symm

/-- **The typed bound for triangle decompositions of a typical graph.** -/
theorem typed_upper_G (lab : Fin n → Fin k) (t : Multiset (Fin k) → ℕ)
    (d : Fin k → Fin k → ℝ) {η c₁ : ℝ} (hη0 : 0 ≤ η) (hη : η ≤ 1 / 3)
    (htyp : Typical.IsTypical G lab d η 5) (hc₁ : 1 ≤ c₁)
    (hcnb : ∀ a b X, G.Adj a b → c₁ ≤ (cnb G lab a b X : ℝ)) (hn : 1 ≤ n)
    (hpos : 0 < countDecomp G lab t) :
    Real.log (countDecomp G lab t) ≤ PhiG G lab (fun τ => (t τ : ℝ)) +
      (n : ℝ) ^ 2 * ((5 * Real.log n + 16) / n + 8 / Real.sqrt (Real.sqrt c₁) + η) := by
  have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hnpos : (0 : ℝ) < n := by linarith
  set Dset := (univ : Finset (Finset (Finset (Fin n)))).filter fun D =>
    IsTriDecomp G D ∧ ∀ τ ∈ blockTypes k, typeCount lab D τ = t τ
  set S := Dset.image (thirdPtG G)
  have hcount : countDecomp G lab t = S.card := by
    rw [countDecomp_eq_card lab t Dset (fun D => by simp [Dset]), Finset.card_image_of_injOn]
    intro D hD D' hD' h
    exact thirdPtG_injective (Finset.mem_filter.mp hD).2.1 (Finset.mem_filter.mp hD').2.1 h
  have hS : ∀ T ∈ S, IsSQG G T := by
    intro T hT
    obtain ⟨D, hD, rfl⟩ := Finset.mem_image.mp hT
    exact thirdPtG_isSQG (Finset.mem_filter.mp hD).2.1
  have hne : S.Nonempty := by
    rw [← Finset.card_pos, ← hcount]
    exact hpos
  obtain ⟨T₀, hT₀⟩ := hne
  obtain ⟨D₀, hD₀, hT₀eq⟩ := Finset.mem_image.mp hT₀
  obtain ⟨hD₀dec, hD₀t⟩ := (Finset.mem_filter.mp hD₀).2
  set M : Multiset (Fin k) → Fin k → ℕ := fun π X => mult π (X ::ₘ π) * t (X ::ₘ π)
  have hM : ∀ T ∈ S, ∀ π X, MstatG G lab T π X = M π X := by
    intro T hT π X
    obtain ⟨D, hD, rfl⟩ := Finset.mem_image.mp hT
    obtain ⟨hDd, hDt⟩ := (Finset.mem_filter.mp hD).2
    rw [MstatG_eq hDd lab π X]
    by_cases hπ : Multiset.card π = 2
    · rw [hDt _ (mem_blockTypes.mpr (by simp [hπ]))]
    · simp [M, mult_eq_zero_of_card hπ]
  have hagg := typed_agg_boundG (L := n) hS ⟨T₀, hT₀⟩ lab hn M hM
  rw [hcount]
  set errU : ℝ := (5 * Real.log n + 16) / n + 8 / Real.sqrt (Real.sqrt c₁)
  -- the per-term bound
  have hterm : ∀ π ∈ pairTypes k, ∀ X, (M π X : ℝ) *
      (Wsum n * (Real.log (EpiG G lab π).card - Real.log (M π X)) +
        Psi n (mstar G lab π X)) ≤
      (mult π (X ::ₘ π) : ℝ) * ((t (X ::ₘ π) : ℝ) *
        ((1 / 3) * (Real.log (trianglesOf G lab (X ::ₘ π)) - Real.log (t (X ::ₘ π))) - 2 / 3)) +
      (M π X : ℝ) * (errU + η) := by
    intro π hπ X
    by_cases hM0 : M π X = 0
    · have h0 : (mult π (X ::ₘ π) : ℝ) * (t (X ::ₘ π) : ℝ) = 0 := by
        have h' : ((M π X : ℕ) : ℝ) = 0 := by exact_mod_cast hM0
        simpa [M] using h'
      rw [hM0]
      simp only [Nat.cast_zero, zero_mul, add_zero]
      rw [← mul_assoc, h0, zero_mul]
    have hMpos : 0 < M π X := Nat.pos_of_ne_zero hM0
    have hmpos : 0 < mult π (X ::ₘ π) := Nat.pos_of_ne_zero fun h => hM0 (by simp [M, h])
    have htpos : 0 < t (X ::ₘ π) := Nat.pos_of_ne_zero fun h => hM0 (by simp [M, h])
    have hME : M π X ≤ (EpiG G lab π).card := by
      rw [← hM T₀ hT₀ π X]
      exact Finset.card_filter_le _ _
    have hEpos : 0 < (EpiG G lab π).card := lt_of_lt_of_le hMpos hME
    have hEne : (EpiG G lab π).Nonempty := Finset.card_pos.mp hEpos
    obtain ⟨p₁, hp₁⟩ := hEne
    -- bounds on `m*`
    have hm_ge : c₁ ≤ (mstar G lab π X : ℝ) := by
      have hadj : G.Adj p₁.1 p₁.2 := (mem_pairsG.mp (Finset.mem_filter.mp hp₁).1).2
      have h1 := hcnb p₁.1 p₁.2 X hadj
      have h2 : cnb G lab p₁.1 p₁.2 X ≤ mstar G lab π X :=
        Finset.le_sup (f := fun q : Pair n => cnb G lab q.1 q.2 X) hp₁
      have h2' : (cnb G lab p₁.1 p₁.2 X : ℝ) ≤ mstar G lab π X := by exact_mod_cast h2
      linarith
    have hm_le : (mstar G lab π X : ℝ) ≤ n := by
      have : mstar G lab π X ≤ n := by
        unfold mstar
        refine Finset.sup_le fun q _ => ?_
        unfold cnb
        exact (Finset.card_filter_le _ _).trans (by simp)
      exact_mod_cast this
    have hc1' : (1 : ℝ) ≤ mstar G lab π X := hc₁.trans hm_ge
    have hEr : (0 : ℝ) < (EpiG G lab π).card := by exact_mod_cast hEpos
    have hMr : (0 : ℝ) < M π X := by exact_mod_cast hMpos
    have hx1 : (1 : ℝ) ≤ (EpiG G lab π).card / M π X := by
      rw [le_div_iff₀ hMr, one_mul]; exact_mod_cast hME
    have hlogx : Real.log (EpiG G lab π).card - Real.log (M π X) =
        Real.log ((EpiG G lab π).card / M π X) := (Real.log_div hEr.ne' hMr.ne').symm
    have ht := term_le (L := n) hn hc1' hx1
    rw [← hlogx] at ht
    -- `|E| m* ≤ ((1+η)/(1−η)) m N`
    have hmr : (0 : ℝ) < mult π (X ::ₘ π) := by exact_mod_cast hmpos
    have htr : (0 : ℝ) < t (X ::ₘ π) := by exact_mod_cast htpos
    have hcr : (0 : ℝ) < mstar G lab π X := by linarith
    have hkey := card_mul_mstar_le lab d hη0 hη htyp π X ⟨p₁, hp₁⟩
    have hsum := sum_cnb (G := G) lab π X
    have hsumr : ∑ p ∈ EpiG G lab π, (cnb G lab p.1 p.2 X : ℝ) =
        (mult π (X ::ₘ π) : ℝ) * trianglesOf G lab (X ::ₘ π) := by
      exact_mod_cast hsum
    rw [hsumr] at hkey
    have h1η : 0 < 1 - η := by linarith
    have hratio : 0 < (1 + η) / (1 - η) := by positivity
    have hNr : (0 : ℝ) < trianglesOf G lab (X ::ₘ π) := by
      have h0 : 0 < ((EpiG G lab π).card : ℝ) * mstar G lab π X := by positivity
      have : 0 < (1 + η) / (1 - η) * ((mult π (X ::ₘ π) : ℝ) * trianglesOf G lab (X ::ₘ π)) :=
        lt_of_lt_of_le h0 hkey
      have := pos_of_mul_pos_right this hratio.le
      exact pos_of_mul_pos_right this hmr.le
    have hMe : (M π X : ℝ) = mult π (X ::ₘ π) * t (X ::ₘ π) := by simp [M]
    have hsumlog : (Real.log (EpiG G lab π).card - Real.log (M π X)) +
        Real.log (mstar G lab π X) ≤
        Real.log (trianglesOf G lab (X ::ₘ π)) - Real.log (t (X ::ₘ π)) + 3 * η := by
      have hlhs : (Real.log (EpiG G lab π).card - Real.log (M π X)) +
          Real.log (mstar G lab π X) =
          Real.log (((EpiG G lab π).card : ℝ) * mstar G lab π X) - Real.log (M π X) := by
        rw [Real.log_mul hEr.ne' hcr.ne']; ring
      have hle : Real.log (((EpiG G lab π).card : ℝ) * mstar G lab π X) ≤
          Real.log ((1 + η) / (1 - η)) + Real.log (mult π (X ::ₘ π)) +
            Real.log (trianglesOf G lab (X ::ₘ π)) := by
        rw [← Real.log_mul hratio.ne' hmr.ne', ← Real.log_mul (by positivity) hNr.ne', mul_assoc]
        exact Real.log_le_log (by positivity) hkey
      rw [hlhs, hMe, Real.log_mul hmr.ne' htr.ne']
      have := log_ratio_le hη0 hη
      linarith
    -- the error
    have hlogE : Real.log (EpiG G lab π).card - Real.log (M π X) ≤ 2 * Real.log n := by
      have hE : ((EpiG G lab π).card : ℝ) ≤ (n : ℝ) ^ 2 := by
        have := (Finset.card_le_card (Finset.filter_subset _ _ : EpiG G lab π ⊆ pairsG G)).trans
          (card_pairsG_le G)
        have : ((EpiG G lab π).card : ℝ) ≤ (n * n : ℕ) := by exact_mod_cast this
        push_cast at this
        nlinarith
      have hM1 : (1 : ℝ) ≤ M π X := by exact_mod_cast hMpos
      have h1 : Real.log (EpiG G lab π).card ≤ Real.log ((n : ℝ) ^ 2) := Real.log_le_log hEr hE
      have h2 : 0 ≤ Real.log (M π X) := Real.log_nonneg hM1
      rw [Real.log_pow] at h1
      push_cast at h1
      linarith
    have hlogc : Real.log (mstar G lab π X) ≤ Real.log n := Real.log_le_log hcr hm_le
    have hsq : 8 / Real.sqrt (Real.sqrt (mstar G lab π X)) ≤ 8 / Real.sqrt (Real.sqrt c₁) := by
      apply div_le_div_of_nonneg_left (by norm_num)
      · exact Real.sqrt_pos.mpr (Real.sqrt_pos.mpr (by linarith))
      · exact Real.sqrt_le_sqrt (Real.sqrt_le_sqrt hm_ge)
    have herr : (Real.log ((EpiG G lab π).card / M π X) + 3 * Real.log (mstar G lab π X) + 16) /
        n + 8 / Real.sqrt (Real.sqrt (mstar G lab π X)) ≤ errU := by
      rw [← hlogx]
      have : (Real.log (EpiG G lab π).card - Real.log (M π X) +
          3 * Real.log (mstar G lab π X) + 16) / n ≤ (5 * Real.log n + 16) / n := by
        apply div_le_div_of_nonneg_right _ hnpos.le
        linarith
      simp only [errU]
      linarith
    have hmain : Wsum n * (Real.log (EpiG G lab π).card - Real.log (M π X)) +
        Psi n (mstar G lab π X) ≤
        (1 / 3) * (Real.log (trianglesOf G lab (X ::ₘ π)) - Real.log (t (X ::ₘ π))) - 2 / 3 +
          (errU + η) := by
      rw [hlogx] at ht hsumlog ⊢
      linarith
    calc (M π X : ℝ) * (Wsum n * (Real.log (EpiG G lab π).card - Real.log (M π X)) +
          Psi n (mstar G lab π X))
        ≤ (M π X : ℝ) * ((1 / 3) * (Real.log (trianglesOf G lab (X ::ₘ π)) -
            Real.log (t (X ::ₘ π))) - 2 / 3 + (errU + η)) :=
          mul_le_mul_of_nonneg_left hmain hMr.le
      _ = _ := by rw [hMe]; ring
  -- sum the terms
  have hsum := Finset.sum_le_sum fun π hπ => Finset.sum_le_sum fun X (_ : X ∈ univ) =>
    hterm π hπ X
  simp only [Finset.sum_add_distrib] at hsum
  have hreg := regroup (fun τ => (t τ : ℝ) * ((1 / 3) * (Real.log (trianglesOf G lab τ) -
    Real.log (t τ)) - 2 / 3))
  rw [hreg] at hsum
  -- the main term is `Φ_G(t)`
  have hPhi : ∑ τ ∈ blockTypes k, 3 * ((t τ : ℝ) * ((1 / 3) * (Real.log (trianglesOf G lab τ) -
      Real.log (t τ)) - 2 / 3)) = PhiG G lab (fun τ => (t τ : ℝ)) := by
    unfold PhiG
    refine Finset.sum_congr rfl fun τ hτ => ?_
    by_cases ht0 : t τ = 0
    · simp [ht0]
    · have htr : (0 : ℝ) < t τ := by exact_mod_cast Nat.pos_of_ne_zero ht0
      -- a block of type `τ` is a triangle of type `τ`
      have hNr : (0 : ℝ) < trianglesOf G lab τ := by
        have hc : 0 < typeCount lab D₀ τ := by rw [hD₀t τ hτ]; exact Nat.pos_of_ne_zero ht0
        obtain ⟨B, hB⟩ := Finset.card_pos.mp hc
        obtain ⟨hBD, hBτ⟩ := Finset.mem_filter.mp hB
        have : 0 < trianglesOf G lab τ := by
          unfold trianglesOf
          refine Finset.card_pos.mpr ⟨B, Finset.mem_filter.mpr ⟨?_, ?_, hBτ⟩⟩
          · exact Finset.mem_powersetCard.mpr ⟨Finset.subset_univ _, (hD₀dec.1 B hBD).1⟩
          · exact (hD₀dec.1 B hBD).2
        exact_mod_cast this
      rw [Real.log_div hNr.ne' htr.ne']
      ring
  rw [hPhi] at hsum
  -- the error term
  have herr0 : 0 ≤ errU + η := by
    have : 0 < Real.sqrt (Real.sqrt c₁) :=
      Real.sqrt_pos.mpr (Real.sqrt_pos.mpr (by linarith))
    have : 0 ≤ Real.log n := Real.log_nonneg hn1
    simp only [errU]
    positivity
  have hcnt : ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) ≤ (n : ℝ) ^ 2 := by
    have h1 : ∀ π ∈ pairTypes k, ∑ X, (M π X : ℝ) = (EpiG G lab π).card := by
      intro π _
      rw [← sum_MstatG lab T₀ π]
      push_cast
      exact Finset.sum_congr rfl fun X _ => by rw [hM T₀ hT₀ π X]
    rw [Finset.sum_congr rfl h1]
    have h2 : ∑ π ∈ pairTypes k, ((EpiG G lab π).card : ℝ) = (pairsG G).card := by
      exact_mod_cast sum_EpiG lab
    rw [h2]
    have h3 : ((pairsG G).card : ℝ) ≤ (n * n : ℕ) := by exact_mod_cast card_pairsG_le G
    push_cast at h3
    nlinarith
  have hErr : ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) * (errU + η) ≤ (n : ℝ) ^ 2 * (errU + η) := by
    have e : ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) * (errU + η) =
        (∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ)) * (errU + η) := by
      rw [Finset.sum_mul]
      exact Finset.sum_congr rfl fun π _ => by rw [Finset.sum_mul]
    rw [e]
    exact mul_le_mul_of_nonneg_right hcnt herr0
  have : (n : ℝ) ^ 2 * ((5 * Real.log n + 16) / n + 8 / Real.sqrt (Real.sqrt c₁) + η) =
      (n : ℝ) ^ 2 * (errU + η) := by simp only [errU]
  rw [this]
  linarith

end ColourStats.TypedG
