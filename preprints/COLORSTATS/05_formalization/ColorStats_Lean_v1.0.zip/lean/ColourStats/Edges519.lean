/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Host519

/-!
# Edge sets of Lemma 5.19

* `EIn S`: the edges inside the common neighbourhood of `S` in the class `A₀`. Then
  `P e = EIn (verts e)` (`P_eq_EIn`), the class `E₀ = EIn ∅`, and for `f ∈ E₀` the edges
  `g` with `g ∈ P e` and `f ∈ P g` are `EIn (verts e ∪ verts f)` (`mem_P_and_iff`).
* `card_EIn`: `|EIn S|` is the number of edges inside the common neighbourhood.
* `card_edge_le`: `|E| ≤ m²`; `card_meet_le`: at most `|S| m` edges meet a vertex set `S`;
  `card_inside_le`: at most `|S|²` edges lie inside `S`.
-/

@[expose] public section

open Finset

noncomputable section

open Classical

namespace ColourStats.Host519

open Typical Counting

variable {V : Type*} [Fintype V] {k : ℕ}

/-- The two endpoints of an unordered pair. -/
def verts (e : Sym2 V) : Finset V := {e.out.1, e.out.2}

omit [Fintype V] in
lemma mem_verts {e : Sym2 V} {u : V} : u ∈ verts e ↔ u ∈ e := by
  conv_rhs => rw [← out_eq e]
  simp [verts, Sym2.mem_iff]

/-- The edges inside the common neighbourhood of `S` in the class `A₀`. -/
def EIn (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) (S : Finset V) :
    Finset (Edge G) :=
  univ.filter fun g => ∀ v ∈ g.1, v ∈ commonIn G cls S A₀

lemma mem_commonIn_iff {G : SimpleGraph V} {cls : V → Fin k} {S : Finset V} {A₀ : Fin k}
    {v : V} : v ∈ commonIn G cls S A₀ ↔ cls v = A₀ ∧ ∀ u ∈ S, G.Adj u v := by
  simp [commonIn]

lemma mem_EIn {G : SimpleGraph V} {cls : V → Fin k} {A₀ : Fin k} {S : Finset V}
    {g : Edge G} : g ∈ EIn G cls A₀ S ↔ ∀ v ∈ g.1, cls v = A₀ ∧ ∀ u ∈ S, G.Adj u v := by
  constructor
  · intro h v hv; exact mem_commonIn_iff.mp ((Finset.mem_filter.mp h).2 v hv)
  · intro h
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, fun v hv => mem_commonIn_iff.mpr (h v hv)⟩

lemma card_EIn (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) (S : Finset V) :
    (EIn G cls A₀ S).card = (edgesIn G (commonIn G cls S A₀)).card := by
  rw [← Finset.card_map ⟨Subtype.val, Subtype.val_injective⟩]
  congr 1
  ext e
  simp only [Finset.mem_map, EIn, edgesIn, Finset.mem_filter, Finset.mem_univ, true_and,
    Function.Embedding.coeFn_mk]
  constructor
  · rintro ⟨g, hg, rfl⟩; exact ⟨g.2, hg⟩
  · rintro ⟨he, h⟩; exact ⟨⟨e, he⟩, h, rfl⟩

lemma mem_P {G : SimpleGraph V} {cls : V → Fin k} {A₀ : Fin k} {e f : Edge G} :
    f ∈ P G cls A₀ e ↔ Boxed G e.1 f.1 ∧ InClass cls A₀ f.1 :=
  ⟨fun h => (Finset.mem_filter.mp h).2, fun h => Finset.mem_filter.mpr ⟨Finset.mem_univ _, h⟩⟩

theorem P_eq_EIn (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) (e : Edge G) :
    P G cls A₀ e = EIn G cls A₀ (verts e.1) := by
  ext f
  rw [mem_P, mem_EIn]
  simp only [Boxed, InClass, mem_verts]
  constructor
  · rintro ⟨h1, h2⟩ v hv
    exact ⟨h2 v hv, fun u hu => h1 u hu v hv⟩
  · intro h
    exact ⟨fun u hu w hw => (h w hw).2 u hu, fun v hv => (h v hv).1⟩

/-- For `f` in the class, `g ∈ P e ∧ f ∈ P g` iff `g` lies inside the common neighbourhood
of the endpoints of `e` and `f`. -/
theorem mem_P_and_iff (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) {e f : Edge G}
    (hf : f ∈ EIn G cls A₀ ∅) (g : Edge G) :
    (g ∈ P G cls A₀ e ∧ f ∈ P G cls A₀ g) ↔ g ∈ EIn G cls A₀ (verts e.1 ∪ verts f.1) := by
  rw [P_eq_EIn, P_eq_EIn]
  simp only [mem_EIn, Finset.mem_union, mem_verts, Finset.notMem_empty, false_imp_iff,
    implies_true, and_true] at hf ⊢
  constructor
  · rintro ⟨h1, h2⟩ v hv
    refine ⟨(h1 v hv).1, fun u hu => ?_⟩
    rcases hu with hu | hu
    · exact (h1 v hv).2 u hu
    · exact G.adj_symm ((h2 u hu).2 v hv)
  · intro h
    refine ⟨fun v hv => ⟨(h v hv).1, fun u hu => (h v hv).2 u (Or.inl hu)⟩,
      fun w hw => ⟨hf w hw, fun u hu => G.adj_symm ((h u hu).2 w (Or.inr hw))⟩⟩

lemma commonIn_empty (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) :
    commonIn G cls ∅ A₀ = classSet cls A₀ := by
  ext v; simp [commonIn, classSet]

/-- `|E| ≤ m²`. -/
lemma card_edge_le (G : SimpleGraph V) :
    (Fintype.card (Edge G) : ℝ) ≤ (Fintype.card V : ℝ) ^ 2 := by
  have h1 : Fintype.card (Edge G) = G.edgeFinset.card := by simp
  have h2 : G.edgeFinset.card ≤ (Fintype.card V).choose 2 := G.card_edgeFinset_le_card_choose_two
  have h3 : (Fintype.card V).choose 2 ≤ Fintype.card V ^ 2 := by
    rw [Nat.choose_two_right]
    calc Fintype.card V * (Fintype.card V - 1) / 2 ≤ Fintype.card V * (Fintype.card V - 1) :=
          Nat.div_le_self _ _
      _ ≤ Fintype.card V * Fintype.card V := Nat.mul_le_mul_left _ (Nat.sub_le _ _)
      _ = Fintype.card V ^ 2 := by ring
  rw [h1]
  exact_mod_cast h2.trans h3

/-- At most `m` edges contain a given vertex. -/
lemma card_contain_le (G : SimpleGraph V) (v : V) :
    ((univ.filter fun f : Edge G => v ∈ f.1).card : ℝ) ≤ Fintype.card V := by
  have : (univ.filter fun f : Edge G => v ∈ f.1).card ≤ (univ : Finset V).card := by
    refine Finset.card_le_card_of_injOn
      (fun f => if h : v ∈ f.1 then Sym2.Mem.other h else v) (fun _ _ => Finset.mem_univ _) ?_
    intro f hf f' hf' heq
    have hv : v ∈ f.1 := (Finset.mem_filter.mp hf).2
    have hv' : v ∈ f'.1 := (Finset.mem_filter.mp hf').2
    simp only [dif_pos hv, dif_pos hv'] at heq
    apply Subtype.ext
    rw [← Sym2.other_spec hv, ← Sym2.other_spec hv', heq]
  rw [Finset.card_univ] at this
  exact_mod_cast this

/-- At most `|S| m` edges meet a vertex set `S`. -/
lemma card_meet_le (G : SimpleGraph V) (S : Finset V) :
    ((univ.filter fun f : Edge G => ∃ v ∈ S, v ∈ f.1).card : ℝ) ≤
      S.card * Fintype.card V := by
  have h1 : (univ.filter fun f : Edge G => ∃ v ∈ S, v ∈ f.1) ⊆
      S.biUnion (fun v => univ.filter fun f : Edge G => v ∈ f.1) := by
    intro f hf
    obtain ⟨v, hv, hvf⟩ := (Finset.mem_filter.mp hf).2
    exact Finset.mem_biUnion.mpr ⟨v, hv, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hvf⟩⟩
  have h2 := (Finset.card_le_card h1).trans Finset.card_biUnion_le
  calc ((univ.filter fun f : Edge G => ∃ v ∈ S, v ∈ f.1).card : ℝ)
      ≤ ∑ v ∈ S, ((univ.filter fun f : Edge G => v ∈ f.1).card : ℝ) := by exact_mod_cast h2
    _ ≤ ∑ _v ∈ S, (Fintype.card V : ℝ) := Finset.sum_le_sum fun v _ => card_contain_le G v
    _ = S.card * Fintype.card V := by simp

/-- At most `|S|²` edges lie inside a vertex set `S`. -/
lemma card_inside_le (G : SimpleGraph V) (S : Finset V) :
    ((univ.filter fun e : Edge G => ∀ v ∈ e.1, v ∈ S).card : ℝ) ≤ (S.card : ℝ) ^ 2 := by
  have h : (univ.filter fun e : Edge G => ∀ v ∈ e.1, v ∈ S).card ≤ (S ×ˢ S).card := by
    refine Finset.card_le_card_of_injOn (fun e => e.1.out) (fun e he => ?_) ?_
    · have hin := (Finset.mem_filter.mp he).2
      exact Finset.mem_product.mpr ⟨hin _ (mem_verts.mp (by simp [verts])),
        hin _ (mem_verts.mp (by simp [verts]))⟩
    · intro e _ e' _ heq
      apply Subtype.ext
      rw [← out_eq e.1, ← out_eq e'.1]
      simp only at heq
      rw [heq]
  rw [Finset.card_product] at h
  have : ((univ.filter fun e : Edge G => ∀ v ∈ e.1, v ∈ S).card : ℝ) ≤ S.card * S.card := by
    exact_mod_cast h
  linarith [this, sq (S.card : ℝ)]

end ColourStats.Host519
