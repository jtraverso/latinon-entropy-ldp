/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import CountingCone.LL.Chain

/-!
# Brégman's theorem (entropy proof)

For a bipartite graph on `Fin n + Fin n` given by the neighbourhoods `A i` of the rows, the
number of perfect matchings satisfies

    log #PM(A) ≤ Σ_i log(|A i|!) / |A i|,

that is, `#PM(A) ≤ Π_i (|A i|!)^{1/|A i|}` (Brégman 1973, conjectured by Minc). The proof is
Radhakrishnan's: reveal the rows in the order of a permutation `τ`; by the corpus chain rule
(`LinialLuria.chain_bound`), `log #PM ≤ E_σ Σ_i log N_i(σ, τ)`, where `N_i(σ, τ)` counts the
columns of `A i` not used by the rows before `i`. For a fixed matching `σ` this is
`|A i| − rank`, where `rank` is the position of `i` among the rows matched into `A i`.
Averaging over all `n!` orders, the rank is uniform on `{0, …, |A i| − 1}` (`sum_rank`), and
`Σ_{m < d} log(d − m) = log d!`.
-/

@[expose] public section

open Finset

namespace ColourStats.Bregman

variable {n : ℕ}

/-! ### The rank of an element in a random order -/

/-- The rank of `i` among the elements of `A` in the order `τ`. -/
def rank (A : Finset (Fin n)) (τ : Equiv.Perm (Fin n)) (i : Fin n) : ℕ :=
  (A.filter fun j => τ j < τ i).card

lemma swap_mem {A : Finset (Fin n)} {i i' j : Fin n} (hi : i ∈ A) (hi' : i' ∈ A) (hj : j ∈ A) :
    Equiv.swap i i' j ∈ A := by
  rw [Equiv.swap_apply_def]
  split_ifs <;> assumption

lemma rank_swap (A : Finset (Fin n)) (τ : Equiv.Perm (Fin n)) {i i' : Fin n} (hi : i ∈ A)
    (hi' : i' ∈ A) : rank A (τ * Equiv.swap i i') i = rank A τ i' := by
  unfold rank
  refine Finset.card_bij' (fun j _ => Equiv.swap i i' j) (fun j _ => Equiv.swap i i' j)
    ?_ ?_ ?_ ?_
  · intro j hj
    obtain ⟨hjA, hlt⟩ := Finset.mem_filter.mp hj
    simp only [Equiv.Perm.coe_mul, Function.comp_apply, Equiv.swap_apply_left] at hlt
    exact Finset.mem_filter.mpr ⟨swap_mem hi hi' hjA, hlt⟩
  · intro j hj
    obtain ⟨hjA, hlt⟩ := Finset.mem_filter.mp hj
    refine Finset.mem_filter.mpr ⟨swap_mem hi hi' hjA, ?_⟩
    simp only [Equiv.Perm.coe_mul, Function.comp_apply, Equiv.swap_apply_left,
      Equiv.swap_apply_self]
    exact hlt
  · intro j _; simp
  · intro j _; simp

lemma sum_rank_swap (A : Finset (Fin n)) (h : ℕ → ℝ) {i i' : Fin n} (hi : i ∈ A)
    (hi' : i' ∈ A) :
    ∑ τ : Equiv.Perm (Fin n), h (rank A τ i) = ∑ τ : Equiv.Perm (Fin n), h (rank A τ i') :=
  Fintype.sum_equiv (Equiv.mulRight (Equiv.swap i' i)) _ _ fun τ => by
    rw [Equiv.coe_mulRight, rank_swap A τ hi' hi]

lemma rank_lt (A : Finset (Fin n)) (τ : Equiv.Perm (Fin n)) {i : Fin n} (hi : i ∈ A) :
    rank A τ i < A.card :=
  Finset.card_lt_card (Finset.filter_ssubset.mpr ⟨i, hi, lt_irrefl _⟩)

lemma rank_lt_rank (A : Finset (Fin n)) (τ : Equiv.Perm (Fin n)) {i i' : Fin n} (hi : i ∈ A)
    (h : τ i < τ i') : rank A τ i < rank A τ i' := by
  unfold rank
  apply Finset.card_lt_card
  rw [Finset.ssubset_iff_of_subset]
  · exact ⟨i, Finset.mem_filter.mpr ⟨hi, h⟩, fun h' => lt_irrefl _ (Finset.mem_filter.mp h').2⟩
  · intro j hj
    obtain ⟨hjA, hj⟩ := Finset.mem_filter.mp hj
    exact Finset.mem_filter.mpr ⟨hjA, hj.trans h⟩

lemma rank_injOn (A : Finset (Fin n)) (τ : Equiv.Perm (Fin n)) : Set.InjOn (rank A τ) A := by
  intro i hi i' hi' h
  by_contra hne
  have : τ i ≠ τ i' := fun e => hne (τ.injective e)
  rcases lt_or_gt_of_ne this with hlt | hlt
  · exact absurd h (rank_lt_rank A τ hi hlt).ne
  · exact absurd h (rank_lt_rank A τ hi' hlt).ne'

lemma image_rank (A : Finset (Fin n)) (τ : Equiv.Perm (Fin n)) :
    A.image (rank A τ) = range A.card := by
  apply Finset.eq_of_subset_of_card_le
  · intro m hm
    obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hm
    exact Finset.mem_range.mpr (rank_lt A τ hi)
  · rw [Finset.card_range, Finset.card_image_of_injOn (rank_injOn A τ)]

/-- For a fixed order, the ranks of the elements of `A` are `0, …, |A| − 1`. -/
lemma sum_rank_on (A : Finset (Fin n)) (τ : Equiv.Perm (Fin n)) (h : ℕ → ℝ) :
    ∑ i ∈ A, h (rank A τ i) = ∑ m ∈ range A.card, h m := by
  rw [← image_rank A τ, Finset.sum_image (rank_injOn A τ)]

/-- **The rank is uniform.** Over all `n!` orders, the rank of `i ∈ A` among `A` takes each
value `m < |A|` equally often. -/
theorem sum_rank (A : Finset (Fin n)) (h : ℕ → ℝ) {i : Fin n} (hi : i ∈ A) :
    (A.card : ℝ) * ∑ τ : Equiv.Perm (Fin n), h (rank A τ i) =
      (n.factorial : ℝ) * ∑ m ∈ range A.card, h m := by
  have h1 : (A.card : ℝ) * ∑ τ : Equiv.Perm (Fin n), h (rank A τ i) =
      ∑ i' ∈ A, ∑ τ : Equiv.Perm (Fin n), h (rank A τ i') := by
    rw [← nsmul_eq_mul, ← Finset.sum_const]
    exact Finset.sum_congr rfl fun i' hi' => sum_rank_swap A h hi hi'
  rw [h1, Finset.sum_comm]
  simp_rw [sum_rank_on A _ h]
  rw [Finset.sum_const, Finset.card_univ, Fintype.card_perm, Fintype.card_fin, nsmul_eq_mul]

lemma sum_log_sub (d : ℕ) :
    ∑ m ∈ range d, Real.log ((d - m : ℕ) : ℝ) = Real.log (d.factorial : ℝ) := by
  calc ∑ m ∈ range d, Real.log ((d - m : ℕ) : ℝ)
      = ∑ m ∈ range d, Real.log ((d - 1 - m + 1 : ℕ) : ℝ) := by
        refine Finset.sum_congr rfl fun m hm => ?_
        have := Finset.mem_range.mp hm
        rw [show d - m = d - 1 - m + 1 by omega]
    _ = ∑ m ∈ range d, Real.log ((m + 1 : ℕ) : ℝ) :=
        Finset.sum_range_reflect (fun m => Real.log ((m + 1 : ℕ) : ℝ)) d
    _ = Real.log (d.factorial : ℝ) := by
        rw [← Real.log_prod (fun m _ => by positivity), ← Nat.cast_prod,
          Finset.prod_range_add_one_eq_factorial]

/-! ### Perfect matchings -/

open Classical in
/-- The perfect matchings of the bipartite graph with row neighbourhoods `A i`, as injective
maps from rows to columns. -/
noncomputable def PM (A : Fin n → Finset (Fin n)) : Finset (Fin n → Fin n) :=
  univ.filter fun σ => Function.Injective σ ∧ ∀ i, σ i ∈ A i

/-- The rows that `σ` matches into `A i`. -/
def pre (A : Fin n → Finset (Fin n)) (σ : Fin n → Fin n) (i : Fin n) : Finset (Fin n) :=
  univ.filter fun j => σ j ∈ A i

lemma mem_PM {A : Fin n → Finset (Fin n)} {σ : Fin n → Fin n} :
    σ ∈ PM A ↔ Function.Injective σ ∧ ∀ i, σ i ∈ A i := by
  classical
  unfold PM
  simp

lemma card_pre (A : Fin n → Finset (Fin n)) {σ : Fin n → Fin n} (hσ : Function.Injective σ)
    (i : Fin n) : (pre A σ i).card = (A i).card := by
  have hsurj : Function.Surjective σ := Finite.injective_iff_surjective.mp hσ
  rw [← Finset.card_image_of_injective _ hσ]
  congr 1
  ext c
  simp only [Finset.mem_image, pre, Finset.mem_filter, mem_univ, true_and]
  constructor
  · rintro ⟨j, hj, rfl⟩; exact hj
  · intro hc
    obtain ⟨j, rfl⟩ := hsurj c
    exact ⟨j, hc, rfl⟩

/-- The values of row `i` still possible after the rows before `i` (in the order `τ`) are
among the columns of `A i` not used by `σ` on those rows. -/
lemma img_card_le (A : Fin n → Finset (Fin n)) (τ : Equiv.Perm (Fin n)) {σ : Fin n → Fin n}
    (hσ : σ ∈ PM A) (i : Fin n) :
    ((LinialLuria.agreeSet (PM A) univ (fun j => (τ j).val) (fun j y => y j) i σ).image
      (fun y => y i)).card ≤ (A i).card - rank (pre A σ i) τ i := by
  obtain ⟨hinj, -⟩ := mem_PM.mp hσ
  have hsurj : Function.Surjective σ := Finite.injective_iff_surjective.mp hinj
  have hsub : (LinialLuria.agreeSet (PM A) univ (fun j => (τ j).val) (fun j y => y j) i σ).image
      (fun y => y i) ⊆ ((pre A σ i).filter fun j => ¬ τ j < τ i).image σ := by
    intro c hc
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hc
    obtain ⟨hyS, hagree⟩ := LinialLuria.mem_agreeSet.mp hy
    obtain ⟨hyinj, hyA⟩ := mem_PM.mp hyS
    obtain ⟨j, hj⟩ := hsurj (y i)
    refine Finset.mem_image.mpr ⟨j, Finset.mem_filter.mpr
      ⟨Finset.mem_filter.mpr ⟨mem_univ _, hj ▸ hyA i⟩, fun hlt => ?_⟩, hj⟩
    have hyj : y j = σ j := hagree j (mem_univ _) hlt
    have hji : j = i := hyinj (hyj.trans hj)
    subst hji
    exact lt_irrefl _ hlt
  have hsplit := Finset.card_filter_add_card_filter_not (s := pre A σ i)
    (fun j => τ j < τ i)
  calc _ ≤ _ := Finset.card_le_card hsub
    _ ≤ _ := Finset.card_image_le
    _ = (pre A σ i).card - rank (pre A σ i) τ i := by unfold rank; omega
    _ = _ := by rw [card_pre A hinj i]

/-- **Brégman's theorem.** `log #PM(A) ≤ Σ_i log(|A i|!) / |A i|`. -/
theorem bregman (A : Fin n → Finset (Fin n)) :
    Real.log (PM A).card ≤ ∑ i, Real.log ((A i).card.factorial : ℝ) / (A i).card := by
  set S := PM A with hSdef
  rcases S.eq_empty_or_nonempty with h0 | hne
  · rw [h0, Finset.card_empty, Nat.cast_zero, Real.log_zero]
    exact Finset.sum_nonneg fun i _ => div_nonneg (Real.log_natCast_nonneg _) (Nat.cast_nonneg _)
  have hSpos : (0 : ℝ) < S.card := by exact_mod_cast hne.card_pos
  -- one order
  have hτ : ∀ τ : Equiv.Perm (Fin n), (S.card : ℝ) * Real.log S.card ≤
      ∑ σ ∈ S, ∑ i, Real.log (((A i).card - rank (pre A σ i) τ i : ℕ) : ℝ) := by
    intro τ
    refine (LinialLuria.chain_bound (fun j => (τ j).val) (fun j y => y j) univ S ?_ ?_).trans ?_
    · intro a _ b _ h
      exact τ.injective (Fin.ext h)
    · intro x _ y _ h
      funext j
      exact h j (mem_univ j)
    · refine Finset.sum_le_sum fun σ hσ => Finset.sum_le_sum fun i _ => ?_
      have hself : σ ∈ LinialLuria.agreeSet S univ (fun j => (τ j).val) (fun j y => y j) i σ :=
        LinialLuria.mem_agreeSet.mpr ⟨hσ, fun _ _ _ => rfl⟩
      have hpos : (0 : ℝ) < ((LinialLuria.agreeSet S univ (fun j => (τ j).val)
          (fun j y => y j) i σ).image (fun y => y i)).card := by
        exact_mod_cast (Finset.Nonempty.image ⟨σ, hself⟩ _).card_pos
      exact Real.log_le_log hpos (by exact_mod_cast img_card_le A τ hσ i)
  -- average over the orders
  have hkey : ∀ σ ∈ S, ∀ i, ∑ τ : Equiv.Perm (Fin n),
      Real.log (((A i).card - rank (pre A σ i) τ i : ℕ) : ℝ) =
        (n.factorial : ℝ) * (Real.log ((A i).card.factorial : ℝ) / (A i).card) := by
    intro σ hσ i
    obtain ⟨hinj, hA⟩ := mem_PM.mp hσ
    have hi : i ∈ pre A σ i := Finset.mem_filter.mpr ⟨mem_univ _, hA i⟩
    have hd : (0 : ℝ) < (A i).card := by
      exact_mod_cast Finset.card_pos.mpr ⟨σ i, hA i⟩
    have h := sum_rank (pre A σ i) (fun m => Real.log (((A i).card - m : ℕ) : ℝ)) hi
    rw [card_pre A hinj i, sum_log_sub] at h
    rw [mul_div_assoc', eq_div_iff hd.ne', mul_comm]
    exact h
  have hsum : (n.factorial : ℝ) * ((S.card : ℝ) * Real.log S.card) ≤
      (n.factorial : ℝ) * ((S.card : ℝ) *
        ∑ i, Real.log ((A i).card.factorial : ℝ) / (A i).card) := by
    calc (n.factorial : ℝ) * ((S.card : ℝ) * Real.log S.card)
        = ∑ τ : Equiv.Perm (Fin n), (S.card : ℝ) * Real.log S.card := by
          rw [Finset.sum_const, Finset.card_univ, Fintype.card_perm, Fintype.card_fin,
            nsmul_eq_mul]
      _ ≤ ∑ τ : Equiv.Perm (Fin n), ∑ σ ∈ S, ∑ i,
            Real.log (((A i).card - rank (pre A σ i) τ i : ℕ) : ℝ) :=
          Finset.sum_le_sum fun τ _ => hτ τ
      _ = ∑ σ ∈ S, ∑ i, ∑ τ : Equiv.Perm (Fin n),
            Real.log (((A i).card - rank (pre A σ i) τ i : ℕ) : ℝ) := by
          rw [Finset.sum_comm]
          exact Finset.sum_congr rfl fun σ _ => Finset.sum_comm
      _ = ∑ σ ∈ S, ∑ i, (n.factorial : ℝ) *
            (Real.log ((A i).card.factorial : ℝ) / (A i).card) :=
          Finset.sum_congr rfl fun σ hσ => Finset.sum_congr rfl fun i _ => hkey σ hσ i
      _ = _ := by
          rw [Finset.sum_const, nsmul_eq_mul, ← Finset.mul_sum]
          ring
  have hfac : (0 : ℝ) < n.factorial := by exact_mod_cast Nat.factorial_pos n
  have := le_of_mul_le_mul_left hsum hfac
  exact le_of_mul_le_mul_left this hSpos

end ColourStats.Bregman
