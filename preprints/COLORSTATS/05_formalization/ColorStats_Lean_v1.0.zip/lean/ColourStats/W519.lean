/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Phi519
public import ColourStats.WeightingError

/-!
# The weighting `W_1` and the functional `σ` on the host (Lemma 5.19)

* `sum_MA_eq`: the triangles through an edge `ab` are the `{a, b, z}` with `z` a common
  neighbour, so `(A F)(ab) = Σ_{z ∈ N(a) ∩ N(b)} F({a, b, z})`.
* `Wvec`: the weighting that puts `w(type t)` on every triangle `t`, with
  `w = weight A₀ A₀ = α 1_{A₀A₀A₀}`. Then `A W = u + e₂` with `u = 1_{E₀}` and
  `|e₂| ≤ η` (`abs_e₂_le`), and `|W| ≤ 1/(δ₀ d₀² m)` (`abs_Wvec_le`).
* `σop r = Σ_e r(e) / |E₀|`, with `‖σ‖ ≤ 4/(δ₀² d₀)` (`norm_σop_le`).
-/

@[expose] public section

open Finset

noncomputable section

open Classical

namespace ColourStats.Host519

open Typical Counting Weighting

variable {V : Type*} [Fintype V] {k : ℕ}

/-- **Triangles through an edge.** -/
theorem sum_MA_eq (G : SimpleGraph V) (e : Edge G) (F : Finset V → ℝ) :
    ∑ t : Tri G, MA G e t * F t.1 =
      ∑ z ∈ univ.filter (fun z => G.Adj e.1.out.1 z ∧ G.Adj e.1.out.2 z),
        F {e.1.out.1, e.1.out.2, z} := by
  set a := e.1.out.1
  set b := e.1.out.2
  have hab : G.Adj a b := adj_out G e
  have he : s(a, b) = e.1 := out_eq e.1
  have hMA : ∀ t : Tri G, MA G e t = if e.1 ∈ TypedTriangle.triEdges t.1 then 1 else 0 := by
    intro t; simp only [MA, TypedTriangle.ind]; split_ifs <;> simp
  simp only [hMA, ite_mul, one_mul, zero_mul]
  rw [← Finset.sum_filter]
  symm
  refine Finset.sum_bij (fun z hz => (⟨{a, b, z}, isTri_of_adj G hab
      (Finset.mem_filter.mp hz).2.1 (Finset.mem_filter.mp hz).2.2⟩ : Tri G))
    (fun z hz => ?_) (fun z hz z' hz' heq => ?_) (fun t ht => ?_) (fun z hz => rfl)
  · refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
    rw [← he, TypedTriangle.mem_triEdges]
    exact ⟨by simp, by simp, G.ne_of_adj hab⟩
  · have hz2 := (Finset.mem_filter.mp hz').2
    have h1 : ({a, b, z} : Finset V) = {a, b, z'} := congrArg Subtype.val heq
    have : z' ∈ ({a, b, z} : Finset V) := by rw [h1]; simp
    simp only [Finset.mem_insert, Finset.mem_singleton] at this
    rcases this with h | h | h
    · exact absurd h (G.ne_of_adj hz2.1).symm
    · exact absurd h (G.ne_of_adj hz2.2).symm
    · exact h.symm
  · have hmem := (Finset.mem_filter.mp ht).2
    rw [← he, TypedTriangle.mem_triEdges] at hmem
    obtain ⟨ha, hb, -⟩ := hmem
    have hcard : ((t.1.erase a).erase b).card = 1 := by
      rw [Finset.card_erase_of_mem (Finset.mem_erase.mpr ⟨G.ne_of_adj hab |>.symm, hb⟩),
        Finset.card_erase_of_mem ha, t.2.1]
    obtain ⟨z, hz⟩ := Finset.card_eq_one.mp hcard
    have hzt : z ∈ (t.1.erase a).erase b := by rw [hz]; simp
    simp only [Finset.mem_erase] at hzt
    obtain ⟨hzb, hza, hzt⟩ := hzt
    have haz : G.Adj a z := t.2.2 a ha z hzt (Ne.symm hza)
    have hbz : G.Adj b z := t.2.2 b hb z hzt (Ne.symm hzb)
    refine ⟨z, Finset.mem_filter.mpr ⟨Finset.mem_univ _, haz, hbz⟩, Subtype.ext ?_⟩
    show ({a, b, z} : Finset V) = t.1
    refine (Finset.eq_of_subset_of_card_le ?_ ?_)
    · intro v hv
      simp only [Finset.mem_insert, Finset.mem_singleton] at hv
      rcases hv with rfl | rfl | rfl <;> assumption
    · rw [t.2.1]
      exact (isTri_of_adj G hab haz hbz).1.ge

/-- The weighting `W_1`: `w(type t)` on every triangle `t`. -/
def Wvec (G : SimpleGraph V) (cls : V → Fin k) (d : Fin k → Fin k → ℝ) (A₀ : Fin k) :
    Tri G → ℝ :=
  fun t => weight cls d A₀ A₀ (t.1.val.map cls)

/-- The indicator `u = 1_{E₀}` of the edges inside the class `A₀`. -/
def uvec (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) : Edge G → ℝ :=
  fun f => if f ∈ EIn G cls A₀ ∅ then 1 else 0

lemma val_triple {a b z : V} (hab : a ≠ b) (haz : a ≠ z) (hbz : b ≠ z) :
    ({a, b, z} : Finset V).val = {a, b, z} := by
  rw [Finset.insert_val_of_notMem (by simp [hab, haz]),
    Finset.insert_val_of_notMem (by simp [hbz])]
  rfl

lemma mulVec_Wvec (G : SimpleGraph V) (cls : V → Fin k) (d : Fin k → Fin k → ℝ)
    (A₀ : Fin k) (e : Edge G) :
    (MA G).mulVec (Wvec G cls d A₀) e =
      load G cls (weight cls d A₀ A₀) e.1.out.1 e.1.out.2 := by
  simp only [Matrix.mulVec, dotProduct, Wvec]
  rw [sum_MA_eq G e (fun S => weight cls d A₀ A₀ (S.val.map cls)), load]
  refine Finset.sum_congr rfl fun z hz => ?_
  have hz' := (Finset.mem_filter.mp hz).2
  rw [val_triple (G.ne_of_adj (adj_out G e)) (G.ne_of_adj hz'.1) (G.ne_of_adj hz'.2)]
  simp [Multiset.insert_eq_cons]

lemma weight_self (cls : V → Fin k) (d : Fin k → Fin k → ℝ) (A₀ : Fin k)
    (τ : Multiset (Fin k)) :
    weight cls d A₀ A₀ τ = if τ = {A₀, A₀, A₀} then alpha cls d A₀ A₀ else 0 := by
  simp [weight]

lemma triple_eq_AAA {X Y Z A : Fin k} :
    ({X, Y, Z} : Multiset (Fin k)) = {A, A, A} ↔ X = A ∧ Y = A ∧ Z = A := by
  constructor
  · intro h
    have hr : ({X, Y, Z} : Multiset (Fin k)) = Multiset.replicate 3 A := by
      rw [h]; rfl
    have := (Multiset.eq_replicate.mp hr).2
    exact ⟨this X (by simp), this Y (by simp), this Z (by simp)⟩
  · rintro ⟨rfl, rfl, rfl⟩; rfl

namespace Hyp

variable {G : SimpleGraph V} {cls : V → Fin k} {d : Fin k → Fin k → ℝ} {A₀ : Fin k}
  {η δ₀ d₀ : ℝ} (H : Hyp G cls d A₀ η δ₀ d₀)
include H

lemma csz_pos : 0 < csz cls A₀ := by
  unfold csz
  have := H.class_lower A₀
  have := mul_pos H.δ₀_pos H.m_pos
  linarith

lemma alpha_pos : 0 < alpha cls d A₀ A₀ := by
  unfold alpha
  have := H.csz_pos
  have := H.d₀_pos.trans_le (H.d_lower A₀ A₀)
  positivity

/-- `|e₂| ≤ η`: the load of `W_1` is `1_{E₀}` up to `η`. -/
lemma abs_e₂_le (e : Edge G) :
    |(MA G).mulVec (Wvec G cls d A₀) e - uvec G cls A₀ e| ≤ η := by
  set a := e.1.out.1
  set b := e.1.out.2
  have hab : a ≠ b := G.ne_of_adj (adj_out G e)
  have hdA := H.d₀_pos.trans_le (H.d_lower A₀ A₀)
  have h := load_weight_error H.typ (by norm_num) (A := A₀) (B := A₀) H.csz_pos.ne' hdA.ne'
    hdA.ne' hab
  have hu : uvec G cls A₀ e =
      if ({cls a, cls b} : Multiset (Fin k)) = {A₀, A₀} then 1 else 0 := by
    have : e ∈ EIn G cls A₀ ∅ ↔ cls a = A₀ ∧ cls b = A₀ := by
      rw [mem_EIn]
      constructor
      · intro h'; exact ⟨(h' a (out1_mem _)).1, (h' b (out2_mem _)).1⟩
      · rintro ⟨h1, h2⟩ v hv
        rcases mem_iff_out.mp hv with rfl | rfl
        · exact ⟨h1, by simp⟩
        · exact ⟨h2, by simp⟩
    have h2 : ({cls a, cls b} : Multiset (Fin k)) = {A₀, A₀} ↔ cls a = A₀ ∧ cls b = A₀ := by
      constructor
      · intro hh
        have hr : ({cls a, cls b} : Multiset (Fin k)) = Multiset.replicate 2 A₀ := by
          rw [hh]; rfl
        have := (Multiset.eq_replicate.mp hr).2
        exact ⟨this _ (by simp), this _ (by simp)⟩
      · rintro ⟨h1, h2⟩; rw [h1, h2]
    simp only [uvec, this, h2]
  rw [mulVec_Wvec, hu]
  refine h.trans ?_
  have hsum : ∑ Z, |weight cls d A₀ A₀ {cls a, cls b, Z}| * ideal cls d {a, b} Z ≤ 1 := by
    rw [Finset.sum_eq_single A₀]
    · rw [weight_self, ideal_pair cls d hab]
      by_cases hc : cls a = A₀ ∧ cls b = A₀
      · rw [if_pos (triple_eq_AAA.mpr ⟨hc.1, hc.2, rfl⟩), hc.1, hc.2,
          abs_of_pos H.alpha_pos]
        unfold alpha csz
        have := H.csz_pos
        unfold csz at this
        field_simp
        rfl
      · rw [if_neg (fun hh => hc ⟨(triple_eq_AAA.mp hh).1, (triple_eq_AAA.mp hh).2.1⟩)]
        simp
    · intro Z _ hZ
      rw [weight_self, if_neg (fun hh => hZ (triple_eq_AAA.mp hh).2.2)]
      simp
    · simp
  nlinarith [H.η_nonneg]

/-- `|W_1| ≤ 1/(δ₀ d₀² m)`. -/
lemma abs_Wvec_le (t : Tri G) :
    |Wvec G cls d A₀ t| ≤ 1 / (δ₀ * d₀ ^ 2) / Fintype.card V := by
  have hal := H.alpha_pos
  have hbound : alpha cls d A₀ A₀ ≤ 1 / (δ₀ * d₀ ^ 2) / Fintype.card V := by
    have h1 := H.class_lower A₀
    have h2 := H.d_lower A₀ A₀
    have hm := H.m_pos
    have hδ := H.δ₀_pos
    have hd := H.d₀_pos
    have hdA : 0 < d A₀ A₀ := hd.trans_le h2
    have hlow : δ₀ * d₀ ^ 2 * Fintype.card V ≤
        (classSet cls A₀).card * d A₀ A₀ * d A₀ A₀ := by
      calc δ₀ * d₀ ^ 2 * Fintype.card V = (δ₀ * Fintype.card V) * (d₀ * d₀) := by ring
        _ ≤ (classSet cls A₀).card * (d A₀ A₀ * d A₀ A₀) :=
            mul_le_mul h1 (mul_le_mul h2 h2 hd.le hdA.le) (mul_pos hd hd).le
              (Nat.cast_nonneg _)
        _ = (classSet cls A₀).card * d A₀ A₀ * d A₀ A₀ := by ring
    unfold alpha csz
    rw [div_div]
    exact one_div_le_one_div_of_le (mul_pos (mul_pos hδ (pow_pos hd 2)) hm) hlow
  unfold Wvec
  rw [weight_self]
  split_ifs
  · rw [abs_of_pos hal]; exact hbound
  · rw [abs_zero]; exact hal.le.trans hbound

end Hyp

end ColourStats.Host519
