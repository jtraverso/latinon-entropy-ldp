/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedGAgg
public import ColourStats.TypedStats
public import ColourStats.Statements

/-!
# Triangle decompositions as quasigroups, and the counts on `G`

* `thirdPtG`: the quasigroup of a triangle decomposition; it satisfies `IsSQG`
  (`thirdPtG_isSQG`) and determines the decomposition (`thirdPtG_injective`).
* `MstatG_eq`: a decomposition with `t_τ` triangles of type `τ` has `m_π(τ) t_τ` edges of
  class `π` whose third point has class `X`, `τ = X :: π`.
* `card_EpiG`: `|E_π| = e_π(G)`.
* `sum_cnb`: `Σ_{ab ∈ E_π} |N(a) ∩ N(b) ∩ X| = m_π(τ) N_τ(G)` (double count of triangles).
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.TypedG

open ColourStats ColourStats.Statements ColourStats.TypedChain ColourStats.TypedSTS

open Classical

variable {n k : ℕ} {G : SimpleGraph (Fin n)} {D : Finset (Finset (Fin n))}

lemma adj_of_mem (hD : IsTriDecomp G D) {B : Finset (Fin n)} (hB : B ∈ D) {x y : Fin n}
    (hx : x ∈ B) (hy : y ∈ B) (hxy : x ≠ y) : G.Adj x y :=
  (hD.1 B hB).2 x hx y hy hxy

lemma exists_thirdG (hD : IsTriDecomp G D) {a b : Fin n} (hab : G.Adj a b) :
    ∃ c, c ≠ a ∧ c ≠ b ∧ ({a, b, c} : Finset (Fin n)) ∈ D := by
  obtain ⟨A, ⟨hA, haA, hbA⟩, -⟩ := hD.2 a b hab
  have h3 := (hD.1 A hA).1
  have hcard : ((A.erase a).erase b).card = 1 := by
    rw [Finset.card_erase_of_mem (Finset.mem_erase.2 ⟨Ne.symm hab.ne, hbA⟩),
      Finset.card_erase_of_mem haA, h3]
  obtain ⟨c, hc⟩ := Finset.card_eq_one.1 hcard
  have hcm : c ∈ (A.erase a).erase b := by rw [hc]; exact Finset.mem_singleton_self c
  simp only [Finset.mem_erase] at hcm
  refine ⟨c, hcm.2.1, hcm.1, ?_⟩
  have : A = {a, b, c} := by
    ext x
    simp only [Finset.mem_insert, Finset.mem_singleton]
    constructor
    · intro hx
      by_cases hxa : x = a
      · exact Or.inl hxa
      by_cases hxb : x = b
      · exact Or.inr (Or.inl hxb)
      have : x ∈ (A.erase a).erase b := by simp [hxa, hxb, hx]
      rw [hc, Finset.mem_singleton] at this
      exact Or.inr (Or.inr this)
    · rintro (rfl | rfl | rfl)
      · exact haA
      · exact hbA
      · exact hcm.2.2
  rw [← this]; exact hA

lemma third_uniqueG (hD : IsTriDecomp G D) {a b c c' : Fin n} (hab : G.Adj a b)
    (hc : ({a, b, c} : Finset (Fin n)) ∈ D) (hc'a : c' ≠ a) (hc'b : c' ≠ b)
    (hc' : ({a, b, c'} : Finset (Fin n)) ∈ D) : c = c' := by
  obtain ⟨A, -, hAu⟩ := hD.2 a b hab
  have e1 := hAu {a, b, c} ⟨hc, by simp, by simp⟩
  have e2 := hAu {a, b, c'} ⟨hc', by simp, by simp⟩
  have : c' ∈ ({a, b, c} : Finset (Fin n)) := by rw [e1, ← e2]; simp
  simp only [Finset.mem_insert, Finset.mem_singleton] at this
  rcases this with h | h | h
  · exact absurd h hc'a
  · exact absurd h hc'b
  · exact h.symm

/-- The third point of the triangle through an edge (and `a` off the edges). -/
noncomputable def thirdPtG (G : SimpleGraph (Fin n)) (D : Finset (Finset (Fin n))) (a b : Fin n) :
    Fin n :=
  if h : G.Adj a b ∧ ∃ c, c ≠ a ∧ c ≠ b ∧ ({a, b, c} : Finset (Fin n)) ∈ D then
    Classical.choose h.2 else a

lemma thirdPtG_spec (hD : IsTriDecomp G D) {a b : Fin n} (hab : G.Adj a b) :
    thirdPtG G D a b ≠ a ∧ thirdPtG G D a b ≠ b ∧
      ({a, b, thirdPtG G D a b} : Finset (Fin n)) ∈ D := by
  have h : G.Adj a b ∧ ∃ c, c ≠ a ∧ c ≠ b ∧ ({a, b, c} : Finset (Fin n)) ∈ D :=
    ⟨hab, exists_thirdG hD hab⟩
  unfold thirdPtG
  rw [dif_pos h]
  exact Classical.choose_spec h.2

lemma thirdPtG_eq (hD : IsTriDecomp G D) {a b c : Fin n} (hab : G.Adj a b) (hca : c ≠ a)
    (hcb : c ≠ b) (hc : ({a, b, c} : Finset (Fin n)) ∈ D) : thirdPtG G D a b = c := by
  obtain ⟨-, -, h3⟩ := thirdPtG_spec hD hab
  exact third_uniqueG hD hab h3 hca hcb hc

lemma thirdPtG_isSQG (hD : IsTriDecomp G D) : IsSQG G (thirdPtG G D) := by
  refine ⟨fun a b hab => ?_, fun a b hab => ?_⟩
  · obtain ⟨h1, h2, h3⟩ := thirdPtG_spec hD hab
    have hac : G.Adj a (thirdPtG G D a b) := adj_of_mem hD h3 (by simp) (by simp) (Ne.symm h1)
    refine ⟨h1, h2, ?_, ?_, hac⟩
    · apply thirdPtG_eq hD hab.symm h2 h1
      have : ({b, a, thirdPtG G D a b} : Finset (Fin n)) = {a, b, thirdPtG G D a b} := by
        ext; simp; tauto
      rw [this]; exact h3
    · apply thirdPtG_eq hD hac (Ne.symm hab.ne) (Ne.symm h2)
      have : ({a, thirdPtG G D a b, b} : Finset (Fin n)) = {a, b, thirdPtG G D a b} := by
        ext; simp; tauto
      rw [this]; exact h3
  · unfold thirdPtG
    rw [dif_neg]
    exact fun h => hab h.1

lemma mem_of_thirdPtG (hD : IsTriDecomp G D) {A : Finset (Fin n)} (hA : A ∈ D) :
    ∃ a b, G.Adj a b ∧ A = {a, b, thirdPtG G D a b} := by
  obtain ⟨a, b, c, hab, hac, hbc, rfl⟩ := Finset.card_eq_three.1 (hD.1 A hA).1
  have hadj : G.Adj a b := adj_of_mem hD hA (by simp) (by simp) hab
  refine ⟨a, b, hadj, ?_⟩
  rw [thirdPtG_eq hD hadj (Ne.symm hac) (Ne.symm hbc) hA]

lemma thirdPtG_injective {D D' : Finset (Finset (Fin n))} (hD : IsTriDecomp G D)
    (hD' : IsTriDecomp G D') (h : thirdPtG G D = thirdPtG G D') : D = D' := by
  have sub : ∀ {D D' : Finset (Finset (Fin n))}, IsTriDecomp G D → IsTriDecomp G D' →
      thirdPtG G D = thirdPtG G D' → D ⊆ D' := by
    intro D D' hD hD' h A hA
    obtain ⟨a, b, hab, rfl⟩ := mem_of_thirdPtG hD hA
    rw [h]
    exact (thirdPtG_spec hD' hab).2.2
  exact Finset.Subset.antisymm (sub hD hD' h) (sub hD' hD h.symm)

/-! ### Pair statistics -/

/-- The block through an edge. -/
noncomputable def blkBG (G : SimpleGraph (Fin n)) (D : Finset (Finset (Fin n))) (p : Pair n) :
    Finset (Fin n) :=
  {p.1, p.2, thirdPtG G D p.1 p.2}

lemma mem_pairsG {p : Pair n} : p ∈ pairsG G ↔ p.1 < p.2 ∧ G.Adj p.1 p.2 := by
  simp [pairsG, TypedSTS.pairs]

/-- **Pair statistics on `G`.** -/
theorem MstatG_eq (hD : IsTriDecomp G D) (lab : Fin n → Fin k) (π : Multiset (Fin k))
    (X : Fin k) :
    MstatG G lab (thirdPtG G D) π X = mult π (X ::ₘ π) * typeCount lab D (X ::ₘ π) := by
  set F := D.sigma fun A => (A.powersetCard 2).filter
    fun e => blockType lab e = π ∧ blockType lab A = X ::ₘ π
  have hF : F.card = mult π (X ::ₘ π) * typeCount lab D (X ::ₘ π) := by
    rw [Finset.card_sigma]
    have h1 : ∀ A ∈ D, ((A.powersetCard 2).filter
        fun e => blockType lab e = π ∧ blockType lab A = X ::ₘ π).card =
        if blockType lab A = X ::ₘ π then mult π (X ::ₘ π) else 0 := by
      intro A _
      split_ifs with hA
      · rw [← hA, ← card_pairs_of_type lab A π]
        congr 1
        exact Finset.filter_congr fun e _ => by simp [hA]
      · rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
        exact fun e _ h => hA h.2
    rw [Finset.sum_congr rfl h1, ← Finset.sum_filter, Finset.sum_const, smul_eq_mul, mul_comm]
    rfl
  rw [← hF]
  unfold MstatG
  refine Finset.card_bij (fun p _ => ⟨blkBG G D p, {p.1, p.2}⟩) ?_ ?_ ?_
  · intro p hp
    obtain ⟨hpE, hX⟩ := Finset.mem_filter.mp hp
    obtain ⟨hpp, hπ⟩ := Finset.mem_filter.mp hpE
    obtain ⟨hlt, hadj⟩ := mem_pairsG.mp hpp
    obtain ⟨hca, hcb, hmem⟩ := thirdPtG_spec hD hadj
    refine Finset.mem_sigma.mpr ⟨hmem, Finset.mem_filter.mpr ⟨?_, ?_, ?_⟩⟩
    · rw [Finset.mem_powersetCard]
      refine ⟨?_, Finset.card_pair hlt.ne⟩
      intro z hz
      simp only [Finset.mem_insert, Finset.mem_singleton] at hz
      simp only [blkBG, Finset.mem_insert, Finset.mem_singleton]
      tauto
    · rw [blockType_pair lab hlt.ne, hπ]
    · unfold blkBG
      rw [blockType_triple lab hlt.ne (Ne.symm hca) (Ne.symm hcb), hX, hπ]
  · intro p hp q hq h
    have hp' : p.1 < p.2 := (mem_pairsG.mp (Finset.mem_filter.mp (Finset.mem_filter.mp hp).1).1).1
    have hq' : q.1 < q.2 := (mem_pairsG.mp (Finset.mem_filter.mp (Finset.mem_filter.mp hq).1).1).1
    have h2 : ({p.1, p.2} : Finset (Fin n)) = {q.1, q.2} := by
      have := congrArg Sigma.snd h
      simpa using this
    rcases pair_eq_cases hp'.ne h2 with ⟨e1, e2⟩ | ⟨e1, e2⟩
    · exact Prod.ext e1 e2
    · exfalso
      rw [e1, e2] at hp'
      exact lt_asymm hp' hq'
  · rintro ⟨A, e⟩ hAe
    obtain ⟨hA, he⟩ := Finset.mem_sigma.mp hAe
    obtain ⟨he2, hπ, hτ⟩ := Finset.mem_filter.mp he
    obtain ⟨hsub, hcard⟩ := Finset.mem_powersetCard.mp he2
    obtain ⟨x, y, hxy, rfl⟩ := Finset.card_eq_two.mp hcard
    have hxA : x ∈ A := hsub (by simp)
    have hyA : y ∈ A := hsub (by simp)
    have hxyadj : G.Adj x y := adj_of_mem hD hA hxA hyA hxy
    set p := sp x y with hpdef
    have hset : ({p.1, p.2} : Finset (Fin n)) = {x, y} := sp_set x y
    have hpp : p ∈ pairsG G := sp_memG hxyadj
    obtain ⟨hlt, hadj⟩ := mem_pairsG.mp hpp
    obtain ⟨hca, hcb, hmem⟩ := thirdPtG_spec hD hadj
    have h1A : p.1 ∈ A := by
      have : p.1 ∈ ({x, y} : Finset (Fin n)) := hset ▸ (by simp)
      simp only [Finset.mem_insert, Finset.mem_singleton] at this
      rcases this with h | h <;> rw [h] <;> assumption
    have h2A : p.2 ∈ A := by
      have : p.2 ∈ ({x, y} : Finset (Fin n)) := hset ▸ (by simp)
      simp only [Finset.mem_insert, Finset.mem_singleton] at this
      rcases this with h | h <;> rw [h] <;> assumption
    have hblk : blkBG G D p = A := by
      obtain ⟨A₀, -, hA₀⟩ := hD.2 p.1 p.2 hadj
      have e1 := hA₀ (blkBG G D p) ⟨hmem, by simp [blkBG], by simp [blkBG]⟩
      have e2 := hA₀ A ⟨hA, h1A, h2A⟩
      rw [e1, e2]
    have hπp : ({lab p.1, lab p.2} : Multiset (Fin k)) = π := by
      rw [← blockType_pair lab hlt.ne, hset, hπ]
    refine ⟨p, Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr ⟨hpp, hπp⟩, ?_⟩, ?_⟩
    · have hT := blockType_triple lab hlt.ne (Ne.symm hca) (Ne.symm hcb)
      rw [show ({p.1, p.2, thirdPtG G D p.1 p.2} : Finset (Fin n)) = blkBG G D p from rfl, hblk,
        hτ, hπp] at hT
      exact (Multiset.cons_inj_left _).mp hT.symm
    · simp only [hblk, hset]

/-! ### Edges and triangles of `G` -/

/-- `|E_π| = e_π(G)`. -/
lemma card_EpiG (lab : Fin n → Fin k) (π : Multiset (Fin k)) :
    (EpiG G lab π).card = edgesOf G lab π := by
  unfold EpiG edgesOf
  refine Finset.card_bij (fun p _ => ({p.1, p.2} : Finset (Fin n))) ?_ ?_ ?_
  · intro p hp
    obtain ⟨hpp, hπp⟩ := Finset.mem_filter.mp hp
    obtain ⟨hlt, hadj⟩ := mem_pairsG.mp hpp
    refine Finset.mem_filter.mpr ⟨Finset.mem_powersetCard.mpr ⟨Finset.subset_univ _,
      Finset.card_pair hlt.ne⟩, ?_, ?_⟩
    · intro x hx y hy hxy
      simp only [Finset.mem_insert, Finset.mem_singleton] at hx hy
      rcases hx with rfl | rfl <;> rcases hy with rfl | rfl
      · exact absurd rfl hxy
      · exact hadj
      · exact hadj.symm
      · exact absurd rfl hxy
    · rw [blockType_pair lab hlt.ne, hπp]
  · intro p hp q hq h
    have hp' : p.1 < p.2 := (mem_pairsG.mp (Finset.mem_filter.mp hp).1).1
    have hq' : q.1 < q.2 := (mem_pairsG.mp (Finset.mem_filter.mp hq).1).1
    rcases pair_eq_cases hp'.ne h with ⟨e1, e2⟩ | ⟨e1, e2⟩
    · exact Prod.ext e1 e2
    · exfalso
      rw [e1, e2] at hp'
      exact lt_asymm hp' hq'
  · intro e he
    obtain ⟨he2, hadjE, hτ⟩ := Finset.mem_filter.mp he
    obtain ⟨-, hcard⟩ := Finset.mem_powersetCard.mp he2
    obtain ⟨x, y, hxy, rfl⟩ := Finset.card_eq_two.mp hcard
    have hxyadj : G.Adj x y := hadjE x (by simp) y (by simp) hxy
    have hpp := sp_memG hxyadj
    have hlt : (sp x y).1 < (sp x y).2 := (mem_pairsG.mp hpp).1
    refine ⟨sp x y, Finset.mem_filter.mpr ⟨hpp, ?_⟩, sp_set x y⟩
    rw [← blockType_pair lab hlt.ne, sp_set, hτ]

/-- **Double count of triangles.** `Σ_{ab ∈ E_π} |N(a) ∩ N(b) ∩ X| = m_π(τ) N_τ(G)`. -/
theorem sum_cnb (lab : Fin n → Fin k) (π : Multiset (Fin k)) (X : Fin k) :
    ∑ p ∈ EpiG G lab π, cnb G lab p.1 p.2 X = mult π (X ::ₘ π) * trianglesOf G lab (X ::ₘ π) := by
  set Tri := ((univ : Finset (Fin n)).powersetCard 3).filter fun B =>
    ∀ x ∈ B, ∀ y ∈ B, x ≠ y → G.Adj x y
  set F := Tri.sigma fun A => (A.powersetCard 2).filter
    fun e => blockType lab e = π ∧ blockType lab A = X ::ₘ π
  have hF : F.card = mult π (X ::ₘ π) * trianglesOf G lab (X ::ₘ π) := by
    rw [Finset.card_sigma]
    have h1 : ∀ A ∈ Tri, ((A.powersetCard 2).filter
        fun e => blockType lab e = π ∧ blockType lab A = X ::ₘ π).card =
        if blockType lab A = X ::ₘ π then mult π (X ::ₘ π) else 0 := by
      intro A _
      split_ifs with hA
      · rw [← hA, ← card_pairs_of_type lab A π]
        congr 1
        exact Finset.filter_congr fun e _ => by simp [hA]
      · rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
        exact fun e _ h => hA h.2
    rw [Finset.sum_congr rfl h1, ← Finset.sum_filter, Finset.sum_const, smul_eq_mul, mul_comm]
    unfold trianglesOf
    rw [Finset.filter_filter]
  rw [← hF]
  set P := (EpiG G lab π).sigma fun p : Pair n =>
    univ.filter fun z => lab z = X ∧ G.Adj p.1 z ∧ G.Adj p.2 z
  have hP : P.card = ∑ p ∈ EpiG G lab π, cnb G lab p.1 p.2 X := by
    rw [Finset.card_sigma]
    rfl
  rw [← hP]
  refine Finset.card_bij (fun q _ => ⟨{q.1.1, q.1.2, q.2}, {q.1.1, q.1.2}⟩) ?_ ?_ ?_
  · rintro ⟨p, z⟩ hq
    obtain ⟨hp, hz⟩ := Finset.mem_sigma.mp hq
    obtain ⟨hpp, hπp⟩ := Finset.mem_filter.mp hp
    obtain ⟨hlt, hadj⟩ := mem_pairsG.mp hpp
    obtain ⟨-, hzX, h1z, h2z⟩ := Finset.mem_filter.mp hz
    have hz1 : z ≠ p.1 := (G.ne_of_adj h1z).symm
    have hz2 : z ≠ p.2 := (G.ne_of_adj h2z).symm
    refine Finset.mem_sigma.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_powersetCard.mpr
      ⟨Finset.subset_univ _, ?_⟩, ?_⟩, Finset.mem_filter.mpr ⟨?_, ?_, ?_⟩⟩
    · rw [Finset.card_eq_three]
      exact ⟨p.1, p.2, z, hlt.ne, Ne.symm hz1, Ne.symm hz2, rfl⟩
    · intro x hx y hy hxy
      simp only [Finset.mem_insert, Finset.mem_singleton] at hx hy
      rcases hx with rfl | rfl | rfl <;> rcases hy with rfl | rfl | rfl
      all_goals first
        | exact absurd rfl hxy
        | exact hadj | exact hadj.symm | exact h1z | exact h1z.symm | exact h2z | exact h2z.symm
    · rw [Finset.mem_powersetCard]
      refine ⟨?_, Finset.card_pair hlt.ne⟩
      intro w hw
      simp only [Finset.mem_insert, Finset.mem_singleton] at hw ⊢
      tauto
    · rw [blockType_pair lab hlt.ne, hπp]
    · rw [blockType_triple lab hlt.ne (Ne.symm hz1) (Ne.symm hz2), hzX, hπp]
  · rintro ⟨p, z⟩ hq ⟨p', z'⟩ hq' h
    obtain ⟨hp, hz⟩ := Finset.mem_sigma.mp hq
    obtain ⟨hp', hz'⟩ := Finset.mem_sigma.mp hq'
    have hlt : p.1 < p.2 := (mem_pairsG.mp (Finset.mem_filter.mp hp).1).1
    have hlt' : p'.1 < p'.2 := (mem_pairsG.mp (Finset.mem_filter.mp hp').1).1
    have h2 : ({p.1, p.2} : Finset (Fin n)) = {p'.1, p'.2} := by
      have := congrArg Sigma.snd h
      simpa using this
    have h1 : ({p.1, p.2, z} : Finset (Fin n)) = {p'.1, p'.2, z'} := by
      have := congrArg Sigma.fst h
      simpa using this
    have hpe : p = p' := by
      rcases pair_eq_cases hlt.ne h2 with ⟨e1, e2⟩ | ⟨e1, e2⟩
      · exact Prod.ext e1 e2
      · exfalso
        rw [e1, e2] at hlt
        exact lt_asymm hlt hlt'
    subst hpe
    obtain ⟨-, -, h1z, h2z⟩ := Finset.mem_filter.mp hz
    have hz1 : z ≠ p.1 := (G.ne_of_adj h1z).symm
    have hz2 : z ≠ p.2 := (G.ne_of_adj h2z).symm
    have hzm : z ∈ ({p.1, p.2, z'} : Finset (Fin n)) := h1 ▸ (by simp)
    simp only [Finset.mem_insert, Finset.mem_singleton] at hzm
    rcases hzm with h | h | h
    · exact absurd h hz1
    · exact absurd h hz2
    · rw [h]
  · rintro ⟨A, e⟩ hAe
    obtain ⟨hA, he⟩ := Finset.mem_sigma.mp hAe
    obtain ⟨hA3, hAadj⟩ := Finset.mem_filter.mp hA
    obtain ⟨-, hAcard⟩ := Finset.mem_powersetCard.mp hA3
    obtain ⟨he2, hπ, hτ⟩ := Finset.mem_filter.mp he
    obtain ⟨hsub, hcard⟩ := Finset.mem_powersetCard.mp he2
    obtain ⟨x, y, hxy, rfl⟩ := Finset.card_eq_two.mp hcard
    have hxA : x ∈ A := hsub (by simp)
    have hyA : y ∈ A := hsub (by simp)
    -- the third point of `A`
    have hc1 : ((A.erase x).erase y).card = 1 := by
      rw [Finset.card_erase_of_mem (Finset.mem_erase.2 ⟨Ne.symm hxy, hyA⟩),
        Finset.card_erase_of_mem hxA, hAcard]
    obtain ⟨z, hzc⟩ := Finset.card_eq_one.1 hc1
    have hzm : z ∈ (A.erase x).erase y := by rw [hzc]; exact Finset.mem_singleton_self z
    simp only [Finset.mem_erase] at hzm
    obtain ⟨hzy, hzx, hzA⟩ := hzm
    have hAeq : A = {x, y, z} := by
      ext w
      simp only [Finset.mem_insert, Finset.mem_singleton]
      constructor
      · intro hw
        by_cases hwx : w = x
        · exact Or.inl hwx
        by_cases hwy : w = y
        · exact Or.inr (Or.inl hwy)
        have : w ∈ (A.erase x).erase y := by simp [hwx, hwy, hw]
        rw [hzc, Finset.mem_singleton] at this
        exact Or.inr (Or.inr this)
      · rintro (rfl | rfl | rfl)
        · exact hxA
        · exact hyA
        · exact hzA
    have hxyadj : G.Adj x y := hAadj x hxA y hyA hxy
    set p := sp x y with hpdef
    have hset : ({p.1, p.2} : Finset (Fin n)) = {x, y} := sp_set x y
    have hpp : p ∈ pairsG G := sp_memG hxyadj
    have hlt : p.1 < p.2 := (mem_pairsG.mp hpp).1
    have hπp : ({lab p.1, lab p.2} : Multiset (Fin k)) = π := by
      rw [← blockType_pair lab hlt.ne, hset, hπ]
    have hpA : ({p.1, p.2, z} : Finset (Fin n)) = A := by
      rw [hAeq]
      ext w
      have : w ∈ ({p.1, p.2} : Finset (Fin n)) ↔ w ∈ ({x, y} : Finset (Fin n)) := by rw [hset]
      simp only [Finset.mem_insert, Finset.mem_singleton] at this ⊢
      tauto
    have hp1 : p.1 ∈ ({x, y} : Finset (Fin n)) := hset ▸ (by simp)
    have hp2 : p.2 ∈ ({x, y} : Finset (Fin n)) := hset ▸ (by simp)
    simp only [Finset.mem_insert, Finset.mem_singleton] at hp1 hp2
    have hzp1 : z ≠ p.1 := by rcases hp1 with h | h <;> rw [h] <;> assumption
    have hzp2 : z ≠ p.2 := by rcases hp2 with h | h <;> rw [h] <;> assumption
    have hadj1 : G.Adj p.1 z := by
      refine hAadj _ ?_ _ hzA (Ne.symm hzp1)
      rcases hp1 with h | h <;> rw [h] <;> assumption
    have hadj2 : G.Adj p.2 z := by
      refine hAadj _ ?_ _ hzA (Ne.symm hzp2)
      rcases hp2 with h | h <;> rw [h] <;> assumption
    have hzX : lab z = X := by
      have hT := blockType_triple lab hlt.ne (Ne.symm hzp1) (Ne.symm hzp2)
      rw [hpA, hτ, hπp] at hT
      exact (Multiset.cons_inj_left _).mp hT.symm
    refine ⟨⟨p, z⟩, Finset.mem_sigma.mpr ⟨Finset.mem_filter.mpr ⟨hpp, hπp⟩,
      Finset.mem_filter.mpr ⟨Finset.mem_univ _, hzX, hadj1, hadj2⟩⟩, ?_⟩
    simp only [hpA, hset]

end ColourStats.TypedG
