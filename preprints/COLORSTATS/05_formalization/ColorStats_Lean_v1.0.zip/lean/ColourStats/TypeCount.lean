/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Challenge
public import ColourStats.ColourFirst

/-!
# Counting sets of points by type, and Lemma 5.12(b) in the form `Φ(t)`

For a partition `lab : Fin n → Fin k` of the points, the number of sets of points of type
`μ` is `Π_X C(c_X, μ_X)`, with `c_X` the size of class `X` (`card_type`). In particular
`N_τ = numTriples lab τ` and `e_π = numPairs lab π` are the `typeNum` of `ColourFirst`.

With this, Lemma 5.12(b) with `ν ≡ 1` and `t' = t` reads
`Σ_π e_π H(P(·|π)) + Σ_τ t_τ (log D_τ − 2) = Φ(t)` (`colour_first_Phi`).
-/

@[expose] public section

open Finset

namespace ColourStats

open ColourFirst

variable {n k : ℕ}

lemma count_blockType (lab : Fin n → Fin k) (B : Finset (Fin n)) (X : Fin k) :
    (blockType lab B).count X = (B.filter fun v => lab v = X).card := by
  simp only [blockType, Multiset.count_map, Finset.card_def, Finset.filter_val]
  congr 1
  exact Multiset.filter_congr fun x _ => eq_comm

lemma filter_biUnion_fibres (lab : Fin n → Fin k) (F : Fin k → Finset (Fin n))
    (hF : ∀ Y, ∀ v ∈ F Y, lab v = Y) (X : Fin k) :
    (univ.biUnion F).filter (fun v => lab v = X) = F X := by
  ext v
  simp only [Finset.mem_filter, Finset.mem_biUnion, Finset.mem_univ, true_and]
  constructor
  · rintro ⟨⟨Y, hv⟩, hX⟩
    have hY := hF Y v hv
    rw [hY] at hX
    exact hX ▸ hv
  · intro hv
    exact ⟨⟨X, hv⟩, hF X v hv⟩

/-- **Counting by type.** The number of sets of points of type `μ` is
`Π_X C(c_X, μ_X)`. -/
theorem card_type (lab : Fin n → Fin k) (μ : Multiset (Fin k)) :
    (((univ : Finset (Fin n)).powersetCard (Multiset.card μ)).filter
      fun B => blockType lab B = μ).card = typeNum (classSize lab) μ := by
  classical
  let T : ∀ _ : Fin k, Finset (Finset (Fin n)) := fun X =>
    (univ.filter fun v => lab v = X).powersetCard (μ.count X)
  have hT : (Fintype.piFinset T).card = typeNum (classSize lab) μ := by
    rw [Fintype.card_piFinset]
    simp only [T, Finset.card_powersetCard, typeNum, classSize]
  rw [← hT]
  refine Finset.card_nbij' (fun B X => B.filter fun v => lab v = X)
    (fun F => univ.biUnion F) ?_ ?_ ?_ ?_
  · intro B hB
    simp only [Finset.mem_coe, Finset.mem_filter] at hB
    simp only [Finset.mem_coe, Fintype.mem_piFinset, T, Finset.mem_powersetCard]
    intro X
    refine ⟨fun v hv => ?_, ?_⟩
    · simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hv ⊢
      exact hv.2
    · rw [← count_blockType, hB.2]
  · intro F hF
    simp only [Finset.mem_coe, Fintype.mem_piFinset, T, Finset.mem_powersetCard] at hF
    have hlab : ∀ Y, ∀ v ∈ F Y, lab v = Y := fun Y v hv => by
      have := (hF Y).1 hv
      simpa using this
    have hμ : blockType lab (univ.biUnion F) = μ := by
      ext X
      rw [count_blockType, filter_biUnion_fibres lab F hlab X, (hF X).2]
    simp only [Finset.mem_coe, Finset.mem_filter, Finset.mem_powersetCard]
    refine ⟨⟨Finset.subset_univ _, ?_⟩, hμ⟩
    rw [← hμ, blockType, Multiset.card_map, Finset.card_def]
  · intro B _
    ext v
    simp
  · intro F hF
    simp only [Finset.mem_coe, Fintype.mem_piFinset, T, Finset.mem_powersetCard] at hF
    have hlab : ∀ Y, ∀ v ∈ F Y, lab v = Y := fun Y v hv => by
      have := (hF Y).1 hv
      simpa using this
    funext X
    exact filter_biUnion_fibres lab F hlab X

/-- `N_τ = Π_X C(c_X, τ_X)` for a block type `τ`. -/
theorem numTriples_eq (lab : Fin n → Fin k) {τ : Multiset (Fin k)}
    (hτ : Multiset.card τ = 3) : numTriples lab τ = typeNum (classSize lab) τ := by
  rw [numTriples, ← hτ]
  exact card_type lab τ

/-- `e_π = Π_X C(c_X, π_X)` for a pair class `π`. -/
theorem numPairs_eq (lab : Fin n → Fin k) {π : Multiset (Fin k)}
    (hπ : Multiset.card π = 2) : numPairs lab π = typeNum (classSize lab) π := by
  rw [numPairs, ← hπ]
  exact card_type lab π

/-- **Lemma 5.12(b) with `ν ≡ 1` and `t' = t`.** For positive `t`,
`Σ_π e_π H(P(·|π)) + Σ_τ t_τ (log D_τ − 2) = Φ(t)`. -/
theorem colour_first_Phi (lab : Fin n → Fin k) (hc : ∀ X, 3 ≤ classSize lab X)
    (t : Multiset (Fin k) → ℕ) (ht : ∀ τ ∈ blockTypes k, 0 < t τ) :
    ∑ π ∈ pairTypes k, (numPairs lab π : ℝ) *
        ∑ τ ∈ blockTypes k,
          Real.negMulLog (P (classSize lab) (fun _ => 1) (fun τ => (t τ : ℝ)) τ π) +
      ∑ τ ∈ blockTypes k,
        (t τ : ℝ) * (Real.log (D (classSize lab) (fun τ => (t τ : ℝ)) τ) - 2) =
    Phi lab t := by
  have h := entropy_identity_one (classSize lab) hc (fun τ => (t τ : ℝ))
    (fun τ hτ => by exact_mod_cast ht τ hτ)
  have hL : ∑ π ∈ pairTypes k, (numPairs lab π : ℝ) *
        ∑ τ ∈ blockTypes k,
          Real.negMulLog (P (classSize lab) (fun _ => 1) (fun τ => (t τ : ℝ)) τ π) =
      ∑ π ∈ pairTypes k, (typeNum (classSize lab) π : ℝ) *
        ∑ τ ∈ blockTypes k,
          Real.negMulLog (P (classSize lab) (fun _ => 1) (fun τ => (t τ : ℝ)) τ π) :=
    Finset.sum_congr rfl fun π hπ => by rw [numPairs_eq lab (mem_pairTypes.mp hπ)]
  have hR : Phi lab t = ∑ τ ∈ blockTypes k,
      (t τ : ℝ) * (Real.log ((typeNum (classSize lab) τ : ℝ) / t τ) - 2) :=
    Finset.sum_congr rfl fun τ hτ => by rw [numTriples_eq lab (mem_blockTypes.mp hτ)]
  rw [hL, hR]
  exact h

end ColourStats
