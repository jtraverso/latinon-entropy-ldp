/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Estimates519

/-!
# The norm of `Φ₁` (Lemma 5.19)

The gadget `g(e, f)` is supported on triangles `t` that contain one of `e, f` and meet the
other (`gadget_support`), and `|g| ≤ 2`. At most `9` edges lie inside a triangle and at most
`3m` edges meet it, while `ν_e(f) ≤ 1/(p m²)`. Hence `‖Φ₁‖ ≤ 108/(p m)` (`norm_Phiop_le`).
-/

@[expose] public section

open Finset

noncomputable section

open Classical

namespace ColourStats.Host519

open Typical Counting

variable {V : Type*} [Fintype V] {k : ℕ}

/-- The edges inside the triangle `t`. -/
def Ain (G : SimpleGraph V) (t : Tri G) : Finset (Edge G) :=
  univ.filter fun e => ∀ v ∈ e.1, v ∈ t.1

/-- The edges meeting the triangle `t`. -/
def Bmeet (G : SimpleGraph V) (t : Tri G) : Finset (Edge G) :=
  univ.filter fun f => ∃ v ∈ t.1, v ∈ f.1

omit [Fintype V] in
lemma mem_iff_out {e : Sym2 V} {v : V} : v ∈ e ↔ v = e.out.1 ∨ v = e.out.2 := by
  rw [← mem_verts]; simp [verts]

omit [Fintype V] in
lemma out1_mem (e : Sym2 V) : e.out.1 ∈ e := mem_iff_out.mpr (Or.inl rfl)

omit [Fintype V] in
lemma out2_mem (e : Sym2 V) : e.out.2 ∈ e := mem_iff_out.mpr (Or.inr rfl)

lemma gadget_apply (G : SimpleGraph V) (e f : Edge G) (t : Tri G) :
    gadget G e f t = 1 / 2 * (triInd G {e.1.out.1, e.1.out.2, f.1.out.1} t +
      triInd G {e.1.out.1, e.1.out.2, f.1.out.2} t -
      triInd G {e.1.out.1, f.1.out.1, f.1.out.2} t -
      triInd G {e.1.out.2, f.1.out.1, f.1.out.2} t) := by
  simp [gadget]

lemma abs_gadget_le (G : SimpleGraph V) (e f : Edge G) (t : Tri G) : |gadget G e f t| ≤ 2 := by
  rw [gadget_apply]
  unfold triInd
  split_ifs <;> norm_num

lemma gadget_support {G : SimpleGraph V} {e f : Edge G} {t : Tri G}
    (h : gadget G e f t ≠ 0) :
    (e ∈ Ain G t ∧ f ∈ Bmeet G t) ∨ (f ∈ Ain G t ∧ e ∈ Bmeet G t) := by
  by_contra hc
  push_neg at hc
  apply h
  have inA : ∀ (g : Edge G) (z : V), t.1 = {g.1.out.1, g.1.out.2, z} → g ∈ Ain G t := by
    intro g z ht
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, fun v hv => ?_⟩
    rw [ht]
    rcases mem_iff_out.mp hv with rfl | rfl <;> simp
  have inA' : ∀ (g : Edge G) (z : V), t.1 = {z, g.1.out.1, g.1.out.2} → g ∈ Ain G t := by
    intro g z ht
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, fun v hv => ?_⟩
    rw [ht]
    rcases mem_iff_out.mp hv with rfl | rfl <;> simp
  have inB : ∀ (g : Edge G) (z : V), z ∈ t.1 → z ∈ g.1 → g ∈ Bmeet G t :=
    fun g z hz hzg => Finset.mem_filter.mpr ⟨Finset.mem_univ _, z, hz, hzg⟩
  have n1 : t.1 ≠ {e.1.out.1, e.1.out.2, f.1.out.1} := fun ht =>
    hc.1 (inA e _ ht) (inB f _ (by rw [ht]; simp) (out1_mem _))
  have n2 : t.1 ≠ {e.1.out.1, e.1.out.2, f.1.out.2} := fun ht =>
    hc.1 (inA e _ ht) (inB f _ (by rw [ht]; simp) (out2_mem _))
  have n3 : t.1 ≠ {e.1.out.1, f.1.out.1, f.1.out.2} := fun ht =>
    hc.2 (inA' f _ ht) (inB e _ (by rw [ht]; simp) (out1_mem _))
  have n4 : t.1 ≠ {e.1.out.2, f.1.out.1, f.1.out.2} := fun ht =>
    hc.2 (inA' f _ ht) (inB e _ (by rw [ht]; simp) (out2_mem _))
  rw [gadget_apply]
  simp [triInd, n1, n2, n3, n4]

/-- The indicator of `Ain G t`. -/
def indA (G : SimpleGraph V) (t : Tri G) (e : Edge G) : ℝ := if e ∈ Ain G t then 1 else 0

/-- The indicator of `Bmeet G t`. -/
def indB (G : SimpleGraph V) (t : Tri G) (e : Edge G) : ℝ := if e ∈ Bmeet G t then 1 else 0

lemma indA_nonneg (G : SimpleGraph V) (t : Tri G) (e : Edge G) : 0 ≤ indA G t e := by
  unfold indA; split_ifs <;> norm_num

lemma indB_nonneg (G : SimpleGraph V) (t : Tri G) (e : Edge G) : 0 ≤ indB G t e := by
  unfold indB; split_ifs <;> norm_num

lemma sum_indA (G : SimpleGraph V) (t : Tri G) : ∑ e, indA G t e = (Ain G t).card := by
  unfold indA
  rw [Finset.sum_boole, Finset.filter_mem_eq_inter, Finset.univ_inter]

lemma sum_indB (G : SimpleGraph V) (t : Tri G) : ∑ e, indB G t e = (Bmeet G t).card := by
  unfold indB
  rw [Finset.sum_boole, Finset.filter_mem_eq_inter, Finset.univ_inter]

namespace Hyp

variable {G : SimpleGraph V} {cls : V → Fin k} {d : Fin k → Fin k → ℝ} {A₀ : Fin k}
  {η δ₀ d₀ : ℝ} (H : Hyp G cls d A₀ η δ₀ d₀)
include H

lemma gadget_term_le (t : Tri G) (e f : Edge G) :
    ν G cls A₀ e f * |gadget G e f t| ≤
      1 / (pconst δ₀ d₀ * (Fintype.card V : ℝ) ^ 2) *
        (2 * (indA G t e * indB G t f + indA G t f * indB G t e)) := by
  have hq0 : 0 ≤ 1 / (pconst δ₀ d₀ * (Fintype.card V : ℝ) ^ 2) :=
    (one_div_pos.mpr (mul_pos H.p_pos (pow_pos H.m_pos 2))).le
  have h1 := mul_nonneg (indA_nonneg G t e) (indB_nonneg G t f)
  have h2 := mul_nonneg (indA_nonneg G t f) (indB_nonneg G t e)
  by_cases hg : gadget G e f t = 0
  · rw [hg, abs_zero, mul_zero]
    exact mul_nonneg hq0 (mul_nonneg (by norm_num) (add_nonneg h1 h2))
  · have hsum : 1 ≤ indA G t e * indB G t f + indA G t f * indB G t e := by
      rcases gadget_support hg with ⟨ha, hb⟩ | ⟨ha, hb⟩
      · have e1 : indA G t e = 1 := if_pos ha
        have e2 : indB G t f = 1 := if_pos hb
        rw [e1, e2]; linarith
      · have e1 : indA G t f = 1 := if_pos ha
        have e2 : indB G t e = 1 := if_pos hb
        rw [e1, e2]; linarith
    calc ν G cls A₀ e f * |gadget G e f t|
        ≤ 1 / (pconst δ₀ d₀ * (Fintype.card V : ℝ) ^ 2) * 2 :=
          mul_le_mul (H.ν_le e f) (abs_gadget_le G e f t) (abs_nonneg _) hq0
      _ ≤ _ := mul_le_mul_of_nonneg_left (by linarith) hq0

/-- `‖Φ₁‖ ≤ 108/(p m)`. -/
lemma norm_Phiop_le :
    ‖Phiop G cls A₀‖ ≤ 108 / pconst δ₀ d₀ / Fintype.card V := by
  have hp := H.p_pos
  have hm := H.m_pos
  refine E3Assembly.opNorm_le_of_rowSum (Phiop G cls A₀) (MPhi G cls A₀) (fun r t => ?_)
    (by positivity) (fun t => ?_)
  · simp [Phiop, Matrix.mulVec, dotProduct]
  set q : ℝ := 1 / (pconst δ₀ d₀ * (Fintype.card V : ℝ) ^ 2) with hq
  have hAc : ((Ain G t).card : ℝ) ≤ 9 := by
    have h := card_inside_le G t.1
    rw [t.2.1] at h
    have h9 : ((3 : ℕ) : ℝ) ^ 2 = 9 := by norm_num
    rw [h9] at h
    exact h
  have hBc : ((Bmeet G t).card : ℝ) ≤ 3 * Fintype.card V := by
    have := card_meet_le G t.1
    rw [t.2.1] at this
    exact_mod_cast this
  have hs1 : ∑ e, ∑ f, indA G t e * indB G t f =
      (∑ e, indA G t e) * (∑ f, indB G t f) := (Finset.sum_mul_sum _ _ _ _).symm
  have hs2 : ∑ e, ∑ f, indA G t f * indB G t e =
      (∑ e, indA G t e) * (∑ f, indB G t f) := by
    rw [Finset.sum_comm]; exact (Finset.sum_mul_sum _ _ _ _).symm
  have hrow : ∀ e, |MPhi G cls A₀ t e| ≤ ∑ f, ν G cls A₀ e f * |gadget G e f t| := by
    intro e
    refine (abs_sum_le_sum_abs _ _).trans (le_of_eq (Finset.sum_congr rfl fun f _ => ?_))
    rw [abs_mul, abs_of_nonneg (H.ν_nonneg e f)]
  calc ∑ e, |MPhi G cls A₀ t e|
      ≤ ∑ e, ∑ f, q * (2 * (indA G t e * indB G t f + indA G t f * indB G t e)) :=
        Finset.sum_le_sum fun e _ => (hrow e).trans
          (Finset.sum_le_sum fun f _ => H.gadget_term_le t e f)
    _ = 2 * q * (∑ e, ∑ f, indA G t e * indB G t f + ∑ e, ∑ f, indA G t f * indB G t e) := by
        rw [mul_add, Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
        refine Finset.sum_congr rfl fun e _ => ?_
        rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
        exact Finset.sum_congr rfl fun f _ => by ring
    _ = 2 * q * (2 * (((Ain G t).card : ℝ) * (Bmeet G t).card)) := by
        rw [hs1, hs2, sum_indA, sum_indB]; ring
    _ ≤ 2 * q * (2 * (9 * (3 * Fintype.card V))) := by
        have hq0 : 0 ≤ q := by positivity
        have : ((Ain G t).card : ℝ) * (Bmeet G t).card ≤ 9 * (3 * Fintype.card V) :=
          mul_le_mul hAc hBc (by positivity) (by norm_num)
        gcongr
    _ = 108 / pconst δ₀ d₀ / Fintype.card V := by
        rw [hq]; field_simp; ring

end Hyp

end ColourStats.Host519
