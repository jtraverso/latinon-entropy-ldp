/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Typed1F

/-!
# The typed bound for 1-factorizations: assembly and aggregation

* `class_sum_le`, `edge_bound`: the class part and the bound for one edge;
* `raw_bound`: summed over the labellings, with weights `1/L`;
* `agg_bound`: aggregated over the edge classes `π` with constant statistics `t(π, Γ)`:

  `log |S| ≤ Σ_π Σ_Γ t(π, Γ) (log(|E_π| / t(π, Γ)) + Ψ₁(h_Γ − 1))`,
  with `Ψ₁(c) = Σ_r (1/L) log(1 + c u_r²)`.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.Typed1F

open ColourStats ColourStats.Statements ColourStats.TypedChain ColourStats.TypedSTS

open Classical

variable {n L k ℓ : ℕ} {S : Finset (KEdge n → Fin (n - 1))}

/-- The systems whose colour at `e` is in the class `Γ`. -/
def Scl (S : Finset (KEdge n → Fin (n - 1))) (col : Fin (n - 1) → Fin ℓ) (e : KEdge n)
    (Γ : Fin ℓ) : Finset (KEdge n → Fin (n - 1)) :=
  S.filter fun f => col (f e) = Γ

/-- The pairs `(lam, f)` with `lam e = r`. -/
def Uset (S : Finset (KEdge n → Fin (n - 1))) (e : KEdge n) (r : Fin L) :
    Finset ((KEdge n → Fin L) × (KEdge n → Fin (n - 1))) :=
  (univ ×ˢ S).filter fun y => y.1 e = r

lemma sum_Uset (e : KEdge n) (r : Fin L) (hL : 0 < L) (G : (KEdge n → Fin (n - 1)) → ℝ) :
    ∑ y ∈ Uset S e r, G y.2 = Bv n L * ∑ f ∈ S, G f := by
  unfold Uset
  rw [Finset.sum_filter, Finset.sum_product_right, Finset.mul_sum]
  refine Finset.sum_congr rfl fun f _ => ?_
  dsimp only
  rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul, box1_eq e r, card_box1 e r hL]

/-- The block map of the coarser past at `e`. -/
noncomputable def bmap (S : Finset (KEdge n → Fin (n - 1))) (e : KEdge n)
    (y : (KEdge n → Fin L) × (KEdge n → Fin (n - 1))) :
    (KEdge n → Fin L) × Finset (KEdge n → Fin (n - 1)) :=
  (y.1, before S univ (key2 y.1) coord e y.2)

lemma Uset_block {e : KEdge n} {r : Fin L} {y : (KEdge n → Fin L) × (KEdge n → Fin (n - 1))}
    (hy : y ∈ Uset S e r) :
    ((Uset S e r).filter fun z => bmap S e z = bmap S e y) =
      (before S univ (key2 y.1) coord e y.2).image (fun f' => (y.1, f')) := by
  obtain ⟨hyS, hyr⟩ : y.2 ∈ S ∧ y.1 e = r := by
    simp only [Uset, Finset.mem_filter, Finset.mem_product, Finset.mem_univ, true_and] at hy
    exact hy
  ext ⟨lam', f'⟩
  simp only [Finset.mem_filter, Finset.mem_image, Uset, Finset.mem_product, Finset.mem_univ,
    true_and, bmap, Prod.mk.injEq]
  constructor
  · rintro ⟨⟨hf'S, -⟩, rfl, hbe⟩
    refine ⟨f', ?_, rfl, rfl⟩
    rw [← hbe]
    exact mem_before_self hf'S
  · rintro ⟨f'', hf'', rfl, rfl⟩
    exact ⟨⟨(mem_before.mp hf'').1, hyr⟩, rfl, before_eq hf''⟩

lemma Uset_block_class (col : Fin (n - 1) → Fin ℓ) {e : KEdge n} {r : Fin L}
    {y : (KEdge n → Fin L) × (KEdge n → Fin (n - 1))} (hy : y ∈ Uset S e r) :
    ((Uset S e r).filter fun z => bmap S e z = bmap S e y ∧ col (z.2 e) = col (y.2 e)) =
      (sameClass S univ (key2 y.1) coord col e y.2).image (fun f' => (y.1, f')) := by
  rw [← Finset.filter_filter, Uset_block hy]
  ext ⟨lam', f'⟩
  simp only [Finset.mem_filter, Finset.mem_image, Prod.mk.injEq]
  constructor
  · rintro ⟨⟨f'', hf'', rfl, rfl⟩, hcl⟩
    exact ⟨f'', mem_sameClass.mpr ⟨hf'', hcl⟩, rfl, rfl⟩
  · rintro ⟨f'', hf'', rfl, rfl⟩
    obtain ⟨hb, hcl⟩ := mem_sameClass.mp hf''
    exact ⟨⟨f'', hb, rfl, rfl⟩, hcl⟩

/-- **The class part on `U_r`.** -/
theorem class_sum_le (col : Fin (n - 1) → Fin ℓ) (e : KEdge n) (r : Fin L) (hL : 0 < L) :
    ∑ y ∈ Uset S e r, (Real.log (before S univ (key2 y.1) coord e y.2).card -
        Real.log (sameClass S univ (key2 y.1) coord col e y.2).card) ≤
      Bv n L * ∑ f ∈ S, (Real.log S.card - Real.log (Scl S col e (col (f e))).card) := by
  have h := cond_le (Uset S e r) (bmap S e) (fun z => col (z.2 e))
  have hinj : ∀ lam : KEdge n → Fin L, Function.Injective
      (fun f' : KEdge n → Fin (n - 1) => (lam, f')) := fun lam _ _ h => (Prod.mk.inj h).2
  have hL1 : ∀ y ∈ Uset S e r, Real.log ((Uset S e r).filter
      fun z => bmap S e z = bmap S e y).card -
      Real.log ((Uset S e r).filter fun z => bmap S e z = bmap S e y ∧
        col (z.2 e) = col (y.2 e)).card =
      Real.log (before S univ (key2 y.1) coord e y.2).card -
        Real.log (sameClass S univ (key2 y.1) coord col e y.2).card := by
    intro y hy
    rw [Uset_block hy, Uset_block_class col hy,
      Finset.card_image_of_injective _ (hinj y.1), Finset.card_image_of_injective _ (hinj y.1)]
  have hBv : 0 < Bv n L := by
    unfold Bv
    have : (0 : ℝ) < L := by exact_mod_cast hL
    positivity
  have hcard : ((Uset S e r).card : ℝ) = Bv n L * S.card := by
    have := sum_Uset (S := S) e r hL (fun _ => (1 : ℝ))
    simpa using this
  have hcardc : ∀ Γ, (((Uset S e r).filter fun z => col (z.2 e) = Γ).card : ℝ) =
      Bv n L * (Scl S col e Γ).card := by
    intro Γ
    have h' := sum_Uset (S := S) e r hL (fun f => if col (f e) = Γ then (1 : ℝ) else 0)
    rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul, mul_one, Finset.sum_boole] at h'
    simp only [Scl]
    convert h' using 2
  have hR1 : ∀ y ∈ Uset S e r, Real.log (Uset S e r).card -
      Real.log ((Uset S e r).filter fun z => col (z.2 e) = col (y.2 e)).card =
      Real.log S.card - Real.log (Scl S col e (col (y.2 e))).card := by
    intro y hy
    have hyS : y.2 ∈ S := by
      simp only [Uset, Finset.mem_filter, Finset.mem_product] at hy
      exact hy.1.2
    have hS0 : (0 : ℝ) < S.card := by exact_mod_cast Finset.card_pos.mpr ⟨_, hyS⟩
    have hmem : y.2 ∈ Scl S col e (col (y.2 e)) := Finset.mem_filter.mpr ⟨hyS, rfl⟩
    have hc0 : (0 : ℝ) < (Scl S col e (col (y.2 e))).card := by
      exact_mod_cast Finset.card_pos.mpr ⟨_, hmem⟩
    rw [hcard, hcardc, Real.log_mul hBv.ne' hS0.ne', Real.log_mul hBv.ne' hc0.ne']
    ring
  rw [Finset.sum_congr rfl hL1, Finset.sum_congr rfl hR1] at h
  refine h.trans (le_of_eq ?_)
  exact sum_Uset e r hL (fun f => Real.log S.card - Real.log (Scl S col e (col (f e))).card)

/-- **The bound for one edge.** -/
theorem edge_bound (col : Fin (n - 1) → Fin ℓ) (hS : ∀ f ∈ S, IsOneFact f) (e : KEdge n)
    (hL : 0 < L) :
    ∑ lam : KEdge n → Fin L, ∑ f ∈ S,
        ((Real.log (before S univ (key2 lam) coord e f).card -
          Real.log (sameClass S univ (key2 lam) coord col e f).card) +
        Real.log ((sameClass S univ (key2 lam) coord col e f).image (coord e)).card) ≤
      ∑ r : Fin L, Bv n L * ∑ f ∈ S,
        ((Real.log S.card - Real.log (Scl S col e (col (f e))).card) +
          Real.log (1 + ((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2)) := by
  simp only [Finset.sum_add_distrib, mul_add]
  have hP : ∑ lam : KEdge n → Fin L, ∑ f ∈ S, Real.log
      ((sameClass S univ (key2 lam) coord col e f).image (coord e)).card ≤
      ∑ r : Fin L, Bv n L * ∑ f ∈ S,
        Real.log (1 + ((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2) := by
    rw [Finset.sum_comm]
    simp only [Finset.mul_sum]
    rw [Finset.sum_comm (s := (univ : Finset (Fin L)))]
    exact Finset.sum_le_sum fun f hf => point_sum_le col hS hf e hL
  have hC : ∑ lam : KEdge n → Fin L, ∑ f ∈ S,
      (Real.log (before S univ (key2 lam) coord e f).card -
        Real.log (sameClass S univ (key2 lam) coord col e f).card) ≤
      ∑ r : Fin L, Bv n L * ∑ f ∈ S,
        (Real.log S.card - Real.log (Scl S col e (col (f e))).card) := by
    set A : (KEdge n → Fin L) × (KEdge n → Fin (n - 1)) → ℝ := fun y =>
      Real.log (before S univ (key2 y.1) coord e y.2).card -
        Real.log (sameClass S univ (key2 y.1) coord col e y.2).card
    have h1 : ∑ lam : KEdge n → Fin L, ∑ f ∈ S,
        (Real.log (before S univ (key2 lam) coord e f).card -
          Real.log (sameClass S univ (key2 lam) coord col e f).card) =
        ∑ y ∈ univ ×ˢ S, A y := (Finset.sum_product (s := univ) (t := S) (f := A)).symm
    rw [h1, ← Finset.sum_fiberwise (s := univ ×ˢ S)
      (g := fun y : (KEdge n → Fin L) × (KEdge n → Fin (n - 1)) => y.1 e)]
    exact Finset.sum_le_sum fun r _ => class_sum_le col e r hL
  linarith

/-- **The chain bound summed over labellings.** -/
theorem raw_bound (col : Fin (n - 1) → Fin ℓ) (hS : ∀ f ∈ S, IsOneFact f) (hL : 0 < L) :
    (S.card : ℝ) * Real.log S.card ≤
      ∑ e : KEdge n, ∑ r : Fin L, (1 / (L : ℝ)) * ∑ f ∈ S,
        ((Real.log S.card - Real.log (Scl S col e (col (f e))).card) +
          Real.log (1 + ((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2)) := by
  have hLpos : (0 : ℝ) < L := by exact_mod_cast hL
  have hN : (0 : ℝ) < (L : ℝ) ^ Fintype.card (KEdge n) := by positivity
  have hchain : ∀ lam : KEdge n → Fin L, (S.card : ℝ) * Real.log S.card ≤
      ∑ e : KEdge n, ∑ f ∈ S,
        ((Real.log (before S univ (key2 lam) coord e f).card -
          Real.log (sameClass S univ (key2 lam) coord col e f).card) +
        Real.log ((sameClass S univ (key2 lam) coord col e f).image (coord e)).card) := by
    intro lam
    refine chain_typed (key1 lam) (key2 lam) coord col S univ ((key1_injective lam).injOn)
      (fun f _ f' _ h => funext fun e => h e (Finset.mem_univ e))
      (fun s _ t _ h => key1_lt_of_key2_lt lam h)
  have hsum := Finset.sum_le_sum (s := (univ : Finset (KEdge n → Fin L))) fun lam _ => hchain lam
  rw [Finset.sum_const, Finset.card_univ, Fintype.card_fun, Fintype.card_fin, nsmul_eq_mul,
    Finset.sum_comm] at hsum
  have hedges := Finset.sum_le_sum (s := (univ : Finset (KEdge n))) fun e _ =>
    edge_bound (L := L) col hS e hL
  have htot := hsum.trans hedges
  have hBv : Bv n L = (L : ℝ) ^ Fintype.card (KEdge n) * (1 / L) := by
    unfold Bv NE
    ring
  have hfac : ∑ e : KEdge n, ∑ r : Fin L, Bv n L * ∑ f ∈ S,
      ((Real.log S.card - Real.log (Scl S col e (col (f e))).card) +
        Real.log (1 + ((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2)) =
      (L : ℝ) ^ Fintype.card (KEdge n) * ∑ e : KEdge n, ∑ r : Fin L, (1 / (L : ℝ)) *
        ∑ f ∈ S, ((Real.log S.card - Real.log (Scl S col e (col (f e))).card) +
          Real.log (1 + ((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2)) := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun e _ => ?_
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun r _ => ?_
    rw [hBv]
    ring
  rw [hfac] at htot
  push_cast at htot
  exact le_of_mul_le_mul_left htot hN

end ColourStats.Typed1F
