/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Typical

/-!
# The weighting `W_1` of Lemma 5.19

Fix a target class pair `π₀ = {A, B}`. The *ideal load* of a type weighting `w` on a pair
of class `π` is `Σ_Z w(Z + π) |Z| Π_{X ∈ π} d(X, Z)` (`idealLoad`); by
`Typical.load_estimate` it is the load of `w` up to a relative error `η`. We solve
`ideal load = 1_{π₀}` explicitly with two types (`weight`):
`w = α 1_{AAB} + [A ≠ B] β 1_{AAA}` with `α = 1/(|A| d(A,A) d(B,A))` and
`β = −α |B| d(A,B)² / (|A| d(A,A)²)`.

Main result (`idealLoad_weight`): the ideal load of this weighting is exactly `1_{π₀}` on
every class pair.
-/

@[expose] public section

open Finset

namespace ColourStats.Weighting

open Typical

variable {V : Type*} [Fintype V] [DecidableEq V] {k : ℕ}

/-- `Σ_Z [Z + π = T] g(Z) = Σ_{Z ∈ T} [T − Z = π] g(Z)`. -/
lemma sum_cons_eq (π T : Multiset (Fin k)) (g : Fin k → ℝ) :
    ∑ Z, (if Z ::ₘ π = T then g Z else 0) =
      ∑ Z ∈ T.toFinset, (if T.erase Z = π then g Z else 0) := by
  rw [← Finset.sum_subset (Finset.subset_univ T.toFinset) (fun Z _ hZ => ?_)]
  · refine Finset.sum_congr rfl fun Z hZ => ?_
    have hZ' : Z ∈ T := Multiset.mem_toFinset.mp hZ
    have : Z ::ₘ π = T ↔ T.erase Z = π :=
      ⟨by rintro rfl; exact Multiset.erase_cons_head _ _,
        by rintro rfl; exact Multiset.cons_erase hZ'⟩
    simp only [this]
  · rw [if_neg]
    intro h
    exact hZ (Multiset.mem_toFinset.mpr (by rw [← h]; simp))

/-- The size `|Z|` of a class, as a real number. -/
noncomputable def csz (cls : V → Fin k) (Z : Fin k) : ℝ := (classSet cls Z).card

/-- The ideal load `Σ_Z w(Z + π) |Z| Π_{X ∈ π} d(X, Z)` on a pair of class `π`. -/
noncomputable def idealLoad (cls : V → Fin k) (d : Fin k → Fin k → ℝ)
    (w : Multiset (Fin k) → ℝ) (π : Multiset (Fin k)) : ℝ :=
  ∑ Z, w (Z ::ₘ π) * (csz cls Z * (π.map fun X => d X Z).prod)

/-- `α = 1/(|A| d(A,A) d(B,A))`. -/
noncomputable def alpha (cls : V → Fin k) (d : Fin k → Fin k → ℝ) (A B : Fin k) : ℝ :=
  1 / (csz cls A * d A A * d B A)

/-- `β = −α |B| d(A,B)² / (|A| d(A,A)²)`. -/
noncomputable def beta (cls : V → Fin k) (d : Fin k → Fin k → ℝ) (A B : Fin k) : ℝ :=
  -(alpha cls d A B) * csz cls B * d A B ^ 2 / (csz cls A * d A A ^ 2)

/-- The weighting `α 1_{AAB} + [A ≠ B] β 1_{AAA}`. -/
noncomputable def weight (cls : V → Fin k) (d : Fin k → Fin k → ℝ) (A B : Fin k)
    (τ : Multiset (Fin k)) : ℝ :=
  (if τ = {A, A, B} then alpha cls d A B else 0) +
    (if τ = {A, A, A} then (if A ≠ B then beta cls d A B else 0) else 0)

omit [DecidableEq V] in
/-- **The weighting solves the ideal load equations.** -/
theorem idealLoad_weight (cls : V → Fin k) (d : Fin k → Fin k → ℝ) {A B : Fin k}
    (hA : csz cls A ≠ 0) (hdAA : d A A ≠ 0) (hdBA : d B A ≠ 0) (π : Multiset (Fin k)) :
    idealLoad cls d (weight cls d A B) π = if π = {A, B} then 1 else 0 := by
  set Q : Fin k → ℝ := fun Z => csz cls Z * (π.map fun X => d X Z).prod with hQ
  have hsplit : idealLoad cls d (weight cls d A B) π =
      ∑ Z, (if Z ::ₘ π = {A, A, B} then alpha cls d A B * Q Z else 0) +
        ∑ Z, (if Z ::ₘ π = {A, A, A} then (if A ≠ B then beta cls d A B else 0) * Q Z
          else 0) := by
    unfold idealLoad weight
    rw [← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun Z _ => ?_
    simp only [add_mul, ite_mul, zero_mul, Q]
  rw [hsplit, sum_cons_eq, sum_cons_eq]
  by_cases hAB : A = B
  · subst hAB
    simp only [ne_eq, not_true_eq_false, if_false, zero_mul, ite_self, Finset.sum_const_zero,
      add_zero]
    have hfin : (({A, A, A} : Multiset (Fin k))).toFinset = {A} := by
      ext Z; simp
    rw [hfin, Finset.sum_singleton]
    have herase : ({A, A, A} : Multiset (Fin k)).erase A = {A, A} := by
      simp [Multiset.insert_eq_cons]
    rw [herase]
    by_cases hπ : π = {A, A}
    · subst hπ
      simp only [if_true, Q, alpha]
      simp only [Multiset.insert_eq_cons, Multiset.map_cons, Multiset.map_singleton,
        Multiset.prod_cons, Multiset.prod_singleton]
      field_simp
    · rw [if_neg (Ne.symm hπ), if_neg hπ]
  · have hfin1 : (({A, A, B} : Multiset (Fin k))).toFinset = {A, B} := by
      ext Z; simp
    have hfin2 : (({A, A, A} : Multiset (Fin k))).toFinset = {A} := by
      ext Z; simp
    have he1 : ({A, A, B} : Multiset (Fin k)).erase A = {A, B} := by
      simp [Multiset.insert_eq_cons]
    have he2 : ({A, A, B} : Multiset (Fin k)).erase B = {A, A} := by
      show (A ::ₘ A ::ₘ {B}).erase B = A ::ₘ {A}
      rw [Multiset.erase_cons_tail _ hAB, Multiset.erase_cons_tail _ hAB,
        Multiset.erase_singleton]
      rfl
    have he3 : ({A, A, A} : Multiset (Fin k)).erase A = {A, A} := by
      simp [Multiset.insert_eq_cons]
    have hne : ({A, B} : Multiset (Fin k)) ≠ {A, A} := by
      simp [Multiset.insert_eq_cons, Multiset.cons_inj_right, Ne.symm hAB]
    rw [hfin1, hfin2, Finset.sum_pair hAB, Finset.sum_singleton, he1, he2, he3,
      if_pos hAB]
    by_cases h1 : π = {A, B}
    · subst h1
      rw [if_pos rfl, if_neg hne.symm, if_neg hne.symm, if_pos rfl]
      simp only [Q, alpha]
      simp only [Multiset.insert_eq_cons, Multiset.map_cons, Multiset.map_singleton,
        Multiset.prod_cons, Multiset.prod_singleton]
      field_simp
      ring
    · by_cases h2 : π = {A, A}
      · subst h2
        rw [if_neg (Ne.symm h1), if_pos rfl, if_pos rfl, if_neg h1]
        simp only [Q, beta, alpha]
        simp only [Multiset.insert_eq_cons, Multiset.map_cons, Multiset.map_singleton,
          Multiset.prod_cons, Multiset.prod_singleton]
        field_simp
        ring
      · rw [if_neg (Ne.symm h1), if_neg (Ne.symm h2), if_neg (Ne.symm h2), if_neg h1]
        ring

end ColourStats.Weighting
