/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedSTS

/-!
# The revealing process on a graph (Theorem 1.9, upper half)

A triangle decomposition of a graph `G` on `Fin n` is encoded by its quasigroup `T`
(`IsSQG G T`): for an edge `ab`, `T a b` is the third point of the triangle through `ab`; for
a non-edge, `T a b = a`. The coordinates are the edges of `G` (`pairsG G`).

This file adapts `ColourStats.TypedSTS` to that setting: every pair of a block is an edge, and
the revealing lemma (`good_of_memG`) gives the same six pairs. The candidates `z` must be
common neighbours of `a` and `b`.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.TypedG

open ColourStats.TypedChain ColourStats.TypedSTS

open Classical

variable {n L : ℕ} {G : SimpleGraph (Fin n)}

/-- `T` encodes a triangle decomposition of `G`. -/
def IsSQG (G : SimpleGraph (Fin n)) (T : Fin n → Fin n → Fin n) : Prop :=
  (∀ a b, G.Adj a b → T a b ≠ a ∧ T a b ≠ b ∧ T b a = T a b ∧ T a (T a b) = b ∧
    G.Adj a (T a b)) ∧ ∀ a b, ¬ G.Adj a b → T a b = a

section SQG

variable {T : Fin n → Fin n → Fin n} (hT : IsSQG G T)
include hT

lemma IsSQG.ne_left {a b : Fin n} (h : G.Adj a b) : T a b ≠ a := (hT.1 a b h).1
lemma IsSQG.ne_right {a b : Fin n} (h : G.Adj a b) : T a b ≠ b := (hT.1 a b h).2.1
lemma IsSQG.comm {a b : Fin n} (h : G.Adj a b) : T b a = T a b := (hT.1 a b h).2.2.1
lemma IsSQG.invol {a b : Fin n} (h : G.Adj a b) : T a (T a b) = b := (hT.1 a b h).2.2.2.1
lemma IsSQG.adj_left {a b : Fin n} (h : G.Adj a b) : G.Adj a (T a b) := (hT.1 a b h).2.2.2.2
lemma IsSQG.adj_right {a b : Fin n} (h : G.Adj a b) : G.Adj b (T a b) := by
  rw [← hT.comm h]; exact hT.adj_left h.symm
lemma IsSQG.third {a b : Fin n} (h : G.Adj a b) : T b (T a b) = a := by
  rw [← hT.comm h, hT.invol h.symm]

end SQG

/-- The edges of `G`, as pairs `(a, b)` with `a < b`. -/
noncomputable def pairsG (G : SimpleGraph (Fin n)) : Finset (Pair n) :=
  (pairs n).filter fun p => G.Adj p.1 p.2

lemma sp_adj {u v : Fin n} (h : G.Adj u v) : G.Adj (sp u v).1 (sp u v).2 := by
  unfold sp
  rcases le_total u v with h' | h'
  · rw [min_eq_left h', max_eq_right h']; exact h
  · rw [min_eq_right h', max_eq_left h']; exact h.symm

lemma sp_memG {u v : Fin n} (h : G.Adj u v) : sp u v ∈ pairsG G :=
  Finset.mem_filter.mpr ⟨sp_mem h.ne, sp_adj h⟩

lemma coord_spG {T : Fin n → Fin n → Fin n} (hT : IsSQG G T) {u v : Fin n} (h : G.Adj u v) :
    coord (sp u v) T = T u v := by
  unfold coord sp
  rcases le_total u v with h' | h'
  · rw [min_eq_left h', max_eq_right h']
  · rw [min_eq_right h', max_eq_left h', hT.comm h]

section Blocks

variable {T : Fin n → Fin n → Fin n}

lemma blk_commG (hT : IsSQG G T) {u v : Fin n} (h : G.Adj u v) : blk T v u = blk T u v := by
  unfold blk
  rw [hT.comm h]
  ext x
  simp only [Finset.mem_insert, Finset.mem_singleton]
  tauto

lemma blk_leftG (hT : IsSQG G T) {u v : Fin n} (h : G.Adj u v) :
    blk T u (T u v) = blk T u v := by
  unfold blk
  rw [hT.invol h]
  ext x
  simp only [Finset.mem_insert, Finset.mem_singleton]
  tauto

lemma blk_rightG (hT : IsSQG G T) {u v : Fin n} (h : G.Adj u v) :
    blk T v (T u v) = blk T u v := by
  unfold blk
  rw [hT.third h]
  ext x
  simp only [Finset.mem_insert, Finset.mem_singleton]
  tauto

lemma blk_of_spG (hT : IsSQG G T) {u v u' v' : Fin n} (h : G.Adj u v)
    (he : sp u v = sp u' v') : blk T u v = blk T u' v' := by
  rcases sp_inj h.ne he with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
  · rfl
  · exact (blk_commG hT h).symm

lemma card_blockPairsG (hT : IsSQG G T) {u v : Fin n} (h : G.Adj u v) :
    (blockPairs T u v).card = 3 := by
  have h1 : T u v ≠ u := hT.ne_left h
  have h2 : T u v ≠ v := hT.ne_right h
  unfold blockPairs
  refine Finset.card_eq_three.mpr ⟨_, _, _, ?_, ?_, ?_, rfl⟩
  · intro he
    rcases sp_inj h.ne he with ⟨-, e⟩ | ⟨e, -⟩
    · exact h2 e.symm
    · exact h1 e.symm
  · intro he
    rcases sp_inj h.ne he with ⟨e, -⟩ | ⟨e, -⟩
    · exact h.ne e
    · exact h1 e.symm
  · intro he
    rcases sp_inj (Ne.symm h1) he with ⟨e, -⟩ | ⟨e, -⟩
    · exact h.ne e
    · exact h1 e.symm

lemma mem_blockPairsG (hT : IsSQG G T) {u v : Fin n} (h : G.Adj u v) {q : Pair n}
    (hq : q ∈ blockPairs T u v) :
    ∃ x y, G.Adj x y ∧ q = sp x y ∧ blk T x y = blk T u v := by
  simp only [blockPairs, Finset.mem_insert, Finset.mem_singleton] at hq
  rcases hq with rfl | rfl | rfl
  · exact ⟨u, v, h, rfl, rfl⟩
  · exact ⟨u, T u v, hT.adj_left h, rfl, blk_leftG hT h⟩
  · exact ⟨v, T u v, hT.adj_right h, rfl, blk_rightG hT h⟩

lemma disjoint_blockPairsG (hT : IsSQG G T) {u v u' v' : Fin n} (h : G.Adj u v)
    (h' : G.Adj u' v') (hne : blk T u v ≠ blk T u' v') :
    Disjoint (blockPairs T u v) (blockPairs T u' v') := by
  rw [Finset.disjoint_left]
  intro q hq hq'
  obtain ⟨x, y, hxy, rfl, hb⟩ := mem_blockPairsG hT h hq
  obtain ⟨x', y', -, he, hb'⟩ := mem_blockPairsG hT h' hq'
  exact hne (hb.symm.trans ((blk_of_spG hT hxy he).trans hb'))

lemma blockPairs_subsetG (hT : IsSQG G T) {u v : Fin n} (h : G.Adj u v) :
    blockPairs T u v ⊆ pairsG G := by
  intro q hq
  obtain ⟨x, y, hxy, rfl, -⟩ := mem_blockPairsG hT h hq
  exact sp_memG hxy

end Blocks

/-! ### Agreement with the coarser past -/

variable {S : Finset (Fin n → Fin n → Fin n)}

lemma agree_of_memG (lam : Pair n → Fin L) (hS : ∀ T ∈ S, IsSQG G T) {p : Pair n}
    {T T' : Fin n → Fin n → Fin n} (hT : T ∈ S)
    (hT' : T' ∈ before S (pairsG G) (key2 lam) coord p T)
    {u v : Fin n} (huv : G.Adj u v) (hlt : lam (sp u v) < lam p) : T' u v = T u v := by
  obtain ⟨hT'S, h⟩ := mem_before.mp hT'
  have := h (sp u v) (sp_memG huv) hlt
  rwa [coord_spG (hS T' hT'S) huv, coord_spG (hS T hT) huv] at this

lemma det_of_not_FG (lam : Pair n → Fin L) (hS : ∀ T ∈ S, IsSQG G T) {a b : Fin n}
    (hab : G.Adj a b) {T T' : Fin n → Fin n → Fin n} (hT : T ∈ S)
    (hT' : T' ∈ before S (pairsG G) (key2 lam) coord (a, b) T)
    (hF : lam (sp a (T a b)) < lam (a, b) ∨ lam (sp b (T a b)) < lam (a, b)) :
    T' a b = T a b := by
  have hTq := hS T hT
  have hT'q := hS T' (mem_before.mp hT').1
  rcases hF with h | h
  · have hac : G.Adj a (T a b) := hTq.adj_left hab
    have e := agree_of_memG lam hS hT hT' hac h
    rw [hTq.invol hab] at e
    calc T' a b = T' a (T' a (T a b)) := by rw [e]
      _ = T a b := hT'q.invol hac
  · have hbc : G.Adj b (T a b) := hTq.adj_right hab
    have e := agree_of_memG lam hS hT hT' hbc h
    rw [hTq.third hab] at e
    calc T' a b = T' b a := (hT'q.comm hab).symm
      _ = T' b (T' b (T a b)) := by rw [e]
      _ = T a b := hT'q.invol hbc

lemma F_iffG (lam : Pair n → Fin L) (hS : ∀ T ∈ S, IsSQG G T) {a b : Fin n} (hab : G.Adj a b)
    {T T' : Fin n → Fin n → Fin n} (hT : T ∈ S)
    (hT' : T' ∈ before S (pairsG G) (key2 lam) coord (a, b) T) :
    Fm lam a b T' ↔ Fm lam a b T := by
  by_cases he : T' a b = T a b
  · unfold Fm; rw [he]
  · have hF : Fm lam a b T := by
      by_contra hF
      unfold Fm at hF
      rw [not_and_or, not_le, not_le] at hF
      exact he (det_of_not_FG lam hS hab hT hT' hF)
    have hTmem : T ∈ before S (pairsG G) (key2 lam) coord (a, b) T' := by
      rw [before_eq hT']
      exact mem_before_self hT
    have hF' : Fm lam a b T' := by
      by_contra hF'
      unfold Fm at hF'
      rw [not_and_or, not_le, not_le] at hF'
      exact he (det_of_not_FG lam hS hab (mem_before.mp hT').1 hTmem hF').symm
    exact ⟨fun _ => hF, fun _ => hF'⟩

/-- **The revealing lemma on `G`.** -/
lemma good_of_memG (lam : Pair n → Fin L) (hS : ∀ T ∈ S, IsSQG G T) {a b : Fin n}
    (hab : G.Adj a b) {T T' : Fin n → Fin n → Fin n} (hT : T ∈ S)
    (hT' : T' ∈ before S (pairsG G) (key2 lam) coord (a, b) T) (hz : T' a b ≠ T a b) :
    ∀ q ∈ blockPairs T a (T' a b) ∪ blockPairs T b (T' a b), lam (a, b) ≤ lam q := by
  have hTq := hS T hT
  have hT'q := hS T' (mem_before.mp hT').1
  set z := T' a b with hzdef
  have haz : G.Adj a z := hT'q.adj_left hab
  have hbz : G.Adj b z := hT'q.adj_right hab
  have h'az : T' a z = b := hT'q.invol hab
  have h'bz : T' b z = a := hT'q.third hab
  have agree : ∀ u v, G.Adj u v → lam (sp u v) < lam (a, b) → T' u v = T u v :=
    fun u v huv h => agree_of_memG lam hS hT hT' huv h
  have hTaz : T a z ≠ b := by
    intro h
    apply hz
    show z = T a b
    rw [← h, hTq.invol haz]
  have hTbz : T b z ≠ a := by
    intro h
    apply hz
    show z = T a b
    calc z = T b (T b z) := (hTq.invol hbz).symm
      _ = T b a := by rw [h]
      _ = T a b := hTq.comm hab
  intro q hq
  by_contra hlt
  rw [not_le] at hlt
  rcases Finset.mem_union.mp hq with hq | hq <;>
    simp only [blockPairs, Finset.mem_insert, Finset.mem_singleton] at hq
  · rcases hq with rfl | rfl | rfl
    · have e := agree a z haz hlt
      exact hTaz (e ▸ h'az)
    · have hw : G.Adj a (T a z) := hTq.adj_left haz
      have e := agree a (T a z) hw hlt
      rw [hTq.invol haz] at e
      have : T a z = b := by
        have h2 := congrArg (T' a) e
        rw [hT'q.invol hw] at h2
        rw [h2, h'az]
      exact hTaz this
    · have hw : G.Adj z (T a z) := hTq.adj_right haz
      have e := agree z (T a z) hw hlt
      rw [hTq.third haz] at e
      have : T a z = b := by
        have h2 := congrArg (T' z) e
        rw [hT'q.invol hw, hT'q.comm haz] at h2
        rw [h2, h'az]
      exact hTaz this
  · rcases hq with rfl | rfl | rfl
    · have e := agree b z hbz hlt
      exact hTbz (e ▸ h'bz)
    · have hw : G.Adj b (T b z) := hTq.adj_left hbz
      have e := agree b (T b z) hw hlt
      rw [hTq.invol hbz] at e
      have : T b z = a := by
        have h2 := congrArg (T' b) e
        rw [hT'q.invol hw] at h2
        rw [h2, h'bz]
      exact hTbz this
    · have hw : G.Adj z (T b z) := hTq.adj_right hbz
      have e := agree z (T b z) hw hlt
      rw [hTq.third hbz] at e
      have : T b z = a := by
        have h2 := congrArg (T' z) e
        rw [hT'q.invol hw, hT'q.comm hbz] at h2
        rw [h2, h'bz]
      exact hTbz this

lemma blocks_distinctG {T : Fin n → Fin n → Fin n} (hT : IsSQG G T) {a b z : Fin n}
    (hab : G.Adj a b) (haz : G.Adj a z) (hzb : z ≠ b) (hzc : z ≠ T a b) :
    blk T a z ≠ blk T a b ∧ blk T b z ≠ blk T a b ∧ blk T a z ≠ blk T b z := by
  have hza : z ≠ a := haz.ne.symm
  have hz1 : z ∈ blk T a z := by simp [blk]
  have hz2 : z ∈ blk T b z := by simp [blk]
  have hz0 : z ∉ blk T a b := by simp [blk, hza, hzb, hzc]
  refine ⟨fun h => hz0 (h ▸ hz1), fun h => hz0 (h ▸ hz2), fun h => ?_⟩
  have hb : b ∈ blk T a z := h ▸ (by simp [blk] : b ∈ blk T b z)
  simp only [blk, Finset.mem_insert, Finset.mem_singleton] at hb
  rcases hb with hb | hb | hb
  · exact hab.ne hb.symm
  · exact hzb hb.symm
  · apply hzc
    rw [hb, hT.invol haz]

end ColourStats.TypedG
