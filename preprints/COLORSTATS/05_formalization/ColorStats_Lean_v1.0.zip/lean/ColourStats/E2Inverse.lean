/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import Mathlib

/-!
# An explicit inverse on balanced vectors of `K_m ∨ C_h` (Lemma 5.16)

The host `K_m ∨ C_h` has the pairs `uv` of `m` vertices and the pairs `uc` of a vertex and
one of `h` colours; its triangles are `{u, v, c}` with `u ≠ v`. A vector `x` on its pairs is
given by `xV : Fin m → Fin m → ℝ` (zero diagonal) and `xC : Fin m → Fin h → ℝ`. It is
*balanced* if `X_V(u) = Σ_v x(uv)` equals `X_C(u) = Σ_c x(uc)` for every `u`. Put

    W = Σ_{uv} x(uv) = (Σ_u X_V(u))/2,   Z(c) = Σ_u x(uc),   χ(c) = (Z(c) − 2W/h)/(2m − 2),
    y(uv) = x(uv)/h,   y(uc) = (x(uc) − X_V(u)/h − χ(c))/(m − 2),
    (Φx)(u, v, c) = y(uv) + y(uc) + y(vc).

Main results, for `m ≥ 3`, `h ≥ 1` and balanced `x`:
* `pair_load`: `Σ_c (Φx)(u, v, c) = x(uv)`;
* `colour_load`: `Σ_{v ≠ u} (Φx)(u, v, c) = x(uc)`;
* `inverse_bound`: `|(Φx)(u, v, c)| ≤ 13 (1 + m/h) ‖x‖_∞ / min(m, h)`, so the paper's
  constant `K` can be taken to be `13`.

Symmetry of `xV` is not needed for the identities.
-/

@[expose] public section

open Finset

namespace ColourStats.E2Inverse

variable {m h : ℕ}

/-- `X_V(u) = Σ_v x(uv)`. -/
noncomputable def XV (xV : Fin m → Fin m → ℝ) (u : Fin m) : ℝ := ∑ v, xV u v

/-- `X_C(u) = Σ_c x(uc)`. -/
noncomputable def XC (xC : Fin m → Fin h → ℝ) (u : Fin m) : ℝ := ∑ c, xC u c

/-- `W = (Σ_u X_V(u))/2`, the sum of `x` over the pairs `uv`. -/
noncomputable def W (xV : Fin m → Fin m → ℝ) : ℝ := (∑ u, XV xV u) / 2

/-- `Z(c) = Σ_u x(uc)`. -/
noncomputable def Z (xC : Fin m → Fin h → ℝ) (c : Fin h) : ℝ := ∑ u, xC u c

/-- `χ(c) = (Z(c) − 2W/h)/(2m − 2)`. -/
noncomputable def chi (xV : Fin m → Fin m → ℝ) (xC : Fin m → Fin h → ℝ) (c : Fin h) : ℝ :=
  (Z xC c - 2 * W xV / h) / (2 * (m : ℝ) - 2)

/-- `y(uv) = x(uv)/h`. -/
noncomputable def yV (xV : Fin m → Fin m → ℝ) (u v : Fin m) : ℝ := xV u v / (h : ℝ)

/-- `y(uc) = (x(uc) − X_V(u)/h − χ(c))/(m − 2)`. -/
noncomputable def yC (xV : Fin m → Fin m → ℝ) (xC : Fin m → Fin h → ℝ) (u : Fin m)
    (c : Fin h) : ℝ :=
  (xC u c - XV xV u / h - chi xV xC c) / ((m : ℝ) - 2)

/-- `(Φx)(u, v, c) = y(uv) + y(uc) + y(vc)`. -/
noncomputable def Phi (xV : Fin m → Fin m → ℝ) (xC : Fin m → Fin h → ℝ) (u v : Fin m)
    (c : Fin h) : ℝ :=
  yV (h := h) xV u v + yC xV xC u c + yC xV xC v c

/-- `Σ_u X_C(u) = Σ_c Z(c)`. -/
lemma sum_XC_eq_sum_Z (xC : Fin m → Fin h → ℝ) : ∑ u, XC xC u = ∑ c, Z xC c := by
  unfold XC Z
  exact Finset.sum_comm

/-- `Σ_c χ(c) = 0` for balanced `x`. -/
lemma sum_chi (_hm : 3 ≤ m) (hh : 1 ≤ h) (xV : Fin m → Fin m → ℝ) (xC : Fin m → Fin h → ℝ)
    (hbal : ∀ u, XV xV u = XC xC u) : ∑ c, chi xV xC c = 0 := by
  have hhR : (1 : ℝ) ≤ h := by exact_mod_cast hh
  have hh0 : (h : ℝ) ≠ 0 := by linarith
  unfold chi
  rw [← Finset.sum_div, Finset.sum_sub_distrib, ← sum_XC_eq_sum_Z, Finset.sum_const,
    Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  have hW : ∑ u, XC xC u = 2 * W xV := by
    unfold W; rw [Finset.sum_congr rfl fun u _ => (hbal u).symm]; ring
  rw [hW]
  field_simp
  ring

/-- `Σ_c y(uc) = 0` for balanced `x`. -/
lemma sum_yC (hm : 3 ≤ m) (hh : 1 ≤ h) (xV : Fin m → Fin m → ℝ) (xC : Fin m → Fin h → ℝ)
    (hbal : ∀ u, XV xV u = XC xC u) (u : Fin m) : ∑ c, yC xV xC u c = 0 := by
  have hhR : (1 : ℝ) ≤ h := by exact_mod_cast hh
  have hh0 : (h : ℝ) ≠ 0 := by linarith
  unfold yC
  rw [← Finset.sum_div, Finset.sum_sub_distrib, Finset.sum_sub_distrib, sum_chi hm hh xV xC hbal,
    Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  have : ∑ c, xC u c = XV xV u := (hbal u).symm
  rw [this]
  field_simp
  ring

/-- **Pair loads.** `Σ_c (Φx)(u, v, c) = x(uv)`. -/
theorem pair_load (hm : 3 ≤ m) (hh : 1 ≤ h) (xV : Fin m → Fin m → ℝ)
    (xC : Fin m → Fin h → ℝ) (hbal : ∀ u, XV xV u = XC xC u) (u v : Fin m) :
    ∑ c, Phi xV xC u v c = xV u v := by
  have hhR : (1 : ℝ) ≤ h := by exact_mod_cast hh
  have hh0 : (h : ℝ) ≠ 0 := by linarith
  unfold Phi
  rw [Finset.sum_add_distrib, Finset.sum_add_distrib, sum_yC hm hh xV xC hbal u,
    sum_yC hm hh xV xC hbal v, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
    nsmul_eq_mul]
  unfold yV
  field_simp
  ring

/-- `Σ_v y(vc) = χ(c)`. -/
lemma sum_yC_col (hm : 3 ≤ m) (hh : 1 ≤ h) (xV : Fin m → Fin m → ℝ)
    (xC : Fin m → Fin h → ℝ) (c : Fin h) : ∑ v, yC xV xC v c = chi xV xC c := by
  have hmR : (3 : ℝ) ≤ m := by exact_mod_cast hm
  have hhR : (1 : ℝ) ≤ h := by exact_mod_cast hh
  have hh0 : (h : ℝ) ≠ 0 := by linarith
  have hm2 : (m : ℝ) - 2 ≠ 0 := by linarith
  have hm22 : 2 * (m : ℝ) - 2 ≠ 0 := by linarith
  have hm1 : (m : ℝ) - 1 ≠ 0 := by linarith
  have hchi : (2 * (m : ℝ) - 2) * chi xV xC c = Z xC c - 2 * W xV / h := by
    unfold chi; field_simp
  unfold yC
  rw [← Finset.sum_div, Finset.sum_sub_distrib, Finset.sum_sub_distrib, Finset.sum_const,
    Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, ← Finset.sum_div]
  have hZ : ∑ v, xC v c = Z xC c := rfl
  have hW2 : ∑ v, XV xV v = 2 * W xV := by unfold W; ring
  rw [hZ, hW2, div_eq_iff hm2]
  linear_combination (-1 : ℝ) * hchi

/-- **Colour loads.** `Σ_{v ≠ u} (Φx)(u, v, c) = x(uc)`. -/
theorem colour_load (hm : 3 ≤ m) (hh : 1 ≤ h) (xV : Fin m → Fin m → ℝ)
    (xC : Fin m → Fin h → ℝ) (hdiag : ∀ u, xV u u = 0) (u : Fin m) (c : Fin h) :
    ∑ v ∈ univ.erase u, Phi xV xC u v c = xC u c := by
  have hmR : (3 : ℝ) ≤ m := by exact_mod_cast hm
  have hhR : (1 : ℝ) ≤ h := by exact_mod_cast hh
  have hh0 : (h : ℝ) ≠ 0 := by linarith
  have hm2 : (m : ℝ) - 2 ≠ 0 := by linarith
  rw [Finset.sum_erase_eq_sub (mem_univ u)]
  unfold Phi
  rw [Finset.sum_add_distrib, Finset.sum_add_distrib, sum_yC_col hm hh xV xC c,
    Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  have hyV : ∑ v, yV (h := h) xV u v = XV xV u / h := by
    unfold yV XV; rw [Finset.sum_div]
  have hyu : yV (h := h) xV u u = 0 := by unfold yV; rw [hdiag]; simp
  rw [hyV, hyu]
  have hy : ((m : ℝ) - 2) * yC xV xC u c = xC u c - XV xV u / h - chi xV xC c := by
    unfold yC; field_simp
  linear_combination hy

/-- **The norm bound.** `|(Φx)(u, v, c)| ≤ 13 (1 + m/h) B / min(m, h)` whenever `|x| ≤ B`. -/
theorem inverse_bound (hm : 3 ≤ m) (hh : 1 ≤ h) (xV : Fin m → Fin m → ℝ)
    (xC : Fin m → Fin h → ℝ) {B : ℝ} (hBV : ∀ u v, |xV u v| ≤ B) (hBC : ∀ u c, |xC u c| ≤ B)
    (u v : Fin m) (c : Fin h) :
    |Phi xV xC u v c| ≤ 13 * (1 + (m : ℝ) / h) * B / min (m : ℝ) h := by
  have hmR : (3 : ℝ) ≤ m := by exact_mod_cast hm
  have hhR : (1 : ℝ) ≤ h := by exact_mod_cast hh
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hBV ⟨0, by omega⟩ ⟨0, by omega⟩)
  set R : ℝ := 1 + (m : ℝ) / h with hR
  have hmh : 0 ≤ (m : ℝ) / h := by positivity
  have hR1 : 1 ≤ R := by linarith
  have hXV : ∀ u, |XV xV u| ≤ m * B := by
    intro u
    calc |XV xV u| ≤ ∑ v, |xV u v| := abs_sum_le_sum_abs _ _
      _ ≤ ∑ _v : Fin m, B := sum_le_sum fun v _ => hBV u v
      _ = m * B := by simp
  have hZ : ∀ c, |Z xC c| ≤ m * B := by
    intro c
    calc |Z xC c| ≤ ∑ u, |xC u c| := abs_sum_le_sum_abs _ _
      _ ≤ ∑ _u : Fin m, B := sum_le_sum fun u _ => hBC u c
      _ = m * B := by simp
  have hW : |2 * W xV / h| ≤ m * (m * B) / h := by
    have h1 : |∑ u, XV xV u| ≤ m * (m * B) :=
      calc |∑ u, XV xV u| ≤ ∑ u, |XV xV u| := abs_sum_le_sum_abs _ _
        _ ≤ ∑ _u : Fin m, (m * B) := sum_le_sum fun u _ => hXV u
        _ = m * (m * B) := by simp
    have : 2 * W xV / h = (∑ u, XV xV u) / h := by unfold W; ring
    rw [this, abs_div, abs_of_pos (by linarith : (0 : ℝ) < h)]
    exact div_le_div_of_nonneg_right h1 (by linarith)
  have hmB : m * (m * B) / h = (m : ℝ) / h * (m * B) := by ring
  have hchi : ∀ c, |chi xV xC c| ≤ B * R := by
    intro c
    unfold chi
    rw [abs_div, abs_of_pos (by linarith : (0 : ℝ) < 2 * m - 2),
      div_le_iff₀ (by linarith : (0 : ℝ) < 2 * m - 2)]
    have h1 := abs_le.mp (hZ c)
    have h2 := abs_le.mp hW
    have h3 : |Z xC c - 2 * W xV / h| ≤ m * B + m * (m * B) / h :=
      abs_le.mpr ⟨by linarith, by linarith⟩
    refine h3.trans ?_
    rw [hmB, hR]
    nlinarith [mul_nonneg (mul_nonneg hB0 (by linarith : (0 : ℝ) ≤ 1 + (m : ℝ) / h))
      (by linarith : (0 : ℝ) ≤ m - 2)]
  have hyC : ∀ u c, |yC xV xC u c| ≤ 6 * B * R / m := by
    intro u c
    unfold yC
    rw [abs_div, abs_of_pos (by linarith : (0 : ℝ) < m - 2),
      div_le_div_iff₀ (by linarith) (by linarith)]
    have h1 := abs_le.mp (hBC u c)
    have h2 : |XV xV u / h| ≤ (m : ℝ) / h * B := by
      rw [abs_div, abs_of_pos (by linarith : (0 : ℝ) < h)]
      rw [div_mul_eq_mul_div, mul_comm (m : ℝ) B]
      exact div_le_div_of_nonneg_right (by linarith [hXV u]) (by linarith)
    have h2' := abs_le.mp h2
    have h3 := abs_le.mp (hchi c)
    rw [hR] at h3
    have h4 : |xC u c - XV xV u / h - chi xV xC c| ≤ 2 * B * R :=
      abs_le.mpr ⟨by rw [hR]; linarith, by rw [hR]; linarith⟩
    have hBR : 0 ≤ B * R := mul_nonneg hB0 (by linarith)
    nlinarith [mul_le_mul_of_nonneg_right h4 (by linarith : (0 : ℝ) ≤ m),
      mul_nonneg hBR (by linarith : (0 : ℝ) ≤ m - 3)]
  have hyV : |yV (h := h) xV u v| ≤ B / h := by
    unfold yV
    rw [abs_div, abs_of_pos (by linarith : (0 : ℝ) < h)]
    exact div_le_div_of_nonneg_right (hBV u v) (by linarith)
  set μ : ℝ := min (m : ℝ) h with hμ
  have hμ0 : 0 < μ := lt_min (by linarith) (by linarith)
  have hμm : μ ≤ m := min_le_left _ _
  have hμh : μ ≤ h := min_le_right _ _
  have e1 : B / h ≤ B * R / μ :=
    calc B / h ≤ B / μ := div_le_div_of_nonneg_left hB0 hμ0 hμh
      _ ≤ B * R / μ := div_le_div_of_nonneg_right (by nlinarith) hμ0.le
  have e2 : 6 * B * R / m ≤ 6 * B * R / μ :=
    div_le_div_of_nonneg_left (mul_nonneg (mul_nonneg (by norm_num) hB0) (by linarith)) hμ0 hμm
  have hsum : |Phi xV xC u v c| ≤ B / h + 2 * (6 * B * R / m) := by
    unfold Phi
    have a1 := abs_le.mp hyV
    have a2 := abs_le.mp (hyC u c)
    have a3 := abs_le.mp (hyC v c)
    exact abs_le.mpr ⟨by linarith, by linarith⟩
  have : 13 * R * B / μ = B * R / μ + 2 * (6 * B * R / μ) := by ring
  rw [this]
  linarith

end ColourStats.E2Inverse
