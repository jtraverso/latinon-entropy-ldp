/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedG
public import ColourStats.TypedBox

/-!
# Label boxes and the point part on a graph

Adaptation of `ColourStats.TypedBox` to triangle decompositions of a graph `G`: the
candidates `z` are common neighbours of `a` and `b` in the class of `T a b` (`candG`), and
`point_sum_leG` bounds the point part by `Σ_r |box_r| log(1 + |candG| ((L − r)/L)^6)`.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.TypedG

open ColourStats.TypedChain ColourStats.TypedSTS

open Classical

variable {n L k : ℕ} {G : SimpleGraph (Fin n)}

variable {T : Fin n → Fin n → Fin n}

/-- The box `{lam | lam p = r, F⁻}`. -/
lemma mem_boxG (hT : IsSQG G T) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b) (r : Fin L) (lam : Pair n → Fin L) :
    lam ∈ boxF (blockPairs T a b) (Acon (a, b) r) ↔ lam (a, b) = r ∧ Fm lam a b T := by
  have hca : T a b ≠ a := hT.ne_left hadj
  have hcb : T a b ≠ b := hT.ne_right hadj
  obtain ⟨h1, h2⟩ := sp_ne_of_ne hab hcb hca
  simp only [boxF, Finset.mem_filter, Finset.mem_univ, true_and, blockPairs, sp_of_lt hab,
    Finset.forall_mem_insert, Finset.mem_singleton, forall_eq, Acon, if_true, if_neg h1,
    if_neg h2, Finset.mem_singleton, Finset.mem_Ici, Fm]
  constructor
  · rintro ⟨e, h1', h2'⟩
    exact ⟨e, e ▸ h1', e ▸ h2'⟩
  · rintro ⟨e, h1', h2'⟩
    exact ⟨e, e ▸ h1', e ▸ h2'⟩

/-- The candidates for the third point at `(a, b)`: points of the class of `T a b`. -/
noncomputable def candG (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k) (T : Fin n → Fin n → Fin n) (a b : Fin n) : Finset (Fin n) :=
  univ.filter fun z => lab z = lab (T a b) ∧ z ≠ a ∧ z ≠ b ∧ z ≠ T a b ∧ G.Adj a z ∧ G.Adj b z

/-- `X`: the candidates whose six pairs all have labels at least `lam (a, b)`. -/
noncomputable def XsetG (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k) (T : Fin n → Fin n → Fin n) (a b : Fin n)
    (lam : Pair n → Fin L) : Finset (Fin n) :=
  (candG G lab T a b).filter fun z => ∀ q ∈ six T a b z, lam (a, b) ≤ lam q

lemma card_D9G {lab : Fin n → Fin k} (hT : IsSQG G T) {a b z : Fin n} (hab : a < b) (hadj : G.Adj a b) (hz : z ∈ candG G lab T a b) :
    (blockPairs T a b ∪ six T a b z).card = 9 := by
  obtain ⟨-, hza, hzb, hzc, haz, hbz⟩ := (Finset.mem_filter.mp hz).2
  obtain ⟨d1, d2, d3⟩ := blocks_distinctG hT hadj haz hzb hzc
  have hd6 : Disjoint (blockPairs T a z) (blockPairs T b z) :=
    disjoint_blockPairsG hT haz hbz d3
  have hd0 : Disjoint (blockPairs T a b) (six T a b z) := by
    rw [six, Finset.disjoint_union_right]
    exact ⟨disjoint_blockPairsG hT hadj haz (Ne.symm d1),
      disjoint_blockPairsG hT hadj hbz (Ne.symm d2)⟩
  rw [Finset.card_union_of_disjoint hd0, six, Finset.card_union_of_disjoint hd6,
    card_blockPairsG hT hadj, card_blockPairsG hT haz, card_blockPairsG hT hbz]

lemma mem_box9G {lab : Fin n → Fin k} (hT : IsSQG G T) {a b z : Fin n} (hab : a < b) (hadj : G.Adj a b)
    (hz : z ∈ candG G lab T a b) (r : Fin L) (lam : Pair n → Fin L) :
    lam ∈ boxF (blockPairs T a b ∪ six T a b z) (Acon (a, b) r) ↔
      lam ∈ boxF (blockPairs T a b) (Acon (a, b) r) ∧ ∀ q ∈ six T a b z, lam (a, b) ≤ lam q := by
  obtain ⟨-, hza, hzb, hzc, haz, hbz⟩ := (Finset.mem_filter.mp hz).2
  obtain ⟨d1, d2, -⟩ := blocks_distinctG hT hadj haz hzb hzc
  have hp6 : ∀ q ∈ six T a b z, q ≠ (a, b) := by
    intro q hq e
    rw [six, Finset.mem_union] at hq
    have hp := p_mem_blockPairs (T := T) hab
    rcases hq with hq | hq
    · exact Finset.disjoint_left.mp (disjoint_blockPairsG hT hadj haz (Ne.symm d1))
        hp (e ▸ hq)
    · exact Finset.disjoint_left.mp (disjoint_blockPairsG hT hadj hbz (Ne.symm d2))
        hp (e ▸ hq)
  simp only [boxF, Finset.mem_filter, Finset.mem_univ, true_and, Finset.forall_mem_union]
  constructor
  · rintro ⟨h0, h6⟩
    refine ⟨h0, fun q hq => ?_⟩
    have hpr : lam (a, b) = r := by
      have := h0 (a, b) (p_mem_blockPairs hab)
      simpa [Acon] using this
    have := h6 q hq
    rw [Acon, if_neg (hp6 q hq), Finset.mem_Ici] at this
    rw [hpr]; exact this
  · rintro ⟨h0, h6⟩
    refine ⟨h0, fun q hq => ?_⟩
    have hpr : lam (a, b) = r := by
      have := h0 (a, b) (p_mem_blockPairs hab)
      simpa [Acon] using this
    rw [Acon, if_neg (hp6 q hq), Finset.mem_Ici, ← hpr]
    exact h6 q hq

/-- **The average of `X` over the box.** -/
lemma sum_X_leG (hT : IsSQG G T) (lab : Fin n → Fin k) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b) (r : Fin L)
    (hL : 0 < L) :
    ∑ lam ∈ boxF (blockPairs T a b) (Acon (a, b) r), ((XsetG G lab T a b lam).card : ℝ) ≤
      ((boxF (blockPairs T a b) (Acon (a, b) r)).card : ℝ) *
        ((candG G lab T a b).card * (((L : ℝ) - r) / L) ^ 6) := by
  set B := boxF (blockPairs T a b) (Acon (a, b) r)
  have hswap : ∑ lam ∈ B, ((XsetG G lab T a b lam).card : ℝ) =
      ∑ z ∈ candG G lab T a b, ((B.filter fun lam =>
        ∀ q ∈ six T a b z, lam (a, b) ≤ lam q).card : ℝ) := by
    simp only [XsetG, Finset.card_filter, Nat.cast_sum]
    rw [Finset.sum_comm]
  rw [hswap]
  have hLpos : (0 : ℝ) < L := by exact_mod_cast hL
  have hz : ∀ z ∈ candG G lab T a b, ((B.filter fun lam =>
      ∀ q ∈ six T a b z, lam (a, b) ≤ lam q).card : ℝ) =
      (B.card : ℝ) * (((L : ℝ) - r) / L) ^ 6 := by
    intro z hz
    have heq : (B.filter fun lam => ∀ q ∈ six T a b z, lam (a, b) ≤ lam q) =
        boxF (blockPairs T a b ∪ six T a b z) (Acon (a, b) r) := by
      ext lam
      rw [Finset.mem_filter, mem_box9G hT hab hadj hz]
    rw [heq, card_boxF_real _ (Finset.mem_union_left _ (p_mem_blockPairs hab)) r hL,
      card_D9G hT hab hadj hz, card_boxF_real _ (p_mem_blockPairs hab) r hL,
      card_blockPairsG hT hadj]
    field_simp
    ring
  rw [Finset.sum_congr rfl hz, Finset.sum_const, nsmul_eq_mul]
  exact le_of_eq (by ring)

/-- **The values still possible at `(a, b)`.** -/
lemma aval_leG {S : Finset (Fin n → Fin n → Fin n)} (hS : ∀ T ∈ S, IsSQG G T) (lab : Fin n → Fin k)
    {a b : Fin n} (hab : a < b) (hadj : G.Adj a b) (hT : T ∈ S) (lam : Pair n → Fin L) :
    ((sameClass S (pairsG G) (key2 lam) coord lab (a, b) T).image (coord (a, b))).card ≤
      if Fm lam a b T then 1 + (XsetG G lab T a b lam).card else 1 := by
  set C := sameClass S (pairsG G) (key2 lam) coord lab (a, b) T
  have hmemC : ∀ T' ∈ C, T' ∈ before S (pairsG G) (key2 lam) coord (a, b) T ∧
      lab (T' a b) = lab (T a b) := fun T' hT' => Finset.mem_filter.mp hT'
  split_ifs with hF
  · have hsub : C.image (coord (a, b)) ⊆ insert (T a b) (XsetG G lab T a b lam) := by
      intro z hz
      obtain ⟨T', hT', rfl⟩ := Finset.mem_image.mp hz
      obtain ⟨hb, hcl⟩ := hmemC T' hT'
      simp only [coord]
      by_cases he : T' a b = T a b
      · rw [he]; exact Finset.mem_insert_self _ _
      · refine Finset.mem_insert_of_mem (Finset.mem_filter.mpr ⟨?_, ?_⟩)
        · have hT'q := hS T' (mem_before.mp hb).1
          exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hcl, hT'q.ne_left hadj,
            hT'q.ne_right hadj, he, hT'q.adj_left hadj, hT'q.adj_right hadj⟩
        · exact good_of_memG lam hS hadj hT hb he
    calc (C.image (coord (a, b))).card ≤ (insert (T a b) (XsetG G lab T a b lam)).card :=
          Finset.card_le_card hsub
      _ ≤ (XsetG G lab T a b lam).card + 1 := Finset.card_insert_le _ _
      _ = 1 + (XsetG G lab T a b lam).card := by ring
  · have hsub : C.image (coord (a, b)) ⊆ {T a b} := by
      intro z hz
      obtain ⟨T', hT', rfl⟩ := Finset.mem_image.mp hz
      obtain ⟨hb, -⟩ := hmemC T' hT'
      have hF' : lam (sp a (T a b)) < lam (a, b) ∨ lam (sp b (T a b)) < lam (a, b) := by
        unfold Fm at hF
        rw [not_and_or, not_le, not_le] at hF
        exact hF
      simp only [coord, Finset.mem_singleton]
      exact det_of_not_FG lam hS hadj hT hb hF'
    exact (Finset.card_le_card hsub).trans (by simp)

lemma one_le_avalG {S : Finset (Fin n → Fin n → Fin n)} (lab : Fin n → Fin k) {a b : Fin n}
    (hT : T ∈ S) (lam : Pair n → Fin L) :
    1 ≤ ((sameClass S (pairsG G) (key2 lam) coord lab (a, b) T).image (coord (a, b))).card := by
  refine Finset.card_pos.mpr ⟨coord (a, b) T, Finset.mem_image.mpr ⟨T, ?_, rfl⟩⟩
  exact Finset.mem_filter.mpr ⟨mem_before_self hT, rfl⟩

/-- **The point part for one system.** -/
theorem point_sum_leG {S : Finset (Fin n → Fin n → Fin n)} (hS : ∀ T ∈ S, IsSQG G T)
    (lab : Fin n → Fin k) {a b : Fin n} (hab : a < b) (hadj : G.Adj a b) (hT : T ∈ S) (hL : 0 < L) :
    ∑ lam : Pair n → Fin L, Real.log
        ((sameClass S (pairsG G) (key2 lam) coord lab (a, b) T).image (coord (a, b))).card ≤
      ∑ r : Fin L, ((boxF (blockPairs T a b) (Acon (a, b) r)).card : ℝ) *
        Real.log (1 + (candG G lab T a b).card * (((L : ℝ) - r) / L) ^ 6) := by
  have hTq := hS T hT
  -- pointwise bound
  have hpt : ∀ lam : Pair n → Fin L, Real.log
      ((sameClass S (pairsG G) (key2 lam) coord lab (a, b) T).image (coord (a, b))).card ≤
      if Fm lam a b T then Real.log (1 + (XsetG G lab T a b lam).card) else 0 := by
    intro lam
    have h1 := aval_leG hS lab hab hadj hT lam
    have h0 := one_le_avalG (G := G) (L := L) lab (a := a) (b := b) hT lam
    have h0' : (0 : ℝ) < ((sameClass S (pairsG G) (key2 lam) coord lab (a, b) T).image
        (coord (a, b))).card := by exact_mod_cast h0
    split_ifs at h1 ⊢ with hF
    · exact Real.log_le_log h0' (by exact_mod_cast h1)
    · have : ((sameClass S (pairsG G) (key2 lam) coord lab (a, b) T).image
          (coord (a, b))).card = 1 := le_antisymm h1 h0
      rw [this]; simp
  refine (Finset.sum_le_sum fun lam _ => hpt lam).trans ?_
  -- split by the label of `p`
  rw [← Finset.sum_fiberwise (s := univ) (g := fun lam : Pair n → Fin L => lam (a, b))]
  refine Finset.sum_le_sum fun r _ => ?_
  have hbox : ∑ lam ∈ univ.filter (fun lam : Pair n → Fin L => lam (a, b) = r),
      (if Fm lam a b T then Real.log (1 + (XsetG G lab T a b lam).card) else 0) =
      ∑ lam ∈ boxF (blockPairs T a b) (Acon (a, b) r),
        Real.log (1 + (XsetG G lab T a b lam).card) := by
    rw [← Finset.sum_filter, Finset.filter_filter]
    refine Finset.sum_congr ?_ fun _ _ => rfl
    ext lam
    rw [Finset.mem_filter, mem_boxG hTq hab hadj]
    simp
  rw [hbox]
  set B := boxF (blockPairs T a b) (Acon (a, b) r)
  have hJ := log_jensen B (fun lam => ((XsetG G lab T a b lam).card : ℝ)) (fun _ _ => by positivity)
  refine hJ.trans ?_
  rcases B.eq_empty_or_nonempty with hB | hB
  · rw [hB]; simp
  have hBpos : (0 : ℝ) < B.card := by exact_mod_cast hB.card_pos
  refine mul_le_mul_of_nonneg_left ?_ hBpos.le
  have hX := sum_X_leG hTq lab hab hadj r hL
  have hsum0 : 0 ≤ (∑ lam ∈ B, ((XsetG G lab T a b lam).card : ℝ)) / B.card :=
    div_nonneg (Finset.sum_nonneg fun _ _ => Nat.cast_nonneg _) hBpos.le
  have hle : (∑ lam ∈ B, ((XsetG G lab T a b lam).card : ℝ)) / B.card ≤
      ((candG G lab T a b).card : ℝ) * (((L : ℝ) - r) / L) ^ 6 := by
    rw [div_le_iff₀ hBpos]
    linarith
  exact Real.log_le_log (by linarith) (by linarith)

end ColourStats.TypedG
