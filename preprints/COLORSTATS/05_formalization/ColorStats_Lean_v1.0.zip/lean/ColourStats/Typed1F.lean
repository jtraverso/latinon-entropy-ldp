/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedPair
public import ColourStats.Statements
public import ColourStats.PaschRank

/-!
# The typed bound for 1-factorizations: the revealing process (Theorem 1.7, upper half)

A 1-factorization `f` of `K_n` assigns to every edge `e` a colour `f e ∈ Fin (n − 1)`, properly.
The edges are revealed in the order of random labels `lam e ∈ Fin L` (ties broken by an
index), and the coarser past is given by the labels alone (`TypedChain.chain_typed`).

Here the block of an edge `e = uv` with colour `c` is the triangle `{u, v, c}`, whose only
vertex–vertex pair is `e`; so there is no event `F` and every label of `e` counts. If a
system agreeing with `f` on the edges with smaller labels gives `e` another colour `c'`, then
the two edges of colour `c'` at `u` and at `v` in `f` have labels at least `lam e`
(`good_of_mem`). These two edges and `e` are distinct, so on the box `lam e = r` the number of
values at `e` is at most `1 + X` with `E X ≤ (h_Γ − 1) ((L − r)/L)²` (`point_sum_le`).

Main result (`edge_bound`): for one edge `e`, summed over labellings and systems,

  `Σ_lam Σ_f [class + point] ≤ Σ_r L^{N−1} Σ_f [log(|S| / |S^e_{Γ(f)}|) + log(1 + (h_Γ − 1) u_r²)]`.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.Typed1F

open ColourStats ColourStats.Statements ColourStats.TypedChain

open Classical

variable {n L k ℓ : ℕ}

/-! ### Orders -/

/-- An injective index of the edges. -/
noncomputable def idx (e : KEdge n) : ℕ := Fintype.equivFin (KEdge n) e

/-- The number of edges. -/
def NE (n : ℕ) : ℕ := Fintype.card (KEdge n)

lemma idx_lt (e : KEdge n) : idx e < NE n := (Fintype.equivFin (KEdge n) e).isLt

/-- The revealing order. -/
noncomputable def key1 (lam : KEdge n → Fin L) (e : KEdge n) : ℕ := idx e + NE n * lam e

/-- The coarser order. -/
def key2 (lam : KEdge n → Fin L) (e : KEdge n) : ℕ := lam e

lemma key1_injective (lam : KEdge n → Fin L) : Function.Injective (key1 lam) := by
  intro e e' h
  unfold key1 at h
  have := congrArg (· % NE n) h
  simp only [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt (idx_lt e),
    Nat.mod_eq_of_lt (idx_lt e')] at this
  exact (Fintype.equivFin (KEdge n)).injective (Fin.ext this)

lemma key1_lt_of_key2_lt (lam : KEdge n → Fin L) {e e' : KEdge n}
    (h : key2 lam e < key2 lam e') : key1 lam e < key1 lam e' := by
  unfold key1
  unfold key2 at h
  have h1 := idx_lt e
  have h2 : (lam e : ℕ) + 1 ≤ lam e' := h
  nlinarith

/-- The coordinate at `e`. -/
def coord (e : KEdge n) (f : KEdge n → Fin (n - 1)) : Fin (n - 1) := f e

/-! ### Every colour appears at every vertex -/

lemma colour_at {f : KEdge n → Fin (n - 1)} (hf : IsOneFact f) (u : Fin n) (c : Fin (n - 1)) :
    ∃ e : KEdge n, u ∈ e.1 ∧ f e = c := by
  let g : {w : Fin n // w ≠ u} → Fin (n - 1) := fun w =>
    f ⟨s(u, w.1), by rw [Sym2.mk_isDiag_iff]; exact w.2.symm⟩
  have hg : Function.Injective g := by
    intro w w' h
    by_contra hne
    refine hf ⟨s(u, w.1), _⟩ ⟨s(u, w'.1), _⟩ ?_ ⟨u, by simp, by simp⟩ h
    intro he
    have := congrArg Subtype.val he
    rw [Sym2.eq_iff] at this
    rcases this with ⟨-, h2⟩ | ⟨-, h2⟩
    · exact hne (Subtype.ext h2)
    · exact w.2 h2
  have hcard : Fintype.card {w : Fin n // w ≠ u} = Fintype.card (Fin (n - 1)) := by
    rw [ColourStats.card_ne, Fintype.card_fin]
  obtain ⟨w, hw⟩ := ((Fintype.bijective_iff_injective_and_card g).mpr ⟨hg, hcard⟩).2 c
  exact ⟨_, by simp, hw⟩

/-- Two distinct edges through a vertex have distinct colours. -/
lemma eq_of_colour {f : KEdge n → Fin (n - 1)} (hf : IsOneFact f) {e₁ e₂ : KEdge n} {u : Fin n}
    (h₁ : u ∈ e₁.1) (h₂ : u ∈ e₂.1) (hc : f e₁ = f e₂) : e₁ = e₂ := by
  by_contra hne
  exact hf e₁ e₂ hne ⟨u, h₁, h₂⟩ hc

/-! ### The revealing lemma -/

variable {S : Finset (KEdge n → Fin (n - 1))}

/-- `c'` is still possible at `e`: the edges of colour `c'` meeting `e` have labels at least
`lam e`. -/
def Good (lam : KEdge n → Fin L) (f : KEdge n → Fin (n - 1)) (e : KEdge n) (c' : Fin (n - 1)) :
    Prop :=
  ∀ e₁ : KEdge n, (∃ w, w ∈ e.1 ∧ w ∈ e₁.1) → e₁ ≠ e → f e₁ = c' → lam e ≤ lam e₁

/-- The candidates: colours of the class of `f e`, other than `f e`, still possible. -/
noncomputable def Xset (col : Fin (n - 1) → Fin ℓ) (lam : KEdge n → Fin L)
    (f : KEdge n → Fin (n - 1)) (e : KEdge n) : Finset (Fin (n - 1)) :=
  univ.filter fun c' => col c' = col (f e) ∧ c' ≠ f e ∧ Good lam f e c'

lemma good_of_mem (lam : KEdge n → Fin L) (hS : ∀ f ∈ S, IsOneFact f) {e : KEdge n}
    {f f' : KEdge n → Fin (n - 1)} (hf' : f' ∈ before S univ (key2 lam) coord e f)
    (hne : f' e ≠ f e) : Good lam f e (f' e) := by
  obtain ⟨hf'S, hagree⟩ := mem_before.mp hf'
  intro e₁ ⟨w, hw, hw₁⟩ he₁ hc
  by_contra hlt
  rw [not_le] at hlt
  have h1 : f' e₁ = f e₁ := hagree e₁ (Finset.mem_univ _) hlt
  exact hS f' hf'S e₁ e he₁ ⟨w, hw₁, hw⟩ (by rw [h1, hc])

lemma aval_le (col : Fin (n - 1) → Fin ℓ) (lam : KEdge n → Fin L) (hS : ∀ f ∈ S, IsOneFact f)
    {f : KEdge n → Fin (n - 1)} (e : KEdge n) :
    ((sameClass S univ (key2 lam) coord col e f).image (coord e)).card ≤
      1 + (Xset col lam f e).card := by
  have hsub : (sameClass S univ (key2 lam) coord col e f).image (coord e) ⊆
      insert (f e) (Xset col lam f e) := by
    intro c hc
    obtain ⟨f', hf', rfl⟩ := Finset.mem_image.mp hc
    obtain ⟨hb, hcl⟩ := mem_sameClass.mp hf'
    simp only [coord] at hcl ⊢
    by_cases he : f' e = f e
    · rw [he]; exact Finset.mem_insert_self _ _
    · refine Finset.mem_insert_of_mem (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hcl, he, ?_⟩)
      exact good_of_mem lam hS hb he
  calc _ ≤ (insert (f e) (Xset col lam f e)).card := Finset.card_le_card hsub
    _ ≤ (Xset col lam f e).card + 1 := Finset.card_insert_le _ _
    _ = 1 + (Xset col lam f e).card := by ring

lemma one_le_aval (col : Fin (n - 1) → Fin ℓ) (lam : KEdge n → Fin L)
    {f : KEdge n → Fin (n - 1)} (hf : f ∈ S) (e : KEdge n) :
    1 ≤ ((sameClass S univ (key2 lam) coord col e f).image (coord e)).card := by
  refine Finset.card_pos.mpr ⟨coord e f, Finset.mem_image.mpr ⟨f, ?_, rfl⟩⟩
  exact Finset.mem_filter.mpr ⟨mem_before_self hf, rfl⟩

/-! ### Boxes -/

/-- The constraint sets: `{r}` at `e` and `[r, L)` elsewhere. -/
def Acon (e : KEdge n) (r : Fin L) (q : KEdge n) : Finset (Fin L) :=
  if q = e then {r} else Finset.Ici r

lemma prod_Acon {D : Finset (KEdge n)} {e : KEdge n} (he : e ∈ D) (r : Fin L) :
    ∏ q ∈ D, (Acon e r q).card = (L - r) ^ (D.card - 1) := by
  rw [← Finset.mul_prod_erase D _ he]
  rw [Finset.prod_congr rfl (fun q hq => by rw [Acon, if_neg (Finset.ne_of_mem_erase hq)])]
  rw [Finset.prod_const, Fin.card_Ici, Finset.card_erase_of_mem he]
  simp [Acon]

lemma card_boxF_real (D : Finset (KEdge n)) {e : KEdge n} (he : e ∈ D) (r : Fin L)
    (hL : 0 < L) :
    ((boxF D (Acon e r)).card : ℝ) =
      (L : ℝ) ^ NE n * ((L : ℝ) - r) ^ (D.card - 1) / (L : ℝ) ^ D.card := by
  have h := card_boxF D (Acon e r)
  rw [prod_Acon he, Fintype.card_fin] at h
  have hLpos : (0 : ℝ) < L := by exact_mod_cast hL
  have hcast : ((L - (r : ℕ) : ℕ) : ℝ) = (L : ℝ) - r := by
    rw [Nat.cast_sub r.isLt.le]
  have h' : ((boxF D (Acon e r)).card : ℝ) * (L : ℝ) ^ D.card =
      (L : ℝ) ^ NE n * ((L : ℝ) - r) ^ (D.card - 1) := by
    rw [← hcast]
    exact_mod_cast h
  field_simp
  linarith

lemma mem_box1 (e : KEdge n) (r : Fin L) (lam : KEdge n → Fin L) :
    lam ∈ boxF {e} (Acon e r) ↔ lam e = r := by
  simp [boxF, Acon]

/-- `B_r = L^{N−1}`. -/
noncomputable def Bv (n L : ℕ) : ℝ := (L : ℝ) ^ NE n / L

lemma card_box1 (e : KEdge n) (r : Fin L) (hL : 0 < L) :
    ((boxF {e} (Acon e r)).card : ℝ) = Bv n L := by
  rw [card_boxF_real {e} (Finset.mem_singleton_self e) r hL, Finset.card_singleton, Bv]
  simp

lemma box1_eq (e : KEdge n) (r : Fin L) :
    (univ.filter fun lam : KEdge n → Fin L => lam e = r) = boxF {e} (Acon e r) := by
  ext lam
  rw [Finset.mem_filter, mem_box1]
  simp

/-- **The average of `X` on the box.** -/
lemma sum_X_le (col : Fin (n - 1) → Fin ℓ) {f : KEdge n → Fin (n - 1)} (hf : IsOneFact f)
    (e : KEdge n) (r : Fin L) (hL : 0 < L) :
    ∑ lam ∈ boxF {e} (Acon e r), ((Xset col lam f e).card : ℝ) ≤
      Bv n L * (((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2) := by
  classical
  -- the endpoints of `e`
  obtain ⟨⟨u, v⟩, huv⟩ := Quot.exists_rep e.1
  have heuv : e.1 = s(u, v) := huv.symm
  have hne : u ≠ v := by
    intro h
    apply e.2
    rw [heuv, Sym2.mk_isDiag_iff]
    exact h
  have hu : u ∈ e.1 := by rw [heuv]; simp
  have hv : v ∈ e.1 := by rw [heuv]; simp
  set B := boxF {e} (Acon e r)
  -- swap the sums
  set C := univ.filter (fun c' => col c' = col (f e) ∧ c' ≠ f e)
  have hX : ∀ lam : KEdge n → Fin L, ((Xset col lam f e).card : ℝ) =
      ∑ c' ∈ C, if Good lam f e c' then (1 : ℝ) else 0 := by
    intro lam
    rw [Finset.sum_boole]
    congr 2
    ext c'
    simp [Xset, C, and_assoc]
  have hswap : ∑ lam ∈ B, ((Xset col lam f e).card : ℝ) =
      ∑ c' ∈ C, ((B.filter fun lam => Good lam f e c').card : ℝ) := by
    rw [Finset.sum_congr rfl fun lam _ => hX lam, Finset.sum_comm]
    refine Finset.sum_congr rfl fun c' _ => ?_
    rw [Finset.sum_boole]
  rw [hswap]
  -- each candidate
  have hc : ∀ c' ∈ C,
      ((B.filter fun lam => Good lam f e c').card : ℝ) = Bv n L * (((L : ℝ) - r) / L) ^ 2 := by
    intro c' hc'
    have hce : c' ≠ f e := (Finset.mem_filter.mp hc').2.2
    obtain ⟨eu, heu, hfu⟩ := colour_at hf u c'
    obtain ⟨ev, hev, hfv⟩ := colour_at hf v c'
    have heu_ne : eu ≠ e := fun h => hce (h ▸ hfu).symm
    have hev_ne : ev ≠ e := fun h => hce (h ▸ hfv).symm
    have huv_ne : eu ≠ ev := by
      intro h
      apply heu_ne
      apply Subtype.ext
      have h2 : u ∈ eu.1 ∧ v ∈ eu.1 := ⟨heu, h ▸ hev⟩
      rw [(Sym2.mem_and_mem_iff hne).mp h2, heuv]
    have hD : ({e, eu, ev} : Finset (KEdge n)).card = 3 := by
      rw [Finset.card_eq_three]
      exact ⟨e, eu, ev, Ne.symm heu_ne, Ne.symm hev_ne, huv_ne, rfl⟩
    have heq : (B.filter fun lam => Good lam f e c') = boxF {e, eu, ev} (Acon e r) := by
      ext lam
      simp only [Finset.mem_filter, B, boxF, Finset.mem_univ, true_and,
        Finset.forall_mem_insert, Finset.mem_singleton, forall_eq, Acon, if_true,
        if_neg heu_ne, if_neg hev_ne, Finset.mem_Ici]
      constructor
      · rintro ⟨hr, hg⟩
        refine ⟨hr, ?_, ?_⟩
        · rw [← hr]; exact hg eu ⟨u, hu, heu⟩ heu_ne hfu
        · rw [← hr]; exact hg ev ⟨v, hv, hev⟩ hev_ne hfv
      · rintro ⟨hr, h1, h2⟩
        refine ⟨hr, fun e₁ ⟨w, hw, hw₁⟩ he₁ hc₁ => ?_⟩
        rw [heuv] at hw
        rcases Sym2.mem_iff.mp hw with rfl | rfl
        · rw [eq_of_colour hf hw₁ heu (hc₁.trans hfu.symm), hr]; exact h1
        · rw [eq_of_colour hf hw₁ hev (hc₁.trans hfv.symm), hr]; exact h2
    rw [heq, card_boxF_real _ (by simp) r hL, hD, Bv]
    have hLpos : (0 : ℝ) < L := by exact_mod_cast hL
    field_simp
  rw [Finset.sum_congr rfl hc, Finset.sum_const, nsmul_eq_mul]
  -- at most `h_Γ − 1` candidates
  have hcand : (C.card : ℝ) ≤ (colSize col (col (f e)) : ℝ) - 1 := by
    have h1 : C =
        (univ.filter fun c' => col c' = col (f e)).erase (f e) := by
      ext c'
      simp [C, and_comm]
    rw [h1, Finset.card_erase_of_mem (by simp)]
    have h2 : (univ.filter fun c' => col c' = col (f e)).card = colSize col (col (f e)) := by
      unfold colSize
      congr 1
    rw [h2]
    have h3 : 1 ≤ colSize col (col (f e)) := by
      rw [← h2]
      exact Finset.card_pos.mpr ⟨f e, by simp⟩
    rw [Nat.cast_sub h3]
    simp
  have hBv : 0 ≤ Bv n L := by unfold Bv; positivity
  have hu2 : 0 ≤ (((L : ℝ) - r) / L) ^ 2 := by positivity
  calc (C.card : ℝ) * (Bv n L * (((L : ℝ) - r) / L) ^ 2)
      ≤ ((colSize col (col (f e)) : ℝ) - 1) * (Bv n L * (((L : ℝ) - r) / L) ^ 2) :=
        mul_le_mul_of_nonneg_right hcand (mul_nonneg hBv hu2)
    _ = _ := by ring

/-- **The point part for one system.** -/
theorem point_sum_le (col : Fin (n - 1) → Fin ℓ) (hS : ∀ f ∈ S, IsOneFact f)
    {f : KEdge n → Fin (n - 1)} (hf : f ∈ S) (e : KEdge n) (hL : 0 < L) :
    ∑ lam : KEdge n → Fin L, Real.log
        ((sameClass S univ (key2 lam) coord col e f).image (coord e)).card ≤
      ∑ r : Fin L, Bv n L *
        Real.log (1 + ((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2) := by
  have hpt : ∀ lam : KEdge n → Fin L, Real.log
      ((sameClass S univ (key2 lam) coord col e f).image (coord e)).card ≤
      Real.log (1 + (Xset col lam f e).card) := by
    intro lam
    have h1 := aval_le col lam hS (f := f) e
    have h0 := one_le_aval col lam hf e
    have h0' : (0 : ℝ) < ((sameClass S univ (key2 lam) coord col e f).image (coord e)).card := by
      exact_mod_cast h0
    exact Real.log_le_log h0' (by exact_mod_cast h1)
  refine (Finset.sum_le_sum fun lam _ => hpt lam).trans ?_
  rw [← Finset.sum_fiberwise (s := univ) (g := fun lam : KEdge n → Fin L => lam e)]
  refine Finset.sum_le_sum fun r _ => ?_
  rw [box1_eq e r]
  set B := boxF {e} (Acon e r)
  have hJ := log_jensen B (fun lam => ((Xset col lam f e).card : ℝ)) (fun _ _ => by positivity)
  refine hJ.trans ?_
  have hBc : (B.card : ℝ) = Bv n L := card_box1 e r hL
  rw [hBc]
  have hBpos : 0 < Bv n L := by
    unfold Bv
    have : (0 : ℝ) < L := by exact_mod_cast hL
    positivity
  refine mul_le_mul_of_nonneg_left ?_ hBpos.le
  have hX := sum_X_le col (hS f hf) e r hL
  have hsum0 : 0 ≤ (∑ lam ∈ B, ((Xset col lam f e).card : ℝ)) / Bv n L :=
    div_nonneg (Finset.sum_nonneg fun _ _ => Nat.cast_nonneg _) hBpos.le
  have hle : (∑ lam ∈ B, ((Xset col lam f e).card : ℝ)) / Bv n L ≤
      ((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2 := by
    rw [div_le_iff₀ hBpos]
    linarith
  exact Real.log_le_log (by linarith) (by linarith)

end ColourStats.Typed1F
