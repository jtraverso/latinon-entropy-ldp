/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Statements

/-!
# Corollary 1.11 from Theorems 1.9(a) and 1.10

The paper derives Corollary 1.11 in three lines: completions of a partial Steiner triple
system `Q` are the triangle decompositions of `G = K_n − L_Q`, and `G` is
triangle-divisible. This file proves those two facts and the implication
`Theorem_1_10_typical → Corollary_1_11` (`corollary_1_11_of`).

* `completionEquiv`: `D ↦ D \ Q` is a bijection from the Steiner triple systems containing
  `Q` with type vector `t` to the triangle decompositions of `G` with type vector
  `t − t(Q)` (when `t ≥ t(Q)`);
* `triDivisible_leave`: for `n ≡ 1, 3 (mod 6)`, every degree of `G` is
  `n − 1 − 2 deg_Q(v)`, which is even, and `e(G) = C(n, 2) − 3|Q| ≡ 0 (mod 3)`.
-/

@[expose] public section

open Finset

namespace ColourStats.Statements

open ColourStats

variable {n k : ℕ}

lemma two_le_card_inter {B C : Finset (Fin n)} {x y : Fin n} (hxy : x ≠ y) (hxB : x ∈ B)
    (hyB : y ∈ B) (hxC : x ∈ C) (hyC : y ∈ C) : 2 ≤ (B ∩ C).card := by
  have hsub : ({x, y} : Finset (Fin n)) ⊆ B ∩ C := by
    intro z hz
    simp only [Finset.mem_insert, Finset.mem_singleton] at hz
    rcases hz with rfl | rfl <;> simp_all
  have := Finset.card_le_card hsub
  rwa [Finset.card_pair hxy] at this

/-- In a partial Steiner triple system two points lie in at most one block. -/
lemma partial_unique {Q : Finset (Finset (Fin n))} (hQ : IsPartialSTS Q) {B C : Finset (Fin n)}
    (hB : B ∈ Q) (hC : C ∈ Q) {x y : Fin n} (hxy : x ≠ y) (hxB : x ∈ B) (hyB : y ∈ B)
    (hxC : x ∈ C) (hyC : y ∈ C) : B = C := by
  by_contra hne
  have := hQ.2 B hB C hC hne
  have := two_le_card_inter hxy hxB hyB hxC hyC
  omega

lemma typeCount_union (lab : Fin n → Fin k) {A B : Finset (Finset (Fin n))} (h : Disjoint A B)
    (τ : Multiset (Fin k)) : typeCount lab (A ∪ B) τ = typeCount lab A τ + typeCount lab B τ := by
  unfold typeCount
  rw [Finset.filter_union, Finset.card_union_of_disjoint
    (Finset.disjoint_filter_filter h)]

lemma triDecomp_sdiff {Q : Finset (Finset (Fin n))} {D : STS.STSOn n} (hQD : Q ⊆ D.1) :
    IsTriDecomp (leaveGraph Q) (D.1 \ Q) := by
  obtain ⟨hcard, huniq⟩ := D.2
  refine ⟨fun B hB => ?_, fun x y hxy => ?_⟩
  · obtain ⟨hBD, hBQ⟩ := Finset.mem_sdiff.mp hB
    refine ⟨hcard B hBD, fun x hx y hy hxy => ⟨hxy, ?_⟩⟩
    rintro ⟨C, hC, hxC, hyC⟩
    have h1 := (huniq x y hxy).unique ⟨hBD, hx, hy⟩ ⟨hQD hC, hxC, hyC⟩
    exact hBQ (h1 ▸ hC)
  · obtain ⟨A, ⟨hAD, hxA, hyA⟩, hA⟩ := huniq x y hxy.1
    refine ⟨A, ⟨Finset.mem_sdiff.mpr ⟨hAD, fun hAQ => hxy.2 ⟨A, hAQ, hxA, hyA⟩⟩, hxA, hyA⟩, ?_⟩
    rintro B ⟨hB, hxB, hyB⟩
    exact hA B ⟨(Finset.mem_sdiff.mp hB).1, hxB, hyB⟩

lemma disjoint_decomp {Q E : Finset (Finset (Fin n))} (hQ : IsPartialSTS Q)
    (hE : IsTriDecomp (leaveGraph Q) E) : Disjoint E Q := by
  rw [Finset.disjoint_left]
  intro B hBE hBQ
  have h3 := hQ.1 B hBQ
  obtain ⟨x, y, z, hxy, -, -, rfl⟩ := Finset.card_eq_three.mp h3
  have := (hE.1 _ hBE).2 x (by simp) y (by simp) hxy
  exact this.2 ⟨_, hBQ, by simp, by simp⟩

lemma isSTS_union {Q E : Finset (Finset (Fin n))} (hQ : IsPartialSTS Q)
    (hE : IsTriDecomp (leaveGraph Q) E) : STS.IsSTS (E ∪ Q) := by
  refine ⟨fun A hA => ?_, fun x y hxy => ?_⟩
  · rcases Finset.mem_union.mp hA with h | h
    · exact (hE.1 A h).1
    · exact hQ.1 A h
  · by_cases hcov : ∃ B ∈ Q, x ∈ B ∧ y ∈ B
    · obtain ⟨B, hBQ, hxB, hyB⟩ := hcov
      refine ⟨B, ⟨Finset.mem_union_right _ hBQ, hxB, hyB⟩, ?_⟩
      rintro A ⟨hA, hxA, hyA⟩
      rcases Finset.mem_union.mp hA with h | h
      · exact absurd ⟨B, hBQ, hxB, hyB⟩ ((hE.1 A h).2 x hxA y hyA hxy).2
      · exact partial_unique hQ h hBQ hxy hxA hyA hxB hyB
    · obtain ⟨B, ⟨hBE, hxB, hyB⟩, hB⟩ := hE.2 x y ⟨hxy, hcov⟩
      refine ⟨B, ⟨Finset.mem_union_left _ hBE, hxB, hyB⟩, ?_⟩
      rintro A ⟨hA, hxA, hyA⟩
      rcases Finset.mem_union.mp hA with h | h
      · exact hB A ⟨h, hxA, hyA⟩
      · exact absurd ⟨A, h, hxA, hyA⟩ hcov

/-- **Completions are decompositions of the leave.** -/
noncomputable def completionEquiv (lab : Fin n → Fin k) {Q : Finset (Finset (Fin n))}
    (hQ : IsPartialSTS Q) (t : Multiset (Fin k) → ℕ)
    (hge : ∀ τ ∈ blockTypes k, typeCount lab Q τ ≤ t τ) :
    {D : STS.STSOn n // Q ⊆ D.1 ∧ ∀ τ ∈ blockTypes k, typeCount lab D.1 τ = t τ} ≃
      {E : Finset (Finset (Fin n)) // IsTriDecomp (leaveGraph Q) E ∧
        ∀ τ ∈ blockTypes k, typeCount lab E τ = t τ - typeCount lab Q τ} where
  toFun D := ⟨D.1.1 \ Q, triDecomp_sdiff D.2.1, fun τ hτ => by
    have hdis : Disjoint (D.1.1 \ Q) Q := Finset.sdiff_disjoint
    have hu := typeCount_union lab hdis τ
    rw [Finset.sdiff_union_of_subset D.2.1, D.2.2 τ hτ] at hu
    omega⟩
  invFun E := ⟨⟨E.1 ∪ Q, isSTS_union hQ E.2.1⟩, Finset.subset_union_right, fun τ hτ => by
    rw [typeCount_union lab (disjoint_decomp hQ E.2.1), E.2.2 τ hτ]
    have := hge τ hτ
    omega⟩
  left_inv D := by
    apply Subtype.ext
    apply Subtype.ext
    exact Finset.sdiff_union_of_subset D.2.1
  right_inv E := Subtype.ext (Finset.union_sdiff_cancel_right (disjoint_decomp hQ E.2.1))

lemma countCompletions_eq (lab : Fin n → Fin k) {Q : Finset (Finset (Fin n))}
    (hQ : IsPartialSTS Q) (t : Multiset (Fin k) → ℕ)
    (hge : ∀ τ ∈ blockTypes k, typeCount lab Q τ ≤ t τ) :
    countCompletions lab Q t =
      countDecomp (leaveGraph Q) lab (fun τ => t τ - typeCount lab Q τ) :=
  Nat.card_congr (completionEquiv lab hQ t hge)

/-! ### The leave is triangle-divisible -/

open Classical

/-- The pairs covered by `Q`. -/
def covered (Q : Finset (Finset (Fin n))) : Finset (Finset (Fin n)) :=
  Q.biUnion fun B => B.powersetCard 2

lemma card_covered {Q : Finset (Finset (Fin n))} (hQ : IsPartialSTS Q) :
    (covered Q).card = 3 * Q.card := by
  unfold covered
  rw [Finset.card_biUnion]
  · rw [Finset.sum_congr rfl fun B hB => by rw [Finset.card_powersetCard, hQ.1 B hB]]
    simp [mul_comm]
  · intro B hB C hC hne
    rw [Function.onFun, Finset.disjoint_left]
    intro e heB heC
    obtain ⟨hsB, he2⟩ := Finset.mem_powersetCard.mp heB
    obtain ⟨hsC, -⟩ := Finset.mem_powersetCard.mp heC
    have := Finset.card_le_card (Finset.subset_inter hsB hsC)
    have := hQ.2 B hB C hC hne
    omega

lemma leave_adj {Q : Finset (Finset (Fin n))} {x y : Fin n} :
    (leaveGraph Q).Adj x y ↔ x ≠ y ∧ ¬ ∃ B ∈ Q, x ∈ B ∧ y ∈ B := Iff.rfl

lemma edges_leave_eq (Q : Finset (Finset (Fin n))) :
    ((univ : Finset (Fin n)).powersetCard 2 |>.filter fun e =>
      ∀ x ∈ e, ∀ y ∈ e, x ≠ y → (leaveGraph Q).Adj x y) =
      (univ : Finset (Fin n)).powersetCard 2 \ covered Q := by
  ext e
  rw [Finset.mem_filter, Finset.mem_sdiff, Finset.mem_powersetCard, covered,
    Finset.mem_biUnion]
  constructor
  · rintro ⟨⟨hsub, he⟩, hadj⟩
    refine ⟨⟨hsub, he⟩, ?_⟩
    rintro ⟨B, hB, heB⟩
    obtain ⟨hsB, -⟩ := Finset.mem_powersetCard.mp heB
    obtain ⟨x, y, hxy, rfl⟩ := Finset.card_eq_two.mp he
    exact (leave_adj.mp (hadj x (by simp) y (by simp) hxy)).2
      ⟨B, hB, hsB (by simp), hsB (by simp)⟩
  · rintro ⟨⟨hsub, he⟩, hnot⟩
    refine ⟨⟨hsub, he⟩, fun x hx y hy hxy => leave_adj.mpr ⟨hxy, ?_⟩⟩
    rintro ⟨B, hB, hxB, hyB⟩
    obtain ⟨a, b, hab, rfl⟩ := Finset.card_eq_two.mp he
    have hxy' : ({x, y} : Finset (Fin n)) = {a, b} := by
      apply Finset.eq_of_subset_of_card_le
      · intro z hz
        simp only [Finset.mem_insert, Finset.mem_singleton] at hz
        rcases hz with rfl | rfl <;> assumption
      · rw [Finset.card_pair hab, Finset.card_pair hxy]
    refine hnot ⟨B, hB, Finset.mem_powersetCard.mpr ⟨?_, he⟩⟩
    rw [← hxy']
    intro z hz
    simp only [Finset.mem_insert, Finset.mem_singleton] at hz
    rcases hz with rfl | rfl <;> assumption

lemma three_dvd_choose_two (hmod : n % 6 = 1 ∨ n % 6 = 3) : 3 ∣ n.choose 2 := by
  rw [Nat.choose_two_right]
  have h : 6 ∣ n * (n - 1) := by
    rcases hmod with h | h
    · obtain ⟨q, rfl⟩ : ∃ q, n = 6 * q + 1 := ⟨n / 6, by omega⟩
      exact ⟨q * (6 * q + 1), by rw [show 6 * q + 1 - 1 = 6 * q by omega]; ring⟩
    · obtain ⟨q, rfl⟩ : ∃ q, n = 6 * q + 3 := ⟨n / 6, by omega⟩
      exact ⟨(2 * q + 1) * (3 * q + 1), by rw [show 6 * q + 3 - 1 = 6 * q + 2 by omega]; ring⟩
  obtain ⟨m, hm⟩ := h
  rw [hm, show 6 * m = 2 * (3 * m) by ring, Nat.mul_div_cancel_left _ (by norm_num)]
  exact ⟨m, rfl⟩

/-- The neighbours of `v` covered by `Q`. -/
def coveredNbrs (Q : Finset (Finset (Fin n))) (v : Fin n) : Finset (Fin n) :=
  (Q.filter fun B => v ∈ B).biUnion fun B => B.erase v

lemma card_coveredNbrs {Q : Finset (Finset (Fin n))} (hQ : IsPartialSTS Q) (v : Fin n) :
    (coveredNbrs Q v).card = 2 * (Q.filter fun B => v ∈ B).card := by
  unfold coveredNbrs
  rw [Finset.card_biUnion]
  · rw [Finset.sum_congr rfl fun B hB => by
      rw [Finset.card_erase_of_mem (Finset.mem_filter.mp hB).2,
        hQ.1 B (Finset.mem_filter.mp hB).1]]
    simp [mul_comm]
  · intro B hB C hC hne
    rw [Function.onFun, Finset.disjoint_left]
    intro x hxB hxC
    obtain ⟨hxv, hxB⟩ := Finset.mem_erase.mp hxB
    obtain ⟨-, hxC⟩ := Finset.mem_erase.mp hxC
    exact hne (partial_unique hQ (Finset.mem_filter.mp hB).1 (Finset.mem_filter.mp hC).1
      hxv hxB (Finset.mem_filter.mp hB).2 hxC (Finset.mem_filter.mp hC).2)

lemma nbrs_leave_eq (Q : Finset (Finset (Fin n))) (v : Fin n) :
    (univ.filter ((leaveGraph Q).Adj v)) = (univ.erase v) \ coveredNbrs Q v := by
  ext u
  rw [Finset.mem_filter, Finset.mem_sdiff, Finset.mem_erase, coveredNbrs, Finset.mem_biUnion,
    leave_adj]
  constructor
  · rintro ⟨-, hvu, hnot⟩
    refine ⟨⟨fun e => hvu e.symm, Finset.mem_univ _⟩, ?_⟩
    rintro ⟨B, hB, hu⟩
    exact hnot ⟨B, (Finset.mem_filter.mp hB).1, (Finset.mem_filter.mp hB).2,
      (Finset.mem_erase.mp hu).2⟩
  · rintro ⟨⟨huv, -⟩, hnot⟩
    refine ⟨Finset.mem_univ _, fun e => huv e.symm, ?_⟩
    rintro ⟨B, hB, hvB, huB⟩
    exact hnot ⟨B, Finset.mem_filter.mpr ⟨hB, hvB⟩, Finset.mem_erase.mpr ⟨huv, huB⟩⟩

/-- **The leave of a partial Steiner triple system is triangle-divisible.** -/
theorem triDivisible_leave {Q : Finset (Finset (Fin n))} (hQ : IsPartialSTS Q)
    (hmod : n % 6 = 1 ∨ n % 6 = 3) : TriDivisible (leaveGraph Q) := by
  refine ⟨fun v => ?_, ?_⟩
  · rw [nbrs_leave_eq, Finset.card_sdiff_of_subset]
    · rw [Finset.card_erase_of_mem (Finset.mem_univ v), Finset.card_univ, Fintype.card_fin,
        card_coveredNbrs hQ]
      have hcov : 2 * (Q.filter fun B => v ∈ B).card ≤ n - 1 := by
        rw [← card_coveredNbrs hQ v]
        have : coveredNbrs Q v ⊆ univ.erase v := by
          intro u hu
          obtain ⟨B, -, hu⟩ := Finset.mem_biUnion.mp hu
          exact Finset.mem_erase.mpr ⟨(Finset.mem_erase.mp hu).1, Finset.mem_univ _⟩
        have h := Finset.card_le_card this
        rwa [Finset.card_erase_of_mem (Finset.mem_univ v), Finset.card_univ,
          Fintype.card_fin] at h
      refine ⟨(n - 1) / 2 - (Q.filter fun B => v ∈ B).card, ?_⟩
      omega
    · intro u hu
      obtain ⟨B, -, hu⟩ := Finset.mem_biUnion.mp hu
      exact Finset.mem_erase.mpr ⟨(Finset.mem_erase.mp hu).1, Finset.mem_univ _⟩
  · rw [edges_leave_eq, Finset.card_sdiff_of_subset]
    · rw [Finset.card_powersetCard, Finset.card_univ, Fintype.card_fin, card_covered hQ]
      exact Nat.dvd_sub (three_dvd_choose_two hmod) (Nat.dvd_mul_right 3 _)
    · intro e he
      obtain ⟨B, -, he⟩ := Finset.mem_biUnion.mp he
      exact Finset.mem_powersetCard.mpr ⟨Finset.subset_univ _,
        (Finset.mem_powersetCard.mp he).2⟩

/-- **Corollary 1.11 from Theorem 1.10 for Theorem 1.9(a).** -/
theorem corollary_1_11_of (h : Theorem_1_10_typical) : Corollary_1_11 := by
  intro k hk c₀ δ₀ d₀ ζ hc₀ hδ₀ hd₀ hζ
  obtain ⟨c, K, hc, n₀, hn₀⟩ := h k hk c₀ δ₀ d₀ ζ hc₀ hδ₀ hd₀ hζ
  refine ⟨c, K, hc, max n₀ 1, fun n hn hmod lab Q hQ hcls htyp t hid hζt => ?_⟩
  have hn1 : 1 ≤ n := le_of_max_le_right hn
  have hnpos : (0 : ℝ) < n := by exact_mod_cast hn1
  have hge : ∀ τ ∈ blockTypes k, typeCount lab Q τ ≤ t τ := by
    intro τ hτ
    by_contra hlt
    have h0 : t τ - typeCount lab Q τ = 0 := by omega
    have := hζt τ hτ
    rw [h0] at this
    simp only [Nat.cast_zero] at this
    have : 0 < ζ * (n : ℝ) ^ 2 := by positivity
    linarith
  rw [countCompletions_eq lab hQ t hge]
  exact hn₀ n (le_of_max_le_left hn) (leaveGraph Q) lab
    ⟨triDivisible_leave hQ hmod, hcls, htyp⟩ _ hid hζt

end ColourStats.Statements
