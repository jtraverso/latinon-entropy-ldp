/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import Mathlib

/-!
# The normalised form of the rate (Proposition 1.3)

Classes `X : Fin k` have sizes `c_X`, with `n = Σ_X c_X`. For a matrix `t` of block counts
(`t_XY` blocks of type `XXY`, `X ≠ Y`) put

    N_XY = C(c_X, 2) c_Y,   Φ(t) = Σ_{X≠Y} t_XY (log(N_XY / t_XY) − 2),
    Q_XY = 6 t_XY / n²,     P₀(XXY) = 3 γ_X² γ_Y  (γ_X = c_X / n),
    D(Q‖P₀) = Σ_{X≠Y} Q_XY log(Q_XY / P₀(XXY)).

Main result (`prop_1_3`): if every `c_X ≥ 2`, every `t_XY > 0`, the row identities
`Σ_{Y≠X} t_XY = C(c_X, 2)` of (1.3) hold and the partition is admissible
(`3 Σ_X c_X(c_X − 1) = n(n − 1)`), then

    |Φ(t) − (n²/6)(log n − 2 − D(Q‖P₀))| ≤ (n/6)|log n − 2| + n.

This is Proposition 1.3 with an explicit error, which is `O(n log n)`. The exact identity
behind it is `prop_1_3_exact`:

    Φ(t) − (n²/6)(log n − 2 − D(Q‖P₀)) = −(n/6)(log n − 2) + Σ_{X≠Y} t_XY log(1 − 1/c_X).

No lower bounds on the class sizes or on `t` beyond positivity are needed.
-/

@[expose] public section

open Finset Real

namespace ColourStats.Prop13

variable {k : ℕ}

/-- `N_XY = C(c_X, 2) c_Y`. -/
noncomputable def Nxy (c : Fin k → ℕ) (X Y : Fin k) : ℝ :=
  (c X : ℝ) * (c X - 1) / 2 * c Y

/-- `Φ(t) = Σ_{X≠Y} t_XY (log(N_XY / t_XY) − 2)`. -/
noncomputable def Phi (c : Fin k → ℕ) (t : Fin k → Fin k → ℝ) : ℝ :=
  ∑ X, ∑ Y ∈ univ.erase X, t X Y * (log (Nxy c X Y / t X Y) - 2)

/-- `Q_XY = 6 t_XY / n²`. -/
noncomputable def Q (n : ℕ) (t : Fin k → Fin k → ℝ) (X Y : Fin k) : ℝ := 6 * t X Y / (n : ℝ) ^ 2

/-- `P₀(XXY) = 3 γ_X² γ_Y`. -/
noncomputable def P0 (n : ℕ) (c : Fin k → ℕ) (X Y : Fin k) : ℝ :=
  3 * ((c X : ℝ) / n) ^ 2 * ((c Y : ℝ) / n)

/-- `D(Q‖P₀) = Σ_{X≠Y} Q_XY log(Q_XY / P₀(XXY))`. -/
noncomputable def KL (n : ℕ) (c : Fin k → ℕ) (t : Fin k → Fin k → ℝ) : ℝ :=
  ∑ X, ∑ Y ∈ univ.erase X, Q n t X Y * log (Q n t X Y / P0 n c X Y)

lemma term_eq {n : ℕ} {c : Fin k → ℕ} {t : Fin k → Fin k → ℝ} (hn : 0 < n)
    {X Y : Fin k} (hcX : 2 ≤ c X) (hcY : 1 ≤ c Y) (ht : 0 < t X Y) :
    t X Y * (log (Nxy c X Y / t X Y) - 2) + (n : ℝ) ^ 2 / 6 * (Q n t X Y *
        log (Q n t X Y / P0 n c X Y)) =
      t X Y * (log n - 2) + t X Y * log (((c X : ℝ) - 1) / c X) := by
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  have hcXR : (2 : ℝ) ≤ c X := by exact_mod_cast hcX
  have hcYR : (1 : ℝ) ≤ c Y := by exact_mod_cast hcY
  have hcX0 : (0 : ℝ) < c X := by linarith
  have hcX1 : (0 : ℝ) < c X - 1 := by linarith
  have hcY0 : (0 : ℝ) < c Y := by linarith
  have hN : 0 < Nxy c X Y := by
    unfold Nxy
    exact mul_pos (div_pos (mul_pos hcX0 hcX1) (by norm_num)) hcY0
  have hQ : 0 < Q n t X Y := by unfold Q; positivity
  have hP : 0 < P0 n c X Y := by
    unfold P0
    exact mul_pos (mul_pos (by norm_num) (pow_pos (div_pos hcX0 hnR) 2)) (div_pos hcY0 hnR)
  have hQt : (n : ℝ) ^ 2 / 6 * Q n t X Y = t X Y := by unfold Q; field_simp
  have hprod : Nxy c X Y / t X Y * (Q n t X Y / P0 n c X Y) =
      n * (((c X : ℝ) - 1) / c X) := by
    unfold Nxy Q P0
    have : (0 : ℝ) < c X := by linarith
    have : (0 : ℝ) < c Y := by linarith
    field_simp
    ring
  have hlog : log (Nxy c X Y / t X Y) + log (Q n t X Y / P0 n c X Y) =
      log n + log (((c X : ℝ) - 1) / c X) := by
    rw [← log_mul (div_pos hN ht).ne' (div_pos hQ hP).ne', hprod,
      log_mul hnR.ne' (div_pos (by linarith) (by linarith)).ne']
  calc t X Y * (log (Nxy c X Y / t X Y) - 2) + (n : ℝ) ^ 2 / 6 * (Q n t X Y *
        log (Q n t X Y / P0 n c X Y))
      = t X Y * (log (Nxy c X Y / t X Y) - 2) +
          (n : ℝ) ^ 2 / 6 * Q n t X Y * log (Q n t X Y / P0 n c X Y) := by ring
    _ = t X Y * (log (Nxy c X Y / t X Y) + log (Q n t X Y / P0 n c X Y) - 2) := by
        rw [hQt]; ring
    _ = _ := by rw [hlog]; ring

/-- **Proposition 1.3, exact form.** -/
theorem prop_1_3_exact {n : ℕ} {c : Fin k → ℕ} {t : Fin k → Fin k → ℝ} (hn : 0 < n)
    (hc : ∀ X, 2 ≤ c X) (ht : ∀ X Y, X ≠ Y → 0 < t X Y)
    (hrow : ∀ X, ∑ Y ∈ univ.erase X, t X Y = (c X : ℝ) * (c X - 1) / 2)
    (hadm : 3 * ∑ X, (c X : ℝ) * (c X - 1) = n * (n - 1)) :
    Phi c t - (n : ℝ) ^ 2 / 6 * (log n - 2 - KL n c t) =
      -((n : ℝ) / 6 * (log n - 2)) +
        ∑ X, ∑ Y ∈ univ.erase X, t X Y * log (((c X : ℝ) - 1) / c X) := by
  have hsplit : Phi c t + (n : ℝ) ^ 2 / 6 * KL n c t =
      ∑ X, ∑ Y ∈ univ.erase X, (t X Y * (log n - 2) +
        t X Y * log (((c X : ℝ) - 1) / c X)) := by
    unfold Phi KL
    rw [Finset.mul_sum, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun X _ => ?_
    rw [Finset.mul_sum, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun Y hY => ?_
    have hXY : Y ≠ X := Finset.ne_of_mem_erase hY
    exact term_eq hn (hc X) ((by norm_num : 1 ≤ 2).trans (hc Y)) (ht X Y hXY.symm)
  have hT : ∑ X, ∑ Y ∈ univ.erase X, t X Y = (n : ℝ) * (n - 1) / 6 := by
    rw [Finset.sum_congr rfl fun X _ => hrow X, ← Finset.sum_div]
    linarith
  have hsum : ∑ X, ∑ Y ∈ univ.erase X, (t X Y * (log n - 2) +
      t X Y * log (((c X : ℝ) - 1) / c X)) =
      (n : ℝ) * (n - 1) / 6 * (log n - 2) +
        ∑ X, ∑ Y ∈ univ.erase X, t X Y * log (((c X : ℝ) - 1) / c X) := by
    rw [← hT, Finset.sum_mul, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun X _ => ?_
    rw [Finset.sum_mul, ← Finset.sum_add_distrib]
  have h := hsplit.trans hsum
  linarith

lemma abs_log_sub_one_div {c : ℝ} (hc : 2 ≤ c) : |log ((c - 1) / c)| ≤ 2 / c := by
  have h1 : 0 < c - 1 := by linarith
  have h0 : 0 < c := by linarith
  have hle : (c - 1) / c ≤ 1 := by rw [div_le_one h0]; linarith
  have hneg : log ((c - 1) / c) ≤ 0 := log_nonpos (by positivity) hle
  rw [abs_of_nonpos hneg]
  have hinv : -log ((c - 1) / c) = log (c / (c - 1)) := by
    rw [← log_inv, inv_div]
  rw [hinv]
  have := log_le_sub_one_of_pos (div_pos h0 h1)
  have e : c / (c - 1) - 1 = 1 / (c - 1) := by field_simp; ring
  rw [e] at this
  refine this.trans ?_
  rw [div_le_div_iff₀ h1 h0]
  linarith

/-- **Proposition 1.3.** `|Φ(t) − (n²/6)(log n − 2 − D(Q‖P₀))| ≤ (n/6)|log n − 2| + n`. -/
theorem prop_1_3 {n : ℕ} {c : Fin k → ℕ} {t : Fin k → Fin k → ℝ} (hn : 0 < n)
    (hsize : ∑ X, c X = n) (hc : ∀ X, 2 ≤ c X) (ht : ∀ X Y, X ≠ Y → 0 < t X Y)
    (hrow : ∀ X, ∑ Y ∈ univ.erase X, t X Y = (c X : ℝ) * (c X - 1) / 2)
    (hadm : 3 * ∑ X, (c X : ℝ) * (c X - 1) = n * (n - 1)) :
    |Phi c t - (n : ℝ) ^ 2 / 6 * (log n - 2 - KL n c t)| ≤
      (n : ℝ) / 6 * |log n - 2| + n := by
  rw [prop_1_3_exact hn hc ht hrow hadm]
  have hnR : (0 : ℝ) ≤ n := by positivity
  have hE : |∑ X, ∑ Y ∈ univ.erase X, t X Y * log (((c X : ℝ) - 1) / c X)| ≤ n := by
    calc |∑ X, ∑ Y ∈ univ.erase X, t X Y * log (((c X : ℝ) - 1) / c X)|
        ≤ ∑ X, ∑ Y ∈ univ.erase X, t X Y * (2 / c X) := by
          refine (abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun X _ => ?_)
          refine (abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun Y hY => ?_)
          have hXY : Y ≠ X := Finset.ne_of_mem_erase hY
          rw [abs_mul, abs_of_pos (ht X Y hXY.symm)]
          exact mul_le_mul_of_nonneg_left
            (abs_log_sub_one_div (by exact_mod_cast hc X)) (ht X Y hXY.symm).le
      _ = ∑ X, ((c X : ℝ) - 1) := by
          refine Finset.sum_congr rfl fun X _ => ?_
          rw [← Finset.sum_mul, hrow X]
          have : (0 : ℝ) < c X := by have := hc X; positivity
          field_simp
      _ ≤ ∑ X, (c X : ℝ) := Finset.sum_le_sum fun X _ => by linarith
      _ = n := by exact_mod_cast hsize
  calc |-((n : ℝ) / 6 * (log n - 2)) +
        ∑ X, ∑ Y ∈ univ.erase X, t X Y * log (((c X : ℝ) - 1) / c X)|
      ≤ |-((n : ℝ) / 6 * (log n - 2))| +
        |∑ X, ∑ Y ∈ univ.erase X, t X Y * log (((c X : ℝ) - 1) / c X)| := abs_add_le _ _
    _ ≤ (n : ℝ) / 6 * |log n - 2| + n := by
        rw [abs_neg, abs_mul, abs_of_nonneg (by positivity : (0 : ℝ) ≤ n / 6)]
        linarith

end ColourStats.Prop13
