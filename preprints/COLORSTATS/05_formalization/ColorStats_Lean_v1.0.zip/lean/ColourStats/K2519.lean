/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Phi519

/-!
# Two steps of the gadget walk (Lemma 5.19)

`K₂(e, f) = Σ_g ν_e(g) ν_g(f)` is the kernel of `T²`. For `f` inside the class `A₀`, the
edges `g` with `ν_e(g) ν_g(f) ≠ 0` are the edges inside the common neighbourhood of the
endpoints of `e` and `f` (`K2_eq`). Typicality for sets of four and five vertices gives,
for `e` and `f` disjoint, `|K₂(e, f) − 1/|E₀|| ≤ 19η / M` with `M = ½ |A₀|² d(A₀, A₀)`
(`abs_K2_sub_disjoint`); this replaces the normalisation argument of the paper by a direct
count. For `e` meeting `f`, `K₂(e, f) ≤ 1/(p² m²)`.
-/

@[expose] public section

open Finset

noncomputable section

open Classical

namespace ColourStats.Host519

open Typical Counting

variable {V : Type*} [Fintype V] {k : ℕ}

/-- The kernel of `T²`. -/
def K2 (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) (e f : Edge G) : ℝ :=
  ∑ g, ν G cls A₀ e g * ν G cls A₀ g f

lemma approx_trans {ε₁ ε₂ X Y x : ℝ} (h1 : Approx ε₁ Y x) (h2 : Approx ε₂ X Y) (_hX : 0 ≤ X)
    (hε₁ : 0 ≤ ε₁) : Approx (ε₁ + ε₂ + ε₁ * ε₂) X x := by
  unfold Approx at *
  have hY : Y ≤ (1 + ε₂) * X := by have := (abs_le.mp h2).2; linarith
  calc |x - X| = |(x - Y) + (Y - X)| := by ring_nf
    _ ≤ |x - Y| + |Y - X| := abs_add_le _ _
    _ ≤ ε₁ * Y + ε₂ * X := add_le_add h1 h2
    _ ≤ ε₁ * ((1 + ε₂) * X) + ε₂ * X := by gcongr
    _ = (ε₁ + ε₂ + ε₁ * ε₂) * X := by ring

lemma K2_eq (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) {e f : Edge G}
    (hf : f ∈ EIn G cls A₀ ∅) :
    K2 G cls A₀ e f = ∑ g ∈ EIn G cls A₀ (verts e.1 ∪ verts f.1),
      (1 / ((P G cls A₀ e).card : ℝ)) * (1 / ((P G cls A₀ g).card : ℝ)) := by
  unfold K2
  rw [← Finset.sum_filter_add_sum_filter_not univ
    (fun g => g ∈ EIn G cls A₀ (verts e.1 ∪ verts f.1))]
  have h0 : ∑ g ∈ univ.filter (fun g => ¬ g ∈ EIn G cls A₀ (verts e.1 ∪ verts f.1)),
      ν G cls A₀ e g * ν G cls A₀ g f = 0 := by
    refine Finset.sum_eq_zero fun g hg => ?_
    have hg' := (Finset.mem_filter.mp hg).2
    rw [← mem_P_and_iff G cls A₀ hf] at hg'
    by_cases h1 : g ∈ P G cls A₀ e
    · have h2 : f ∉ P G cls A₀ g := fun h2 => hg' ⟨h1, h2⟩
      simp [ν, h2]
    · simp [ν, h1]
  rw [h0, add_zero, Finset.filter_mem_eq_inter, Finset.univ_inter]
  refine Finset.sum_congr rfl fun g hg => ?_
  obtain ⟨h1, h2⟩ := (mem_P_and_iff G cls A₀ hf g).mpr hg
  simp [ν, h1, h2]

lemma K2_eq_zero (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) {f : Edge G}
    (hf : f ∉ EIn G cls A₀ ∅) (e : Edge G) : K2 G cls A₀ e f = 0 := by
  unfold K2
  refine Finset.sum_eq_zero fun g _ => ?_
  have : f ∉ P G cls A₀ g := by
    intro h
    apply hf
    rw [mem_EIn]
    exact fun v hv => ⟨(mem_P.mp h).2 v hv, by simp⟩
  simp [ν, this]

namespace Hyp

variable {G : SimpleGraph V} {cls : V → Fin k} {d : Fin k → Fin k → ℝ} {A₀ : Fin k}
  {η δ₀ d₀ : ℝ} (H : Hyp G cls d A₀ η δ₀ d₀)
include H

/-- `M = ½ |A₀|² d(A₀, A₀)`. -/
def Mc (_H : Hyp G cls d A₀ η δ₀ d₀) : ℝ :=
  1 / 2 * ((classSet cls A₀).card ^ 2 * d A₀ A₀)

lemma dAA_pos : 0 < d A₀ A₀ := H.d₀_pos.trans_le (H.d_lower A₀ A₀)

lemma c_pos : (0 : ℝ) < (classSet cls A₀).card := by
  have := H.class_lower A₀; have := mul_pos H.δ₀_pos H.m_pos; linarith

lemma Mc_pos : 0 < H.Mc := by
  unfold Mc; have := H.c_pos; have := H.dAA_pos; positivity

lemma Mc_lower : δ₀ ^ 2 * d₀ * (Fintype.card V : ℝ) ^ 2 / 2 ≤ H.Mc := by
  unfold Mc
  have h1 := H.class_lower A₀
  have h0 : 0 ≤ δ₀ * Fintype.card V := (mul_pos H.δ₀_pos H.m_pos).le
  have h2 : (δ₀ * Fintype.card V) ^ 2 ≤ ((classSet cls A₀).card : ℝ) ^ 2 :=
    pow_le_pow_left₀ h0 h1 2
  have h3 := H.d_lower A₀ A₀
  have := H.d₀_pos
  nlinarith [mul_le_mul h2 h3 this.le (by positivity)]

lemma approx_card_E₀ : Approx (2 * η + η ^ 2) H.Mc (EIn G cls A₀ ∅).card := by
  rw [card_EIn]
  have := card_edgesIn_commonIn H.typ H.η_nonneg (by linarith [H.η_small]) H.d_nonneg
    (S := (∅ : Finset V)) (by simp) A₀
  simpa [ideal, Mc] using this

lemma card_E₀_lower : δ₀ ^ 2 * d₀ * (Fintype.card V : ℝ) ^ 2 / 4 ≤ (EIn G cls A₀ ∅).card := by
  have h := H.approx_card_E₀.lower
  have := H.ε_le
  have := H.Mc_lower
  have := H.Mc_pos
  nlinarith

lemma card_E₀_pos : (0 : ℝ) < (EIn G cls A₀ ∅).card := by
  have := H.card_E₀_lower
  have := mul_pos (mul_pos (pow_pos H.δ₀_pos 2) H.d₀_pos) (pow_pos H.m_pos 2)
  linarith

/-- `|P_g| ≈_ε P₀` for `g` inside the class. -/
lemma approx_card_P_class {g : Edge G} (hg : g ∈ EIn G cls A₀ ∅) :
    Approx (2 * η + η ^ 2)
      (1 / 2 * (((classSet cls A₀).card * (d A₀ A₀ * d A₀ A₀)) ^ 2 * d A₀ A₀))
      (P G cls A₀ g).card := by
  have h := H.approx_card_P g
  rw [ideal_verts H g] at h
  have h1 := (mem_EIn.mp hg g.1.out.1 (out1_mem _)).1
  have h2 := (mem_EIn.mp hg g.1.out.2 (out2_mem _)).1
  rwa [h1, h2] at h

/-- **`K₂` on disjoint pairs.** -/
lemma abs_K2_sub_disjoint {e f : Edge G} (hf : f ∈ EIn G cls A₀ ∅)
    (hdisj : Disjoint (verts e.1) (verts f.1)) :
    |K2 G cls A₀ e f - 1 / (EIn G cls A₀ ∅).card| ≤ 19 * η / H.Mc := by
  set ε := 2 * η + η ^ 2 with hε
  have hε0 : 0 ≤ ε := H.ε_nonneg
  have hε1 : ε ≤ 21 / 100 := H.ε_le
  set c : ℝ := ((classSet cls A₀).card : ℝ)
  set D : ℝ := d A₀ A₀
  set Ie : ℝ := ideal cls d (verts e.1) A₀
  have hc := H.c_pos
  have hD := H.dAA_pos
  have hIe : 0 < Ie := by
    have := H.ideal_verts_lower e
    have := mul_pos (mul_pos H.δ₀_pos H.m_pos) (pow_pos H.d₀_pos 2)
    linarith
  -- the support of `K₂`
  set S := verts e.1 ∪ verts f.1
  have hS : S.card = 4 := by
    rw [Finset.card_union_of_disjoint hdisj, H.verts_card e, H.verts_card f]
  have hIS : ideal cls d S A₀ = Ie * (D * D) := by
    unfold ideal
    rw [Finset.prod_union hdisj]
    have hf1 := (mem_EIn.mp hf f.1.out.1 (out1_mem _)).1
    have hf2 := (mem_EIn.mp hf f.1.out.2 (out2_mem _)).1
    have hprod : ∏ v ∈ verts f.1, d (cls v) A₀ = D * D := by
      unfold verts
      rw [Finset.prod_pair (G.ne_of_adj (adj_out G f)), hf1, hf2]
    rw [hprod]
    rw [show Ie = ideal cls d (verts e.1) A₀ from rfl]
    unfold ideal
    ring
  have hQ : Approx ε (1 / 2 * ((Ie * (D * D)) ^ 2 * D)) (EIn G cls A₀ S).card := by
    rw [card_EIn, ← hIS]
    exact card_edgesIn_commonIn H.typ H.η_nonneg (by linarith [H.η_small]) H.d_nonneg
      (by rw [hS]) A₀
  -- the terms
  set Pe : ℝ := 1 / 2 * (Ie ^ 2 * D)
  set P0 : ℝ := 1 / 2 * ((c * (D * D)) ^ 2 * D)
  have hPe : 0 < Pe := by positivity
  have hP0 : 0 < P0 := by positivity
  have hinvPe : Approx (2 * ε) (1 / Pe) (1 / (P G cls A₀ e).card) :=
    (H.approx_card_P e).inv hPe (by linarith)
  have hterm : ∀ g ∈ EIn G cls A₀ S, Approx (2 * ε + 2 * ε + 2 * ε * (2 * ε))
      (1 / Pe * (1 / P0)) (1 / (P G cls A₀ e).card * (1 / (P G cls A₀ g).card)) := by
    intro g hg
    have hgc : g ∈ EIn G cls A₀ ∅ := by
      rw [mem_EIn] at hg ⊢
      exact fun v hv => ⟨(hg v hv).1, by simp⟩
    have hinvPg : Approx (2 * ε) (1 / P0) (1 / (P G cls A₀ g).card) :=
      (H.approx_card_P_class hgc).inv hP0 (by linarith)
    exact hinvPe.mul hinvPg (by positivity) (by positivity) (by linarith) (by linarith)
  have hsum := approx_sum hterm
  have hK2 := K2_eq G cls A₀ (e := e) hf
  rw [show verts e.1 ∪ verts f.1 = S from rfl] at hK2
  rw [← hK2] at hsum
  -- combine with `|Q|`
  set ε₂ : ℝ := 2 * ε + 2 * ε + 2 * ε * (2 * ε)
  have hε₂ : 0 ≤ ε₂ := by positivity
  have hQ' : Approx ε (1 / 2 * ((Ie * (D * D)) ^ 2 * D) * (1 / Pe * (1 / P0)))
      ((EIn G cls A₀ S).card * (1 / Pe * (1 / P0))) := by
    have := hQ.smul (c := 1 / Pe * (1 / P0)) (by positivity)
    convert this using 1 <;> ring
  have hK := approx_trans hsum hQ' (by positivity) hε₂
  have hval : 1 / 2 * ((Ie * (D * D)) ^ 2 * D) * (1 / Pe * (1 / P0)) = 1 / H.Mc := by
    have hMc : H.Mc = 1 / 2 * (c ^ 2 * D) := rfl
    have hc' : c ≠ 0 := hc.ne'
    have hD' : D ≠ 0 := hD.ne'
    have hIe' : Ie ≠ 0 := hIe.ne'
    rw [hMc, show Pe = 1 / 2 * (Ie ^ 2 * D) from rfl,
      show P0 = 1 / 2 * ((c * (D * D)) ^ 2 * D) from rfl]
    field_simp
  rw [hval] at hK
  have hN := (H.approx_card_E₀).inv H.Mc_pos (by linarith)
  -- final estimate
  have hMinv : 0 < 1 / H.Mc := one_div_pos.mpr H.Mc_pos
  unfold Approx at hK hN
  have htot : |K2 G cls A₀ e f - 1 / (EIn G cls A₀ ∅).card| ≤
      (ε₂ + ε + ε₂ * ε) * (1 / H.Mc) + 2 * ε * (1 / H.Mc) := by
    calc |K2 G cls A₀ e f - 1 / (EIn G cls A₀ ∅).card|
        = |(K2 G cls A₀ e f - 1 / H.Mc) - (1 / (EIn G cls A₀ ∅).card - 1 / H.Mc)| := by
          ring_nf
      _ ≤ |K2 G cls A₀ e f - 1 / H.Mc| + |1 / (EIn G cls A₀ ∅).card - 1 / H.Mc| :=
          abs_sub _ _
      _ ≤ _ := add_le_add hK hN
  refine htot.trans ?_
  rw [div_eq_mul_one_div (19 * η)]
  have hη := H.η_nonneg
  have hη1 := H.η_small
  have hcoef : ε₂ + ε + ε₂ * ε + 2 * ε ≤ 19 * η := by
    simp only [ε₂, hε]
    nlinarith [mul_nonneg hη hη, mul_nonneg (mul_nonneg hη hη) hη,
      mul_nonneg (mul_nonneg (mul_nonneg hη hη) hη) hη]
  nlinarith [mul_le_mul_of_nonneg_right hcoef hMinv.le]

/-- `K₂(e, f) ≤ 1/(p² m²)`. -/
lemma K2_le (e f : Edge G) :
    K2 G cls A₀ e f ≤ 1 / (pconst δ₀ d₀ ^ 2 * (Fintype.card V : ℝ) ^ 2) := by
  have hp := H.p_pos
  have hm := H.m_pos
  set q : ℝ := 1 / (pconst δ₀ d₀ * (Fintype.card V : ℝ) ^ 2)
  have hq : 0 ≤ q := by positivity
  unfold K2
  calc ∑ g, ν G cls A₀ e g * ν G cls A₀ g f ≤ ∑ _g : Edge G, q * q :=
        Finset.sum_le_sum fun g _ => mul_le_mul (H.ν_le e g) (H.ν_le g f) (H.ν_nonneg g f) hq
    _ = Fintype.card (Edge G) * (q * q) := by simp
    _ ≤ (Fintype.card V : ℝ) ^ 2 * (q * q) :=
        mul_le_mul_of_nonneg_right (card_edge_le G) (by positivity)
    _ = 1 / (pconst δ₀ d₀ ^ 2 * (Fintype.card V : ℝ) ^ 2) := by
        simp only [q]; field_simp

lemma K2_nonneg (e f : Edge G) : 0 ≤ K2 G cls A₀ e f :=
  Finset.sum_nonneg fun g _ => mul_nonneg (H.ν_nonneg e g) (H.ν_nonneg g f)

end Hyp

end ColourStats.Host519
