/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Challenge
public import ColourStats.Typical

/-!
# Statements: the remaining results of Section 1

Target statements of the paper (draft 6), as `Prop`s; nothing here is proved. Together with
`ColourStats.Challenge` (Theorems 1.2 and 1.5) this covers every numbered result of
Section 1.

* `Theorem_1_1`: Latin squares with a prescribed outline;
* `Corollary_1_4`: bicoloured Steiner triple systems with three almost equal classes;
* `Corollary_1_6`: large deviations of the type statistics of a random Steiner triple
  system, in the counting form `CountLDP`;
* `Theorem_1_7`, `Theorem_1_7_upper`: 1-factorizations of `K_n` with prescribed types;
* `Corollary_1_8`: large deviations for 1-factorizations;
* `Theorem_1_9a`, `Theorem_1_9a_upper`, `Theorem_1_9b`: triangle decompositions of typical
  graphs;
* `Theorem_1_10`: polynomial error terms;
* `Corollary_1_11`: counting completions of a partial Steiner triple system.

Choices made in the statements (the paper leaves them implicit):
* In Theorem 1.1 the lower bound assumes the margin identities of `M`
  (`OutlineMargins`); without them there is no Latin square with outline `M`.
* The large-deviation principles are stated through counts (`CountLDP`): for closed `F`
  and every `r` below the rate on `F`, eventually `#{Q_n ∈ F} ≤ total · e^{−s r}`; for
  open `U`, `Q ∈ U` feasible and `ε > 0`, eventually `#{Q_n ∈ U} ≥ total · e^{−s(I(Q)+ε)}`.
  These are the two LDP bounds for a rate that is continuous on a compact feasible set.
* Theorem 1.10 covers Theorems 1.1 (lower half), 1.2, 1.5, 1.7 and 1.9(a). Its claim about
  Corollaries 1.6 and 1.8 does not say which neighbourhoods are meant, so it is not stated.
-/

@[expose] public section

open Finset Filter Topology
open Real (log exp sqrt negMulLog)

namespace ColourStats.Statements

open ColourStats

/-! ### Shared notions -/

/-- Large deviations in counting form. `count n A` counts the objects of size `n` whose
normalised statistic lies in `A`, out of `total n`; the speed is `speed n`, the feasible set
`Feas` and the rate `I` on it (the rate is `+∞` off `Feas`). -/
def CountLDP {ι : Type} [Fintype ι] (adm : ℕ → Prop) (total : ℕ → ℝ)
    (count : ℕ → Set (ι → ℝ) → ℝ) (speed : ℕ → ℝ) (Feas : Set (ι → ℝ))
    (I : (ι → ℝ) → ℝ) : Prop :=
  (∀ F : Set (ι → ℝ), IsClosed F → ∀ r : ℝ, (∀ Q ∈ F, Q ∈ Feas → r < I Q) →
      ∀ᶠ n in atTop, adm n → count n F ≤ total n * exp (-(speed n * r))) ∧
    ∀ U : Set (ι → ℝ), IsOpen U → ∀ Q ∈ U, Q ∈ Feas → ∀ ε : ℝ, 0 < ε →
      ∀ᶠ n in atTop, adm n → total n * exp (-(speed n * (I Q + ε))) ≤ count n U

/-- Relative entropy `D(Q‖P) = Σ Q log(Q/P)`, with `0 log(0/P) = 0`. -/
noncomputable def KL {ι : Type} [Fintype ι] (Q P : ι → ℝ) : ℝ :=
  ∑ i, Q i * log (Q i / P i)

/-! ### Theorem 1.1: Latin squares -/

section Latin

variable {n a b c : ℕ}

/-- The outline `M(i, j, l) = #{(r, c) : r ∈ R_i, c ∈ C_j, L(r, c) ∈ S_l}`. -/
noncomputable def outline (R : Fin n → Fin a) (C : Fin n → Fin b) (S : Fin n → Fin c)
    (L : Fin n → Fin n → Fin n) (i : Fin a) (j : Fin b) (l : Fin c) : ℕ := by
  classical
  exact (univ.filter fun rc : Fin n × Fin n =>
    R rc.1 = i ∧ C rc.2 = j ∧ S (L rc.1 rc.2) = l).card

/-- `#LS(M)`: the number of Latin squares of order `n` with outline `M`. -/
noncomputable def numLS (R : Fin n → Fin a) (C : Fin n → Fin b) (S : Fin n → Fin c)
    (M : Fin a → Fin b → Fin c → ℕ) : ℕ :=
  Nat.card {L : Fin n → Fin n → Fin n // STS.IsLatin L ∧ outline R C S L = M}

/-- The size of a class. -/
noncomputable def csize {m : ℕ} (P : Fin n → Fin m) (i : Fin m) : ℕ := by
  classical
  exact (univ.filter fun v => P v = i).card

/-- Total correlation `TC(Q) = H(R) + H(C) + H(S) − H(R, C, S)`. -/
noncomputable def TC (Q : Fin a → Fin b → Fin c → ℝ) : ℝ :=
  ∑ i, negMulLog (∑ j, ∑ l, Q i j l) + ∑ j, negMulLog (∑ i, ∑ l, Q i j l) +
    ∑ l, negMulLog (∑ i, ∑ j, Q i j l) - ∑ i, ∑ j, ∑ l, negMulLog (Q i j l)

/-- The margin identities satisfied by every outline:
`Σ_l M(i,j,l) = |R_i||C_j|`, `Σ_j M(i,j,l) = |R_i||S_l|`, `Σ_i M(i,j,l) = |C_j||S_l|`. -/
def OutlineMargins (R : Fin n → Fin a) (C : Fin n → Fin b) (S : Fin n → Fin c)
    (M : Fin a → Fin b → Fin c → ℕ) : Prop :=
  (∀ i j, ∑ l, M i j l = csize R i * csize C j) ∧
    (∀ i l, ∑ j, M i j l = csize R i * csize S l) ∧
    ∀ j l, ∑ i, M i j l = csize C j * csize S l

/-- The hypotheses of Theorem 1.1: class proportions at least `δ₀`, `Q = M/n² ≥ ζ`. -/
def LSHyp (δ₀ ζ : ℝ) (R : Fin n → Fin a) (C : Fin n → Fin b) (S : Fin n → Fin c)
    (M : Fin a → Fin b → Fin c → ℕ) : Prop :=
  (∀ i, δ₀ * n ≤ csize R i) ∧ (∀ j, δ₀ * n ≤ csize C j) ∧ (∀ l, δ₀ * n ≤ csize S l) ∧
    ∀ i j l, ζ ≤ (M i j l : ℝ) / (n : ℝ) ^ 2

/-- **Theorem 1.1.** For fixed numbers of classes and `δ₀, ζ > 0`:
(1.1) `log #LS(M) ≤ n²(log n − 2 − TC(Q)) + O(n log² n)`, and
(1.2) `log #LS(M) ≥ n²(log n − 2 − TC(Q)) − o(n²)` (for outlines with the margin
identities), uniformly in the partitions and in `M`. -/
def Theorem_1_1 : Prop :=
  ∀ a b c : ℕ, ∀ δ₀ ζ : ℝ, 0 < δ₀ → 0 < ζ →
    (∃ K : ℝ, ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → ∀ (R : Fin n → Fin a) (C : Fin n → Fin b)
        (S : Fin n → Fin c) (M : Fin a → Fin b → Fin c → ℕ), LSHyp δ₀ ζ R C S M →
        log (numLS R C S M) ≤ (n : ℝ) ^ 2 *
          (log n - 2 - TC (fun i j l => (M i j l : ℝ) / (n : ℝ) ^ 2)) +
            K * n * (log n) ^ 2) ∧
    ∀ ε : ℝ, 0 < ε → ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → ∀ (R : Fin n → Fin a) (C : Fin n → Fin b)
        (S : Fin n → Fin c) (M : Fin a → Fin b → Fin c → ℕ), LSHyp δ₀ ζ R C S M →
        OutlineMargins R C S M →
        (n : ℝ) ^ 2 * (log n - 2 - TC (fun i j l => (M i j l : ℝ) / (n : ℝ) ^ 2)) -
          ε * (n : ℝ) ^ 2 ≤ log (numLS R C S M)

end Latin

/-! ### Corollaries 1.4 and 1.6: Steiner triple systems -/

section STS

variable {n k : ℕ}

/-- A family of blocks is bicoloured if every block meets exactly two classes. -/
def IsBicoloured (lab : Fin n → Fin k) (D : Finset (Finset (Fin n))) : Prop :=
  ∀ B ∈ D, (B.image lab).card = 2

/-- The number of Steiner triple systems on `Fin n` bicoloured with respect to `lab`. -/
noncomputable def countBicol (lab : Fin n → Fin k) : ℕ :=
  Nat.card {D : STS.STSOn n // IsBicoloured lab D.1}

/-- **Corollary 1.4.** For three admissible classes of sizes `n/3 + O(√n)`, the number of
bicoloured Steiner triple systems is `((2/3 + o(1)) n/e²)^{n²/6}`. -/
def Corollary_1_4 : Prop :=
  ∀ K ε : ℝ, 0 < ε → ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → ∀ lab : Fin n → Fin 3, Admissible lab →
    (∀ X, |(classSize lab X : ℝ) - n / 3| ≤ K * sqrt n) →
    |log (countBicol lab) - (n : ℝ) ^ 2 / 6 * (log n + log (2 / 3) - 2)| ≤ ε * (n : ℝ) ^ 2

/-- The law `P` of the unordered type of three independent classes with law `γ`. -/
noncomputable def typeLaw (γ : Fin k → ℝ) (τ : Multiset (Fin k)) : ℝ := by
  classical
  exact ∑ x : Fin k × Fin k × Fin k,
    if ({x.1, x.2.1, x.2.2} : Multiset (Fin k)) = τ then γ x.1 * γ x.2.1 * γ x.2.2 else 0

/-- The class law of a uniformly random pair: `w_{XY} = 2γ_Xγ_Y`, `w_{XX} = γ_X²`. -/
noncomputable def pairLaw (γ : Fin k → ℝ) (π : Multiset (Fin k)) : ℝ := by
  classical
  exact ∑ x : Fin k × Fin k, if ({x.1, x.2} : Multiset (Fin k)) = π then γ x.1 * γ x.2 else 0

/-- `F_γ`: probability vectors on types with `Σ_τ m_π(τ) Q_τ = 3 w_π`. -/
def feasSTS (γ : Fin k → ℝ) : Set (blockTypes k → ℝ) :=
  {Q | (∀ τ, 0 ≤ Q τ) ∧ ∑ τ, Q τ = 1 ∧
    ∀ π ∈ pairTypes k, ∑ τ : blockTypes k, (mult π τ : ℝ) * Q τ = 3 * pairLaw γ π}

/-- The normalised type vector `Q_τ = 6 t_τ / n²` of a family of blocks. -/
noncomputable def normTypes (lab : Fin n → Fin k) (D : Finset (Finset (Fin n))) :
    blockTypes k → ℝ :=
  fun τ => 6 * (typeCount lab D τ : ℝ) / (n : ℝ) ^ 2

/-- **Corollary 1.6.** For partitions with `c_X/n → γ_X > 0`, the normalised type vector of a
uniformly random Steiner triple system satisfies a large-deviation principle with speed
`n²/6` and rate `D(Q‖P)` on `F_γ` (`+∞` elsewhere). -/
def Corollary_1_6 : Prop :=
  ∀ k : ℕ, 1 ≤ k → ∀ γ : Fin k → ℝ, (∀ X, 0 < γ X) → ∑ X, γ X = 1 →
    ∀ labs : (n : ℕ) → Fin n → Fin k,
      (∀ X, Tendsto (fun n => (classSize (labs n) X : ℝ) / n) atTop (𝓝 (γ X))) →
      CountLDP (fun n => n % 6 = 1 ∨ n % 6 = 3) (fun n => (STS.D n : ℝ))
        (fun n A => (Nat.card {D : STS.STSOn n // normTypes (labs n) D.1 ∈ A} : ℝ))
        (fun n => (n : ℝ) ^ 2 / 6) (feasSTS γ)
        (fun Q => KL Q (fun τ => typeLaw γ τ))

end STS

/-! ### Theorem 1.7 and Corollary 1.8: 1-factorizations -/

section OneFact

variable {n k ℓ : ℕ}

/-- The edges of `K_n`. -/
abbrev KEdge (n : ℕ) := {e : Sym2 (Fin n) // ¬ e.IsDiag}

/-- A 1-factorization of `K_n` with labelled colours: a proper edge colouring with the
`n − 1` colours of `Fin (n − 1)`. -/
def IsOneFact (f : KEdge n → Fin (n - 1)) : Prop :=
  ∀ e e' : KEdge n, e ≠ e' → (∃ v, v ∈ e.1 ∧ v ∈ e'.1) → f e ≠ f e'

/-- The pair class of an edge. -/
def edgeClass (lab : Fin n → Fin k) (e : KEdge n) : Multiset (Fin k) :=
  Sym2.toMultiset (e.1.map lab)

/-- The number of edges of type `(π, Γ)`. -/
noncomputable def edgeTypeCount (lab : Fin n → Fin k) (col : Fin (n - 1) → Fin ℓ)
    (f : KEdge n → Fin (n - 1)) (π : Multiset (Fin k)) (Γ : Fin ℓ) : ℕ := by
  classical
  exact (univ.filter fun e : KEdge n => edgeClass lab e = π ∧ col (f e) = Γ).card

/-- `N^{1F}_t`: the number of 1-factorizations with type vector `t`. -/
noncomputable def count1F (lab : Fin n → Fin k) (col : Fin (n - 1) → Fin ℓ)
    (t : Multiset (Fin k) → Fin ℓ → ℕ) : ℕ :=
  Nat.card {f : KEdge n → Fin (n - 1) // IsOneFact f ∧
    ∀ π ∈ pairTypes k, ∀ Γ, edgeTypeCount lab col f π Γ = t π Γ}

/-- The size `h_Γ` of a colour class. -/
noncomputable def colSize (col : Fin (n - 1) → Fin ℓ) (Γ : Fin ℓ) : ℕ := by
  classical
  exact (univ.filter fun x => col x = Γ).card

/-- The identities (1.5): `Σ_Γ t(π, Γ) = e_π` and `Σ_π m_X(π) t(π, Γ) = c_X h_Γ`. -/
def Identities1F (lab : Fin n → Fin k) (col : Fin (n - 1) → Fin ℓ)
    (t : Multiset (Fin k) → Fin ℓ → ℕ) : Prop :=
  (∀ π ∈ pairTypes k, ∑ Γ, t π Γ = numPairs lab π) ∧
    ∀ X Γ, ∑ π ∈ pairTypes k, π.count X * t π Γ = classSize lab X * colSize col Γ

/-- `Φ(t) = Σ_{π,Γ} t (log(e_π h_Γ / t) − 2)`. -/
noncomputable def Phi1F (lab : Fin n → Fin k) (col : Fin (n - 1) → Fin ℓ)
    (t : Multiset (Fin k) → Fin ℓ → ℕ) : ℝ :=
  ∑ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ) *
    (log ((numPairs lab π : ℝ) * colSize col Γ / t π Γ) - 2)

/-- **Theorem 1.7.** `log N^{1F}_t = Φ(t) + o(n²)` for `t` satisfying (1.5) with all entries
at least `ζ n²`, uniformly. -/
def Theorem_1_7 : Prop :=
  ∀ k ℓ : ℕ, 1 ≤ k → 1 ≤ ℓ → ∀ δ₀ ζ ε : ℝ, 0 < δ₀ → 0 < ζ → 0 < ε → ∃ n₀ : ℕ,
    ∀ n : ℕ, n₀ ≤ n → Even n → ∀ (lab : Fin n → Fin k) (col : Fin (n - 1) → Fin ℓ),
      (∀ X, δ₀ * n ≤ classSize lab X) → (∀ Γ, δ₀ * n ≤ colSize col Γ) →
      ∀ t : Multiset (Fin k) → Fin ℓ → ℕ, Identities1F lab col t →
        (∀ π ∈ pairTypes k, ∀ Γ, ζ * (n : ℝ) ^ 2 ≤ t π Γ) →
        |log (count1F lab col t) - Phi1F lab col t| ≤ ε * (n : ℝ) ^ 2

/-- **Theorem 1.7, upper half**, for every `t` satisfying (1.5). -/
def Theorem_1_7_upper : Prop :=
  ∀ k ℓ : ℕ, 1 ≤ k → 1 ≤ ℓ → ∀ δ₀ ε : ℝ, 0 < δ₀ → 0 < ε → ∃ n₀ : ℕ,
    ∀ n : ℕ, n₀ ≤ n → Even n → ∀ (lab : Fin n → Fin k) (col : Fin (n - 1) → Fin ℓ),
      (∀ X, δ₀ * n ≤ classSize lab X) → (∀ Γ, δ₀ * n ≤ colSize col Γ) →
      ∀ t : Multiset (Fin k) → Fin ℓ → ℕ, Identities1F lab col t →
        log (count1F lab col t) ≤ Phi1F lab col t + ε * (n : ℝ) ^ 2

/-- The feasible set of Corollary 1.8: probability vectors `Q` on (pair class, colour class)
with `Σ_Γ Q(π, Γ) = w_π` and `Σ_π m_X(π) Q(π, Γ) = 2 γ_X η_Γ`. -/
def feas1F (γ : Fin k → ℝ) (η : Fin ℓ → ℝ) : Set (pairTypes k × Fin ℓ → ℝ) :=
  {Q | (∀ i, 0 ≤ Q i) ∧ ∑ i, Q i = 1 ∧
    (∀ π : pairTypes k, ∑ Γ, Q (π, Γ) = pairLaw γ π) ∧
    ∀ X Γ, ∑ π : pairTypes k, ((π : Multiset (Fin k)).count X : ℝ) * Q (π, Γ) =
      2 * γ X * η Γ}

/-- The normalised type vector `Q = t / C(n, 2)` of an edge colouring. -/
noncomputable def normTypes1F (lab : Fin n → Fin k) (col : Fin (n - 1) → Fin ℓ)
    (f : KEdge n → Fin (n - 1)) : pairTypes k × Fin ℓ → ℝ :=
  fun i => (edgeTypeCount lab col f i.1 i.2 : ℝ) / (n.choose 2 : ℝ)

/-- **Corollary 1.8.** For vertex partitions with `c_X/n → γ_X > 0` and colour partitions with
`h_Γ/(n − 1) → η_Γ > 0`, the normalised type vector of a uniformly random 1-factorization
satisfies a large-deviation principle with speed `C(n, 2)` and rate `D(Q‖P)`,
`P(π, Γ) = w_π η_Γ`, on the feasible set. -/
def Corollary_1_8 : Prop :=
  ∀ k ℓ : ℕ, 1 ≤ k → 1 ≤ ℓ → ∀ (γ : Fin k → ℝ) (η : Fin ℓ → ℝ), (∀ X, 0 < γ X) →
    (∀ Γ, 0 < η Γ) → ∑ X, γ X = 1 → ∑ Γ, η Γ = 1 →
    ∀ (labs : (n : ℕ) → Fin n → Fin k) (cols : (n : ℕ) → Fin (n - 1) → Fin ℓ),
      (∀ X, Tendsto (fun n => (classSize (labs n) X : ℝ) / n) atTop (𝓝 (γ X))) →
      (∀ Γ, Tendsto (fun n => (colSize (cols n) Γ : ℝ) / (n - 1)) atTop (𝓝 (η Γ))) →
      CountLDP (fun n => Even n)
        (fun n => (Nat.card {f : KEdge n → Fin (n - 1) // IsOneFact f} : ℝ))
        (fun n A => (Nat.card {f : KEdge n → Fin (n - 1) //
          IsOneFact f ∧ normTypes1F (labs n) (cols n) f ∈ A} : ℝ))
        (fun n => (n.choose 2 : ℝ)) (feas1F γ η)
        (fun Q => KL Q (fun i => pairLaw γ i.1 * η i.2))

end OneFact

/-! ### Theorem 1.9: typical graphs -/

section Typical

variable {n k : ℕ}

open Classical in
/-- `D` is a triangle decomposition of `G`: its members are triangles of `G` and every edge of
`G` lies in exactly one of them. -/
def IsTriDecomp (G : SimpleGraph (Fin n)) (D : Finset (Finset (Fin n))) : Prop :=
  (∀ B ∈ D, B.card = 3 ∧ ∀ x ∈ B, ∀ y ∈ B, x ≠ y → G.Adj x y) ∧
    ∀ x y, G.Adj x y → ∃! B, B ∈ D ∧ x ∈ B ∧ y ∈ B

open Classical in
/-- `G` is triangle-divisible: all degrees are even and `3 ∣ e(G)`. -/
def TriDivisible (G : SimpleGraph (Fin n)) : Prop :=
  (∀ v, Even (univ.filter (G.Adj v)).card) ∧
    3 ∣ ((univ : Finset (Fin n)).powersetCard 2 |>.filter fun e =>
      ∀ x ∈ e, ∀ y ∈ e, x ≠ y → G.Adj x y).card

open Classical in
/-- `e_π(G)`: the number of edges of `G` of class `π`. -/
noncomputable def edgesOf (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k)
    (π : Multiset (Fin k)) : ℕ :=
  ((univ : Finset (Fin n)).powersetCard 2 |>.filter fun e =>
    (∀ x ∈ e, ∀ y ∈ e, x ≠ y → G.Adj x y) ∧ blockType lab e = π).card

open Classical in
/-- `N_τ(G)`: the number of triangles of `G` of type `τ`. -/
noncomputable def trianglesOf (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k)
    (τ : Multiset (Fin k)) : ℕ :=
  ((univ : Finset (Fin n)).powersetCard 3 |>.filter fun B =>
    (∀ x ∈ B, ∀ y ∈ B, x ≠ y → G.Adj x y) ∧ blockType lab B = τ).card

/-- The pair identities (1.6) of `G`, for a real type vector. -/
def PairIdentitiesG (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k)
    (t : Multiset (Fin k) → ℝ) : Prop :=
  ∀ π ∈ pairTypes k, ∑ τ ∈ blockTypes k, (mult π τ : ℝ) * t τ = edgesOf G lab π

/-- `Φ_G(t) = Σ_τ t_τ (log(N_τ(G)/t_τ) − 2)`, for a real type vector. -/
noncomputable def PhiG (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k)
    (t : Multiset (Fin k) → ℝ) : ℝ :=
  ∑ τ ∈ blockTypes k, t τ * (log ((trianglesOf G lab τ : ℝ) / t τ) - 2)

/-- The number of triangle decompositions of `G` with type vector `t`. -/
noncomputable def countDecomp (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k)
    (t : Multiset (Fin k) → ℕ) : ℕ :=
  Nat.card {D : Finset (Finset (Fin n)) // IsTriDecomp G D ∧
    ∀ τ ∈ blockTypes k, typeCount lab D τ = t τ}

/-- The number of triangle decompositions of `G`. -/
noncomputable def countAllDecomp (G : SimpleGraph (Fin n)) : ℕ :=
  Nat.card {D : Finset (Finset (Fin n)) // IsTriDecomp G D}

open Classical in
/-- The hypotheses of Theorem 1.9 on `G`: triangle-divisible, classes of size `≥ δ₀ n`,
`(n^{−c₀}, 5)`-typical with densities at least `d₀`. -/
def TypHyp (c₀ δ₀ d₀ : ℝ) (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k) : Prop :=
  TriDivisible G ∧ (∀ X, δ₀ * n ≤ classSize lab X) ∧
    ∃ d : Fin k → Fin k → ℝ, (∀ X Y, d₀ ≤ d X Y) ∧
      Typical.IsTypical G lab d ((n : ℝ) ^ (-c₀)) 5

/-- **Theorem 1.9(a).** `#decompositions with type t = exp(Φ_G(t) + o(n²))` for `t`
satisfying (1.6) with all entries at least `ζ n²`. -/
def Theorem_1_9a : Prop :=
  ∀ k : ℕ, 1 ≤ k → ∀ c₀ δ₀ d₀ ζ ε : ℝ, 0 < c₀ → 0 < δ₀ → 0 < d₀ → 0 < ζ → 0 < ε →
    ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → ∀ (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k),
      TypHyp c₀ δ₀ d₀ G lab → ∀ t : Multiset (Fin k) → ℕ,
        PairIdentitiesG G lab (fun τ => t τ) →
        (∀ τ ∈ blockTypes k, ζ * (n : ℝ) ^ 2 ≤ t τ) →
        |log (countDecomp G lab t) - PhiG G lab (fun τ => t τ)| ≤ ε * (n : ℝ) ^ 2

/-- **Theorem 1.9(a), upper half**, for every `t` satisfying (1.6). -/
def Theorem_1_9a_upper : Prop :=
  ∀ k : ℕ, 1 ≤ k → ∀ c₀ δ₀ d₀ ε : ℝ, 0 < c₀ → 0 < δ₀ → 0 < d₀ → 0 < ε →
    ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → ∀ (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k),
      TypHyp c₀ δ₀ d₀ G lab → ∀ t : Multiset (Fin k) → ℕ,
        PairIdentitiesG G lab (fun τ => t τ) →
        log (countDecomp G lab t) ≤ PhiG G lab (fun τ => t τ) + ε * (n : ℝ) ^ 2

/-- **Theorem 1.9(b).** If some real `t ≥ 0` satisfying (1.6) has all entries at least
`ζ n²`, the number of triangle decompositions is `exp(max Φ_G + o(n²))`, the maximum over
real `t ≥ 0` satisfying (1.6). -/
def Theorem_1_9b : Prop :=
  ∀ k : ℕ, 1 ≤ k → ∀ c₀ δ₀ d₀ ζ ε : ℝ, 0 < c₀ → 0 < δ₀ → 0 < d₀ → 0 < ζ → 0 < ε →
    ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → ∀ (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k),
      TypHyp c₀ δ₀ d₀ G lab →
      (∃ t : Multiset (Fin k) → ℝ, PairIdentitiesG G lab t ∧
        ∀ τ ∈ blockTypes k, ζ * (n : ℝ) ^ 2 ≤ t τ) →
      |log (countAllDecomp G) - sSup {x | ∃ t : Multiset (Fin k) → ℝ,
          (∀ τ, 0 ≤ t τ) ∧ PairIdentitiesG G lab t ∧ x = PhiG G lab t}| ≤ ε * (n : ℝ) ^ 2

end Typical

/-! ### Theorem 1.10 and Corollary 1.11 -/

section Poly

variable {n k : ℕ}

/-- Theorem 1.10 for Theorem 1.2. -/
def Theorem_1_10_bicol : Prop :=
  ∀ k : ℕ, 3 ≤ k → ∀ δ₀ ζ : ℝ, 0 < δ₀ → 0 < ζ → ∃ c K : ℝ, 0 < c ∧ ∃ n₀ : ℕ,
    ∀ n : ℕ, n₀ ≤ n → ∀ lab : Fin n → Fin k, Admissible lab →
      (∀ X, δ₀ * n ≤ classSize lab X) →
      ∀ t : Fin k → Fin k → ℕ, BicolConditions lab t →
        (∀ X Y, X ≠ Y → ζ * (n : ℝ) ^ 2 ≤ t X Y) →
        |log (countAll lab (bicolTypes t)) - Phi lab (bicolTypes t)| ≤
          K * (n : ℝ) ^ (2 - c)

/-- Theorem 1.10 for Theorem 1.5. -/
def Theorem_1_10_all : Prop :=
  ∀ k : ℕ, 1 ≤ k → ∀ δ₀ ζ : ℝ, 0 < δ₀ → 0 < ζ → ∃ c K : ℝ, 0 < c ∧ ∃ n₀ : ℕ,
    ∀ n : ℕ, n₀ ≤ n → (n % 6 = 1 ∨ n % 6 = 3) → ∀ lab : Fin n → Fin k,
      (∀ X, δ₀ * n ≤ classSize lab X) →
      ∀ t : Multiset (Fin k) → ℕ, PairIdentities lab t →
        (∀ τ ∈ blockTypes k, ζ * (n : ℝ) ^ 2 ≤ t τ) →
        |log (countAll lab t) - Phi lab t| ≤ K * (n : ℝ) ^ (2 - c)

/-- Theorem 1.10 for the lower half of Theorem 1.1. -/
def Theorem_1_10_latin : Prop :=
  ∀ a b c : ℕ, ∀ δ₀ ζ : ℝ, 0 < δ₀ → 0 < ζ → ∃ c' K : ℝ, 0 < c' ∧ ∃ n₀ : ℕ,
    ∀ n : ℕ, n₀ ≤ n → ∀ (R : Fin n → Fin a) (C : Fin n → Fin b)
      (S : Fin n → Fin c) (M : Fin a → Fin b → Fin c → ℕ), LSHyp δ₀ ζ R C S M →
      OutlineMargins R C S M →
      (n : ℝ) ^ 2 * (log n - 2 - TC (fun i j l => (M i j l : ℝ) / (n : ℝ) ^ 2)) -
        K * (n : ℝ) ^ (2 - c') ≤ log (numLS R C S M)

/-- Theorem 1.10 for Theorem 1.7. -/
def Theorem_1_10_oneFact : Prop :=
  ∀ k ℓ : ℕ, 1 ≤ k → 1 ≤ ℓ → ∀ δ₀ ζ : ℝ, 0 < δ₀ → 0 < ζ → ∃ c K : ℝ, 0 < c ∧ ∃ n₀ : ℕ,
    ∀ n : ℕ, n₀ ≤ n → Even n → ∀ (lab : Fin n → Fin k) (col : Fin (n - 1) → Fin ℓ),
      (∀ X, δ₀ * n ≤ classSize lab X) → (∀ Γ, δ₀ * n ≤ colSize col Γ) →
      ∀ t : Multiset (Fin k) → Fin ℓ → ℕ, Identities1F lab col t →
        (∀ π ∈ pairTypes k, ∀ Γ, ζ * (n : ℝ) ^ 2 ≤ t π Γ) →
        |log (count1F lab col t) - Phi1F lab col t| ≤ K * (n : ℝ) ^ (2 - c)

/-- Theorem 1.10 for Theorem 1.9(a). -/
def Theorem_1_10_typical : Prop :=
  ∀ k : ℕ, 1 ≤ k → ∀ c₀ δ₀ d₀ ζ : ℝ, 0 < c₀ → 0 < δ₀ → 0 < d₀ → 0 < ζ →
    ∃ c K : ℝ, 0 < c ∧ ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n →
      ∀ (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k), TypHyp c₀ δ₀ d₀ G lab →
      ∀ t : Multiset (Fin k) → ℕ, PairIdentitiesG G lab (fun τ => t τ) →
        (∀ τ ∈ blockTypes k, ζ * (n : ℝ) ^ 2 ≤ t τ) →
        |log (countDecomp G lab t) - PhiG G lab (fun τ => t τ)| ≤ K * (n : ℝ) ^ (2 - c)

/-- **Theorem 1.10 (polynomial error terms)**, for Theorems 1.1 (lower half), 1.2, 1.5, 1.7
and 1.9(a). -/
def Theorem_1_10 : Prop :=
  Theorem_1_10_latin ∧ Theorem_1_10_bicol ∧ Theorem_1_10_all ∧ Theorem_1_10_oneFact ∧
    Theorem_1_10_typical

/-- A partial Steiner triple system: triples, any two sharing at most one point. -/
def IsPartialSTS (Q : Finset (Finset (Fin n))) : Prop :=
  (∀ B ∈ Q, B.card = 3) ∧ ∀ B ∈ Q, ∀ C ∈ Q, B ≠ C → (B ∩ C).card ≤ 1

/-- `K_n − L_Q`: the pairs not covered by `Q`. -/
def leaveGraph (Q : Finset (Finset (Fin n))) : SimpleGraph (Fin n) where
  Adj x y := x ≠ y ∧ ¬ ∃ B ∈ Q, x ∈ B ∧ y ∈ B
  symm := ⟨fun x y h => ⟨h.1.symm, fun ⟨B, hB, hy, hx⟩ => h.2 ⟨B, hB, hx, hy⟩⟩⟩
  loopless := ⟨fun x h => h.1 rfl⟩

/-- The number of Steiner triple systems that contain `Q` and have type vector `t`. -/
noncomputable def countCompletions (lab : Fin n → Fin k) (Q : Finset (Finset (Fin n)))
    (t : Multiset (Fin k) → ℕ) : ℕ :=
  Nat.card {D : STS.STSOn n // Q ⊆ D.1 ∧ ∀ τ ∈ blockTypes k, typeCount lab D.1 τ = t τ}

open Classical in
/-- **Corollary 1.11 (counting completions).** If `G = K_n − L_Q` satisfies the hypotheses
of Theorem 1.9 and `t − t(Q)` satisfies (1.6) for `G` with all entries at least `ζ n²`,
the number of Steiner triple systems containing `Q` with type vector `t` is
`exp(Φ_G(t − t(Q)) + O(n^{2−c}))`. -/
def Corollary_1_11 : Prop :=
  ∀ k : ℕ, 1 ≤ k → ∀ c₀ δ₀ d₀ ζ : ℝ, 0 < c₀ → 0 < δ₀ → 0 < d₀ → 0 < ζ →
    ∃ c K : ℝ, 0 < c ∧ ∃ n₀ : ℕ, ∀ n : ℕ, n₀ ≤ n → (n % 6 = 1 ∨ n % 6 = 3) →
      ∀ (lab : Fin n → Fin k) (Q : Finset (Finset (Fin n))), IsPartialSTS Q →
      (∀ X, δ₀ * n ≤ classSize lab X) →
      (∃ d : Fin k → Fin k → ℝ, (∀ X Y, d₀ ≤ d X Y) ∧
        Typical.IsTypical (leaveGraph Q) lab d ((n : ℝ) ^ (-c₀)) 5) →
      ∀ t : Multiset (Fin k) → ℕ,
        PairIdentitiesG (leaveGraph Q) lab (fun τ => (t τ - typeCount lab Q τ : ℕ)) →
        (∀ τ ∈ blockTypes k, ζ * (n : ℝ) ^ 2 ≤ (t τ - typeCount lab Q τ : ℕ)) →
        |log (countCompletions lab Q t) -
            PhiG (leaveGraph Q) lab (fun τ => (t τ - typeCount lab Q τ : ℕ))| ≤
          K * (n : ℝ) ^ (2 - c)

end Poly

end ColourStats.Statements
