/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Typed1FThm

/-!
# The upper half of Theorem 1.7: the final bound

* `agg_bound`: `log |S| ≤ Σ_π Σ_Γ t(π, Γ) (log(|E_π| / t(π, Γ)) + Ψ₁(h_Γ − 1))`;
* `typed_upper_1F`: `log N^{1F}_t ≤ Φ(t) + n² ((log n + 4)/n + 7 / h₁^{1/4})`;
* `theorem_1_7_upper_exp`: `N^{1F}_t ≤ exp(Φ(t) + ε n²)` for `n ≥ n₀`.
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.Typed1F

open ColourStats ColourStats.Statements ColourStats.TypedChain ColourStats.TypedSTS

open Classical

variable {n L k ℓ : ℕ} {S : Finset (KEdge n → Fin (n - 1))}

lemma sum_inv_L (hL : 0 < L) : ∑ _r : Fin L, (1 / (L : ℝ)) = 1 := by
  have : (0 : ℝ) < L := by exact_mod_cast hL
  rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  field_simp

/-- **The aggregated bound.** -/
theorem agg_bound (col : Fin (n - 1) → Fin ℓ) (lab : Fin n → Fin k) (hS : ∀ f ∈ S, IsOneFact f)
    (hne : S.Nonempty) (hL : 0 < L) (t : Multiset (Fin k) → Fin ℓ → ℕ)
    (hM : ∀ f ∈ S, ∀ π ∈ pairTypes k, ∀ Γ, edgeTypeCount lab col f π Γ = t π Γ) :
    Real.log S.card ≤ ∑ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ) *
      ((Real.log (Epi1 lab π).card - Real.log (t π Γ)) +
        Psi1 L ((colSize col Γ : ℝ) - 1)) := by
  have hS0 : (0 : ℝ) < S.card := by exact_mod_cast hne.card_pos
  have h0 := raw_bound (L := L) col hS hL
  have hre : ∀ e : KEdge n, ∑ r : Fin L, (1 / (L : ℝ)) * ∑ f ∈ S,
      ((Real.log S.card - Real.log (Scl S col e (col (f e))).card) +
        Real.log (1 + ((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2)) =
      ∑ f ∈ S, (Real.log S.card - Real.log (Scl S col e (col (f e))).card) +
        ∑ f ∈ S, Psi1 L ((colSize col (col (f e)) : ℝ) - 1) := by
    intro e
    have hc : ∑ f ∈ S, ∑ r : Fin L, (1 / (L : ℝ)) * Real.log (1 +
        ((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2) =
        ∑ r : Fin L, ∑ f ∈ S, (1 / (L : ℝ)) * Real.log (1 +
        ((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2) := Finset.sum_comm
    unfold Psi1
    have e1 : ∀ r : Fin L, (1 / (L : ℝ)) * ∑ f ∈ S,
        ((Real.log S.card - Real.log (Scl S col e (col (f e))).card) +
          Real.log (1 + ((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2)) =
        (1 / (L : ℝ)) * ∑ f ∈ S, (Real.log S.card - Real.log (Scl S col e (col (f e))).card) +
          ∑ f ∈ S, (1 / (L : ℝ)) *
            Real.log (1 + ((colSize col (col (f e)) : ℝ) - 1) * (((L : ℝ) - r) / L) ^ 2) := by
      intro r
      rw [Finset.sum_add_distrib, mul_add]
      congr 1
      rw [Finset.mul_sum]
    rw [Finset.sum_congr rfl (fun r _ => e1 r), Finset.sum_add_distrib, ← Finset.sum_mul,
      sum_inv_L hL, one_mul, ← hc]
  rw [Finset.sum_congr rfl fun e _ => hre e, Finset.sum_add_distrib] at h0
  -- class part
  have hA : ∑ e : KEdge n, ∑ f ∈ S,
      (Real.log S.card - Real.log (Scl S col e (col (f e))).card) ≤
      S.card * ∑ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ) *
        (Real.log (Epi1 lab π).card - Real.log (t π Γ)) := by
    rw [sum_edges_by_class lab, Finset.mul_sum]
    exact Finset.sum_le_sum fun π hπ =>
      class_agg col lab π (t π) (fun f hf Γ => hM f hf π hπ Γ) hne
  -- point part
  have hB : ∑ e : KEdge n, ∑ f ∈ S, Psi1 L ((colSize col (col (f e)) : ℝ) - 1) =
      S.card * ∑ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ) * Psi1 L ((colSize col Γ : ℝ) - 1) := by
    rw [sum_edges_by_class lab, Finset.mul_sum]
    refine Finset.sum_congr rfl fun π hπ => ?_
    rw [Finset.sum_comm]
    rw [Finset.sum_congr rfl fun f hf => sum_by_colour col lab f π
      (fun Γ => Psi1 L ((colSize col Γ : ℝ) - 1))]
    rw [Finset.sum_congr rfl fun f hf => Finset.sum_congr rfl fun Γ _ => by
      rw [hM f hf π hπ Γ], Finset.sum_const, nsmul_eq_mul]
  have htot : (S.card : ℝ) * Real.log S.card ≤ S.card * ∑ π ∈ pairTypes k, ∑ Γ,
      (t π Γ : ℝ) * ((Real.log (Epi1 lab π).card - Real.log (t π Γ)) +
        Psi1 L ((colSize col Γ : ℝ) - 1)) := by
    have : (S.card : ℝ) * ∑ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ) *
        ((Real.log (Epi1 lab π).card - Real.log (t π Γ)) + Psi1 L ((colSize col Γ : ℝ) - 1)) =
        S.card * ∑ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ) *
          (Real.log (Epi1 lab π).card - Real.log (t π Γ)) +
        S.card * ∑ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ) * Psi1 L ((colSize col Γ : ℝ) - 1) := by
      simp only [mul_add, Finset.sum_add_distrib, Finset.mul_sum]
    rw [this]
    linarith
  exact le_of_mul_le_mul_left htot hS0

/-! ### Counting the edges of a class -/

lemma toFinset_mk (a b : Fin n) : Sym2.toFinset s(a, b) = {a, b} := by
  ext x
  simp [Sym2.mem_toFinset]

lemma edgeClass_eq (lab : Fin n → Fin k) {e : KEdge n} {a b : Fin n} (h : e.1 = s(a, b)) :
    edgeClass lab e = {lab a, lab b} := by
  unfold edgeClass
  rw [h, Sym2.map_mk]
  rfl

lemma ends (e : KEdge n) : ∃ a b : Fin n, a ≠ b ∧ e.1 = s(a, b) := by
  obtain ⟨⟨a, b⟩, h⟩ := Quot.exists_rep e.1
  refine ⟨a, b, ?_, h.symm⟩
  intro hab
  apply e.2
  rw [← h, hab]
  exact Sym2.mk_isDiag_iff.mpr rfl

/-- `|E_π| = e_π`. -/
lemma card_Epi1 (lab : Fin n → Fin k) (π : Multiset (Fin k)) :
    (Epi1 lab π).card = numPairs lab π := by
  unfold Epi1 numPairs
  refine Finset.card_bij (fun e _ => Sym2.toFinset e.1) ?_ ?_ ?_
  · intro e he
    obtain ⟨a, b, hab, h⟩ := ends e
    have hπ := (Finset.mem_filter.mp he).2
    rw [h, toFinset_mk]
    refine Finset.mem_filter.mpr ⟨Finset.mem_powersetCard.mpr ⟨Finset.subset_univ _,
      Finset.card_pair hab⟩, ?_⟩
    rw [blockType_pair lab hab, ← edgeClass_eq lab h, hπ]
  · intro e _ e' _ h
    obtain ⟨a, b, hab, h1⟩ := ends e
    obtain ⟨a', b', -, h2⟩ := ends e'
    rw [h1, h2, toFinset_mk, toFinset_mk] at h
    apply Subtype.ext
    rw [h1, h2, Sym2.eq_iff]
    exact pair_eq_cases hab h
  · intro E hE
    obtain ⟨hE2, hτ⟩ := Finset.mem_filter.mp hE
    obtain ⟨-, hcard⟩ := Finset.mem_powersetCard.mp hE2
    obtain ⟨a, b, hab, rfl⟩ := Finset.card_eq_two.mp hcard
    refine ⟨⟨s(a, b), by rw [Sym2.mk_isDiag_iff]; exact hab⟩, Finset.mem_filter.mpr
      ⟨Finset.mem_univ _, ?_⟩, toFinset_mk a b⟩
    rw [edgeClass_eq lab rfl, ← blockType_pair lab hab, hτ]

lemma card_KEdge_le (n : ℕ) : Fintype.card (KEdge n) ≤ n * n := by
  rw [Sym2.card_subtype_not_diag, Fintype.card_fin, Nat.choose_two_right]
  exact (Nat.div_le_self _ _).trans (Nat.mul_le_mul_left _ (Nat.sub_le _ _))

lemma count1F_eq (lab : Fin n → Fin k) (col : Fin (n - 1) → Fin ℓ)
    (t : Multiset (Fin k) → Fin ℓ → ℕ) :
    count1F lab col t = (univ.filter fun f : KEdge n → Fin (n - 1) => IsOneFact f ∧
      ∀ π ∈ pairTypes k, ∀ Γ, edgeTypeCount lab col f π Γ = t π Γ).card := by
  unfold count1F
  rw [Nat.card_eq_fintype_card, Fintype.card_subtype]

/-! ### The final bound -/

/-- **The typed bound for 1-factorizations.** -/
theorem typed_upper_1F (lab : Fin n → Fin k) (col : Fin (n - 1) → Fin ℓ)
    (t : Multiset (Fin k) → Fin ℓ → ℕ) {h₁ : ℝ} (hh : 1 ≤ h₁)
    (hcol : ∀ Γ, h₁ + 1 ≤ colSize col Γ) (hn : 1 ≤ n) (hpos : 0 < count1F lab col t) :
    Real.log (count1F lab col t) ≤ Phi1F lab col t +
      (n : ℝ) ^ 2 * ((Real.log n + 4) / n + 7 / Real.sqrt (Real.sqrt h₁)) := by
  have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hnpos : (0 : ℝ) < n := by linarith
  set S := univ.filter fun f : KEdge n → Fin (n - 1) => IsOneFact f ∧
    ∀ π ∈ pairTypes k, ∀ Γ, edgeTypeCount lab col f π Γ = t π Γ
  have hcount : count1F lab col t = S.card := count1F_eq lab col t
  have hS : ∀ f ∈ S, IsOneFact f := fun f hf => (Finset.mem_filter.mp hf).2.1
  have hM : ∀ f ∈ S, ∀ π ∈ pairTypes k, ∀ Γ, edgeTypeCount lab col f π Γ = t π Γ :=
    fun f hf => (Finset.mem_filter.mp hf).2.2
  have hne : S.Nonempty := by
    rw [← Finset.card_pos, ← hcount]; exact hpos
  have hagg := agg_bound (L := n) col lab hS hne hn t hM
  rw [hcount]
  set errU : ℝ := (Real.log n + 4) / n + 7 / Real.sqrt (Real.sqrt h₁)
  have herr0 : 0 ≤ errU := by
    have : 0 < Real.sqrt (Real.sqrt h₁) := Real.sqrt_pos.mpr (Real.sqrt_pos.mpr (by linarith))
    have : 0 ≤ Real.log n := Real.log_nonneg hn1
    simp only [errU]
    positivity
  obtain ⟨f₀, hf₀⟩ := hne
  -- the per-term bound
  have hterm : ∀ π ∈ pairTypes k, ∀ Γ, (t π Γ : ℝ) *
      ((Real.log (Epi1 lab π).card - Real.log (t π Γ)) + Psi1 n ((colSize col Γ : ℝ) - 1)) ≤
      (t π Γ : ℝ) * (Real.log ((numPairs lab π : ℝ) * colSize col Γ / t π Γ) - 2) +
        (t π Γ : ℝ) * errU := by
    intro π hπ Γ
    by_cases ht0 : t π Γ = 0
    · simp [ht0]
    have htr : (0 : ℝ) < t π Γ := by exact_mod_cast Nat.pos_of_ne_zero ht0
    have htE : t π Γ ≤ (Epi1 lab π).card := by
      rw [← hM f₀ hf₀ π hπ Γ]
      unfold edgeTypeCount Epi1
      apply Finset.card_le_card
      intro e he
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at he ⊢
      exact he.1
    have hEr : (0 : ℝ) < (Epi1 lab π).card := by
      exact_mod_cast lt_of_lt_of_le (Nat.pos_of_ne_zero ht0) htE
    have hx1 : (1 : ℝ) ≤ (Epi1 lab π).card / t π Γ := by
      rw [le_div_iff₀ htr, one_mul]; exact_mod_cast htE
    have hh1 : h₁ ≤ (colSize col Γ : ℝ) - 1 := by linarith [hcol Γ]
    have hc1 : (1 : ℝ) ≤ (colSize col Γ : ℝ) - 1 := hh.trans hh1
    have hlogx : Real.log (Epi1 lab π).card - Real.log (t π Γ) =
        Real.log ((Epi1 lab π).card / t π Γ) := (Real.log_div hEr.ne' htr.ne').symm
    have ht := term1F_le (L := n) hn hc1 hx1
    -- `log x + log(h − 1) ≤ log(e_π h / t)`
    have hcolpos : (0 : ℝ) < colSize col Γ := by linarith
    have hlogsum : Real.log ((Epi1 lab π).card / t π Γ) + Real.log ((colSize col Γ : ℝ) - 1) ≤
        Real.log ((numPairs lab π : ℝ) * colSize col Γ / t π Γ) := by
      rw [← Real.log_mul (by positivity) (by linarith)]
      apply Real.log_le_log (by positivity)
      rw [card_Epi1]
      have hnp : (0 : ℝ) ≤ numPairs lab π := Nat.cast_nonneg _
      rw [div_mul_eq_mul_div]
      apply div_le_div_of_nonneg_right _ htr.le
      exact mul_le_mul_of_nonneg_left (by linarith) hnp
    -- the error
    have hcle : (colSize col Γ : ℝ) - 1 ≤ n := by
      have : colSize col Γ ≤ n - 1 := by
        unfold colSize
        exact (Finset.card_filter_le _ _).trans (by simp)
      have : (colSize col Γ : ℝ) ≤ n := by
        have h' : colSize col Γ ≤ n := this.trans (Nat.sub_le _ _)
        exact_mod_cast h'
      linarith
    have hlogc : Real.log ((colSize col Γ : ℝ) - 1) ≤ Real.log n :=
      Real.log_le_log (by linarith) hcle
    have hsq : 7 / Real.sqrt (Real.sqrt ((colSize col Γ : ℝ) - 1)) ≤
        7 / Real.sqrt (Real.sqrt h₁) := by
      apply div_le_div_of_nonneg_left (by norm_num)
      · exact Real.sqrt_pos.mpr (Real.sqrt_pos.mpr (by linarith))
      · exact Real.sqrt_le_sqrt (Real.sqrt_le_sqrt hh1)
    have herr : (Real.log ((colSize col Γ : ℝ) - 1) + 4) / n +
        7 / Real.sqrt (Real.sqrt ((colSize col Γ : ℝ) - 1)) ≤ errU := by
      have : (Real.log ((colSize col Γ : ℝ) - 1) + 4) / n ≤ (Real.log n + 4) / n :=
        div_le_div_of_nonneg_right (by linarith) hnpos.le
      simp only [errU]
      linarith
    have hmain : (Real.log (Epi1 lab π).card - Real.log (t π Γ)) +
        Psi1 n ((colSize col Γ : ℝ) - 1) ≤
        (Real.log ((numPairs lab π : ℝ) * colSize col Γ / t π Γ) - 2) + errU := by
      rw [hlogx]
      linarith
    calc (t π Γ : ℝ) * ((Real.log (Epi1 lab π).card - Real.log (t π Γ)) +
          Psi1 n ((colSize col Γ : ℝ) - 1))
        ≤ (t π Γ : ℝ) * ((Real.log ((numPairs lab π : ℝ) * colSize col Γ / t π Γ) - 2) +
            errU) := mul_le_mul_of_nonneg_left hmain htr.le
      _ = _ := by ring
  have hsum := Finset.sum_le_sum fun π hπ => Finset.sum_le_sum fun Γ (_ : Γ ∈ univ) =>
    hterm π hπ Γ
  simp only [Finset.sum_add_distrib] at hsum
  have hPhi : ∑ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ) *
      (Real.log ((numPairs lab π : ℝ) * colSize col Γ / t π Γ) - 2) = Phi1F lab col t := rfl
  rw [hPhi] at hsum
  -- `Σ t ≤ n²`
  have hcnt : ∑ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ) ≤ (n : ℝ) ^ 2 := by
    have h1 : ∀ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ) = (Epi1 lab π).card := by
      intro π hπ
      have := sum_by_colour col lab f₀ π (fun _ => (1 : ℝ))
      simp only [mul_one, Finset.sum_const, nsmul_eq_mul] at this
      rw [Finset.sum_congr rfl fun Γ _ => by rw [← hM f₀ hf₀ π hπ Γ]]
      linarith
    rw [Finset.sum_congr rfl h1]
    have h2 : ∑ π ∈ pairTypes k, ((Epi1 lab π).card : ℝ) = Fintype.card (KEdge n) := by
      have := sum_edges_by_class lab (fun _ => (1 : ℝ))
      simp only [Finset.sum_const, nsmul_eq_mul, mul_one, Finset.card_univ] at this
      linarith
    rw [h2]
    have h3 : (Fintype.card (KEdge n) : ℝ) ≤ (n * n : ℕ) := by exact_mod_cast card_KEdge_le n
    push_cast at h3
    nlinarith
  have hErr : ∑ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ) * errU ≤ (n : ℝ) ^ 2 * errU := by
    have e : ∑ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ) * errU =
        (∑ π ∈ pairTypes k, ∑ Γ, (t π Γ : ℝ)) * errU := by
      rw [Finset.sum_mul]
      exact Finset.sum_congr rfl fun π _ => by rw [Finset.sum_mul]
    rw [e]
    exact mul_le_mul_of_nonneg_right hcnt herr0
  linarith

/-- **Upper half of Theorem 1.7**, exponential form, for every type vector. -/
def Theorem_1_7_upper_exp : Prop :=
  ∀ k ℓ : ℕ, ∀ δ₀ ε : ℝ, 0 < δ₀ → 0 < ε → ∃ n₀ : ℕ,
    ∀ n : ℕ, n₀ ≤ n → ∀ (lab : Fin n → Fin k) (col : Fin (n - 1) → Fin ℓ),
      (∀ Γ, δ₀ * n ≤ colSize col Γ) →
      ∀ t : Multiset (Fin k) → Fin ℓ → ℕ,
        (count1F lab col t : ℝ) ≤ Real.exp (Phi1F lab col t + ε * (n : ℝ) ^ 2)

lemma err1F_le {δ₀ ε : ℝ} (hδ : 0 < δ₀) (hε : 0 < ε) {n : ℕ}
    (hn1 : (42 / ε) ^ 2 ≤ n) (hn2 : 4 / δ₀ ≤ n) (hn3 : 2 * (16 / ε) ^ 4 / δ₀ ≤ n) (hn : 1 ≤ n) :
    (Real.log n + 4) / n + 7 / Real.sqrt (Real.sqrt (δ₀ * n - 1)) ≤ ε := by
  have h := err_le hδ hε hn1 hn2 hn3 hn
  have hnr : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hlog : 0 ≤ Real.log n := Real.log_nonneg hnr
  have h1 : (Real.log n + 4) / n ≤ (5 * Real.log n + 16) / n :=
    div_le_div_of_nonneg_right (by linarith) (by linarith)
  have hc2 : 1 ≤ δ₀ * n - 2 := by
    have : 4 ≤ δ₀ * n := by rw [div_le_iff₀ hδ] at hn2; linarith
    linarith
  have hs : Real.sqrt (Real.sqrt (δ₀ * n - 2)) ≤ Real.sqrt (Real.sqrt (δ₀ * n - 1)) :=
    Real.sqrt_le_sqrt (Real.sqrt_le_sqrt (by linarith))
  have hpos : 0 < Real.sqrt (Real.sqrt (δ₀ * n - 2)) :=
    Real.sqrt_pos.mpr (Real.sqrt_pos.mpr (by linarith))
  have h2 : 7 / Real.sqrt (Real.sqrt (δ₀ * n - 1)) ≤ 8 / Real.sqrt (Real.sqrt (δ₀ * n - 2)) := by
    calc 7 / Real.sqrt (Real.sqrt (δ₀ * n - 1)) ≤ 7 / Real.sqrt (Real.sqrt (δ₀ * n - 2)) :=
          div_le_div_of_nonneg_left (by norm_num) hpos hs
      _ ≤ 8 / Real.sqrt (Real.sqrt (δ₀ * n - 2)) :=
          div_le_div_of_nonneg_right (by norm_num) hpos.le
  linarith

/-- **The upper half of Theorem 1.7**, for every type vector. -/
theorem theorem_1_7_upper_exp : Theorem_1_7_upper_exp := by
  intro k ℓ δ₀ ε hδ hε
  refine ⟨⌈(42 / ε) ^ 2 + 4 / δ₀ + 2 * (16 / ε) ^ 4 / δ₀⌉₊ + 1,
    fun n hn lab col hcol t => ?_⟩
  have hceil : (42 / ε) ^ 2 + 4 / δ₀ + 2 * (16 / ε) ^ 4 / δ₀ ≤ n := by
    have := Nat.le_ceil ((42 / ε) ^ 2 + 4 / δ₀ + 2 * (16 / ε) ^ 4 / δ₀)
    have h' : ((⌈(42 / ε) ^ 2 + 4 / δ₀ + 2 * (16 / ε) ^ 4 / δ₀⌉₊ : ℕ) : ℝ) ≤ n := by
      exact_mod_cast (Nat.le_succ _).trans hn
    linarith
  have p1 : 0 ≤ (42 / ε) ^ 2 := by positivity
  have p2 : 0 ≤ 4 / δ₀ := by positivity
  have p3 : 0 ≤ 2 * (16 / ε) ^ 4 / δ₀ := by positivity
  have hn1 : 1 ≤ n := by omega
  rcases Nat.eq_zero_or_pos (count1F lab col t) with h0 | hpos
  · rw [h0, Nat.cast_zero]
    exact (Real.exp_pos _).le
  have hh : 1 ≤ δ₀ * n - 1 := by
    have : 4 ≤ δ₀ * n := by
      have : 4 / δ₀ ≤ n := by linarith
      rw [div_le_iff₀ hδ] at this; linarith
    linarith
  have hc : ∀ Γ, δ₀ * n - 1 + 1 ≤ colSize col Γ := fun Γ => by linarith [hcol Γ]
  have hup := typed_upper_1F lab col t hh hc hn1 hpos
  have herr := err1F_le hδ hε (n := n) (by linarith) (by linarith) (by linarith) hn1
  have hcount : (0 : ℝ) < count1F lab col t := by exact_mod_cast hpos
  rw [← Real.exp_log hcount]
  apply Real.exp_le_exp.mpr
  have : (n : ℝ) ^ 2 * ((Real.log n + 4) / n + 7 / Real.sqrt (Real.sqrt (δ₀ * n - 1))) ≤
      ε * (n : ℝ) ^ 2 := by
    rw [mul_comm ε]
    exact mul_le_mul_of_nonneg_left herr (by positivity)
  linarith

end ColourStats.Typed1F
