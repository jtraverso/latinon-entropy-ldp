/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Cor111

/-!
# Theorem 1.5 is Theorem 1.9(a) for `K_n`

The paper remarks that for `G = K_n` with `k` classes, Theorem 1.9(a) is Theorem 1.5. This
file proves the implication `Theorem_1_9a → Theorem_1_5` (`theorem_1_5_of`):

* `K_n` is `leaveGraph ∅`; its triangle decompositions are the Steiner triple systems
  (`isTriDecomp_top_iff`), its edge and triangle counts are `e_π` and `N_τ`
  (`edgesOf_top`, `trianglesOf_top`);
* `K_n` is triangle-divisible for `n ≡ 1, 3 (mod 6)` (`triDivisible_leave` with `Q = ∅`);
* `K_n` is `(n^{−1/2}, 5)`-typical with all densities `1` once every class has at least
  `5√n` vertices (`isTypical_top`).
-/

@[expose] public section

open Finset
open Real (log sqrt)

namespace ColourStats.Statements

open ColourStats

variable {n k : ℕ}

lemma leave_empty_adj {x y : Fin n} : (leaveGraph (∅ : Finset (Finset (Fin n)))).Adj x y ↔ x ≠ y := by
  simp [leaveGraph]

lemma isTriDecomp_top_iff (D : Finset (Finset (Fin n))) :
    IsTriDecomp (leaveGraph ∅) D ↔ STS.IsSTS D := by
  constructor
  · rintro ⟨h1, h2⟩
    exact ⟨fun A hA => (h1 A hA).1, fun x y hxy => h2 x y (leave_empty_adj.mpr hxy)⟩
  · rintro ⟨h1, h2⟩
    exact ⟨fun B hB => ⟨h1 B hB, fun x _ y _ hxy => leave_empty_adj.mpr hxy⟩,
      fun x y hxy => h2 x y (leave_empty_adj.mp hxy)⟩

lemma countDecomp_top (lab : Fin n → Fin k) (t : Multiset (Fin k) → ℕ) :
    countDecomp (leaveGraph ∅) lab t = countAll lab t := by
  unfold countDecomp countAll
  refine Nat.card_congr
    { toFun := fun D => ⟨⟨D.1, (isTriDecomp_top_iff D.1).mp D.2.1⟩, D.2.2⟩
      invFun := fun D => ⟨D.1.1, (isTriDecomp_top_iff D.1.1).mpr D.1.2, D.2⟩
      left_inv := fun D => rfl
      right_inv := fun D => rfl }

open Classical in
lemma edgesOf_top (lab : Fin n → Fin k) (π : Multiset (Fin k)) :
    edgesOf (leaveGraph ∅) lab π = numPairs lab π := by
  unfold edgesOf numPairs
  congr 1
  refine Finset.filter_congr fun e _ => ?_
  simp [leave_empty_adj]

open Classical in
lemma trianglesOf_top (lab : Fin n → Fin k) (τ : Multiset (Fin k)) :
    trianglesOf (leaveGraph ∅) lab τ = numTriples lab τ := by
  unfold trianglesOf numTriples
  congr 1
  refine Finset.filter_congr fun e _ => ?_
  simp [leave_empty_adj]

open Classical in
lemma card_commonIn_top (lab : Fin n → Fin k) (S : Finset (Fin n)) (Z : Fin k) :
    Typical.commonIn (leaveGraph ∅) lab S Z = Typical.classSet lab Z \ S := by
  ext z
  simp only [Typical.commonIn, Typical.classSet, Finset.mem_filter, Finset.mem_univ, true_and,
    Finset.mem_sdiff, leave_empty_adj]
  constructor
  · rintro ⟨hz, hS⟩
    exact ⟨hz, fun hzS => hS z hzS rfl⟩
  · rintro ⟨hz, hzS⟩
    exact ⟨hz, fun v hv hvz => hzS (hvz ▸ hv)⟩

open Classical in
/-- `K_n` is `(n^{−1/2}, 5)`-typical with all densities `1` when every class has at least
`5√n` vertices. -/
lemma isTypical_top (lab : Fin n → Fin k) (hn : 0 < n)
    (hcls : ∀ Z, 5 * sqrt n ≤ (Typical.classSet lab Z).card) :
    Typical.IsTypical (leaveGraph ∅) lab (fun _ _ => 1) ((n : ℝ) ^ (-(1 / 2 : ℝ))) 5 := by
  intro S hS Z
  rw [card_commonIn_top]
  simp only [Typical.ideal, Finset.prod_const_one, mul_one]
  have hsub : (Typical.classSet lab Z \ S).card + (Typical.classSet lab Z ∩ S).card =
      (Typical.classSet lab Z).card := Finset.card_sdiff_add_card_inter _ _
  have hle : (Typical.classSet lab Z ∩ S).card ≤ 5 :=
    (Finset.card_le_card Finset.inter_subset_right).trans hS
  have hle' : ((Typical.classSet lab Z ∩ S).card : ℝ) ≤ 5 := by exact_mod_cast hle
  have hcast : ((Typical.classSet lab Z \ S).card : ℝ) - (Typical.classSet lab Z).card =
      -((Typical.classSet lab Z ∩ S).card : ℝ) := by
    rw [← hsub]; push_cast; ring
  rw [hcast, abs_neg, abs_of_nonneg (by positivity)]
  have hnpos : (0 : ℝ) < n := by exact_mod_cast hn
  have hs : (n : ℝ) ^ (-(1 / 2 : ℝ)) * sqrt n = 1 := by
    rw [Real.sqrt_eq_rpow, ← Real.rpow_add hnpos]
    norm_num
  have hpos : 0 ≤ (n : ℝ) ^ (-(1 / 2 : ℝ)) := by positivity
  calc ((Typical.classSet lab Z ∩ S).card : ℝ) ≤ 5 := hle'
    _ = (n : ℝ) ^ (-(1 / 2 : ℝ)) * (5 * sqrt n) := by rw [mul_left_comm, hs, mul_one]
    _ ≤ (n : ℝ) ^ (-(1 / 2 : ℝ)) * (Typical.classSet lab Z).card :=
        mul_le_mul_of_nonneg_left (hcls Z) hpos

/-- **Theorem 1.5 from Theorem 1.9(a)**, applied to `G = K_n`. -/
theorem theorem_1_5_of (h : Theorem_1_9a) : Theorem_1_5 := by
  intro k hk δ₀ ζ ε hδ₀ hζ hε
  obtain ⟨n₀, hn₀⟩ := h k hk (1 / 2) δ₀ 1 ζ ε (by norm_num) hδ₀ one_pos hζ hε
  refine ⟨max n₀ (max 1 ⌈(5 / δ₀) ^ 2⌉₊), fun n hn hmod lab hcls t hid ht => ?_⟩
  have hn0 : n₀ ≤ n := le_of_max_le_left hn
  have hn1 : 1 ≤ n := le_of_max_le_left (le_of_max_le_right hn)
  have hn2 : ⌈(5 / δ₀) ^ 2⌉₊ ≤ n := le_of_max_le_right (le_of_max_le_right hn)
  have hnpos : (0 : ℝ) < n := by exact_mod_cast hn1
  -- every class has at least `5√n` points
  have hbig : ∀ Z, 5 * sqrt n ≤ (Typical.classSet lab Z).card := by
    intro Z
    have hc : (Typical.classSet lab Z).card = classSize lab Z := rfl
    rw [hc]
    have h1 : (5 / δ₀) ^ 2 ≤ (n : ℝ) := (Nat.ceil_le.mp hn2)
    have h2 : 5 / δ₀ ≤ sqrt n := by
      rw [show (5 / δ₀) = sqrt ((5 / δ₀) ^ 2) by
        rw [Real.sqrt_sq (by positivity)]]
      exact Real.sqrt_le_sqrt h1
    have h3 : 5 * sqrt n ≤ δ₀ * n := by
      have hsq : sqrt n * sqrt n = n := Real.mul_self_sqrt hnpos.le
      have := mul_le_mul_of_nonneg_right h2 (Real.sqrt_nonneg n)
      rw [div_mul_eq_mul_div, div_le_iff₀ hδ₀, hsq] at this
      linarith
    exact h3.trans (hcls Z)
  have htyp : TypHyp (1 / 2) δ₀ 1 (leaveGraph ∅) lab := by
    refine ⟨triDivisible_leave ⟨fun B hB => by simp at hB, fun B hB => by simp at hB⟩ hmod,
      hcls, fun _ _ => 1, fun _ _ => le_rfl, ?_⟩
    have := isTypical_top lab hn1 hbig
    convert this using 2
  have hidG : PairIdentitiesG (leaveGraph ∅) lab (fun τ => (t τ : ℝ)) := by
    intro π hπ
    rw [edgesOf_top]
    show ∑ τ ∈ blockTypes k, (mult π τ : ℝ) * (t τ : ℝ) = numPairs lab π
    exact_mod_cast hid π hπ
  have key := hn₀ n hn0 (leaveGraph ∅) lab htyp t hidG ht
  rw [countDecomp_top] at key
  have hPhi : PhiG (leaveGraph ∅) lab (fun τ => (t τ : ℝ)) = Phi lab t := by
    unfold PhiG Phi
    refine Finset.sum_congr rfl fun τ _ => ?_
    rw [trianglesOf_top]
  rwa [hPhi] at key

end ColourStats.Statements
