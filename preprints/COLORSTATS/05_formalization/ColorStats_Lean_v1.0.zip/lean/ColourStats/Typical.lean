/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import Mathlib

/-!
# Typical graphs and the load of a type weighting (Lemma 5.19)

A graph `G` whose vertices carry classes `cls : V → Fin k` is `(η, h)`-*typical with
densities* `d` (`IsTypical`) if for every set `S` of at most `h` vertices and every class `Z`,
the common neighbourhood of `S` has `(1 ± η) |Z| Π_{s ∈ S} d(cl(s), Z)` vertices in `Z`
(Section 1 of the paper).

A type weighting puts `w(τ)` on every triangle of type `τ`. Its load on a pair `xy` is
`Σ_{z ∈ N(x) ∩ N(y)} w({cl x, cl y, cl z})` (`load`). Typicality for sets of two vertices
gives (`load_estimate`)

    |load(xy) − Σ_Z w({X, Y, Z}) |Z| d(X, Z) d(Y, Z)| ≤ η Σ_Z |w({X, Y, Z})| |Z| d(X, Z) d(Y, Z).

This is the estimate behind the weighting `W_c` of Lemma 5.19.
-/

@[expose] public section

open Finset

namespace ColourStats.Typical

variable {V : Type*} [Fintype V] [DecidableEq V] {k : ℕ}

/-- The class `Z` as a set of vertices. -/
def classSet (cls : V → Fin k) (Z : Fin k) : Finset V := univ.filter fun z => cls z = Z

/-- The common neighbours of `S` in the class `Z`. -/
def commonIn (G : SimpleGraph V) [DecidableRel G.Adj] (cls : V → Fin k) (S : Finset V)
    (Z : Fin k) : Finset V :=
  univ.filter fun z => cls z = Z ∧ ∀ v ∈ S, G.Adj v z

/-- The predicted size `|Z| Π_{s ∈ S} d(cl(s), Z)` of the common neighbourhood. -/
noncomputable def ideal (cls : V → Fin k) (d : Fin k → Fin k → ℝ) (S : Finset V)
    (Z : Fin k) : ℝ :=
  (classSet cls Z).card * ∏ v ∈ S, d (cls v) Z

/-- `(η, h)`-typicality with densities `d`. -/
def IsTypical (G : SimpleGraph V) [DecidableRel G.Adj] (cls : V → Fin k)
    (d : Fin k → Fin k → ℝ) (η : ℝ) (h : ℕ) : Prop :=
  ∀ S : Finset V, S.card ≤ h → ∀ Z,
    |((commonIn G cls S Z).card : ℝ) - ideal cls d S Z| ≤ η * ideal cls d S Z

lemma ideal_pair (cls : V → Fin k) (d : Fin k → Fin k → ℝ) {x y : V} (hxy : x ≠ y)
    (Z : Fin k) :
    ideal cls d {x, y} Z = (classSet cls Z).card * (d (cls x) Z * d (cls y) Z) := by
  rw [ideal, Finset.prod_pair hxy]

/-- The load at the pair `xy` of the weighting that puts `w(τ)` on every triangle of
type `τ`. -/
noncomputable def load (G : SimpleGraph V) [DecidableRel G.Adj] (cls : V → Fin k)
    (w : Multiset (Fin k) → ℝ) (x y : V) : ℝ :=
  ∑ z ∈ univ.filter (fun z => G.Adj x z ∧ G.Adj y z), w {cls x, cls y, cls z}

lemma load_eq (G : SimpleGraph V) [DecidableRel G.Adj] (cls : V → Fin k)
    (w : Multiset (Fin k) → ℝ) (x y : V) :
    load G cls w x y = ∑ Z, w {cls x, cls y, Z} * (commonIn G cls {x, y} Z).card := by
  unfold load
  rw [← Finset.sum_fiberwise (s := univ.filter (fun z => G.Adj x z ∧ G.Adj y z)) (g := cls)]
  refine Finset.sum_congr rfl fun Z _ => ?_
  rw [Finset.sum_congr rfl (fun z hz => by rw [(Finset.mem_filter.mp hz).2]),
    Finset.sum_const, nsmul_eq_mul, mul_comm]
  congr 3
  ext z
  simp only [Finset.mem_filter, Finset.mem_univ, true_and, commonIn, Finset.mem_insert,
    Finset.mem_singleton, forall_eq_or_imp, forall_eq]
  tauto

/-- **The load estimate.** Typicality for pairs of vertices controls the load of a type
weighting. -/
theorem load_estimate {G : SimpleGraph V} [DecidableRel G.Adj] {cls : V → Fin k}
    {d : Fin k → Fin k → ℝ} {η : ℝ} {h : ℕ} (hT : IsTypical G cls d η h) (hh : 2 ≤ h)
    {x y : V} (hxy : x ≠ y) (w : Multiset (Fin k) → ℝ) :
    |load G cls w x y - ∑ Z, w {cls x, cls y, Z} * ideal cls d {x, y} Z| ≤
      η * ∑ Z, |w {cls x, cls y, Z}| * ideal cls d {x, y} Z := by
  rw [load_eq, ← Finset.sum_sub_distrib, Finset.mul_sum]
  refine (abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun Z _ => ?_)
  rw [← mul_sub, abs_mul]
  have hS : ({x, y} : Finset V).card ≤ h := by rw [Finset.card_pair hxy]; exact hh
  calc |w {cls x, cls y, Z}| * |((commonIn G cls {x, y} Z).card : ℝ) - ideal cls d {x, y} Z|
      ≤ |w {cls x, cls y, Z}| * (η * ideal cls d {x, y} Z) :=
        mul_le_mul_of_nonneg_left (hT {x, y} hS Z) (abs_nonneg _)
    _ = η * (|w {cls x, cls y, Z}| * ideal cls d {x, y} Z) := by ring

end ColourStats.Typical
