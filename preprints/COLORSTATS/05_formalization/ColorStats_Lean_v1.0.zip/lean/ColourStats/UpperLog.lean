/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedThm
public import ColourStats.Typed1FMain
public import ColourStats.TypedGThm

/-!
# The logarithmic upper statements, including the case with no objects

Since `log 0 = 0` in Lean, `log N ≤ Φ + ε n²` with `N = 0` asks for `Φ + ε n² ≥ 0`. Under the
identities of each theorem and the class-size hypotheses, every term of `Φ` is nonnegative once
`n` is large: a positive type count `t` is at most the number of pairs of a sub-class, and the
number of available triples is at least `8 t` (the double count `w(τ, π) e_π = m_π(τ) N_τ`, with
`w ≥ 24`, `m ≤ 3`). So `Φ ≥ 0` and the zero case holds. Combined with the exponential forms this
proves the statements exactly as written:

* `theorem_1_5_upper : Theorem_1_5_upper` (Steiner triple systems, all block types);
* `theorem_1_7_upper : Statements.Theorem_1_7_upper` (1-factorizations);
* `theorem_1_9a_upper : Statements.Theorem_1_9a_upper` (typical graphs).
-/

@[expose] public section

open Finset

namespace ColourStats.UpperLog

open ColourStats

lemma exp_two_lt_eight : Real.exp 2 < 8 := by
  have h := Real.exp_one_lt_d9
  have h0 := Real.exp_pos 1
  have : Real.exp 2 = Real.exp 1 * Real.exp 1 := by rw [← Real.exp_add]; norm_num
  rw [this]; nlinarith

/-- A term `t (log(N/t) − 2)` with `8 t ≤ N` is nonnegative. -/
lemma term_nonneg {t N : ℝ} (ht : 0 ≤ t) (h : t * 8 ≤ N) : 0 ≤ t * (Real.log (N / t) - 2) := by
  rcases ht.eq_or_lt with h0 | hpos
  · rw [← h0]; simp
  apply mul_nonneg ht
  have h8 : 8 ≤ N / t := by rw [le_div_iff₀ hpos]; linarith
  have : 2 ≤ Real.log (N / t) := by
    rw [Real.le_log_iff_exp_le (by linarith)]
    linarith [exp_two_lt_eight]
  linarith

lemma mult_le_three {k : ℕ} (π τ : Multiset (Fin k)) (hτ : Multiset.card τ = 3) :
    mult π τ ≤ 3 := by
  unfold mult pairs
  calc _ ≤ Multiset.card (Multiset.powersetCard 2 τ) := Multiset.count_le_card _ _
    _ = 3 := by rw [Multiset.card_powersetCard, hτ]; rfl

lemma add_logsq_nonneg {Φ ε : ℝ} (n : ℕ) (hΦ : 0 ≤ Φ) (hε : 0 < ε) :
    Real.log 0 ≤ Φ + ε * (n : ℝ) ^ 2 := by
  rw [Real.log_zero]; positivity

lemma ceil_bound {δ c : ℝ} (hδ : 0 < δ) {n : ℕ} (h : ⌈c / δ⌉₊ ≤ n) : c ≤ δ * n := by
  have h2 : c / δ ≤ n := (Nat.le_ceil _).trans (by exact_mod_cast h)
  rw [div_le_iff₀ hδ] at h2; linarith

/-! ### Steiner triple systems -/

/-- Under the pair identities and classes of size at least `26`, `Φ(t) ≥ 0`. -/
theorem Phi_nonneg {n k : ℕ} (lab : Fin n → Fin k) (t : Multiset (Fin k) → ℕ)
    (ht : PairIdentities lab t) (hc : ∀ X, (26 : ℝ) ≤ classSize lab X) : 0 ≤ Phi lab t := by
  unfold Phi
  refine Finset.sum_nonneg fun τ hτ => term_nonneg (Nat.cast_nonneg _) ?_
  obtain ⟨a, b, c, rfl⟩ := Multiset.card_eq_three.mp (mem_blockTypes.mp hτ)
  have hπc : Multiset.card ({b, c} : Multiset (Fin k)) = 2 := by simp
  have hπ : ({b, c} : Multiset (Fin k)) ∈ pairTypes k := mem_pairTypes.mpr hπc
  have hm : 1 ≤ mult {b, c} {a, b, c} := Nat.pos_of_ne_zero (mult_cons_ne_zero hπc a)
  have hm3 : mult {b, c} {a, b, c} ≤ 3 := mult_le_three _ _ (mem_blockTypes.mp hτ)
  have hle : t {a, b, c} ≤ numPairs lab {b, c} := by
    rw [← ht _ hπ]
    calc t {a, b, c} ≤ mult {b, c} {a, b, c} * t {a, b, c} := Nat.le_mul_of_pos_left _ hm
      _ ≤ ∑ τ ∈ blockTypes k, mult {b, c} τ * t τ :=
        Finset.single_le_sum (f := fun τ => mult {b, c} τ * t τ) (fun _ _ => Nat.zero_le _) hτ
  have hkey := ColourFirst.compl_mul_typeNum (classSize lab) a b c
  rw [← numPairs_eq lab hπc, ← numTriples_eq lab (mem_blockTypes.mp hτ)] at hkey
  have hcount : ({b, c} : Multiset (Fin k)).count a ≤ 2 :=
    hπc ▸ Multiset.count_le_card a {b, c}
  have hcompl : ColourFirst.compl (classSize lab) a {b, c} + 2 ≥ classSize lab a := by
    unfold ColourFirst.compl; omega
  have hcomplR : (classSize lab a : ℝ) ≤ ColourFirst.compl (classSize lab) a {b, c} + 2 := by
    exact_mod_cast hcompl
  have hkeyR : (ColourFirst.compl (classSize lab) a {b, c} : ℝ) * numPairs lab {b, c} =
      mult {b, c} {a, b, c} * numTriples lab {a, b, c} := by exact_mod_cast hkey
  have hleR : (t {a, b, c} : ℝ) ≤ numPairs lab {b, c} := by exact_mod_cast hle
  have hm3R : (mult {b, c} {a, b, c} : ℝ) ≤ 3 := by exact_mod_cast hm3
  have hca := hc a
  have h0 : (0 : ℝ) ≤ t {a, b, c} := Nat.cast_nonneg _
  have hN : (0 : ℝ) ≤ numTriples lab {a, b, c} := Nat.cast_nonneg _
  have h24 : (24 : ℝ) ≤ ColourFirst.compl (classSize lab) a {b, c} := by linarith
  have hP : (0 : ℝ) ≤ numPairs lab {b, c} := Nat.cast_nonneg _
  nlinarith [mul_le_mul h24 hleR h0 (by linarith : (0 : ℝ) ≤ ColourFirst.compl (classSize lab) a {b, c}),
    mul_le_mul_of_nonneg_right hm3R hN]

/-- **The upper half of Theorem 1.5**, exactly as stated (logarithmic form, all `N ≥ 0`). -/
theorem theorem_1_5_upper : Theorem_1_5_upper := by
  intro k _ δ₀ ε hδ hε
  obtain ⟨n₀, h⟩ := TypedSTS.theorem_1_5_upper_exp k δ₀ ε hδ hε
  refine ⟨max n₀ ⌈26 / δ₀⌉₊, fun n hn lab hcls t ht => ?_⟩
  have hn26 : (26 : ℝ) ≤ δ₀ * n := ceil_bound hδ (le_of_max_le_right hn)
  rcases Nat.eq_zero_or_pos (countAll lab t) with h0 | hpos
  · rw [h0, Nat.cast_zero]
    exact add_logsq_nonneg n (Phi_nonneg lab t ht fun X => hn26.trans (hcls X)) hε
  · have hcount : (0 : ℝ) < countAll lab t := by exact_mod_cast hpos
    rw [Real.log_le_iff_le_exp hcount]
    exact h n (le_of_max_le_left hn) lab hcls t

/-! ### 1-factorizations -/

open ColourStats.Statements in
/-- Under the identities (1.5) and colour classes of size at least `8`, `Φ(t) ≥ 0`. -/
theorem Phi1F_nonneg {n k ℓ : ℕ} (lab : Fin n → Fin k) (col : Fin (n - 1) → Fin ℓ)
    (t : Multiset (Fin k) → Fin ℓ → ℕ) (ht : Identities1F lab col t)
    (hh : ∀ Γ, (8 : ℝ) ≤ colSize col Γ) : 0 ≤ Phi1F lab col t := by
  unfold Phi1F
  refine Finset.sum_nonneg fun π hπ => Finset.sum_nonneg fun Γ _ =>
    term_nonneg (Nat.cast_nonneg _) ?_
  have hle : t π Γ ≤ numPairs lab π := by
    rw [← ht.1 π hπ]
    exact Finset.single_le_sum (f := fun Γ => t π Γ) (fun _ _ => Nat.zero_le _) (mem_univ Γ)
  have hleR : (t π Γ : ℝ) ≤ numPairs lab π := by exact_mod_cast hle
  have h0 : (0 : ℝ) ≤ t π Γ := Nat.cast_nonneg _
  nlinarith [hh Γ]

open ColourStats.Statements in
/-- **The upper half of Theorem 1.7**, exactly as stated. -/
theorem theorem_1_7_upper : Theorem_1_7_upper := by
  intro k ℓ _ _ δ₀ ε hδ hε
  obtain ⟨n₀, h⟩ := Typed1F.theorem_1_7_upper_exp k ℓ δ₀ ε hδ hε
  refine ⟨max n₀ ⌈8 / δ₀⌉₊, fun n hn _ lab col _ hcol t ht => ?_⟩
  have hn8 : (8 : ℝ) ≤ δ₀ * n := ceil_bound hδ (le_of_max_le_right hn)
  rcases Nat.eq_zero_or_pos (count1F lab col t) with h0 | hpos
  · rw [h0, Nat.cast_zero]
    exact add_logsq_nonneg n (Phi1F_nonneg lab col t ht fun Γ => hn8.trans (hcol Γ)) hε
  · have hcount : (0 : ℝ) < count1F lab col t := by exact_mod_cast hpos
    rw [Real.log_le_iff_le_exp hcount]
    exact h n (le_of_max_le_left hn) lab col hcol t

end ColourStats.UpperLog

/-! ### Typical graphs -/

namespace ColourStats.TypedG

open ColourStats ColourStats.Statements ColourStats.TypedSTS ColourStats.UpperLog

open Classical

/-- Under the pair identities (1.6) and at least `24` common neighbours in every class for every
edge, `Φ_G(t) ≥ 0`. -/
theorem PhiG_nonneg {n k : ℕ} (G : SimpleGraph (Fin n)) (lab : Fin n → Fin k)
    (t : Multiset (Fin k) → ℝ) (ht0 : ∀ τ, 0 ≤ t τ) (ht : PairIdentitiesG G lab t)
    (hcnb : ∀ a b X, G.Adj a b → (24 : ℝ) ≤ cnb G lab a b X) : 0 ≤ PhiG G lab t := by
  unfold PhiG
  refine Finset.sum_nonneg fun τ hτ => term_nonneg (ht0 τ) ?_
  obtain ⟨a, b, c, rfl⟩ := Multiset.card_eq_three.mp (mem_blockTypes.mp hτ)
  have hπc : Multiset.card ({b, c} : Multiset (Fin k)) = 2 := by simp
  have hπ : ({b, c} : Multiset (Fin k)) ∈ pairTypes k := mem_pairTypes.mpr hπc
  have hm : (1 : ℝ) ≤ mult {b, c} {a, b, c} := by
    exact_mod_cast Nat.pos_of_ne_zero (mult_cons_ne_zero hπc a)
  have hm3 : (mult {b, c} {a, b, c} : ℝ) ≤ 3 := by
    exact_mod_cast mult_le_three _ _ (mem_blockTypes.mp hτ)
  have hle : t {a, b, c} ≤ edgesOf G lab {b, c} := by
    rw [← ht _ hπ]
    calc t {a, b, c} ≤ mult {b, c} {a, b, c} * t {a, b, c} := by
          nlinarith [ht0 {a, b, c}]
      _ ≤ ∑ τ ∈ blockTypes k, (mult {b, c} τ : ℝ) * t τ :=
        Finset.single_le_sum (f := fun τ => (mult {b, c} τ : ℝ) * t τ)
          (fun τ _ => mul_nonneg (Nat.cast_nonneg _) (ht0 τ)) hτ
  have hsum := sum_cnb (G := G) lab {b, c} a
  have hlow : (edgesOf G lab {b, c} : ℝ) * 24 ≤
      ∑ p ∈ EpiG G lab {b, c}, (cnb G lab p.1 p.2 a : ℝ) := by
    rw [← card_EpiG lab {b, c}]
    have h := Finset.card_nsmul_le_sum (EpiG G lab {b, c}) (fun p => (cnb G lab p.1 p.2 a : ℝ)) 24
      (fun p hp => hcnb _ _ _ (mem_pairsG.mp (Finset.mem_filter.mp hp).1).2)
    rw [nsmul_eq_mul] at h
    linarith
  have hsumR : ∑ p ∈ EpiG G lab {b, c}, (cnb G lab p.1 p.2 a : ℝ) =
      mult {b, c} {a, b, c} * trianglesOf G lab {a, b, c} := by
    rw [← Nat.cast_sum]; exact_mod_cast hsum
  have hN : (0 : ℝ) ≤ trianglesOf G lab {a, b, c} := Nat.cast_nonneg _
  nlinarith [mul_le_mul_of_nonneg_right hm3 hN, ht0 {a, b, c}]

/-- **The upper half of Theorem 1.9(a)**, exactly as stated. -/
theorem theorem_1_9a_upper : Theorem_1_9a_upper := by
  intro k _ c₀ δ₀ d₀ ε hc₀ hδ₀ hd₀ hε
  obtain ⟨n₀, h⟩ := theorem_1_9a_upper_exp k c₀ δ₀ d₀ ε hc₀ hδ₀ hd₀ hε
  set m : ℝ := 1 / 3 with hmdef
  have hm : 0 < m := by norm_num
  set δ' : ℝ := (2 / 3) * δ₀ * d₀ ^ 2 with hδ'
  have hδ'pos : 0 < δ' := by positivity
  set N₁ : ℝ := (1 / m) ^ c₀⁻¹
  refine ⟨max n₀ ⌈N₁ + 26 / δ'⌉₊, fun n hn G lab hyp t ht => ?_⟩
  have hceil : N₁ + 26 / δ' ≤ n :=
    (Nat.le_ceil _).trans (by exact_mod_cast le_of_max_le_right hn)
  have p0 : 0 ≤ N₁ := by positivity
  have p1 : 0 ≤ 26 / δ' := by positivity
  rcases Nat.eq_zero_or_pos (countDecomp G lab t) with h0 | hpos
  · rw [h0, Nat.cast_zero]
    refine add_logsq_nonneg n ?_ hε
    obtain ⟨-, hcls, d, hd, htyp⟩ := hyp
    set η : ℝ := (n : ℝ) ^ (-c₀) with hη
    have hηm : η ≤ m := rpow_neg_le hc₀ hm (show N₁ ≤ n by linarith)
    have hη3 : η ≤ 1 / 3 := hηm
    have hcnb : ∀ a b X, G.Adj a b → δ' * n - 2 ≤ (cnb G lab a b X : ℝ) := by
      intro a b X hab
      have h := htyp {a, b} (by rw [Finset.card_pair hab.ne]; norm_num) X
      rw [card_commonIn_pair, Typical.ideal_pair lab d hab.ne] at h
      have hlow := (abs_le.mp h).1
      have hX : δ₀ * n ≤ ((Typical.classSet lab X).card : ℝ) := hcls X
      have hd1 := hd (lab a) X
      have hd2 := hd (lab b) X
      have hdd : d₀ ^ 2 ≤ d (lab a) X * d (lab b) X := by
        have : 0 ≤ d₀ := hd₀.le
        nlinarith
      have hI : δ₀ * n * d₀ ^ 2 ≤
          ((Typical.classSet lab X).card : ℝ) * (d (lab a) X * d (lab b) X) := by
        calc δ₀ * n * d₀ ^ 2 ≤ ((Typical.classSet lab X).card : ℝ) * d₀ ^ 2 :=
              mul_le_mul_of_nonneg_right hX (by positivity)
          _ ≤ _ := mul_le_mul_of_nonneg_left hdd (Nat.cast_nonneg _)
      have : (1 - η) * (((Typical.classSet lab X).card : ℝ) * (d (lab a) X * d (lab b) X)) ≤
          cnb G lab a b X := by linarith
      have h23 : (2 / 3) * (δ₀ * n * d₀ ^ 2) ≤
          (1 - η) * (((Typical.classSet lab X).card : ℝ) * (d (lab a) X * d (lab b) X)) := by
        have h1η : 2 / 3 ≤ 1 - η := by linarith
        have hIpos : 0 ≤ δ₀ * n * d₀ ^ 2 := by positivity
        nlinarith
      have : δ' * n = (2 / 3) * (δ₀ * n * d₀ ^ 2) := by rw [hδ']; ring
      linarith
    have h26 : (26 : ℝ) ≤ δ' * n := by
      have : 26 / δ' ≤ n := by linarith
      rw [div_le_iff₀ hδ'pos] at this; linarith
    exact PhiG_nonneg G lab _ (fun τ => Nat.cast_nonneg _) ht
      fun a b X hab => by linarith [hcnb a b X hab]
  · have hcount : (0 : ℝ) < countDecomp G lab t := by exact_mod_cast hpos
    rw [Real.log_le_iff_le_exp hcount]
    exact h n (le_of_max_le_left hn) G lab hyp t

end ColourStats.TypedG
