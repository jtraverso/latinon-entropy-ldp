/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import CountingCone.Defs
public import ColourStats.PaschHub

/-!
# Statements: Steiner triple systems with prescribed colour statistics

Target statements of the paper *Counting Steiner triple systems, Latin squares and
1-factorizations with prescribed colour statistics* (draft 6, 14 November 2026).
Each theorem is stated as a `Prop`; nothing here is proved. The Steiner triple systems are
those of the corpus (`STS.IsSTS`, `STS.STSOn` in `CountingCone.Defs`).

* `Theorem_1_2`: bicoloured Steiner triple systems with prescribed block types `XXY`;
* `Theorem_1_5`: Steiner triple systems with prescribed counts of all block types;
* `Theorem_1_5_upper`: the upper half of Theorem 1.5, for every admissible type vector.

Notation: `lab : Fin n → Fin k` is the partition of the points into classes; a block `B`
has type `blockType lab B` (a multiset of three classes); `t τ` is the prescribed number of
blocks of type `τ`; `Phi lab t = Σ_τ t_τ (log(N_τ / t_τ) − 2)` with `N_τ` the number of
triples of type `τ`.
-/

@[expose] public section

open Finset

namespace ColourStats

variable {n k : ℕ}

/-- The type of a set of points: the multiset of the classes of its points. -/
def blockType (lab : Fin n → Fin k) (B : Finset (Fin n)) : Multiset (Fin k) :=
  B.val.map lab

/-- The number of blocks of `D` of type `τ`. -/
def typeCount (lab : Fin n → Fin k) (D : Finset (Finset (Fin n))) (τ : Multiset (Fin k)) : ℕ :=
  (D.filter fun B => blockType lab B = τ).card

/-- `N_τ`: the number of triples of points of type `τ`. -/
def numTriples (lab : Fin n → Fin k) (τ : Multiset (Fin k)) : ℕ :=
  ((univ : Finset (Fin n)).powersetCard 3 |>.filter fun B => blockType lab B = τ).card

/-- `e_π`: the number of pairs of points of class `π`. -/
def numPairs (lab : Fin n → Fin k) (π : Multiset (Fin k)) : ℕ :=
  ((univ : Finset (Fin n)).powersetCard 2 |>.filter fun e => blockType lab e = π).card

/-- The size `c_X` of the class `X`. -/
def classSize (lab : Fin n → Fin k) (X : Fin k) : ℕ :=
  (univ.filter fun v => lab v = X).card

/-- The pair identities (1.4): `Σ_τ m_π(τ) t_τ = e_π` for every pair class `π`. -/
def PairIdentities (lab : Fin n → Fin k) (t : Multiset (Fin k) → ℕ) : Prop :=
  ∀ π ∈ pairTypes k, ∑ τ ∈ blockTypes k, mult π τ * t τ = numPairs lab π

/-- `Φ(t) = Σ_τ t_τ (log(N_τ/t_τ) − 2)`, with `0 · log(·/0) = 0`. -/
noncomputable def Phi (lab : Fin n → Fin k) (t : Multiset (Fin k) → ℕ) : ℝ :=
  ∑ τ ∈ blockTypes k, (t τ : ℝ) * (Real.log ((numTriples lab τ : ℝ) / t τ) - 2)

/-- `N^all_t`: the number of Steiner triple systems on `Fin n` with exactly `t_τ` blocks of
each type `τ`. -/
noncomputable def countAll (lab : Fin n → Fin k) (t : Multiset (Fin k) → ℕ) : ℕ :=
  Nat.card {D : STS.STSOn n // ∀ τ ∈ blockTypes k, typeCount lab D.1 τ = t τ}

/-- **Theorem 1.5.** All block types prescribed, each with at least `ζ n²` blocks:
`log N^all_t = Φ(t) + o(n²)`, uniformly in the partition and in `t`. -/
def Theorem_1_5 : Prop :=
  ∀ k : ℕ, 1 ≤ k → ∀ δ₀ ζ ε : ℝ, 0 < δ₀ → 0 < ζ → 0 < ε → ∃ n₀ : ℕ,
    ∀ n : ℕ, n₀ ≤ n → (n % 6 = 1 ∨ n % 6 = 3) → ∀ lab : Fin n → Fin k,
      (∀ X, δ₀ * n ≤ classSize lab X) →
      ∀ t : Multiset (Fin k) → ℕ, PairIdentities lab t →
        (∀ τ ∈ blockTypes k, ζ * (n : ℝ) ^ 2 ≤ t τ) →
        |Real.log (countAll lab t) - Phi lab t| ≤ ε * (n : ℝ) ^ 2

/-- **Theorem 1.5, upper half.** For every type vector satisfying the pair identities,
`log N^all_t ≤ Φ(t) + o(n²)`. -/
def Theorem_1_5_upper : Prop :=
  ∀ k : ℕ, 1 ≤ k → ∀ δ₀ ε : ℝ, 0 < δ₀ → 0 < ε → ∃ n₀ : ℕ,
    ∀ n : ℕ, n₀ ≤ n → ∀ lab : Fin n → Fin k,
      (∀ X, δ₀ * n ≤ classSize lab X) →
      ∀ t : Multiset (Fin k) → ℕ, PairIdentities lab t →
        Real.log (countAll lab t) ≤ Phi lab t + ε * (n : ℝ) ^ 2

/-- The type vector on all types induced by a bicoloured matrix: `t_{XXY}` blocks of
type `XXY` for `X ≠ Y`, and none of the other types. -/
def bicolTypes (t : Fin k → Fin k → ℕ) (τ : Multiset (Fin k)) : ℕ :=
  ∑ X, ∑ Y, if X ≠ Y ∧ τ = {X, X, Y} then t X Y else 0

/-- Admissible partitions: `n` odd, every `c_X c_Y` even, and
`3 Σ_X c_X (c_X − 1) = n(n − 1)`. -/
def Admissible (lab : Fin n → Fin k) : Prop :=
  Odd n ∧ (∀ X Y, X ≠ Y → Even (classSize lab X * classSize lab Y)) ∧
    3 * ∑ X, classSize lab X * (classSize lab X - 1) = n * (n - 1)

/-- The necessary conditions (1.3): `2(t_XY + t_YX) = c_X c_Y` and
`Σ_{Y ≠ X} t_XY = C(c_X, 2)`. -/
def BicolConditions (lab : Fin n → Fin k) (t : Fin k → Fin k → ℕ) : Prop :=
  (∀ X Y, X ≠ Y → 2 * (t X Y + t Y X) = classSize lab X * classSize lab Y) ∧
    ∀ X, ∑ Y ∈ univ.erase X, t X Y = (classSize lab X).choose 2

/-- **Theorem 1.2.** Bicoloured Steiner triple systems with `t_XY` blocks of type `XXY`:
`log N_t = Φ(t) + o(n²)`, uniformly in the admissible partition and in `t`. -/
def Theorem_1_2 : Prop :=
  ∀ k : ℕ, 3 ≤ k → ∀ δ₀ ζ ε : ℝ, 0 < δ₀ → 0 < ζ → 0 < ε → ∃ n₀ : ℕ,
    ∀ n : ℕ, n₀ ≤ n → ∀ lab : Fin n → Fin k, Admissible lab →
      (∀ X, δ₀ * n ≤ classSize lab X) →
      ∀ t : Fin k → Fin k → ℕ, BicolConditions lab t →
        (∀ X Y, X ≠ Y → ζ * (n : ℝ) ^ 2 ≤ t X Y) →
        |Real.log (countAll lab (bicolTypes t)) - Phi lab (bicolTypes t)| ≤ ε * (n : ℝ) ^ 2

end ColourStats
