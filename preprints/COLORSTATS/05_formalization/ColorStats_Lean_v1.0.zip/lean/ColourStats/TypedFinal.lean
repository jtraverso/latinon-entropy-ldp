/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedAnalytic
public import ColourStats.TypedStats
public import ColourStats.TypeCount

/-!
# The typed Linial–Luria upper bound (Section 4.2, bound (4.3) for all block types)

**Theorem** (`typed_upper`). Let `lab : Fin n → Fin k` have classes of size at least
`c₁ + 2 ≥ 3`, and let `t` be a type vector with at least one Steiner triple system of type `t`.
Then

  `log N^all_t ≤ Φ(t) + n² ((5 log n + 16)/n + 8 / c₁^{1/4})`.

This is the upper half of Theorem 1.5 (and, through `bicolTypes`, of Theorem 1.2) with an
explicit error `O(n log n + n² c₁^{−1/4})`, which is `O(n^{7/4})` when `c₁ ≥ δ₀ n − 2`.

The proof assembles the previous files: the chain rule over random labels with `L = n`
(`typed_raw_bound`), aggregation over pair classes (`typed_agg_bound`), the pair statistics
`M(π, X) = m_π(τ) t_τ` (`Mstat_eq`), the estimate of one term (`term_le`), the double count
`w(τ, π) e_π = m_π(τ) N_τ` of Lemma 5.12 (`ColourFirst.compl_mul_typeNum`), and the
regrouping `Σ_π Σ_X m_π(X :: π) h(X :: π) = 3 Σ_τ h(τ)` (`regroup`).
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.TypedSTS

open ColourStats

variable {n k : ℕ}

/-- `|E_π| = e_π`. -/
lemma card_Epi (lab : Fin n → Fin k) (π : Multiset (Fin k)) :
    (Epi lab π).card = numPairs lab π := by
  unfold Epi numPairs
  refine Finset.card_bij (fun p _ => ({p.1, p.2} : Finset (Fin n))) ?_ ?_ ?_
  · intro p hp
    obtain ⟨hpp, hπp⟩ := Finset.mem_filter.mp hp
    have hlt : p.1 < p.2 := by simpa [pairs] using hpp
    refine Finset.mem_filter.mpr ⟨Finset.mem_powersetCard.mpr ⟨Finset.subset_univ _,
      Finset.card_pair hlt.ne⟩, ?_⟩
    rw [blockType_pair lab hlt.ne, hπp]
  · intro p hp q hq h
    have hp' : p.1 < p.2 := by simpa [pairs] using (Finset.mem_filter.mp hp).1
    have hq' : q.1 < q.2 := by simpa [pairs] using (Finset.mem_filter.mp hq).1
    rcases pair_eq_cases hp'.ne h with ⟨e1, e2⟩ | ⟨e1, e2⟩
    · exact Prod.ext e1 e2
    · exfalso
      rw [e1, e2] at hp'
      exact lt_asymm hp' hq'
  · intro e he
    obtain ⟨he2, hτ⟩ := Finset.mem_filter.mp he
    obtain ⟨-, hcard⟩ := Finset.mem_powersetCard.mp he2
    obtain ⟨x, y, hxy, rfl⟩ := Finset.card_eq_two.mp hcard
    have hpp := sp_mem hxy
    have hlt : (sp x y).1 < (sp x y).2 := by simpa [pairs] using hpp
    refine ⟨sp x y, Finset.mem_filter.mpr ⟨hpp, ?_⟩, sp_set x y⟩
    rw [← blockType_pair lab hlt.ne, sp_set, hτ]

lemma sum_Mstat (lab : Fin n → Fin k) (T : Fin n → Fin n → Fin n) (π : Multiset (Fin k)) :
    ∑ X, Mstat lab T π X = (Epi lab π).card :=
  (Finset.card_eq_sum_card_fiberwise (fun _ _ => Finset.mem_univ _)).symm

lemma card_pairs_le (n : ℕ) : (pairs n).card ≤ n * n := by
  calc (pairs n).card ≤ (univ : Finset (Pair n)).card := Finset.card_le_univ _
    _ = n * n := by simp

lemma sum_Epi (lab : Fin n → Fin k) :
    ∑ π ∈ pairTypes k, (Epi lab π).card = (pairs n).card := by
  have h := sum_pairs_by_class lab (fun _ => (1 : ℝ))
  simp only [Finset.sum_const, nsmul_eq_mul, mul_one] at h
  exact_mod_cast h.symm

/-- `Σ_π m_π(τ) = 3` for a block type `τ`. -/
lemma sum_mult (τ : Multiset (Fin k)) (hτ : τ ∈ blockTypes k) :
    ∑ π ∈ pairTypes k, (mult π τ : ℝ) = 3 := by
  have h := ColourFirst.sum_count_mul (pairTypes k) (ColourStats.pairs τ)
    (fun π hπ => mem_pairTypes.mpr (Multiset.mem_powersetCard.mp hπ).2) (fun _ => (1 : ℝ))
  simp only [mul_one, Multiset.map_const', Multiset.sum_replicate, nsmul_eq_mul] at h
  unfold mult
  rw [h, ColourStats.pairs, Multiset.card_powersetCard, mem_blockTypes.mp hτ]
  norm_num

/-- **Regrouping by block types.** -/
lemma regroup (h : Multiset (Fin k) → ℝ) :
    ∑ π ∈ pairTypes k, ∑ X, (mult π (X ::ₘ π) : ℝ) * h (X ::ₘ π) =
      ∑ τ ∈ blockTypes k, 3 * h τ := by
  have step : ∀ π ∈ pairTypes k, ∑ X, (mult π (X ::ₘ π) : ℝ) * h (X ::ₘ π) =
      ∑ τ ∈ blockTypes k, (mult π τ : ℝ) * h τ := by
    intro π hπ
    rw [← Finset.sum_image (f := fun τ => (mult π τ : ℝ) * h τ) (s := univ)
      (g := fun X : Fin k => X ::ₘ π) (fun X _ Y _ e => (Multiset.cons_inj_left π).mp e)]
    apply Finset.sum_subset
    · intro τ hτ
      obtain ⟨X, -, rfl⟩ := Finset.mem_image.mp hτ
      exact mem_blockTypes.mpr (by simp [mem_pairTypes.mp hπ])
    · intro τ hτ hni
      by_cases hm : mult π τ = 0
      · simp [hm]
      · obtain ⟨C, rfl⟩ := eq_cons_of_mult_ne_zero (mem_blockTypes.mp hτ) hm
        exact absurd (Finset.mem_image.mpr ⟨C, Finset.mem_univ _, rfl⟩) hni
  rw [Finset.sum_congr rfl step, Finset.sum_comm]
  refine Finset.sum_congr rfl fun τ hτ => ?_
  rw [← Finset.sum_mul, sum_mult τ hτ]

lemma mult_eq_zero_of_card {π τ : Multiset (Fin k)} (hπ : Multiset.card π ≠ 2) :
    mult π τ = 0 := by
  unfold mult ColourStats.pairs
  rw [Multiset.count_eq_zero]
  intro h
  exact hπ (Multiset.mem_powersetCard.mp h).2

/-- `N^all_t` is the size of any finset listing the systems of type `t`. -/
lemma countAll_eq_card (lab : Fin n → Fin k) (t : Multiset (Fin k) → ℕ)
    (Dset : Finset (Finset (Finset (Fin n))))
    (hD : ∀ D, D ∈ Dset ↔ STS.IsSTS D ∧ ∀ τ ∈ blockTypes k, typeCount lab D τ = t τ) :
    countAll lab t = Dset.card := by
  unfold countAll
  have e : {D : STS.STSOn n // ∀ τ ∈ blockTypes k, typeCount lab D.1 τ = t τ} ≃
      {D // D ∈ Dset} :=
    { toFun := fun x => ⟨x.1.1, (hD _).mpr ⟨x.1.2, x.2⟩⟩
      invFun := fun y => ⟨⟨y.1, ((hD _).mp y.2).1⟩, ((hD _).mp y.2).2⟩
      left_inv := fun x => rfl
      right_inv := fun y => rfl }
  rw [Nat.card_congr e, Nat.card_eq_fintype_card, Fintype.card_coe]

/-- **The typed Linial–Luria bound.** -/
theorem typed_upper (lab : Fin n → Fin k) (t : Multiset (Fin k) → ℕ) {c₁ : ℝ} (hc₁ : 1 ≤ c₁)
    (hc : ∀ X, c₁ + 2 ≤ classSize lab X) (hn : 1 ≤ n) (hpos : 0 < countAll lab t) :
    Real.log (countAll lab t) ≤ Phi lab t +
      (n : ℝ) ^ 2 * ((5 * Real.log n + 16) / n + 8 / Real.sqrt (Real.sqrt c₁)) := by
  classical
  have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hnpos : (0 : ℝ) < n := by linarith
  have hlogn : 0 ≤ Real.log n := Real.log_nonneg hn1
  have hc3 : ∀ X, 3 ≤ classSize lab X := by
    intro X
    have := hc X
    have h3 : (3 : ℝ) ≤ classSize lab X := by linarith
    exact_mod_cast h3
  -- the systems and their quasigroups
  set Dset := (univ : Finset (Finset (Finset (Fin n)))).filter fun D =>
    STS.IsSTS D ∧ ∀ τ ∈ blockTypes k, typeCount lab D τ = t τ
  set S := Dset.image thirdPt
  have hcount : countAll lab t = S.card := by
    rw [countAll_eq_card lab t Dset (fun D => by simp [Dset]), Finset.card_image_of_injOn]
    intro B hB B' hB' h
    exact thirdPt_injective (Finset.mem_filter.mp hB).2.1 (Finset.mem_filter.mp hB').2.1 h
  have hS : ∀ T ∈ S, IsSQ T := by
    intro T hT
    obtain ⟨B, hB, rfl⟩ := Finset.mem_image.mp hT
    exact thirdPt_isSQ (Finset.mem_filter.mp hB).2.1
  have hne : S.Nonempty := by
    rw [← Finset.card_pos, ← hcount]
    exact hpos
  set M : Multiset (Fin k) → Fin k → ℕ := fun π X => mult π (X ::ₘ π) * t (X ::ₘ π)
  have hM : ∀ T ∈ S, ∀ π X, Mstat lab T π X = M π X := by
    intro T hT π X
    obtain ⟨B, hB, rfl⟩ := Finset.mem_image.mp hT
    obtain ⟨hBs, hBt⟩ := (Finset.mem_filter.mp hB).2
    rw [Mstat_eq hBs lab π X]
    by_cases hπ : Multiset.card π = 2
    · rw [hBt _ (mem_blockTypes.mpr (by simp [hπ]))]
    · simp [M, mult_eq_zero_of_card hπ]
  have hagg := typed_agg_bound (L := n) hS hne lab hn M hM
  rw [hcount]
  -- the uniform error
  set errU : ℝ := (5 * Real.log n + 16) / n + 8 / Real.sqrt (Real.sqrt c₁)
  -- the per-term bound
  have hterm : ∀ π ∈ pairTypes k, ∀ X, (M π X : ℝ) *
      (Wsum n * (Real.log (Epi lab π).card - Real.log (M π X)) + Psi n (compl lab π X)) ≤
      (mult π (X ::ₘ π) : ℝ) * ((t (X ::ₘ π) : ℝ) *
        ((1 / 3) * (Real.log (numTriples lab (X ::ₘ π)) - Real.log (t (X ::ₘ π))) - 2 / 3)) +
      (M π X : ℝ) * errU := by
    intro π hπ X
    by_cases hM0 : M π X = 0
    · have : (mult π (X ::ₘ π) : ℝ) * (t (X ::ₘ π) : ℝ) = 0 := by
        have h' : ((M π X : ℕ) : ℝ) = 0 := by exact_mod_cast hM0
        simpa [M] using h'
      rw [hM0]
      simp only [Nat.cast_zero, zero_mul, add_zero]
      rw [← mul_assoc, this, zero_mul]
    have hMpos : 0 < M π X := Nat.pos_of_ne_zero hM0
    have hmpos : 0 < mult π (X ::ₘ π) := Nat.pos_of_ne_zero fun h => hM0 (by simp [M, h])
    have htpos : 0 < t (X ::ₘ π) := Nat.pos_of_ne_zero fun h => hM0 (by simp [M, h])
    have hπ2 := mem_pairTypes.mp hπ
    obtain ⟨b, c, hbc⟩ := Multiset.card_eq_two.mp hπ2
    -- `M ≤ |E_π|`
    obtain ⟨T₀, hT₀⟩ := hne
    have hME : M π X ≤ (Epi lab π).card := by
      rw [← hM T₀ hT₀ π X]
      exact Finset.card_filter_le _ _
    have hEpos : 0 < (Epi lab π).card := lt_of_lt_of_le hMpos hME
    -- the double count `compl · e_π = m_π(τ) N_τ`
    have hdc : (compl lab π X : ℝ) * (Epi lab π).card =
        (mult π (X ::ₘ π) : ℝ) * numTriples lab (X ::ₘ π) := by
      rw [card_Epi, numPairs_eq lab hπ2, numTriples_eq lab (by simp [hπ2])]
      have h := ColourFirst.compl_mul_typeNum (classSize lab) X b c
      rw [← hbc] at h
      have h' : compl lab π X = ColourFirst.compl (classSize lab) X π := rfl
      rw [h']
      exact_mod_cast h
    -- bounds on `compl`
    have hcount2 : π.count X ≤ 2 := hπ2 ▸ Multiset.count_le_card X π
    have hcls_le : classSize lab X ≤ n := by
      calc classSize lab X ≤ (univ : Finset (Fin n)).card := Finset.card_filter_le _ _
        _ = n := by simp
    have hcompl_cast : (compl lab π X : ℝ) = classSize lab X - π.count X := by
      have : π.count X ≤ classSize lab X := by have := hc3 X; omega
      have h' : compl lab π X = classSize lab X - π.count X := rfl
      rw [h', Nat.cast_sub this]
    have hcompl_ge : c₁ ≤ (compl lab π X : ℝ) := by
      rw [hcompl_cast]
      have h2 : ((π.count X : ℕ) : ℝ) ≤ 2 := by exact_mod_cast hcount2
      linarith [hc X]
    have hcompl_le : (compl lab π X : ℝ) ≤ n := by
      rw [hcompl_cast]
      have : (classSize lab X : ℝ) ≤ n := by exact_mod_cast hcls_le
      have : (0 : ℝ) ≤ π.count X := Nat.cast_nonneg _
      linarith
    have hc1' : (1 : ℝ) ≤ compl lab π X := hc₁.trans hcompl_ge
    -- `x = |E_π| / M ≥ 1`
    have hEr : (0 : ℝ) < (Epi lab π).card := by exact_mod_cast hEpos
    have hMr : (0 : ℝ) < M π X := by exact_mod_cast hMpos
    have hx1 : (1 : ℝ) ≤ (Epi lab π).card / M π X := by
      rw [le_div_iff₀ hMr, one_mul]; exact_mod_cast hME
    have hlogx : Real.log (Epi lab π).card - Real.log (M π X) =
        Real.log ((Epi lab π).card / M π X) := (Real.log_div hEr.ne' hMr.ne').symm
    have ht := term_le (L := n) hn hc1' hx1
    rw [← hlogx] at ht
    -- `log x + log c = log(N_τ / t_τ)`
    have hmr : (0 : ℝ) < mult π (X ::ₘ π) := by exact_mod_cast hmpos
    have htr : (0 : ℝ) < t (X ::ₘ π) := by exact_mod_cast htpos
    have hcr : (0 : ℝ) < compl lab π X := by linarith
    have hNr : (0 : ℝ) < numTriples lab (X ::ₘ π) := by
      have : 0 < (mult π (X ::ₘ π) : ℝ) * numTriples lab (X ::ₘ π) := by
        rw [← hdc]; positivity
      exact pos_of_mul_pos_right this hmr.le
    have hsumlog : (Real.log (Epi lab π).card - Real.log (M π X)) + Real.log (compl lab π X) =
        Real.log (numTriples lab (X ::ₘ π)) - Real.log (t (X ::ₘ π)) := by
      have hMe : (M π X : ℝ) = mult π (X ::ₘ π) * t (X ::ₘ π) := by simp [M]
      have h1 : Real.log (compl lab π X) + Real.log (Epi lab π).card =
          Real.log (mult π (X ::ₘ π)) + Real.log (numTriples lab (X ::ₘ π)) := by
        rw [← Real.log_mul hcr.ne' hEr.ne', ← Real.log_mul hmr.ne' hNr.ne', hdc]
      rw [hMe, Real.log_mul hmr.ne' htr.ne']
      linarith
    -- the error
    have hlogE : Real.log (Epi lab π).card - Real.log (M π X) ≤ 2 * Real.log n := by
      have hE : ((Epi lab π).card : ℝ) ≤ (n : ℝ) ^ 2 := by
        have := (Finset.card_le_card (Finset.filter_subset _ _ : Epi lab π ⊆ pairs n)).trans
          (card_pairs_le n)
        have : ((Epi lab π).card : ℝ) ≤ (n * n : ℕ) := by exact_mod_cast this
        push_cast at this
        nlinarith
      have hM1 : (1 : ℝ) ≤ M π X := by exact_mod_cast hMpos
      have h1 : Real.log (Epi lab π).card ≤ Real.log ((n : ℝ) ^ 2) := Real.log_le_log hEr hE
      have h2 : 0 ≤ Real.log (M π X) := Real.log_nonneg hM1
      rw [Real.log_pow] at h1
      push_cast at h1
      linarith
    have hlogc : Real.log (compl lab π X) ≤ Real.log n := Real.log_le_log hcr hcompl_le
    have hsq : 8 / Real.sqrt (Real.sqrt (compl lab π X)) ≤ 8 / Real.sqrt (Real.sqrt c₁) := by
      apply div_le_div_of_nonneg_left (by norm_num)
      · exact Real.sqrt_pos.mpr (Real.sqrt_pos.mpr (by linarith))
      · exact Real.sqrt_le_sqrt (Real.sqrt_le_sqrt hcompl_ge)
    have herr : (Real.log ((Epi lab π).card / M π X) + 3 * Real.log (compl lab π X) + 16) / n +
        8 / Real.sqrt (Real.sqrt (compl lab π X)) ≤ errU := by
      rw [← hlogx]
      have : (Real.log (Epi lab π).card - Real.log (M π X) + 3 * Real.log (compl lab π X) + 16)
          / n ≤ (5 * Real.log n + 16) / n := by
        apply div_le_div_of_nonneg_right _ hnpos.le
        linarith
      simp only [errU]
      linarith
    -- assemble the term
    have hmain : Wsum n * (Real.log (Epi lab π).card - Real.log (M π X)) +
        Psi n (compl lab π X) ≤
        (1 / 3) * (Real.log (numTriples lab (X ::ₘ π)) - Real.log (t (X ::ₘ π))) - 2 / 3 +
          errU := by
      rw [← hsumlog]
      rw [hlogx] at ht ⊢
      linarith
    have hMe : (M π X : ℝ) = mult π (X ::ₘ π) * t (X ::ₘ π) := by simp [M]
    calc (M π X : ℝ) * (Wsum n * (Real.log (Epi lab π).card - Real.log (M π X)) +
          Psi n (compl lab π X))
        ≤ (M π X : ℝ) * ((1 / 3) * (Real.log (numTriples lab (X ::ₘ π)) -
            Real.log (t (X ::ₘ π))) - 2 / 3 + errU) :=
          mul_le_mul_of_nonneg_left hmain hMr.le
      _ = _ := by rw [hMe]; ring
  -- sum the terms
  have hsum := Finset.sum_le_sum fun π hπ => Finset.sum_le_sum fun X (_ : X ∈ univ) =>
    hterm π hπ X
  simp only [Finset.sum_add_distrib] at hsum
  have hreg := regroup (fun τ => (t τ : ℝ) * ((1 / 3) * (Real.log (numTriples lab τ) -
    Real.log (t τ)) - 2 / 3))
  rw [hreg] at hsum
  -- the main term is `Φ(t)`
  have hPhi : ∑ τ ∈ blockTypes k, 3 * ((t τ : ℝ) * ((1 / 3) * (Real.log (numTriples lab τ) -
      Real.log (t τ)) - 2 / 3)) = Phi lab t := by
    unfold Phi
    refine Finset.sum_congr rfl fun τ hτ => ?_
    by_cases ht0 : t τ = 0
    · simp [ht0]
    · have htr : (0 : ℝ) < t τ := by exact_mod_cast Nat.pos_of_ne_zero ht0
      have hNr : (0 : ℝ) < numTriples lab τ := by
        rw [numTriples_eq lab (mem_blockTypes.mp hτ)]
        exact_mod_cast ColourFirst.typeNum_pos_of_card (j := 3) hc3 (mem_blockTypes.mp hτ)
      rw [Real.log_div hNr.ne' htr.ne']
      ring
  rw [hPhi] at hsum
  -- the error term
  have herr0 : 0 ≤ errU := by
    have : 0 < Real.sqrt (Real.sqrt c₁) :=
      Real.sqrt_pos.mpr (Real.sqrt_pos.mpr (by linarith))
    simp only [errU]
    positivity
  have hcnt : ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) ≤ (n : ℝ) ^ 2 := by
    obtain ⟨T₀, hT₀⟩ := hne
    have h1 : ∀ π ∈ pairTypes k, ∑ X, (M π X : ℝ) = (Epi lab π).card := by
      intro π _
      rw [← sum_Mstat lab T₀ π]
      push_cast
      exact Finset.sum_congr rfl fun X _ => by rw [hM T₀ hT₀ π X]
    rw [Finset.sum_congr rfl h1]
    have h2 : ∑ π ∈ pairTypes k, ((Epi lab π).card : ℝ) = (pairs n).card := by
      exact_mod_cast sum_Epi lab
    rw [h2]
    have h3 : ((pairs n).card : ℝ) ≤ (n * n : ℕ) := by exact_mod_cast card_pairs_le n
    push_cast at h3
    nlinarith
  have hErr : ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) * errU ≤ (n : ℝ) ^ 2 * errU := by
    have e : ∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ) * errU =
        (∑ π ∈ pairTypes k, ∑ X, (M π X : ℝ)) * errU := by
      rw [Finset.sum_mul]
      exact Finset.sum_congr rfl fun π _ => by rw [Finset.sum_mul]
    rw [e]
    exact mul_le_mul_of_nonneg_right hcnt herr0
  linarith

end ColourStats.TypedSTS
