/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedChain

/-!
# The typed chain bound with a coarser past

The revealing order of Section 4.2 comes from random labels `λ_e ∈ Fin L` with ties broken by
a fixed index. Ties make the event "`e` precedes the other pairs of its block" depend on the
system. The remedy is to condition each coordinate only on the coordinates with a *strictly
smaller label* (a coarser past). Conditioning on less information can only increase entropy
(`coarsen_le`), and with the coarser past the relevant events no longer depend on the system.

Main result, `chain_typed`: if `key₁` is injective on `I`, the coordinates determine the
elements of `S`, and `key₂ t < key₂ s → key₁ t < key₁ s`, then
`|S| log |S| ≤ Σ_s Σ_x [(log |B₂(s, x)| − log |C₂(s, x)|) + log #f_s(C₂(s, x))]`,
where `B₂(s, x)` is the set of elements agreeing with `x` on the coordinates with smaller
`key₂`, and `C₂(s, x) ⊆ B₂(s, x)` those whose coordinate `s` has the class of that of `x`.
-/

@[expose] public section

open Finset

namespace ColourStats.TypedChain

variable {α ι β κ : Type*} [DecidableEq α] [DecidableEq β] [DecidableEq κ]

lemma before_eq {S : Finset α} {I : Finset ι} {key : ι → ℕ} {f : ι → α → β} {s : ι} {x y : α}
    (hy : y ∈ before S I key f s x) : before S I key f s y = before S I key f s x := by
  obtain ⟨hyS, hagree⟩ := Finset.mem_filter.mp hy
  ext z
  simp only [before, Finset.mem_filter]
  constructor
  · rintro ⟨hz, h⟩
    exact ⟨hz, fun t ht hts => (h t ht hts).trans (hagree t ht hts)⟩
  · rintro ⟨hz, h⟩
    exact ⟨hz, fun t ht hts => (h t ht hts).trans (hagree t ht hts).symm⟩

lemma before_subset {S : Finset α} {I : Finset ι} {key : ι → ℕ} {f : ι → α → β} {s : ι}
    {x : α} : before S I key f s x ⊆ S :=
  Finset.filter_subset _ _

lemma before_mono {S : Finset α} {I : Finset ι} {key₁ key₂ : ι → ℕ} {f : ι → α → β} {s : ι}
    (hs : s ∈ I) (href : ∀ t ∈ I, key₂ t < key₂ s → key₁ t < key₁ s) (x : α) :
    before S I key₁ f s x ⊆ before S I key₂ f s x := by
  intro y hy
  obtain ⟨hyS, h⟩ := Finset.mem_filter.mp hy
  exact Finset.mem_filter.mpr ⟨hyS, fun t ht hts => h t ht (href t ht hts)⟩

lemma upto_eq_before_filter {S : Finset α} {I : Finset ι} {key : ι → ℕ} {f : ι → α → β}
    (hkey : Set.InjOn key I) {s : ι} (hs : s ∈ I) (x : α) :
    upto S I key f s x = (before S I key f s x).filter fun y => f s y = f s x := by
  ext y
  simp only [upto, before, Finset.mem_filter]
  constructor
  · rintro ⟨hy, h⟩
    exact ⟨⟨hy, fun t ht hts => h t ht hts.le⟩, h s hs le_rfl⟩
  · rintro ⟨⟨hy, h⟩, hs'⟩
    refine ⟨hy, fun t ht hts => ?_⟩
    rcases hts.lt_or_eq with h' | h'
    · exact h t ht h'
    · rw [hkey ht hs h']
      exact hs'

/-- **A coarser past increases entropy.** -/
theorem coarsen_le (key₁ key₂ : ι → ℕ) (f : ι → α → β) (S : Finset α) (I : Finset ι)
    (hkey : Set.InjOn key₁ I) {s : ι} (hs : s ∈ I)
    (href : ∀ t ∈ I, key₂ t < key₂ s → key₁ t < key₁ s) :
    ∑ x ∈ S, (Real.log (before S I key₁ f s x).card - Real.log (upto S I key₁ f s x).card) ≤
      ∑ x ∈ S, (Real.log (before S I key₂ f s x).card -
        Real.log ((before S I key₂ f s x).filter fun y => f s y = f s x).card) := by
  refine sum_le_of_blocks S (before S I key₂ f s) (fun x hx => ⟨mem_before_self hx,
    before_subset⟩) (fun x _ y hy => before_eq hy) _ _ (fun x hx => ?_)
  set U := before S I key₂ f s x
  have hb : ∀ y ∈ U, (U.filter fun z => before S I key₁ f s z = before S I key₁ f s y) =
      before S I key₁ f s y := by
    intro y hy
    ext z
    simp only [Finset.mem_filter]
    constructor
    · rintro ⟨hz, he⟩
      exact he ▸ mem_before_self (before_subset hz)
    · intro hz
      refine ⟨?_, before_eq hz⟩
      have hyU : before S I key₂ f s y = U := before_eq hy
      rw [← hyU]
      exact before_mono hs href y hz
  have hbc : ∀ y ∈ U, (U.filter fun z => before S I key₁ f s z = before S I key₁ f s y ∧
      f s z = f s y) = (before S I key₁ f s y).filter fun z => f s z = f s y := by
    intro y hy
    ext z
    simp only [Finset.mem_filter]
    constructor
    · rintro ⟨hz, he, hv⟩
      exact ⟨he ▸ mem_before_self (before_subset hz), hv⟩
    · rintro ⟨hz, hv⟩
      refine ⟨?_, before_eq hz, hv⟩
      have hyU : before S I key₂ f s y = U := before_eq hy
      rw [← hyU]
      exact before_mono hs href y hz
  have hc : ∀ y ∈ U, (U.filter fun z => f s z = f s y) =
      (before S I key₂ f s y).filter fun z => f s z = f s y := by
    intro y hy
    rw [before_eq hy]
  have hU : ∀ y ∈ U, U = before S I key₂ f s y := fun y hy => (before_eq hy).symm
  have h := cond_le U (fun z => before S I key₁ f s z) (fun z => f s z)
  calc ∑ y ∈ U, (Real.log (before S I key₁ f s y).card - Real.log (upto S I key₁ f s y).card)
      = ∑ y ∈ U, (Real.log (U.filter fun z => before S I key₁ f s z =
            before S I key₁ f s y).card -
          Real.log (U.filter fun z => before S I key₁ f s z = before S I key₁ f s y ∧
            f s z = f s y).card) := by
        refine Finset.sum_congr rfl fun y hy => ?_
        rw [hb y hy, hbc y hy, upto_eq_before_filter hkey hs]
    _ ≤ ∑ y ∈ U, (Real.log U.card - Real.log (U.filter fun z => f s z = f s y).card) := h
    _ = ∑ y ∈ U, (Real.log (before S I key₂ f s y).card -
          Real.log ((before S I key₂ f s y).filter fun z => f s z = f s y).card) := by
        refine Finset.sum_congr rfl fun y hy => ?_
        rw [hc y hy, ← hU y hy]

/-- The point part with a filter in place of `upto`. -/
theorem point_part_le' (key : ι → ℕ) (f : ι → α → β) (cl : β → κ) (S : Finset α)
    (I : Finset ι) (s : ι) :
    ∑ x ∈ S, (Real.log (sameClass S I key f cl s x).card -
        Real.log ((before S I key f s x).filter fun y => f s y = f s x).card) ≤
      ∑ x ∈ S, Real.log ((sameClass S I key f cl s x).image (f s)).card := by
  refine sum_le_of_blocks S (sameClass S I key f cl s) (fun x hx => ⟨?_, ?_⟩)
    (fun x _ y hy => sameClass_eq hy) _ _ (fun x hx => ?_)
  · exact Finset.mem_filter.mpr ⟨mem_before_self hx, rfl⟩
  · intro y hy
    exact (Finset.mem_filter.mp (Finset.mem_filter.mp hy).1).1
  · set B := sameClass S I key f cl s x
    have h1 : ∀ y ∈ B, Real.log (sameClass S I key f cl s y).card -
        Real.log ((before S I key f s y).filter fun z => f s z = f s y).card =
        Real.log B.card - Real.log (B.filter fun z => f s z = f s y).card := by
      intro y hy
      have hfilt : ((before S I key f s y).filter fun z => f s z = f s y) =
          (sameClass S I key f cl s y).filter fun z => f s z = f s y := by
        ext z
        simp only [sameClass, Finset.mem_filter]
        constructor
        · rintro ⟨hz, he⟩
          exact ⟨⟨hz, by rw [he]⟩, he⟩
        · rintro ⟨⟨hz, -⟩, he⟩
          exact ⟨hz, he⟩
      rw [hfilt, sameClass_eq hy]
    have h2 : ∀ y ∈ B, Real.log ((sameClass S I key f cl s y).image (f s)).card =
        Real.log (B.image (f s)).card := by
      intro y hy
      rw [sameClass_eq hy]
    rw [Finset.sum_congr rfl h1, Finset.sum_congr rfl h2, Finset.sum_const, nsmul_eq_mul]
    exact block_values_le B (f s)

/-- **The typed chain bound.** -/
theorem chain_typed (key₁ key₂ : ι → ℕ) (f : ι → α → β) (cl : β → κ) (S : Finset α)
    (I : Finset ι) (hkey : Set.InjOn key₁ I)
    (hdet : ∀ x ∈ S, ∀ y ∈ S, (∀ s ∈ I, f s x = f s y) → x = y)
    (href : ∀ s ∈ I, ∀ t ∈ I, key₂ t < key₂ s → key₁ t < key₁ s) :
    (S.card : ℝ) * Real.log S.card ≤
      ∑ s ∈ I, ∑ x ∈ S, ((Real.log (before S I key₂ f s x).card -
          Real.log (sameClass S I key₂ f cl s x).card) +
        Real.log ((sameClass S I key₂ f cl s x).image (f s)).card) := by
  have h1 : (S.card : ℝ) * Real.log S.card = ∑ x ∈ S, Real.log S.card := by
    rw [Finset.sum_const, nsmul_eq_mul]
  rw [h1, Finset.sum_congr rfl fun x hx => telescope key₁ f S I hkey hdet hx, Finset.sum_comm]
  refine Finset.sum_le_sum fun s hs => ?_
  have hc := coarsen_le key₁ key₂ f S I hkey hs (href s hs)
  have hp := point_part_le' key₂ f cl S I s
  have hsplit : ∀ x ∈ S, Real.log (before S I key₂ f s x).card -
      Real.log ((before S I key₂ f s x).filter fun y => f s y = f s x).card =
      (Real.log (before S I key₂ f s x).card - Real.log (sameClass S I key₂ f cl s x).card) +
      (Real.log (sameClass S I key₂ f cl s x).card -
        Real.log ((before S I key₂ f s x).filter fun y => f s y = f s x).card) := by
    intro x _
    ring
  rw [Finset.sum_congr rfl hsplit, Finset.sum_add_distrib] at hc
  rw [Finset.sum_add_distrib]
  linarith

end ColourStats.TypedChain
