/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Weighting

/-!
# The error `E₂` of the weighting `W_1` (Lemma 5.19)

On an `(η, h)`-typical graph with `h ≥ 2`, the weighting `w = weight A B` of
`ColourStats.Weighting` has load `1_{π₀}(xy) + E₂(xy)` on every pair `xy` of distinct
vertices, with

    |E₂(xy)| ≤ η Σ_Z |w({X, Y, Z})| |Z| d(X, Z) d(Y, Z)        (`load_weight_error`).

Combined with an upper bound for the right side (finitely many types), this is the estimate
`‖e₂‖ ≤ ε₂ = O(η)` used in `E3Assembly.right_inverse_of_estimates`.
-/

@[expose] public section

open Finset

namespace ColourStats.Weighting

open Typical

variable {V : Type*} [Fintype V] [DecidableEq V] {k : ℕ}

lemma triple_eq_cons (X Y Z : Fin k) : ({X, Y, Z} : Multiset (Fin k)) = Z ::ₘ {X, Y} := by
  show X ::ₘ Y ::ₘ {Z} = Z ::ₘ X ::ₘ {Y}
  simp only [← Multiset.singleton_add]
  abel

lemma ideal_pair_eq (cls : V → Fin k) (d : Fin k → Fin k → ℝ) {x y : V} (hxy : x ≠ y)
    (Z : Fin k) :
    ideal cls d {x, y} Z =
      csz cls Z * ((({cls x, cls y} : Multiset (Fin k)).map fun X => d X Z).prod) := by
  rw [ideal_pair cls d hxy]
  simp [csz, Multiset.insert_eq_cons]

/-- **The error of `W_1`.** -/
theorem load_weight_error {G : SimpleGraph V} [DecidableRel G.Adj] {cls : V → Fin k}
    {d : Fin k → Fin k → ℝ} {η : ℝ} {h : ℕ} (hT : IsTypical G cls d η h) (hh : 2 ≤ h)
    {A B : Fin k} (hA : csz cls A ≠ 0) (hdAA : d A A ≠ 0) (hdBA : d B A ≠ 0)
    {x y : V} (hxy : x ≠ y) :
    |load G cls (weight cls d A B) x y -
        (if ({cls x, cls y} : Multiset (Fin k)) = {A, B} then 1 else 0)| ≤
      η * ∑ Z, |weight cls d A B {cls x, cls y, Z}| * ideal cls d {x, y} Z := by
  have hid : ∑ Z, weight cls d A B {cls x, cls y, Z} * ideal cls d {x, y} Z =
      if ({cls x, cls y} : Multiset (Fin k)) = {A, B} then 1 else 0 := by
    rw [← idealLoad_weight cls d hA hdAA hdBA]
    unfold idealLoad
    refine Finset.sum_congr rfl fun Z _ => ?_
    rw [triple_eq_cons, ideal_pair_eq cls d hxy]
  rw [← hid]
  exact load_estimate hT hh hxy _

end ColourStats.Weighting
