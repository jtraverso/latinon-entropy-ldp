/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import Mathlib

/-!
# The triangle lattice of rich hosts inside `K_m ∨ C_h` (Lemma 5.17)

A host `H ⊂ K_m ∨ C_h` is given by a graph `G` on the vertices and a set `EC` of
vertex–colour pairs. Its triangles are `{u, v, c}` with `uv ∈ G` and `uc, vc ∈ EC`.

The paper's richness hypothesis ("every two vertices and two colours span the four triangles
needed below, and any three vertices have a common colour neighbour") is not precise: read
literally it forces `H = K_m ∨ C_h`. We use the following hypotheses (`Rich`), which are
exactly what the proof needs and which follow from typicality:
* every three colours (not necessarily distinct) have a common vertex neighbour;
* for two colours `c, c'`, any two vertices `u, w` adjacent to both have a common
  neighbour `x` in `G` that is also adjacent to both colours;
* every edge `uv` of `G` lies in a triangle of `H`.

Main results, for `H` balanced (`deg_G(u) = deg_C(u)`) with even colour degrees:
* `sum_eq_zero_of_rich`: every map from the pairs of `H` to an abelian group that sums to
  zero on every triangle sums to zero on all pairs of `H`;
* `mem_span_of_rich`: `1_{E(H)}` is an integer sum of triangles of `H`.

The proof is the one of the paper: `χ(uc) = a(u) + b(c)` with `2b = 0` and
`χ(uv) = −a(u) − a(v)`.
-/

@[expose] public section

open Finset

namespace ColourStats.E2Lattice

variable {V C : Type*} [Fintype V] [DecidableEq V] [Fintype C] [DecidableEq C]

/-- The richness hypotheses for Lemma 5.17. -/
structure Rich (G : SimpleGraph V) (EC : Finset (V × C)) : Prop where
  three_colours : ∀ c c' c'', ∃ u, (u, c) ∈ EC ∧ (u, c') ∈ EC ∧ (u, c'') ∈ EC
  link : ∀ c c' u w, (u, c) ∈ EC → (u, c') ∈ EC → (w, c) ∈ EC → (w, c') ∈ EC →
    ∃ x, G.Adj u x ∧ G.Adj w x ∧ (x, c) ∈ EC ∧ (x, c') ∈ EC
  edge : ∀ u v, G.Adj u v → ∃ c, (u, c) ∈ EC ∧ (v, c) ∈ EC

section Group

variable {A : Type*} [AddCommGroup A]

lemma even_nsmul_eq_zero {n : ℕ} (hn : Even n) {b : A} (hb : 2 • b = 0) : n • b = 0 := by
  obtain ⟨j, rfl⟩ := hn
  rw [add_nsmul, ← nsmul_add, ← two_nsmul, hb, nsmul_zero]

/-- **Lemma 5.17, dual form.** -/
theorem sum_eq_zero_of_rich (G : SimpleGraph V) [DecidableRel G.Adj] (EC : Finset (V × C))
    (hR : Rich G EC) (hbal : ∀ u, G.degree u = (EC.filter fun p => p.1 = u).card)
    (heven : ∀ c, Even (EC.filter fun p => p.2 = c).card)
    (χV : Sym2 V → A) (χC : V × C → A)
    (htri : ∀ u v c, G.Adj u v → (u, c) ∈ EC → (v, c) ∈ EC →
      χV s(u, v) + χC (u, c) + χC (v, c) = 0) :
    ∑ e ∈ G.edgeFinset, χV e + ∑ p ∈ EC, χC p = 0 := by
  by_cases hEC : EC = ∅
  · have hE : G.edgeFinset = ∅ := by
      ext e
      induction e using Sym2.ind with
      | _ u v =>
        simp only [SimpleGraph.mem_edgeFinset, SimpleGraph.mem_edgeSet, Finset.notMem_empty,
          iff_false]
        intro huv
        obtain ⟨c, hc, -⟩ := hR.edge u v huv
        simp [hEC] at hc
    simp [hE, hEC]
  obtain ⟨⟨u₀, c₀⟩, hp₀⟩ := Finset.nonempty_iff_ne_empty.mpr hEC
  -- the differences `D(u, c, c') = χ(uc) − χ(uc')`
  have hA : ∀ c c' u u', G.Adj u u' → (u, c) ∈ EC → (u, c') ∈ EC → (u', c) ∈ EC →
      (u', c') ∈ EC → (χC (u, c) - χC (u, c')) + (χC (u', c) - χC (u', c')) = 0 := by
    intro c c' u u' huu' huc huc' hu'c hu'c'
    have t1 := htri u u' c huu' huc hu'c
    have t2 := htri u u' c' huu' huc' hu'c'
    have : (χC (u, c) - χC (u, c')) + (χC (u', c) - χC (u', c')) =
        (χV s(u, u') + χC (u, c) + χC (u', c)) - (χV s(u, u') + χC (u, c') + χC (u', c')) := by
      abel
    rw [this, t1, t2, sub_zero]
  have hB : ∀ c c' u, (u, c) ∈ EC → (u, c') ∈ EC → 2 • (χC (u, c) - χC (u, c')) = 0 := by
    intro c c' u huc huc'
    obtain ⟨x, hux, -, hxc, hxc'⟩ := hR.link c c' u u huc huc' huc huc'
    obtain ⟨y, huy, hxy, hyc, hyc'⟩ := hR.link c c' u x huc huc' hxc hxc'
    have e1 := hA c c' u x hux huc huc' hxc hxc'
    have e2 := hA c c' x y hxy hxc hxc' hyc hyc'
    have e3 := hA c c' u y huy huc huc' hyc hyc'
    have : 2 • (χC (u, c) - χC (u, c')) =
        ((χC (u, c) - χC (u, c')) + (χC (x, c) - χC (x, c'))) -
          ((χC (x, c) - χC (x, c')) + (χC (y, c) - χC (y, c'))) +
          ((χC (u, c) - χC (u, c')) + (χC (y, c) - χC (y, c'))) := by
      abel
    rw [this, e1, e2, e3]
    abel
  have hC : ∀ c c' u w, (u, c) ∈ EC → (u, c') ∈ EC → (w, c) ∈ EC → (w, c') ∈ EC →
      χC (u, c) - χC (u, c') = χC (w, c) - χC (w, c') := by
    intro c c' u w huc huc' hwc hwc'
    obtain ⟨x, hux, hwx, hxc, hxc'⟩ := hR.link c c' u w huc huc' hwc hwc'
    have e1 := hA c c' u x hux huc huc' hxc hxc'
    have e2 := hA c c' w x hwx hwc hwc' hxc hxc'
    have : χC (u, c) - χC (u, c') - (χC (w, c) - χC (w, c')) =
        ((χC (u, c) - χC (u, c')) + (χC (x, c) - χC (x, c'))) -
          ((χC (w, c) - χC (w, c')) + (χC (x, c) - χC (x, c'))) := by
      abel
    exact sub_eq_zero.mp (by rw [this, e1, e2, sub_zero])
  -- the colour potential `b`
  let wc : C → V := fun c => Classical.choose (hR.three_colours c c₀ c₀)
  have hwc : ∀ c, (wc c, c) ∈ EC ∧ (wc c, c₀) ∈ EC := fun c =>
    ⟨(Classical.choose_spec (hR.three_colours c c₀ c₀)).1,
      (Classical.choose_spec (hR.three_colours c c₀ c₀)).2.1⟩
  let β : C → A := fun c => χC (wc c, c) - χC (wc c, c₀)
  have hβ2 : ∀ c, 2 • β c = 0 := fun c => hB c c₀ (wc c) (hwc c).1 (hwc c).2
  have hD : ∀ c c' u, (u, c) ∈ EC → (u, c') ∈ EC → χC (u, c) - χC (u, c') = β c + β c' := by
    intro c c' u huc huc'
    obtain ⟨v, hvc, hvc', hvc₀⟩ := hR.three_colours c c' c₀
    have e1 := hC c c' u v huc huc' hvc hvc'
    have e2 := hC c c₀ v (wc c) hvc hvc₀ (hwc c).1 (hwc c).2
    have e3 := hC c' c₀ v (wc c') hvc' hvc₀ (hwc c').1 (hwc c').2
    have e4 := hβ2 c'
    rw [e1]
    have : χC (v, c) - χC (v, c') =
        (χC (v, c) - χC (v, c₀)) - (χC (v, c') - χC (v, c₀)) := by abel
    rw [this, e2, e3]
    have : β c - β c' = β c + β c' - 2 • β c' := by abel
    show χC (wc c, c) - χC (wc c, c₀) - (χC (wc c', c') - χC (wc c', c₀)) = β c + β c'
    change β c - β c' = β c + β c'
    rw [this, e4, sub_zero]
  -- the vertex potential `α`
  let α : V → A := fun u =>
    if h : ∃ c, (u, c) ∈ EC then χC (u, h.choose) - β h.choose else 0
  have hE : ∀ u c, (u, c) ∈ EC → χC (u, c) = α u + β c := by
    intro u c huc
    have h : ∃ c, (u, c) ∈ EC := ⟨c, huc⟩
    have hα : α u = χC (u, h.choose) - β h.choose := by simp only [α, dif_pos h]
    have e := hD c h.choose u huc h.choose_spec
    have e2 := hβ2 h.choose
    rw [hα]
    have : χC (u, c) = (χC (u, c) - χC (u, h.choose)) + χC (u, h.choose) := by abel
    rw [this, e]
    have : β c + β h.choose + χC (u, h.choose) =
        χC (u, h.choose) - β h.choose + β c + 2 • β h.choose := by abel
    rw [this, e2, add_zero]
  have hF : ∀ u v, G.Adj u v → χV s(u, v) = -α u - α v := by
    intro u v huv
    obtain ⟨c, huc, hvc⟩ := hR.edge u v huv
    have t := htri u v c huv huc hvc
    rw [hE u c huc, hE v c hvc] at t
    have : χV s(u, v) = χV s(u, v) + (α u + β c) + (α v + β c) - α u - α v - 2 • β c := by
      abel
    rw [this, t, hβ2 c]
    abel
  -- summing over the vertex edges
  have hsumV : ∑ e ∈ G.edgeFinset, χV e = ∑ d : G.Dart, -α d.fst := by
    rw [← Finset.sum_fiberwise_of_maps_to (s := univ) (t := G.edgeFinset)
      (g := SimpleGraph.Dart.edge) (fun d _ => by simp)]
    refine Finset.sum_congr rfl fun e he => ?_
    induction e using Sym2.ind with
    | _ a b =>
      have hab : G.Adj a b := by simpa using he
      let d : G.Dart := ⟨(a, b), hab⟩
      have hfib : (univ.filter fun d' : G.Dart => d'.edge = s(a, b)) = {d, d.symm} :=
        SimpleGraph.Dart.edge_fiber d
      rw [hfib, Finset.sum_pair d.symm_ne.symm, hF a b hab]
      show -α a - α b = -α a + -α b
      abel
  have hdegV : ∑ d : G.Dart, -α d.fst = ∑ u, -(G.degree u • α u) := by
    rw [← Finset.sum_fiberwise (s := univ) (g := fun d : G.Dart => d.fst)]
    refine Finset.sum_congr rfl fun u _ => ?_
    have : ∑ d ∈ univ.filter (fun d : G.Dart => d.fst = u), -α d.fst =
        ∑ d ∈ univ.filter (fun d : G.Dart => d.fst = u), -α u :=
      Finset.sum_congr rfl fun d hd => by rw [(Finset.mem_filter.mp hd).2]
    rw [this, Finset.sum_const, SimpleGraph.dart_fst_fiber_card_eq_degree, smul_neg]
  -- summing over the vertex–colour pairs
  have hsumC : ∑ p ∈ EC, χC p = ∑ u, (EC.filter fun p => p.1 = u).card • α u +
      ∑ c, (EC.filter fun p => p.2 = c).card • β c := by
    rw [Finset.sum_congr rfl fun p hp => hE p.1 p.2 hp, Finset.sum_add_distrib]
    congr 1
    · rw [← Finset.sum_fiberwise EC (fun p => p.1)]
      refine Finset.sum_congr rfl fun u _ => ?_
      rw [Finset.sum_congr rfl fun p hp => by rw [(Finset.mem_filter.mp hp).2],
        Finset.sum_const]
    · rw [← Finset.sum_fiberwise EC (fun p => p.2)]
      refine Finset.sum_congr rfl fun c _ => ?_
      rw [Finset.sum_congr rfl fun p hp => by rw [(Finset.mem_filter.mp hp).2],
        Finset.sum_const]
  rw [hsumV, hdegV, hsumC, Finset.sum_eq_zero (s := univ)
    (f := fun c => (EC.filter fun p => p.2 = c).card • β c)
    (fun c _ => even_nsmul_eq_zero (heven c) (hβ2 c)), add_zero, ← Finset.sum_add_distrib]
  refine Finset.sum_eq_zero fun u _ => ?_
  rw [hbal u, neg_add_cancel]

end Group

/-- The vector of the triangle `{u, v, c}`: `1_{uv} + 1_{uc} + 1_{vc}`. -/
def triVec (u v : V) (c : C) : (Sym2 V → ℤ) × (V × C → ℤ) :=
  (Pi.single s(u, v) 1, Pi.single (u, c) 1 + Pi.single (v, c) 1)

/-- **Lemma 5.17.** If the host is rich, balanced at every vertex and has even degree at
every colour, then `1_{E(H)}` is an integer sum of triangles of `H`. -/
theorem mem_span_of_rich (G : SimpleGraph V) [DecidableRel G.Adj] (EC : Finset (V × C))
    (hR : Rich G EC) (hbal : ∀ u, G.degree u = (EC.filter fun p => p.1 = u).card)
    (heven : ∀ c, Even (EC.filter fun p => p.2 = c).card) :
    (∑ e ∈ G.edgeFinset, Pi.single e (1 : ℤ), ∑ p ∈ EC, Pi.single p (1 : ℤ)) ∈
      Submodule.span ℤ {x | ∃ u v c, G.Adj u v ∧ (u, c) ∈ EC ∧ (v, c) ∈ EC ∧
        x = triVec u v c} := by
  set S := Submodule.span ℤ {x | ∃ u v c, G.Adj u v ∧ (u, c) ∈ EC ∧ (v, c) ∈ EC ∧
    x = triVec u v c}
  let χV : Sym2 V → _ ⧸ S := fun e => S.mkQ (Pi.single e 1, 0)
  let χC : V × C → _ ⧸ S := fun p => S.mkQ (0, Pi.single p 1)
  have htri : ∀ u v c, G.Adj u v → (u, c) ∈ EC → (v, c) ∈ EC →
      χV s(u, v) + χC (u, c) + χC (v, c) = 0 := by
    intro u v c huv huc hvc
    have hmem : triVec u v c ∈ S := Submodule.subset_span ⟨u, v, c, huv, huc, hvc, rfl⟩
    simp only [χV, χC, ← map_add]
    rw [Submodule.mkQ_apply, Submodule.Quotient.mk_eq_zero]
    convert hmem using 1
    ext <;> simp [triVec]
  have h := sum_eq_zero_of_rich G EC hR hbal heven χV χC htri
  simp only [χV, χC, ← map_sum, ← map_add] at h
  rw [Submodule.mkQ_apply, Submodule.Quotient.mk_eq_zero] at h
  convert h using 1
  ext <;> simp [Prod.fst_sum, Prod.snd_sum]

end ColourStats.E2Lattice
