/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.PaschHub

/-!
# Alternating swaps generate the pair-preserving lattice of 1-factorizations (Lemma 5.18)

For 1-factorizations with `k` vertex classes and `ℓ` colour classes, a triangle `{u, v, c}`
has type `(π, Γ)`: `π` is the pair class of `uv` (a multiset of two vertex classes) and `Γ`
the class of `c`. A change of type counts `d : Multiset (Fin k) → Fin ℓ → ℤ` is
*pair-preserving* (`InLambda`) if it preserves
* the pairs `uv` of each class `π`: `Σ_Γ d(π, Γ) = 0`;
* the pairs `vc` of each class `(X, Γ)`: `Σ_π m_X(π) d(π, Γ) = 0`, where `m_X(π)` is the
  number of points of class `X` in `π`. This is `Σ_Y (1 + [X = Y]) d(XY, Γ) = 0`
  (`vc_sum_eq`).

An alternating swap on classes `X₁, X₂, X₃, X₄` exchanging colour classes `Γ` and `Γ'`
changes the type counts by `swapVec X₁ X₂ X₃ X₄ Γ Γ'
= (1_{X₁X₂} + 1_{X₃X₄} − 1_{X₂X₃} − 1_{X₄X₁}) ⊗ (1_{Γ'} − 1_Γ)`.

Main results:
* `swapVec_inLambda`: swaps are pair-preserving;
* `inLambda_unique`: a pair-preserving change vanishing on the pair classes avoiding a
  fixed class `o` is zero;
* `inLambda_repr`: every pair-preserving change is
  `Σ_{π ∌ o} Σ_Γ d(π, Γ) · swapVec o o Y Z ω Γ` with `π = {Y, Z}`, for a fixed colour
  class `ω`.

So the swaps `swapVec o o Y Z ω Γ` with `{Y, Z} ∌ o` and `Γ ≠ ω` form a `ℤ`-basis of `Λ`,
whose coefficients are the values `d(π, Γ)`; there are `C(k, 2)(ℓ − 1)` of them. This is
Lemma 5.18 with a simpler basis than the one in the paper.
-/

@[expose] public section

open Finset

namespace ColourStats.E2Swap

open ColourStats

variable {k ℓ : ℕ}

/-- The indicator `1_P` of a pair class. -/
def ind (P ρ : Multiset (Fin k)) : ℤ := if ρ = P then 1 else 0

/-- The pair-class change of an alternating swap on `X₁X₂X₃X₄`. -/
def cycVec (X₁ X₂ X₃ X₄ : Fin k) (ρ : Multiset (Fin k)) : ℤ :=
  ind {X₁, X₂} ρ + ind {X₃, X₄} ρ - ind {X₂, X₃} ρ - ind {X₄, X₁} ρ

/-- The type change of an alternating swap exchanging colour classes `Γ` and `Γ'`. -/
def swapVec (X₁ X₂ X₃ X₄ : Fin k) (Γ Γ' : Fin ℓ) (ρ : Multiset (Fin k)) (Δ : Fin ℓ) : ℤ :=
  cycVec X₁ X₂ X₃ X₄ ρ * ((if Δ = Γ' then 1 else 0) - (if Δ = Γ then 1 else 0))

/-- Pair-preserving changes of type counts. -/
def InLambda (d : Multiset (Fin k) → Fin ℓ → ℤ) : Prop :=
  (∀ π ∈ pairTypes k, ∑ Γ, d π Γ = 0) ∧
    ∀ X Γ, ∑ π ∈ pairTypes k, (π.count X : ℤ) * d π Γ = 0

lemma sum_count_mul_ind (X : Fin k) {P : Multiset (Fin k)} (hP : Multiset.card P = 2) :
    ∑ π ∈ pairTypes k, (π.count X : ℤ) * ind P π = P.count X := by
  simp [ind, mul_ite, mem_pairTypes, hP]

lemma cycVec_balanced (X X₁ X₂ X₃ X₄ : Fin k) :
    ∑ π ∈ pairTypes k, (π.count X : ℤ) * cycVec X₁ X₂ X₃ X₄ π = 0 := by
  simp only [cycVec, mul_add, mul_sub, Finset.sum_add_distrib, Finset.sum_sub_distrib]
  rw [sum_count_mul_ind X (P := {X₁, X₂}) (by simp),
    sum_count_mul_ind X (P := {X₃, X₄}) (by simp),
    sum_count_mul_ind X (P := {X₂, X₃}) (by simp),
    sum_count_mul_ind X (P := {X₄, X₁}) (by simp)]
  simp only [Multiset.insert_eq_cons, Multiset.count_cons, Multiset.count_singleton]
  push_cast
  ring

/-- **Swaps are pair-preserving.** -/
theorem swapVec_inLambda (X₁ X₂ X₃ X₄ : Fin k) (Γ Γ' : Fin ℓ) :
    InLambda (swapVec X₁ X₂ X₃ X₄ Γ Γ') := by
  refine ⟨fun π _ => ?_, fun X Δ => ?_⟩
  · simp only [swapVec]
    rw [← Finset.mul_sum]
    simp [Finset.sum_sub_distrib]
  · simp only [swapVec]
    simp_rw [← mul_assoc]
    rw [← Finset.sum_mul, cycVec_balanced, zero_mul]

lemma pair_eq_of_mem {ρ : Multiset (Fin k)} (hρ : Multiset.card ρ = 2) {o Y : Fin k}
    (ho : o ∈ ρ) (hY : Y ∈ ρ) (hoY : o ≠ Y) : ρ = {o, Y} := by
  obtain ⟨a, b, rfl⟩ := Multiset.card_eq_two.mp hρ
  simp only [Multiset.insert_eq_cons, Multiset.mem_cons, Multiset.mem_singleton] at ho hY
  rcases ho with rfl | rfl <;> rcases hY with rfl | rfl
  · exact absurd rfl hoY
  · rfl
  · exact Multiset.pair_comm _ _
  · exact absurd rfl hoY

lemma exists_pair_of_mem {ρ : Multiset (Fin k)} (hρ : Multiset.card ρ = 2) {o : Fin k}
    (ho : o ∈ ρ) : ∃ Y, ρ = {o, Y} := by
  obtain ⟨a, b, rfl⟩ := Multiset.card_eq_two.mp hρ
  simp only [Multiset.insert_eq_cons, Multiset.mem_cons, Multiset.mem_singleton] at ho
  rcases ho with rfl | rfl
  · exact ⟨b, rfl⟩
  · exact ⟨a, Multiset.pair_comm _ _⟩

/-- **Uniqueness.** A pair-preserving change that vanishes on the pair classes avoiding `o`
is zero. -/
theorem inLambda_unique {e : Multiset (Fin k) → Fin ℓ → ℤ} (he : InLambda e) (o : Fin k)
    (h0 : ∀ π ∈ pairTypes k, o ∉ π → ∀ Γ, e π Γ = 0) :
    ∀ ρ ∈ pairTypes k, ∀ Γ, e ρ Γ = 0 := by
  have hpair : ∀ Y : Fin k, ({o, Y} : Multiset (Fin k)) ∈ pairTypes k :=
    fun Y => mem_pairTypes.mpr (by simp)
  -- the classes `{o, Y}` with `Y ≠ o`
  have h1 : ∀ Y, Y ≠ o → ∀ Γ, e {o, Y} Γ = 0 := by
    intro Y hY Γ
    have hs := he.2 Y Γ
    rw [Finset.sum_eq_single_of_mem ({o, Y} : Multiset (Fin k)) (hpair Y)] at hs
    · simpa [Multiset.insert_eq_cons, Multiset.count_cons, Multiset.count_singleton, hY]
        using hs
    · intro ρ hρ hne
      by_cases hoρ : o ∈ ρ
      · by_cases hYρ : Y ∈ ρ
        · exact absurd (pair_eq_of_mem (mem_pairTypes.mp hρ) hoρ hYρ hY.symm) hne
        · rw [Multiset.count_eq_zero.mpr hYρ]; simp
      · rw [h0 ρ hρ hoρ Γ, mul_zero]
  -- the class `{o, o}`
  have h2 : ∀ Γ, e {o, o} Γ = 0 := by
    intro Γ
    have hs := he.2 o Γ
    rw [Finset.sum_eq_single_of_mem ({o, o} : Multiset (Fin k)) (hpair o)] at hs
    · have : ((({o, o} : Multiset (Fin k)).count o : ℕ) : ℤ) = 2 := by simp
      rw [this] at hs
      omega
    · intro ρ hρ hne
      by_cases hoρ : o ∈ ρ
      · obtain ⟨Y, rfl⟩ := exists_pair_of_mem (mem_pairTypes.mp hρ) hoρ
        have hY : Y ≠ o := fun h => hne (by rw [h])
        rw [h1 Y hY Γ, mul_zero]
      · rw [h0 ρ hρ hoρ Γ, mul_zero]
  intro ρ hρ Γ
  by_cases hoρ : o ∈ ρ
  · obtain ⟨Y, rfl⟩ := exists_pair_of_mem (mem_pairTypes.mp hρ) hoρ
    by_cases hY : Y = o
    · rw [hY]; exact h2 Γ
    · exact h1 Y hY Γ
  · exact h0 ρ hρ hoρ Γ

/-- The swap `swapVec o o Y Z ω Γ` attached to the pair class `π = {Y, Z}`. -/
noncomputable def basisVec (o : Fin k) (ω : Fin ℓ) (π : Multiset (Fin k)) (Γ : Fin ℓ) :
    Multiset (Fin k) → Fin ℓ → ℤ :=
  if h : Multiset.card π = 2 then
    swapVec o o (Multiset.card_eq_two.mp h).choose
      (Multiset.card_eq_two.mp h).choose_spec.choose ω Γ
  else 0

lemma basisVec_inLambda (o : Fin k) (ω : Fin ℓ) (π : Multiset (Fin k)) (Γ : Fin ℓ) :
    InLambda (basisVec o ω π Γ) := by
  unfold basisVec
  split_ifs
  · exact swapVec_inLambda _ _ _ _ _ _
  · exact ⟨fun _ _ => by simp, fun _ _ => by simp⟩

lemma cycVec_avoid {o : Fin k} {ρ : Multiset (Fin k)} (hoρ : o ∉ ρ) (Y Z : Fin k) :
    cycVec o o Y Z ρ = ind {Y, Z} ρ := by
  have h1 : ρ ≠ {o, o} := fun e => hoρ (by rw [e]; simp)
  have h2 : ρ ≠ {o, Y} := fun e => hoρ (by rw [e]; simp)
  have h3 : ρ ≠ {Z, o} := fun e => hoρ (by rw [e]; simp)
  simp only [cycVec, ind, if_neg h1, if_neg h2, if_neg h3]
  ring

/-- On a pair class avoiding `o`, `basisVec o ω π Γ` is `1_π ⊗ (1_Γ − 1_ω)`. -/
lemma basisVec_apply (o : Fin k) (ω : Fin ℓ) {π ρ : Multiset (Fin k)}
    (hπ : π ∈ pairTypes k) (_hρ : ρ ∈ pairTypes k) (hoρ : o ∉ ρ) (Γ Δ : Fin ℓ) :
    basisVec o ω π Γ ρ Δ =
      ind π ρ * ((if Δ = Γ then 1 else 0) - (if Δ = ω then 1 else 0)) := by
  have h := mem_pairTypes.mp hπ
  unfold basisVec
  rw [dif_pos h]
  simp only [swapVec]
  rw [cycVec_avoid hoρ, ← (Multiset.card_eq_two.mp h).choose_spec.choose_spec]

/-- **Representation.** Every pair-preserving change is the combination of the basis swaps
with coefficients `d(π, Γ)`. -/
theorem inLambda_repr {d : Multiset (Fin k) → Fin ℓ → ℤ} (hd : InLambda d) (o : Fin k)
    (ω : Fin ℓ) :
    ∀ ρ ∈ pairTypes k, ∀ Δ, d ρ Δ =
      ∑ π ∈ (pairTypes k).filter (fun π => o ∉ π), ∑ Γ, d π Γ * basisVec o ω π Γ ρ Δ := by
  set A := (pairTypes k).filter (fun π => o ∉ π)
  set R : Multiset (Fin k) → Fin ℓ → ℤ := fun ρ Δ =>
    ∑ π ∈ A, ∑ Γ, d π Γ * basisVec o ω π Γ ρ Δ
  have hR : InLambda R := by
    refine ⟨fun ρ hρ => ?_, fun X Δ => ?_⟩
    · simp only [R]
      rw [Finset.sum_comm]
      refine Finset.sum_eq_zero fun π _ => ?_
      rw [Finset.sum_comm]
      refine Finset.sum_eq_zero fun Γ _ => ?_
      rw [← Finset.mul_sum, (basisVec_inLambda o ω π Γ).1 ρ hρ, mul_zero]
    · simp only [R, Finset.mul_sum]
      rw [Finset.sum_comm]
      refine Finset.sum_eq_zero fun π _ => ?_
      rw [Finset.sum_comm]
      refine Finset.sum_eq_zero fun Γ _ => ?_
      have := (basisVec_inLambda o ω π Γ).2 X Δ
      rw [show ∑ ρ ∈ pairTypes k, (ρ.count X : ℤ) * (d π Γ * basisVec o ω π Γ ρ Δ) =
          d π Γ * ∑ ρ ∈ pairTypes k, (ρ.count X : ℤ) * basisVec o ω π Γ ρ Δ by
        rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun ρ _ => by ring, this, mul_zero]
  have hdiff : InLambda (fun ρ Δ => d ρ Δ - R ρ Δ) := by
    refine ⟨fun π hπ => ?_, fun X Γ => ?_⟩
    · rw [Finset.sum_sub_distrib, hd.1 π hπ, hR.1 π hπ, sub_zero]
    · simp only [mul_sub, Finset.sum_sub_distrib]
      rw [hd.2 X Γ, hR.2 X Γ, sub_zero]
  have hzero : ∀ ρ ∈ pairTypes k, o ∉ ρ → ∀ Δ, d ρ Δ - R ρ Δ = 0 := by
    intro ρ hρ hoρ Δ
    have hRρ : R ρ Δ = d ρ Δ := by
      have hρA : ρ ∈ A := Finset.mem_filter.mpr ⟨hρ, hoρ⟩
      simp only [R]
      rw [Finset.sum_eq_single_of_mem ρ hρA]
      · have e : ∀ Γ, d ρ Γ * basisVec o ω ρ Γ ρ Δ =
            d ρ Γ * ((if Δ = Γ then 1 else 0) - (if Δ = ω then 1 else 0)) := fun Γ => by
          rw [basisVec_apply o ω hρ hρ hoρ Γ Δ]; simp [ind]
        simp only [e]
        by_cases hΔ : Δ = ω
        · simp [hΔ, mul_sub, Finset.sum_sub_distrib, hd.1 ρ hρ]
        · simp [hΔ]
      · intro π hπA hne
        refine Finset.sum_eq_zero fun Γ _ => ?_
        rw [basisVec_apply o ω (Finset.mem_filter.mp hπA).1 hρ hoρ Γ Δ]
        simp [ind, Ne.symm hne]
    rw [hRρ, sub_self]
  intro ρ hρ Δ
  have := inLambda_unique hdiff o hzero ρ hρ Δ
  simp only [R] at this
  linarith

end ColourStats.E2Swap
