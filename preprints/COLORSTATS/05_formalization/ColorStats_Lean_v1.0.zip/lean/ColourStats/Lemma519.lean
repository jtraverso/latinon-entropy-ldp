/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Phi519
public import ColourStats.W519
public import ColourStats.K2519

/-!
# Lemma 5.19: a bounded right inverse on typical hosts

Let `G` be `(η, 5)`-typical with densities `d ∈ [d₀, 1]` and all classes of size at least
`δ₀ m`. Then the edge–triangle incidence map `A` has a linear right inverse `Φ` with
`‖Φ‖_{∞→∞} ≤ K/m`, provided `η` is small and `m` is large:

* `lemma_5_19`: with explicit smallness condition and explicit `K`;
* `lemma_5_19_exists`: the statement of the paper, `∃ η₀ > 0, ∃ m₀, ∃ K` depending only on
  `δ₀, d₀`.

The proof follows the paper with `π₀ = {A₀, A₀}`. The estimate for `T²` is a direct count
of `K₂(e, f)` by typicality (file `K2519`).
-/

@[expose] public section

open Finset

noncomputable section

open Classical

namespace ColourStats.Host519

open Typical Counting Weighting

variable {V : Type*} [Fintype V] {k : ℕ}

/-- `σ r = Σ_e r(e) / |E₀|`. -/
def σlin (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) : (Edge G → ℝ) →ₗ[ℝ] ℝ where
  toFun r := (∑ e, r e) / (EIn G cls A₀ ∅).card
  map_add' r s := by simp [Finset.sum_add_distrib, add_div]
  map_smul' c r := by
    simp only [Pi.smul_apply, smul_eq_mul, RingHom.id_apply]
    rw [← Finset.mul_sum, mul_div_assoc]

def σop (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) : (Edge G → ℝ) →L[ℝ] ℝ :=
  LinearMap.toContinuousLinearMap (σlin G cls A₀)

lemma Top_apply (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) (r : Edge G → ℝ)
    (f : Edge G) : Top G cls A₀ r f = ∑ e, ν G cls A₀ e f * r e := by
  simp [Top, Matrix.mulVec, dotProduct, MT]

lemma TT_apply (G : SimpleGraph V) (cls : V → Fin k) (A₀ : Fin k) (r : Edge G → ℝ)
    (f : Edge G) : Top G cls A₀ (Top G cls A₀ r) f = ∑ e, K2 G cls A₀ e f * r e := by
  rw [Top_apply]
  simp only [Top_apply, Finset.mul_sum, K2, Finset.sum_mul]
  rw [Finset.sum_comm]
  exact Finset.sum_congr rfl fun e _ => Finset.sum_congr rfl fun g _ => by ring

namespace Hyp

variable {G : SimpleGraph V} {cls : V → Fin k} {d : Fin k → Fin k → ℝ} {A₀ : Fin k}
  {η δ₀ d₀ : ℝ} (H : Hyp G cls d A₀ η δ₀ d₀)
include H

lemma norm_σop_le : ‖σop G cls A₀‖ ≤ 4 / (δ₀ ^ 2 * d₀) := by
  have hN := H.card_E₀_lower
  have hNp := H.card_E₀_pos
  have hm := H.m_pos
  have hδd : 0 < δ₀ ^ 2 * d₀ := mul_pos (pow_pos H.δ₀_pos 2) H.d₀_pos
  refine ContinuousLinearMap.opNorm_le_bound _ (by positivity) fun r => ?_
  simp only [σop, LinearMap.coe_toContinuousLinearMap', σlin, LinearMap.coe_mk,
    AddHom.coe_mk, Real.norm_eq_abs]
  rw [abs_div, abs_of_pos hNp, div_le_iff₀ hNp]
  calc |∑ e, r e| ≤ ∑ e, |r e| := abs_sum_le_sum_abs _ _
    _ ≤ ∑ _e : Edge G, ‖r‖ := Finset.sum_le_sum fun e _ => by
        rw [← Real.norm_eq_abs]; exact norm_le_pi_norm r e
    _ = Fintype.card (Edge G) * ‖r‖ := by simp
    _ ≤ (Fintype.card V : ℝ) ^ 2 * ‖r‖ :=
        mul_le_mul_of_nonneg_right (card_edge_le G) (norm_nonneg _)
    _ ≤ 4 / (δ₀ ^ 2 * d₀) * ‖r‖ * (EIn G cls A₀ ∅).card := by
        have : (Fintype.card V : ℝ) ^ 2 ≤ 4 / (δ₀ ^ 2 * d₀) * (EIn G cls A₀ ∅).card := by
          rw [div_mul_eq_mul_div, le_div_iff₀ hδd]
          nlinarith
        nlinarith [norm_nonneg r]

/-- `ε₁ = 38η/(δ₀² d₀) + 2(1/p² + 4/(δ₀² d₀))/m`. -/
def eps1 (_H : Hyp G cls d A₀ η δ₀ d₀) : ℝ :=
  38 * η / (δ₀ ^ 2 * d₀) +
    2 * (1 / pconst δ₀ d₀ ^ 2 + 4 / (δ₀ ^ 2 * d₀)) / Fintype.card V

lemma norm_E₁_le :
    ‖(Top G cls A₀).comp (Top G cls A₀) - (σop G cls A₀).smulRight (uvec G cls A₀)‖ ≤
      H.eps1 := by
  have hm := H.m_pos
  have hp := H.p_pos
  have hδd : 0 < δ₀ ^ 2 * d₀ := mul_pos (pow_pos H.δ₀_pos 2) H.d₀_pos
  have hη := H.η_nonneg
  have heps : 0 ≤ H.eps1 := by unfold eps1; positivity
  set N : ℝ := ((EIn G cls A₀ ∅).card : ℝ)
  have hN := H.card_E₀_pos
  refine E3Assembly.opNorm_le_of_rowSum _
    (fun f e => K2 G cls A₀ e f - uvec G cls A₀ f / N) (fun r f => ?_) heps (fun f => ?_)
  · simp only [ContinuousLinearMap.sub_apply, ContinuousLinearMap.comp_apply,
      ContinuousLinearMap.smulRight_apply, Pi.sub_apply, Pi.smul_apply, smul_eq_mul, TT_apply,
      σop, LinearMap.coe_toContinuousLinearMap', σlin, LinearMap.coe_mk, AddHom.coe_mk]
    rw [Finset.sum_div, Finset.sum_mul, ← Finset.sum_sub_distrib]
    exact Finset.sum_congr rfl fun e _ => by ring
  by_cases hf : f ∈ EIn G cls A₀ ∅
  · have hu : uvec G cls A₀ f = 1 := by simp [uvec, hf]
    simp only [hu]
    -- the meeting edges
    set C : ℝ := 1 / (pconst δ₀ d₀ ^ 2 * (Fintype.card V : ℝ) ^ 2) +
      4 / (δ₀ ^ 2 * d₀ * (Fintype.card V : ℝ) ^ 2)
    have hC : 0 ≤ C := by positivity
    have hinvN : 1 / N ≤ 4 / (δ₀ ^ 2 * d₀ * (Fintype.card V : ℝ) ^ 2) := by
      rw [div_le_div_iff₀ hN (by positivity)]
      nlinarith [H.card_E₀_lower]
    have hMinv : 19 * η / H.Mc ≤ 38 * η / (δ₀ ^ 2 * d₀ * (Fintype.card V : ℝ) ^ 2) := by
      rw [div_le_div_iff₀ H.Mc_pos (by positivity)]
      nlinarith [H.Mc_lower]
    have hterm : ∀ e, |K2 G cls A₀ e f - 1 / N| ≤
        38 * η / (δ₀ ^ 2 * d₀ * (Fintype.card V : ℝ) ^ 2) +
          C * (if ∃ v ∈ verts f.1, v ∈ e.1 then 1 else 0) := by
      intro e
      by_cases hmeet : ∃ v ∈ verts f.1, v ∈ e.1
      · rw [if_pos hmeet, mul_one]
        have h1 := H.K2_le e f
        have h2 := H.K2_nonneg e f
        have h3 : 0 ≤ 1 / N := by positivity
        have : |K2 G cls A₀ e f - 1 / N| ≤ K2 G cls A₀ e f + 1 / N :=
          abs_le.mpr ⟨by linarith, by linarith⟩
        have h4 : 0 ≤ 38 * η / (δ₀ ^ 2 * d₀ * (Fintype.card V : ℝ) ^ 2) := by positivity
        simp only [C]
        linarith
      · rw [if_neg hmeet, mul_zero, add_zero]
        have hdisj : Disjoint (verts e.1) (verts f.1) := by
          rw [Finset.disjoint_right]
          intro v hvf hve
          exact hmeet ⟨v, hvf, mem_verts.mp hve⟩
        exact (H.abs_K2_sub_disjoint hf hdisj).trans hMinv
    calc ∑ e, |K2 G cls A₀ e f - 1 / N|
        ≤ ∑ e, (38 * η / (δ₀ ^ 2 * d₀ * (Fintype.card V : ℝ) ^ 2) +
          C * (if ∃ v ∈ verts f.1, v ∈ e.1 then 1 else 0)) := Finset.sum_le_sum fun e _ => hterm e
      _ = Fintype.card (Edge G) * (38 * η / (δ₀ ^ 2 * d₀ * (Fintype.card V : ℝ) ^ 2)) +
          C * ((univ.filter fun e : Edge G => ∃ v ∈ verts f.1, v ∈ e.1).card) := by
          rw [Finset.sum_add_distrib, ← Finset.mul_sum, Finset.sum_boole]
          simp
      _ ≤ (Fintype.card V : ℝ) ^ 2 * (38 * η / (δ₀ ^ 2 * d₀ * (Fintype.card V : ℝ) ^ 2)) +
          C * (2 * Fintype.card V) := by
          gcongr
          · exact card_edge_le G
          · have := card_meet_le G (verts f.1)
            rwa [H.verts_card f] at this
      _ = H.eps1 := by
          simp only [C, eps1]
          field_simp
  · have hu : uvec G cls A₀ f = 0 := by simp [uvec, hf]
    simp only [hu, zero_div, sub_zero, K2_eq_zero G cls A₀ hf, abs_zero,
      Finset.sum_const_zero]
    exact heps

/-- `‖W_1‖ ≤ b/m` with `b = 1/(δ₀ d₀²)`. -/
lemma norm_Wvec_le : ‖Wvec G cls d A₀‖ ≤ 1 / (δ₀ * d₀ ^ 2) / Fintype.card V := by
  have hm := H.m_pos
  have := H.δ₀_pos
  have := H.d₀_pos
  refine (pi_norm_le_iff_of_nonneg (by positivity)).mpr fun t => ?_
  rw [Real.norm_eq_abs]
  exact H.abs_Wvec_le t

lemma norm_e₂_le :
    ‖(Aop G) (Wvec G cls d A₀) - uvec G cls A₀‖ ≤ η := by
  refine (pi_norm_le_iff_of_nonneg H.η_nonneg).mpr fun e => ?_
  rw [Real.norm_eq_abs]
  simpa [Aop] using H.abs_e₂_le e

/-- **Lemma 5.19**, with explicit constants. -/
theorem lemma_5_19 (hsmall : H.eps1 + 4 / (δ₀ ^ 2 * d₀) * η ≤ 1 / 2) :
    ∃ Φ : (Edge G → ℝ) →L[ℝ] (Tri G → ℝ), (Aop G).comp Φ = 1 ∧
      ‖Φ‖ ≤ 2 * ((108 / pconst δ₀ d₀ + 108 / pconst δ₀ d₀ * (1 / pconst δ₀ d₀) +
        4 / (δ₀ ^ 2 * d₀) * (1 / (δ₀ * d₀ ^ 2))) / Fintype.card V) := by
  have hT2 : (Top G cls A₀).comp (Top G cls A₀) =
      (σop G cls A₀).smulRight (uvec G cls A₀) +
        ((Top G cls A₀).comp (Top G cls A₀) - (σop G cls A₀).smulRight (uvec G cls A₀)) := by
    abel
  have hw : (Aop G) (Wvec G cls d A₀) =
      uvec G cls A₀ + ((Aop G) (Wvec G cls d A₀) - uvec G cls A₀) := by abel
  exact E3Assembly.right_inverse_of_estimates (Aop G) (Phiop G cls A₀) (Top G cls A₀)
    (A_comp_Phi₁ G cls A₀ H.P_nonempty) (σop G cls A₀) (uvec G cls A₀) _ hT2
    (Wvec G cls d A₀) _ hw H.m_pos H.norm_Phiop_le H.norm_Top_le H.norm_σop_le
    H.norm_Wvec_le H.norm_E₁_le H.norm_e₂_le hsmall

end Hyp

/-- **Lemma 5.19** as stated in the paper: for fixed `δ₀, d₀` there are `η₀ > 0`, `m₀` and
`K` such that every `(η, 5)`-typical graph with `η ≤ η₀`, `m ≥ m₀` vertices, classes of
size at least `δ₀ m` and densities in `[d₀, 1]` has a right inverse of norm at most `K/m`. -/
theorem lemma_5_19_exists (δ₀ d₀ : ℝ) (hδ₀ : 0 < δ₀) (hδ₁ : δ₀ ≤ 1) (hd₀ : 0 < d₀) :
    ∃ η₀ > 0, ∃ m₀ : ℕ, ∃ K : ℝ, ∀ {V : Type} [Fintype V] {k : ℕ} (G : SimpleGraph V)
      (cls : V → Fin k) (d : Fin k → Fin k → ℝ) (η : ℝ),
      IsTypical G cls d η 5 → 0 ≤ η → η ≤ η₀ → (∀ X Y, d₀ ≤ d X Y) → (∀ X Y, d X Y ≤ 1) →
      (∀ X, δ₀ * Fintype.card V ≤ (classSet cls X).card) → m₀ ≤ Fintype.card V →
      ∃ Φ : (Edge G → ℝ) →L[ℝ] (Tri G → ℝ), (Aop G).comp Φ = 1 ∧
        ‖Φ‖ ≤ K / Fintype.card V := by
  set p := pconst δ₀ d₀
  have hp : 0 < p := by unfold p pconst; positivity
  have hδd : 0 < δ₀ ^ 2 * d₀ := by positivity
  set C : ℝ := 2 * (1 / p ^ 2 + 4 / (δ₀ ^ 2 * d₀))
  have hC : 0 < C := by positivity
  refine ⟨min (1 / 10) (δ₀ ^ 2 * d₀ / 168), by positivity, ⌈4 * C⌉₊ + 1,
    2 * (108 / p + 108 / p * (1 / p) + 4 / (δ₀ ^ 2 * d₀) * (1 / (δ₀ * d₀ ^ 2))), ?_⟩
  intro V _ k G cls d η hT hη hη₀ hdl hdu hcl hm
  have hmpos : 0 < Fintype.card V := by omega
  obtain ⟨v⟩ := Fintype.card_pos_iff.mp hmpos
  set A₀ : Fin k := cls v
  have H : Hyp G cls d A₀ η δ₀ d₀ :=
    ⟨hT, hη, hη₀.trans (min_le_left _ _), hδ₀, hδ₁, hd₀, hdl, hdu, hcl, hmpos⟩
  have hmR : (4 * C : ℝ) ≤ Fintype.card V := by
    have h1 : (4 * C : ℝ) ≤ ⌈4 * C⌉₊ := Nat.le_ceil _
    have h2 : ((⌈4 * C⌉₊ : ℕ) : ℝ) ≤ Fintype.card V := by
      exact_mod_cast (Nat.le_succ _).trans hm
    linarith
  have hsmall : H.eps1 + 4 / (δ₀ ^ 2 * d₀) * η ≤ 1 / 2 := by
    have hηs : η ≤ δ₀ ^ 2 * d₀ / 168 := hη₀.trans (min_le_right _ _)
    have hm0 : (0 : ℝ) < Fintype.card V := by exact_mod_cast hmpos
    have e1 : 38 * η / (δ₀ ^ 2 * d₀) + 4 / (δ₀ ^ 2 * d₀) * η ≤ 1 / 4 := by
      rw [div_mul_eq_mul_div, ← add_div, div_le_iff₀ hδd]
      linarith
    have e2 : C / Fintype.card V ≤ 1 / 4 := by
      rw [div_le_iff₀ hm0]; linarith
    unfold Hyp.eps1
    have : 2 * (1 / pconst δ₀ d₀ ^ 2 + 4 / (δ₀ ^ 2 * d₀)) / Fintype.card V =
        C / Fintype.card V := rfl
    linarith
  obtain ⟨Φ, hΦ, hn⟩ := H.lemma_5_19 hsmall
  exact ⟨Φ, hΦ, by rw [mul_div_assoc]; exact hn⟩

end ColourStats.Host519
