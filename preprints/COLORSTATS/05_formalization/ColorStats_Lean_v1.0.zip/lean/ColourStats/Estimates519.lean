/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.Edges519

/-!
# The first estimates of Lemma 5.19

Under the hypotheses `Hyp` (an `(η, 5)`-typical graph with `η ≤ 1/10`, classes of size at
least `δ₀ m` and densities in `[d₀, 1]`), with `ε = 2η + η²` and `p = δ₀² d₀⁵ / 4`:

* `approx_card_P`: `|P_e| ≈_ε ½ I_e² d(A₀, A₀)`; `card_P_lower`: `|P_e| ≥ p m²`;
* `approx_card_E₀`: `|E₀| ≈_ε M = ½ |A₀|² d(A₀, A₀)`;
* `norm_Top_le`: `‖T‖ ≤ 1/p`;
* `norm_Phiop_le`: `‖Φ₁‖ ≤ 108/(p m)`.
-/

@[expose] public section

open Finset

noncomputable section

open Classical

namespace ColourStats.Host519

open Typical Counting

variable {V : Type*} [Fintype V] {k : ℕ}

/-- The hypotheses of Lemma 5.19. -/
structure Hyp (G : SimpleGraph V) (cls : V → Fin k) (d : Fin k → Fin k → ℝ) (A₀ : Fin k)
    (η δ₀ d₀ : ℝ) : Prop where
  typ : IsTypical G cls d η 5
  η_nonneg : 0 ≤ η
  η_small : η ≤ 1 / 10
  δ₀_pos : 0 < δ₀
  δ₀_le : δ₀ ≤ 1
  d₀_pos : 0 < d₀
  d_lower : ∀ X Y, d₀ ≤ d X Y
  d_upper : ∀ X Y, d X Y ≤ 1
  class_lower : ∀ X, δ₀ * Fintype.card V ≤ (classSet cls X).card
  card_pos : 0 < Fintype.card V

variable {G : SimpleGraph V} {cls : V → Fin k} {d : Fin k → Fin k → ℝ} {A₀ : Fin k}
  {η δ₀ d₀ : ℝ}

/-- `p = δ₀² d₀⁵ / 4`. -/
def pconst (δ₀ d₀ : ℝ) : ℝ := δ₀ ^ 2 * d₀ ^ 5 / 4

namespace Hyp

variable (H : Hyp G cls d A₀ η δ₀ d₀)
include H

lemma d_nonneg (X Y : Fin k) : 0 ≤ d X Y := H.d₀_pos.le.trans (H.d_lower X Y)

lemma m_pos : (0 : ℝ) < Fintype.card V := by exact_mod_cast H.card_pos

lemma ε_le : 2 * η + η ^ 2 ≤ 21 / 100 := by
  have := H.η_nonneg; have := H.η_small; nlinarith

lemma ε_nonneg : 0 ≤ 2 * η + η ^ 2 := by have := H.η_nonneg; positivity

lemma p_pos : 0 < pconst δ₀ d₀ := by
  unfold pconst; have := H.δ₀_pos; have := H.d₀_pos; positivity

lemma verts_card (e : Edge G) : (verts e.1).card = 2 := by
  unfold verts
  exact Finset.card_pair (G.ne_of_adj (adj_out G e))

lemma ideal_verts (e : Edge G) :
    ideal cls d (verts e.1) A₀ =
      (classSet cls A₀).card * (d (cls e.1.out.1) A₀ * d (cls e.1.out.2) A₀) := by
  unfold verts
  exact ideal_pair cls d (G.ne_of_adj (adj_out G e)) A₀

lemma ideal_verts_lower (e : Edge G) :
    δ₀ * Fintype.card V * d₀ ^ 2 ≤ ideal cls d (verts e.1) A₀ := by
  rw [ideal_verts H e]
  have h1 := H.class_lower A₀
  have h2 := H.d_lower (cls e.1.out.1) A₀
  have h3 := H.d_lower (cls e.1.out.2) A₀
  have hd0 := H.d₀_pos.le
  have hm := H.m_pos
  have hδ := H.δ₀_pos
  calc δ₀ * Fintype.card V * d₀ ^ 2 = (δ₀ * Fintype.card V) * (d₀ * d₀) := by ring
    _ ≤ (classSet cls A₀).card * (d (cls e.1.out.1) A₀ * d (cls e.1.out.2) A₀) :=
        mul_le_mul h1 (mul_le_mul h2 h3 hd0 (H.d_nonneg _ _)) (by positivity) (by positivity)

/-- `|P_e| ≈_ε ½ I_e² d(A₀, A₀)`. -/
lemma approx_card_P (e : Edge G) :
    Approx (2 * η + η ^ 2) (1 / 2 * (ideal cls d (verts e.1) A₀ ^ 2 * d A₀ A₀))
      ((P G cls A₀ e).card) := by
  rw [P_eq_EIn, card_EIn]
  exact card_edgesIn_commonIn H.typ H.η_nonneg (by linarith [H.η_small]) H.d_nonneg
    (by rw [H.verts_card e]; norm_num) A₀

/-- `|P_e| ≥ p m²`. -/
lemma card_P_lower (e : Edge G) :
    pconst δ₀ d₀ * (Fintype.card V : ℝ) ^ 2 ≤ (P G cls A₀ e).card := by
  have h := (H.approx_card_P e).lower
  have hI := H.ideal_verts_lower e
  have hε := H.ε_le
  have hd := H.d_lower A₀ A₀
  have hm := H.m_pos
  have hδ := H.δ₀_pos
  have hd0 := H.d₀_pos
  have hI0 : 0 ≤ δ₀ * Fintype.card V * d₀ ^ 2 := by positivity
  have hI2 : (δ₀ * Fintype.card V * d₀ ^ 2) ^ 2 ≤ ideal cls d (verts e.1) A₀ ^ 2 :=
    pow_le_pow_left₀ hI0 hI 2
  have hX : (δ₀ * Fintype.card V * d₀ ^ 2) ^ 2 * d₀ ≤
      ideal cls d (verts e.1) A₀ ^ 2 * d A₀ A₀ :=
    mul_le_mul hI2 hd hd0.le (by positivity)
  unfold pconst
  calc δ₀ ^ 2 * d₀ ^ 5 / 4 * (Fintype.card V : ℝ) ^ 2
      = (1 / 2) * (1 / 2 * ((δ₀ * Fintype.card V * d₀ ^ 2) ^ 2 * d₀)) := by ring
    _ ≤ (1 - (2 * η + η ^ 2)) * (1 / 2 * (ideal cls d (verts e.1) A₀ ^ 2 * d A₀ A₀)) := by
        apply mul_le_mul (by linarith) (by linarith) (by positivity) (by linarith)
    _ ≤ (P G cls A₀ e).card := h

lemma card_P_pos (e : Edge G) : (0 : ℝ) < (P G cls A₀ e).card := by
  have := H.card_P_lower e
  have := H.p_pos
  have := H.m_pos
  nlinarith [mul_pos H.p_pos (pow_pos H.m_pos 2)]

lemma P_nonempty (e : Edge G) : (P G cls A₀ e).Nonempty := by
  have h := H.card_P_pos e
  exact Finset.card_pos.mp (by exact_mod_cast h)

lemma ν_le (e f : Edge G) : ν G cls A₀ e f ≤ 1 / (pconst δ₀ d₀ * (Fintype.card V : ℝ) ^ 2) := by
  have hp := mul_pos H.p_pos (pow_pos H.m_pos 2)
  unfold ν
  split_ifs
  · exact one_div_le_one_div_of_le hp (H.card_P_lower e)
  · exact (one_div_pos.mpr hp).le

lemma ν_nonneg (e f : Edge G) : 0 ≤ ν G cls A₀ e f := by
  unfold ν; split_ifs
  · exact (one_div_pos.mpr (H.card_P_pos e)).le
  · exact le_rfl

/-- `‖T‖ ≤ 1/p`. -/
lemma norm_Top_le : ‖Top G cls A₀‖ ≤ 1 / pconst δ₀ d₀ := by
  have hp := H.p_pos
  have hm := H.m_pos
  refine E3Assembly.opNorm_le_of_rowSum (Top G cls A₀) (MT G cls A₀) (fun r f => ?_)
    (one_div_pos.mpr hp).le (fun f => ?_)
  · simp [Top, Matrix.mulVec, dotProduct]
  · calc ∑ e, |MT G cls A₀ f e| = ∑ e, ν G cls A₀ e f :=
          Finset.sum_congr rfl fun e _ => abs_of_nonneg (H.ν_nonneg e f)
      _ ≤ ∑ _e : Edge G, 1 / (pconst δ₀ d₀ * (Fintype.card V : ℝ) ^ 2) :=
          Finset.sum_le_sum fun e _ => H.ν_le e f
      _ = Fintype.card (Edge G) * (1 / (pconst δ₀ d₀ * (Fintype.card V : ℝ) ^ 2)) := by
          simp
      _ ≤ (Fintype.card V : ℝ) ^ 2 * (1 / (pconst δ₀ d₀ * (Fintype.card V : ℝ) ^ 2)) :=
          mul_le_mul_of_nonneg_right (card_edge_le G) (by positivity)
      _ = 1 / pconst δ₀ d₀ := by field_simp

end Hyp

end ColourStats.Host519
