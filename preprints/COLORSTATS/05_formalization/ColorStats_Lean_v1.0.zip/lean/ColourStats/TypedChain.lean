/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import CountingCone.LL.Chain

/-!
# A typed chain rule in counting form (Section 4.2, Steps 1–4)

The corpus proves the Linial–Luria chain bound `|S| log |S| ≤ Σ_x Σ_s log b_s(x)`
(`LinialLuria.chain_bound`), where `b_s(x)` counts the values of the coordinate `s` still
possible after the earlier coordinates. The typed bound of the paper needs more: the
entropy of the *class* of each coordinate, not the logarithm of the number of classes.
This file gives the exact counting form of the chain rule and the two inequalities used to
split each term into a class part and a point part.

For a finite set `S`, coordinates `f s`, `s ∈ I`, revealed in the order of an injective
`key`, let `before s x` (resp. `upto s x`) be the elements of `S` agreeing with `x` on the
coordinates revealed before `s` (resp. up to and including `s`).

* `telescope`: if the coordinates determine the elements of `S`, then for every `x ∈ S`,
  `log |S| = Σ_s (log |before s x| − log |upto s x|)`. Summed over `x`, this is the chain
  rule `log |S| = Σ_s H(f_s | past)` for the uniform law on `S`.
* `split_class`: each term is `(log |before| − log |sameClass|) + (log |sameClass| − log |upto|)`,
  where `sameClass s x` are the elements of `before s x` whose coordinate `s` has the class of
  that of `x`. The first part is the class entropy, the second the point entropy given the
  class.
* `point_part_le`: `Σ_x (log |sameClass s x| − log |upto s x|) ≤ Σ_x log a_s(x)`, where
  `a_s(x)` is the number of values of the coordinate `s` in `sameClass s x`.
* `cond_le`: conditioning reduces entropy, in counting form: for a finite set `U` with a
  block map `b` and a class map `c`,
  `Σ_{y ∈ U} log (|U_{b(y)}| / |U_{b(y), c(y)}|) ≤ Σ_{y ∈ U} log (|U| / |U_{c(y)}|)`.
-/

@[expose] public section

open Finset

namespace ColourStats.TypedChain

variable {α ι β κ γ : Type*} [DecidableEq α] [DecidableEq β] [DecidableEq κ] [DecidableEq γ]

/-- The elements of `S` agreeing with `x` on the coordinates revealed before `s`. -/
def before (S : Finset α) (I : Finset ι) (key : ι → ℕ) (f : ι → α → β) (s : ι) (x : α) :
    Finset α :=
  S.filter fun y => ∀ t ∈ I, key t < key s → f t y = f t x

/-- The elements of `S` agreeing with `x` on the coordinates revealed up to `s`. -/
def upto (S : Finset α) (I : Finset ι) (key : ι → ℕ) (f : ι → α → β) (s : ι) (x : α) :
    Finset α :=
  S.filter fun y => ∀ t ∈ I, key t ≤ key s → f t y = f t x

/-- The elements of `S` agreeing with `x` on all coordinates. -/
def agreeAll (S : Finset α) (I : Finset ι) (f : ι → α → β) (x : α) : Finset α :=
  S.filter fun y => ∀ t ∈ I, f t y = f t x

/-- The elements of `before s x` whose coordinate `s` has the class of that of `x`. -/
def sameClass (S : Finset α) (I : Finset ι) (key : ι → ℕ) (f : ι → α → β) (cl : β → κ)
    (s : ι) (x : α) : Finset α :=
  (before S I key f s x).filter fun y => cl (f s y) = cl (f s x)

/-! ### The exact chain rule -/

/-- **Telescoping.** `Σ_s (log |before s x| − log |upto s x|) = log |S| − log |agreeAll x|`. -/
theorem telescope_aux (key : ι → ℕ) (f : ι → α → β) (S : Finset α) (x : α) (I : Finset ι)
    (hkey : Set.InjOn key I) :
    ∑ s ∈ I, (Real.log (before S I key f s x).card - Real.log (upto S I key f s x).card) =
      Real.log S.card - Real.log (agreeAll S I f x).card := by
  classical
  induction I using Finset.induction_on_max_value key with
  | empty => simp [agreeAll]
  | insert a I haI hmax ih =>
    have hkeyI : Set.InjOn key I := hkey.mono (by intro t ht; exact Finset.mem_insert_of_mem ht)
    have hlt : ∀ t ∈ I, key t < key a := by
      intro t ht
      rcases (hmax t ht).lt_or_eq with h | h
      · exact h
      · exact absurd (hkey (Finset.mem_insert_of_mem ht) (Finset.mem_insert_self a I) h)
          (fun e => haI (e ▸ ht))
    have hb : ∀ t ∈ I, before S (insert a I) key f t x = before S I key f t x := by
      intro t ht
      unfold before
      refine Finset.filter_congr fun y _ => ?_
      simp only [Finset.forall_mem_insert]
      constructor
      · exact fun h => h.2
      · exact fun h => ⟨fun h' => absurd h' (not_lt.mpr (hlt t ht).le), h⟩
    have hu : ∀ t ∈ I, upto S (insert a I) key f t x = upto S I key f t x := by
      intro t ht
      unfold upto
      refine Finset.filter_congr fun y _ => ?_
      simp only [Finset.forall_mem_insert]
      constructor
      · exact fun h => h.2
      · exact fun h => ⟨fun h' => absurd h' (not_le.mpr (hlt t ht)), h⟩
    have hba : before S (insert a I) key f a x = agreeAll S I f x := by
      unfold before agreeAll
      refine Finset.filter_congr fun y _ => ?_
      simp only [Finset.forall_mem_insert, lt_irrefl, IsEmpty.forall_iff, true_and]
      constructor
      · exact fun h t ht => h t ht (hlt t ht)
      · exact fun h t ht _ => h t ht
    have hua : upto S (insert a I) key f a x = agreeAll S (insert a I) f x := by
      unfold upto agreeAll
      refine Finset.filter_congr fun y _ => ?_
      simp only [Finset.forall_mem_insert, le_refl, true_implies]
      constructor
      · exact fun h => ⟨h.1, fun t ht => h.2 t ht (hlt t ht).le⟩
      · exact fun h => ⟨h.1, fun t ht _ => h.2 t ht⟩
    rw [Finset.sum_insert haI, hba, hua,
      Finset.sum_congr rfl fun t ht => by rw [hb t ht, hu t ht], ih hkeyI]
    ring

/-- **The exact chain rule.** If the coordinates determine the elements of `S`, then for every
`x ∈ S`, `log |S| = Σ_s (log |before s x| − log |upto s x|)`. -/
theorem telescope (key : ι → ℕ) (f : ι → α → β) (S : Finset α) (I : Finset ι)
    (hkey : Set.InjOn key I) (hdet : ∀ x ∈ S, ∀ y ∈ S, (∀ s ∈ I, f s x = f s y) → x = y)
    {x : α} (hx : x ∈ S) :
    Real.log S.card =
      ∑ s ∈ I, (Real.log (before S I key f s x).card - Real.log (upto S I key f s x).card) := by
  rw [telescope_aux key f S x I hkey]
  have : agreeAll S I f x = {x} := by
    ext y
    simp only [agreeAll, Finset.mem_filter, Finset.mem_singleton]
    constructor
    · rintro ⟨hy, h⟩
      exact hdet y hy x hx h
    · rintro rfl
      exact ⟨hx, fun _ _ => rfl⟩
  rw [this, Finset.card_singleton, Nat.cast_one, Real.log_one, sub_zero]

/-- Each term splits into a class part and a point part. -/
lemma split_class (key : ι → ℕ) (f : ι → α → β) (cl : β → κ) (S : Finset α) (I : Finset ι)
    (s : ι) (x : α) :
    Real.log (before S I key f s x).card - Real.log (upto S I key f s x).card =
      (Real.log (before S I key f s x).card - Real.log (sameClass S I key f cl s x).card) +
      (Real.log (sameClass S I key f cl s x).card - Real.log (upto S I key f s x).card) := by
  ring

/-! ### Summing over blocks -/

/-- Summing over the blocks of a partition given by `G`. -/
lemma sum_blocks (S : Finset α) (G : α → Finset α) (hG : ∀ x ∈ S, x ∈ G x ∧ G x ⊆ S)
    (hGG : ∀ x ∈ S, ∀ y ∈ G x, G y = G x) (F : α → ℝ) :
    ∑ x ∈ S, F x = ∑ B ∈ S.image G, ∑ x ∈ B, F x := by
  rw [← Finset.sum_fiberwise_of_maps_to (s := S) (t := S.image G) (g := G)
    (fun x hx => Finset.mem_image_of_mem _ hx)]
  refine Finset.sum_congr rfl fun B hB => ?_
  obtain ⟨x₀, hx₀, rfl⟩ := Finset.mem_image.mp hB
  congr 1
  ext y
  simp only [Finset.mem_filter]
  constructor
  · rintro ⟨hy, hyB⟩
    exact hyB ▸ (hG y hy).1
  · intro hy
    exact ⟨(hG x₀ hx₀).2 hy, hGG x₀ hx₀ y hy⟩

/-- A blockwise inequality gives a global one. -/
lemma sum_le_of_blocks (S : Finset α) (G : α → Finset α) (hG : ∀ x ∈ S, x ∈ G x ∧ G x ⊆ S)
    (hGG : ∀ x ∈ S, ∀ y ∈ G x, G y = G x) (F H : α → ℝ)
    (hB : ∀ x ∈ S, ∑ y ∈ G x, F y ≤ ∑ y ∈ G x, H y) :
    ∑ x ∈ S, F x ≤ ∑ x ∈ S, H x := by
  rw [sum_blocks S G hG hGG F, sum_blocks S G hG hGG H]
  refine Finset.sum_le_sum fun B hB' => ?_
  obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hB'
  exact hB x hx

/-! ### The point part -/

/-- The log-sum inequality on one block: `Σ_{x ∈ B} (log |B| − log |B_{v(x)}|) ≤ |B| log #v(B)`. -/
lemma block_values_le (B : Finset α) (v : α → β) :
    ∑ x ∈ B, (Real.log B.card - Real.log (B.filter fun y => v y = v x).card) ≤
      B.card * Real.log (B.image v).card := by
  have hcard : B.card = ∑ w ∈ B.image v, (B.filter fun y => v y = w).card :=
    Finset.card_eq_sum_card_fiberwise (fun x hx => Finset.mem_image_of_mem _ hx)
  have hls := LinialLuria.log_sum_ineq (B.image v) (fun w => (B.filter fun y => v y = w).card)
  rw [← hcard] at hls
  have hsum : ∑ x ∈ B, Real.log (B.filter fun y => v y = v x).card =
      ∑ w ∈ B.image v, ((B.filter fun y => v y = w).card : ℝ) *
        Real.log (B.filter fun y => v y = w).card := by
    rw [← Finset.sum_fiberwise_of_maps_to (s := B) (t := B.image v) (g := v)
      (fun x hx => Finset.mem_image_of_mem _ hx)]
    refine Finset.sum_congr rfl fun w _ => ?_
    rw [Finset.sum_congr rfl fun x hx => by rw [(Finset.mem_filter.mp hx).2],
      Finset.sum_const, nsmul_eq_mul]
  rw [Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul, hsum]
  linarith

lemma mem_before_self {S : Finset α} {I : Finset ι} {key : ι → ℕ} {f : ι → α → β} {s : ι}
    {x : α} (hx : x ∈ S) : x ∈ before S I key f s x :=
  Finset.mem_filter.mpr ⟨hx, fun _ _ _ => rfl⟩

lemma sameClass_eq {S : Finset α} {I : Finset ι} {key : ι → ℕ} {f : ι → α → β} {cl : β → κ}
    {s : ι} {x y : α} (hy : y ∈ sameClass S I key f cl s x) :
    sameClass S I key f cl s y = sameClass S I key f cl s x := by
  obtain ⟨hyb, hcl⟩ := Finset.mem_filter.mp hy
  obtain ⟨hyS, hagree⟩ := Finset.mem_filter.mp hyb
  ext z
  simp only [sameClass, before, Finset.mem_filter]
  constructor
  · rintro ⟨⟨hz, h⟩, hc⟩
    exact ⟨⟨hz, fun t ht hts => (h t ht hts).trans (hagree t ht hts)⟩, hc.trans hcl⟩
  · rintro ⟨⟨hz, h⟩, hc⟩
    exact ⟨⟨hz, fun t ht hts => (h t ht hts).trans (hagree t ht hts).symm⟩, hc.trans hcl.symm⟩

lemma upto_eq_filter {key : ι → ℕ} {I : Finset ι} (hkey : Set.InjOn key I) {S : Finset α} {f : ι → α → β} {cl : β → κ}
    {s : ι} (hs : s ∈ I) (x : α) :
    upto S I key f s x = (sameClass S I key f cl s x).filter fun y => f s y = f s x := by
  ext y
  simp only [upto, sameClass, before, Finset.mem_filter]
  constructor
  · rintro ⟨hy, h⟩
    refine ⟨⟨⟨hy, fun t ht hts => h t ht hts.le⟩, by rw [h s hs le_rfl]⟩, h s hs le_rfl⟩
  · rintro ⟨⟨⟨hy, h⟩, -⟩, hs'⟩
    refine ⟨hy, fun t ht hts => ?_⟩
    rcases hts.lt_or_eq with h' | h'
    · exact h t ht h'
    · rw [hkey ht hs h']
      exact hs'

/-- **The point part.** `Σ_x (log |sameClass s x| − log |upto s x|) ≤ Σ_x log a_s(x)`, where
`a_s(x)` is the number of values of the coordinate `s` in `sameClass s x`. -/
theorem point_part_le (key : ι → ℕ) (f : ι → α → β) (cl : β → κ) (S : Finset α)
    (I : Finset ι) (hkey : Set.InjOn key I) {s : ι} (hs : s ∈ I) :
    ∑ x ∈ S, (Real.log (sameClass S I key f cl s x).card -
        Real.log (upto S I key f s x).card) ≤
      ∑ x ∈ S, Real.log ((sameClass S I key f cl s x).image (f s)).card := by
  refine sum_le_of_blocks S (sameClass S I key f cl s) (fun x hx => ⟨?_, ?_⟩)
    (fun x _ y hy => sameClass_eq hy) _ _ (fun x hx => ?_)
  · exact Finset.mem_filter.mpr ⟨mem_before_self hx, rfl⟩
  · intro y hy
    exact (Finset.mem_filter.mp (Finset.mem_filter.mp hy).1).1
  · set B := sameClass S I key f cl s x
    have h1 : ∀ y ∈ B, Real.log (sameClass S I key f cl s y).card -
        Real.log (upto S I key f s y).card =
        Real.log B.card - Real.log (B.filter fun z => f s z = f s y).card := by
      intro y hy
      rw [sameClass_eq hy, upto_eq_filter hkey (cl := cl) hs y, sameClass_eq hy]
    have h2 : ∀ y ∈ B, Real.log ((sameClass S I key f cl s y).image (f s)).card =
        Real.log (B.image (f s)).card := by
      intro y hy
      rw [sameClass_eq hy]
    rw [Finset.sum_congr rfl h1, Finset.sum_congr rfl h2, Finset.sum_const, nsmul_eq_mul]
    exact block_values_le B (f s)

/-! ### Conditioning reduces entropy -/

/-- **Conditioning reduces entropy**, in counting form. For a finite set `U` with a block map
`b` and a class map `c`,
`Σ_{y ∈ U} log (|U_{b(y)}| / |U_{b(y),c(y)}|) ≤ Σ_{y ∈ U} log (|U| / |U_{c(y)}|)`. -/
theorem cond_le (U : Finset α) (b : α → γ) (c : α → κ) :
    ∑ y ∈ U, (Real.log (U.filter fun z => b z = b y).card -
        Real.log (U.filter fun z => b z = b y ∧ c z = c y).card) ≤
      ∑ y ∈ U, (Real.log U.card - Real.log (U.filter fun z => c z = c y).card) := by
  rcases U.eq_empty_or_nonempty with rfl | hU
  · simp
  set Ub : α → Finset α := fun y => U.filter fun z => b z = b y
  set Uc : α → Finset α := fun y => U.filter fun z => c z = c y
  set Ubc : α → Finset α := fun y => U.filter fun z => b z = b y ∧ c z = c y
  have hpos : ∀ y ∈ U, (0 : ℝ) < (Ub y).card ∧ (0 : ℝ) < (Uc y).card ∧ (0 : ℝ) < (Ubc y).card ∧
      (0 : ℝ) < U.card := by
    intro y hy
    refine ⟨?_, ?_, ?_, ?_⟩ <;> norm_cast <;> refine Finset.card_pos.mpr ⟨y, ?_⟩
    · exact Finset.mem_filter.mpr ⟨hy, rfl⟩
    · exact Finset.mem_filter.mpr ⟨hy, rfl⟩
    · exact Finset.mem_filter.mpr ⟨hy, rfl, rfl⟩
    · exact hy
  -- `r y = |U_b| |U_c| / (|U| |U_bc|)`; then `Σ log r ≤ Σ (r − 1) ≤ 0`
  set r : α → ℝ := fun y => ((Ub y).card * (Uc y).card) / (U.card * (Ubc y).card)
  have hlog : ∀ y ∈ U, (Real.log (Ub y).card - Real.log (Ubc y).card) -
      (Real.log U.card - Real.log (Uc y).card) = Real.log (r y) := by
    intro y hy
    obtain ⟨h1, h2, h3, h4⟩ := hpos y hy
    simp only [r]
    rw [Real.log_div (by positivity) (by positivity), Real.log_mul h1.ne' h2.ne',
      Real.log_mul h4.ne' h3.ne']
    ring
  have hrsum : ∑ y ∈ U, r y ≤ U.card := by
    -- `Σ_y r y = (1/|U|) Σ_{z, w ∈ U} [U_{b z, c w} ≠ ∅] ≤ |U|`
    have hU0 : (0 : ℝ) < U.card := by exact_mod_cast hU.card_pos
    have key : ∀ y ∈ U, r y = (1 / (U.card : ℝ)) * ∑ z ∈ U, ∑ w ∈ U,
        (if b z = b y ∧ c w = c y then 1 / ((Ubc y).card : ℝ) else 0) := by
      intro y hy
      obtain ⟨h1, h2, h3, h4⟩ := hpos y hy
      have e : ∀ z w, (if b z = b y ∧ c w = c y then 1 / ((Ubc y).card : ℝ) else 0) =
          (if b z = b y then (1 : ℝ) else 0) *
            ((if c w = c y then (1 : ℝ) else 0) * (1 / ((Ubc y).card : ℝ))) := by
        intro z w
        by_cases hz : b z = b y <;> by_cases hw : c w = c y <;> simp [hz, hw]
      simp_rw [e, ← Finset.mul_sum, ← Finset.sum_mul, Finset.sum_boole]
      simp only [r]
      field_simp
      rfl
    rw [Finset.sum_congr rfl key, ← Finset.mul_sum]
    have hswap : ∀ F : α → α → α → ℝ, ∑ y ∈ U, ∑ z ∈ U, ∑ w ∈ U, F y z w =
        ∑ z ∈ U, ∑ w ∈ U, ∑ y ∈ U, F y z w := by
      intro F
      rw [Finset.sum_comm]
      exact Finset.sum_congr rfl fun z _ => Finset.sum_comm
    rw [hswap]
    have hzw : ∀ z ∈ U, ∀ w ∈ U, ∑ y ∈ U,
        (if b z = b y ∧ c w = c y then 1 / ((Ubc y).card : ℝ) else 0) ≤ 1 := by
      intro z _ w _
      rw [← Finset.sum_filter]
      set V := U.filter fun y => b z = b y ∧ c w = c y with hVdef
      rcases V.eq_empty_or_nonempty with hV | ⟨y₀, hy₀⟩
      · rw [hV]
        simp
      · have hVeq : ∀ y ∈ V, Ubc y = V := by
          intro y hy
          obtain ⟨-, hbz, hcw⟩ := Finset.mem_filter.mp hy
          ext x
          simp only [Ubc, V, Finset.mem_filter]
          constructor
          · rintro ⟨hx, h1, h2⟩
            exact ⟨hx, hbz.trans h1.symm, hcw.trans h2.symm⟩
          · rintro ⟨hx, h1, h2⟩
            exact ⟨hx, (h1.symm.trans hbz), (h2.symm.trans hcw)⟩
        rw [Finset.sum_congr rfl fun y hy => by rw [hVeq y hy], Finset.sum_const, nsmul_eq_mul]
        have : (0 : ℝ) < V.card := by exact_mod_cast Finset.card_pos.mpr ⟨y₀, hy₀⟩
        rw [mul_one_div_cancel this.ne']
    calc 1 / (U.card : ℝ) * ∑ z ∈ U, ∑ w ∈ U, ∑ y ∈ U,
          (if b z = b y ∧ c w = c y then 1 / ((Ubc y).card : ℝ) else 0)
        ≤ 1 / (U.card : ℝ) * ∑ z ∈ U, ∑ w ∈ U, (1 : ℝ) := by
          gcongr with z hz w hw
          exact hzw z hz w hw
      _ = U.card := by
          simp only [Finset.sum_const, nsmul_eq_mul, mul_one]
          field_simp
  have hle : ∑ y ∈ U, Real.log (r y) ≤ 0 := by
    calc ∑ y ∈ U, Real.log (r y) ≤ ∑ y ∈ U, (r y - 1) := by
          refine Finset.sum_le_sum fun y hy => Real.log_le_sub_one_of_pos ?_
          obtain ⟨h1, h2, h3, h4⟩ := hpos y hy
          positivity
      _ ≤ 0 := by
          rw [Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul, mul_one]
          linarith
  have := Finset.sum_congr rfl hlog
  rw [Finset.sum_sub_distrib] at this
  linarith

end ColourStats.TypedChain
