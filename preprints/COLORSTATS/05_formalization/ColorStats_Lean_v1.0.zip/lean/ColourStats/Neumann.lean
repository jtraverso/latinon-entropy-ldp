/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import Mathlib

/-!
# The Neumann series step of Lemma 5.19

Vectors on a finite set carry the sup norm (`Pi` norm), so operator norms are the
`‖·‖_{∞→∞}` norms of the paper. If an approximate right inverse `Φ̃` of `A` satisfies
`AΦ̃ = I − E` with `‖E‖ ≤ 1/2`, then `Φ = Φ̃ Σ_{s ≥ 0} E^s` is an exact right inverse with
`‖Φ‖ ≤ 2‖Φ̃‖` (`exists_right_inverse`).

This is the last step of the proof of Lemma 5.19. The estimates that give `‖E‖ ≤ 1/2` and
`‖Φ̃‖ = O(1/m)` on typical hosts are not formalized here.
-/

@[expose] public section

namespace ColourStats.Neumann

variable {E T : Type*} [Fintype E] [Fintype T]

open NormedRing in
/-- **Neumann series.** An approximate right inverse with error of norm at most `1/2` can be
corrected to an exact right inverse, at the cost of a factor `2` in the norm. -/
theorem exists_right_inverse (A : (T → ℝ) →L[ℝ] (E → ℝ)) (Φ₀ : (E → ℝ) →L[ℝ] (T → ℝ))
    (Err : (E → ℝ) →L[ℝ] (E → ℝ)) (h : A.comp Φ₀ = 1 - Err) (hE : ‖Err‖ ≤ 1 / 2) :
    ∃ Φ : (E → ℝ) →L[ℝ] (T → ℝ), A.comp Φ = 1 ∧ ‖Φ‖ ≤ 2 * ‖Φ₀‖ := by
  have hE1 : ‖Err‖ < 1 := by linarith
  refine ⟨Φ₀.comp (∑' n, Err ^ n), ?_, ?_⟩
  · rw [← ContinuousLinearMap.comp_assoc, h]
    exact mul_neg_geom_series Err hE1
  · have h1 : ‖(1 : (E → ℝ) →L[ℝ] (E → ℝ))‖ ≤ 1 := ContinuousLinearMap.norm_id_le
    have h2 : (1 - ‖Err‖)⁻¹ ≤ 2 :=
      calc (1 - ‖Err‖)⁻¹ ≤ (1 / 2 : ℝ)⁻¹ := inv_anti₀ (by norm_num) (by linarith)
        _ = 2 := by norm_num
    have h3 : ‖∑' n, Err ^ n‖ ≤ 2 := by
      have := tsum_geometric_le_of_norm_lt_one Err hE1
      linarith
    calc ‖Φ₀.comp (∑' n, Err ^ n)‖ ≤ ‖Φ₀‖ * ‖∑' n, Err ^ n‖ :=
          ContinuousLinearMap.opNorm_comp_le _ _
      _ ≤ ‖Φ₀‖ * 2 := mul_le_mul_of_nonneg_left h3 (norm_nonneg _)
      _ = 2 * ‖Φ₀‖ := by ring

end ColourStats.Neumann
