/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module

public import ColourStats.TypedAggregate
public import ColourStats.Challenge
public import CountingCone.LL.STSMain

/-!
# Pair statistics of a Steiner triple system with prescribed types

For a Steiner triple system `B` with quasigroup `T = thirdPt B`, the number of pairs of class
`π` whose third point has class `X` is `m_π(τ) t_τ` with `τ = X :: π` and `t_τ` the number of
blocks of type `τ` (`Mstat_eq`). So every system with type vector `t` has the same pair
statistics, as `typed_agg_bound` requires.

The proof is a double count of flags (block, pair inside it): every pair lies in exactly one
block, and a block of type `τ` contains `m_π(τ)` pairs of class `π` (`card_pairs_of_type`).
-/

@[expose] public section

open Finset LinialLuria

namespace ColourStats.TypedSTS

open ColourStats

variable {n k : ℕ}

lemma blockType_pair (lab : Fin n → Fin k) {a b : Fin n} (hab : a ≠ b) :
    blockType lab ({a, b} : Finset (Fin n)) = {lab a, lab b} := by
  unfold blockType
  rw [Finset.insert_val_of_notMem (by simpa using hab)]
  simp

lemma blockType_triple (lab : Fin n → Fin k) {a b c : Fin n} (hab : a ≠ b) (hac : a ≠ c)
    (hbc : b ≠ c) :
    blockType lab ({a, b, c} : Finset (Fin n)) = lab c ::ₘ {lab a, lab b} := by
  unfold blockType
  rw [Finset.insert_val_of_notMem (by simp [hab, hac]),
    Finset.insert_val_of_notMem (by simpa using hbc)]
  simp only [Finset.singleton_val, Multiset.map_cons, Multiset.map_singleton,
    Multiset.insert_eq_cons]
  ext x
  simp only [Multiset.count_cons, Multiset.count_singleton]
  split_ifs <;> omega

/-- A block of type `τ` contains `m_π(τ)` pairs of class `π`. -/
lemma card_pairs_of_type (lab : Fin n → Fin k) (A : Finset (Fin n)) (π : Multiset (Fin k)) :
    ((A.powersetCard 2).filter fun e => blockType lab e = π).card =
      mult π (blockType lab A) := by
  unfold mult ColourStats.pairs blockType
  rw [Multiset.powersetCard_map, Multiset.count_map, ← Finset.map_val_val_powersetCard,
    Multiset.filter_map, Multiset.card_map]
  show Multiset.card (Multiset.filter _ (A.powersetCard 2).val) = _
  congr 1
  refine Multiset.filter_congr fun e _ => ?_
  simp [Function.comp, eq_comm]

/-- The block through a pair. -/
noncomputable def blkB (B : Finset (Finset (Fin n))) (p : Pair n) : Finset (Fin n) :=
  {p.1, p.2, thirdPt B p.1 p.2}

/-- **Pair statistics.** -/
theorem Mstat_eq {B : Finset (Finset (Fin n))} (hB : STS.IsSTS B) (lab : Fin n → Fin k)
    (π : Multiset (Fin k)) (X : Fin k) :
    Mstat lab (thirdPt B) π X = mult π (X ::ₘ π) * typeCount lab B (X ::ₘ π) := by
  set F := B.sigma fun A => (A.powersetCard 2).filter
    fun e => blockType lab e = π ∧ blockType lab A = X ::ₘ π
  -- the flags
  have hF : F.card = mult π (X ::ₘ π) * typeCount lab B (X ::ₘ π) := by
    rw [Finset.card_sigma]
    have h1 : ∀ A ∈ B, ((A.powersetCard 2).filter
        fun e => blockType lab e = π ∧ blockType lab A = X ::ₘ π).card =
        if blockType lab A = X ::ₘ π then mult π (X ::ₘ π) else 0 := by
      intro A _
      split_ifs with hA
      · rw [← hA, ← card_pairs_of_type lab A π]
        congr 1
        exact Finset.filter_congr fun e _ => by simp [hA]
      · rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
        exact fun e _ h => hA h.2
    rw [Finset.sum_congr rfl h1, ← Finset.sum_filter, Finset.sum_const, smul_eq_mul, mul_comm]
    rfl
  rw [← hF]
  unfold Mstat
  refine Finset.card_bij (fun p _ => ⟨blkB B p, {p.1, p.2}⟩) ?_ ?_ ?_
  · -- the map lands in the flags
    intro p hp
    obtain ⟨hpE, hX⟩ := Finset.mem_filter.mp hp
    obtain ⟨hpp, hπ⟩ := Finset.mem_filter.mp hpE
    have hlt : p.1 < p.2 := by simpa [pairs] using hpp
    obtain ⟨hca, hcb, hmem⟩ := thirdPt_spec hB hlt.ne
    refine Finset.mem_sigma.mpr ⟨hmem, Finset.mem_filter.mpr ⟨?_, ?_, ?_⟩⟩
    · rw [Finset.mem_powersetCard]
      refine ⟨?_, Finset.card_pair hlt.ne⟩
      intro z hz
      simp only [Finset.mem_insert, Finset.mem_singleton] at hz
      simp only [blkB, Finset.mem_insert, Finset.mem_singleton]
      tauto
    · rw [blockType_pair lab hlt.ne, hπ]
    · unfold blkB
      rw [blockType_triple lab hlt.ne (Ne.symm hca) (Ne.symm hcb), hX, hπ]
  · -- injective
    intro p hp q hq h
    have hp' : p.1 < p.2 := by
      simpa [pairs] using (Finset.mem_filter.mp (Finset.mem_filter.mp hp).1).1
    have hq' : q.1 < q.2 := by
      simpa [pairs] using (Finset.mem_filter.mp (Finset.mem_filter.mp hq).1).1
    have h2 : ({p.1, p.2} : Finset (Fin n)) = {q.1, q.2} := by
      have := congrArg Sigma.snd h
      simpa using this
    rcases pair_eq_cases hp'.ne h2 with ⟨e1, e2⟩ | ⟨e1, e2⟩
    · exact Prod.ext e1 e2
    · exfalso
      rw [e1, e2] at hp'
      exact lt_asymm hp' hq'
  · -- surjective
    rintro ⟨A, e⟩ hAe
    obtain ⟨hA, he⟩ := Finset.mem_sigma.mp hAe
    obtain ⟨he2, hπ, hτ⟩ := Finset.mem_filter.mp he
    obtain ⟨hsub, hcard⟩ := Finset.mem_powersetCard.mp he2
    obtain ⟨x, y, hxy, rfl⟩ := Finset.card_eq_two.mp hcard
    set p := sp x y with hpdef
    have hset : ({p.1, p.2} : Finset (Fin n)) = {x, y} := sp_set x y
    have hpp : p ∈ pairs n := sp_mem hxy
    have hlt : p.1 < p.2 := by simpa [pairs] using hpp
    have hxA : x ∈ A := hsub (by simp)
    have hyA : y ∈ A := hsub (by simp)
    obtain ⟨hca, hcb, hmem⟩ := thirdPt_spec hB hlt.ne
    have h1A : p.1 ∈ A := by
      have : p.1 ∈ ({x, y} : Finset (Fin n)) := hset ▸ (by simp)
      simp only [Finset.mem_insert, Finset.mem_singleton] at this
      rcases this with h | h <;> rw [h] <;> assumption
    have h2A : p.2 ∈ A := by
      have : p.2 ∈ ({x, y} : Finset (Fin n)) := hset ▸ (by simp)
      simp only [Finset.mem_insert, Finset.mem_singleton] at this
      rcases this with h | h <;> rw [h] <;> assumption
    -- the block through `p` is `A`
    have hblk : blkB B p = A := by
      obtain ⟨A₀, -, hA₀⟩ := hB.2 p.1 p.2 hlt.ne
      have e1 := hA₀ (blkB B p) ⟨hmem, by simp [blkB], by simp [blkB]⟩
      have e2 := hA₀ A ⟨hA, h1A, h2A⟩
      rw [e1, e2]
    have hπp : ({lab p.1, lab p.2} : Multiset (Fin k)) = π := by
      rw [← blockType_pair lab hlt.ne, hset, hπ]
    refine ⟨p, Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr ⟨hpp, hπp⟩, ?_⟩, ?_⟩
    · have hT := blockType_triple lab hlt.ne (Ne.symm hca) (Ne.symm hcb)
      rw [show ({p.1, p.2, thirdPt B p.1 p.2} : Finset (Fin n)) = blkB B p from rfl, hblk, hτ,
        hπp] at hT
      exact (Multiset.cons_inj_left _).mp hT.symm
    · simp only [hblk, hset]

end ColourStats.TypedSTS
