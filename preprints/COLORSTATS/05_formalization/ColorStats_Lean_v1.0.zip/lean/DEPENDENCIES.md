# Dependencies of the Lean formalization (ColorStats_Lean_v1.0)

This archive contains only the source of the project `colour_stats` (library `ColourStats`).
**Neither Mathlib nor the corpus package `cdr_prescribed_bicolorings` is bundled.** Both must be
obtained separately, at the versions recorded below, before the project can be built.

## Toolchain

- Lean: `leanprover/lean4:v4.35.0-rc3` (file `lean-toolchain`).
- Lake used for the recorded build: `Lake version 5.0.0-src+470d5ce (Lean version 4.35.0-rc3)`.

## Mathlib and its transitive packages

Pinned in `lakefile.toml` and `lake-manifest.json`:

| Package | Source | Revision |
|---|---|---|
| mathlib | https://github.com/leanprover-community/mathlib4 | `c55e6e786f49471c72fbddbec5415808896aec1e` |
| plausible | https://github.com/leanprover-community/plausible | `fb13df72ecefd8ddbf9291021d7f33a8673eb57b` |
| LeanSearchClient | https://github.com/leanprover-community/LeanSearchClient | `29ff470276c725ae01505d55b17148c18fc7dfd3` |
| importGraph | https://github.com/leanprover-community/import-graph | `7e81a29bda33a6b257bd37557a6aa6aebe175d96` |
| proofwidgets | https://github.com/leanprover-community/ProofWidgets4 | `c643bbb3c24f8a25f9c14e3a6b1ceb13d01f3de1` |
| aesop | https://github.com/leanprover-community/aesop | `a90fbf7b02ff06a0deebf74088dff9e5fe02c9ea` |
| Qq | https://github.com/leanprover-community/quote4 | `37b0ba0b26109cf9f9c541f0f9557e50cfa1a3b9` |
| batteries | https://github.com/leanprover-community/batteries | `3b7c8101932390d60e92a3f3d917901d5b5a773b` |
| Cli | https://github.com/leanprover/lean4-cli | `843844fa601dd56767b1eb22b7ada5b64d5e567a` |

The Mathlib checkout actually used for the recorded build is at revision
`c55e6e786f49471c72fbddbec5415808896aec1e` (checked with `git rev-parse HEAD`).

## The corpus dependency `cdr_prescribed_bicolorings`

`lakefile.toml` declares a path dependency and reuses that package's compiled Mathlib:

```toml
packagesDir = "../cdr-clean-20261113/snapshot/lean/.lake/packages"

[[require]]
name = "cdr_prescribed_bicolorings"
path = "../cdr-clean-20261113/snapshot/lean"
```

Both paths are relative to the project root. On the build machine they resolve to
`C:\nw\cdr-clean-20261113\snapshot\lean`.

**Identification.** The corpus directory is the clean reconstruction of the Lean development
of CDR III (package `cdr_prescribed_bicolorings`, version `0.3.0`, aggregate `CDRIII`), made
from source commit `8756b2ef2dbe56002617a86e97e1b16a790ae069` of the CDR III review
repository. Its source is byte-identical to the Lean source in the published freeze
`CDRIII_Lean_v1.0.zip`:

- archive SHA-256: `08dcee5b5d67d00d1f561988e8c716c57c92d250ca54270f3d417429fb52e649`;
- released with *Prescribed block types and abundance in bicolored Steiner triple systems*,
  preprint 1.0, DOI 10.5281/zenodo.24201563 (reference [8] of the paper), GitHub release
  `paper-iii-v1.0` of `jtraverso/cdr-steiner-preprints`.

The comparison was made on 2026-11-17: all 1307 `.lean` files of the corpus directory, and
its `lakefile.toml`, `lake-manifest.json` and `lean-toolchain`, have the same SHA-256 as the
corresponding entries of `CDRIII_Lean_v1.0.zip`, and every `.lean` file matches the
source manifest `SOURCES_AFTER.json` recorded by the clean run.

**Source hashes of the corpus.** Combined hashes are the SHA-256 of the text consisting of one
line `<sha256>  <path>` per file (two spaces, `/` as separator), sorted by path, each line
ending in `\n` (the format of `sha256sum`).

| Set | Files | Combined SHA-256 |
|---|---|---|
| All `.lean` files of the corpus (excluding `.lake`) | 1307 | `2c389bb5968604d220bdf3b2570f3c54b1c6955b81748426dd245a36ac0604a7` |
| Whole corpus source tree (excluding `.lake`; `.lean` files, Lake configuration, third-party licence files) | 1313 | `bd37dc001b64b476d326a1643657b8d0f0dc76091e453c3beb89ed14ec1cdc9b` |
| Corpus modules in the import closure of `ColourStats` | 13 | `335f9f6a11300b73d0c7d325dba34cd31519775804eb10d105c28ed7fb009d62` |

The 13 corpus modules imported, directly or transitively, by `ColourStats`:

| File | SHA-256 |
|---|---|
| `CountingCone/Defs.lean` | `86adcd854fa708bef3c43170cfb6716a6483228d89e4b1337c84a45b8f62684e` |
| `CountingCone/LL/Analysis.lean` | `a25417a2c4a96c31ffb2eb3554ec010ea752b56c38dad6684c4c60bdc842f833` |
| `CountingCone/LL/Chain.lean` | `3bee02948f226a4c3475c7abefc7d65ea7e8a86f8b507fe92b00621d9d832e8c` |
| `CountingCone/LL/Estimates.lean` | `9e28e05eb43152cb5a7059bedb9a576cd3f0257ffcdc68dc8e320b6d30e20d47` |
| `CountingCone/LL/Expect.lean` | `a94b4972b717a92d7680c4a6a87edb8432fea88dd885d8b19d3733dad02e49bc` |
| `CountingCone/LL/Order.lean` | `97c0de8659ce5b1475be2c3a0c75ce393e60330f17d6242ff94f9bcc611c4f66` |
| `CountingCone/LL/STSExpect.lean` | `71c039239f5bdf8cf8cebc18c9fbe418ee1c235c89f90fa9c9e8e2951a176866` |
| `CountingCone/LL/STSMain.lean` | `98aee36a9dfb97bfc85990315294c4cc305e64ebc04fda6f711626895299e919` |
| `CountingCone/LL/STSReveal.lean` | `8cba3e844af52f11676232c8ef9b9d528a6f3c644f7e8b5189cdb58aa5484faf` |
| `RequestProject/TypedTriangle/Absorb.lean` | `9b2389d2d940ddfba19db3a531888dbc0e9fd93edf074f04c05a735d9b24c9df` |
| `RequestProject/TypedTriangle/Basic.lean` | `6393b82eb114aef79fefda5acd0a25ff29af08868469890a48afc0705d2a13a1` |
| `RequestProject/TypedTriangle/Defs.lean` | `5391850892583790739aad946aa1ddddd921b49eacac686c0697d8635fc98e79` |
| `RequestProject/TypedTriangle/Lattice.lean` | `74d6fe47b46a2fb3f120d3bf081d51e67549378cc541cd67e9c7b03f144d2145` |

These are the Linial–Luria chain-rule infrastructure (`CountingCone.LL.*`), the definition of
Steiner triple systems and Latin squares (`CountingCone.Defs`), and the definitions of typed
triangle hosts and of the triangle lattice, with elementary lattice and absorber lemmas
(`RequestProject.TypedTriangle.*`). The absorption theorems T and T⁺, the matching theorem of
Glock, Joos, Kim, Kühn and Lichev, and the theorem of Ehard, Glock and Joos are not in the
import closure.

## Rebuilding

1. Install the toolchain `leanprover/lean4:v4.35.0-rc3` (for example with `elan`).
2. Obtain the corpus source (the `lean/` tree of `CDRIII_Lean_v1.0.zip`) and place it so that
   `../cdr-clean-20261113/snapshot/lean`, relative to this project, is that tree; or edit the
   `path` of `cdr_prescribed_bicolorings` and `packagesDir` in `lakefile.toml` to point to it.
3. Build the corpus's dependencies there (Mathlib at the revision above; `lake exe cache get`
   in the corpus directory fetches compiled Mathlib), so that `packagesDir` contains them.
4. In this project: `lake build --no-build ColourStats` should list only `ColourStats.*`
   modules as out of date; then `lake build ColourStats` and
   `lake env lean checks/Axioms.lean`.

Changing `packagesDir` or the corpus path changes the Lake configuration but not the
mathematical content; the `.lean` files are fixed by `source_manifest.json`.
