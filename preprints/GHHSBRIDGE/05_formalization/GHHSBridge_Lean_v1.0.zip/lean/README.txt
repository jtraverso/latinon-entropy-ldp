GHHS BRIDGE -- LEAN SOURCES, VERSION 1.0

Lean formalization of Proposition 2.3 of "Entropy and large deviations for Latin
squares" (Latinon preprint 1.0) and of Conjecture 12.4 of Garbe, Hancock, Hladky and
Sharifzadeh, "Limits of Latin squares", stated with the definitions of that paper on
the ground space [0, 1].

Contents
  GHHSBridge.lean          aggregate root; imports the seven modules below
  GHHSBridge/Defs.lean        GHHS Definition 3.5 (Latinon) in kernel terms
  GHHSBridge/ToMeasure.lean   kernel => measure
  GHHSBridge/OfMeasure.lean   measure => kernel, round trips
  GHHSBridge/Distance.lean    GHHS cut distance (Section 2.4.1, Definitions 4.1-4.3)
  GHHSBridge/Patterns.lean    GHHS pattern densities (Definition 3.7)
  GHHSBridge/Entropy.lean     conditional chain rule for relative entropy; entropy
  GHHSBridge/Conjecture.lean  Conjecture 12.4 in GHHS terms
  ReviewAxioms.lean        axiom queries for the twelve principal declarations
  lakefile.toml, lake-manifest.json, lean-toolchain
  source_manifest.json     SHA-256 of every file in this directory

Dependencies
  Lean 4.35.0 (lean-toolchain).
  Mathlib at commit 56a005855ea17e0b0958f73ec801ae140b0a1679.
  The Lean sources of Latinon preprint 1.0, archive Latinon_Lean_v1.0.zip,
  SHA-256 567ac3561332351313d176018f5d41e475f88bfbd031cf05dad6b448635cfe81.

Layout expected by lakefile.toml
  <any directory>/GHHSBridge_Lean_v1.0/lean     this directory
  <any directory>/Latinon_Lean_v1.0/lean        the lean directory of Latinon_Lean_v1.0.zip

The external packages (Mathlib and its dependencies) are shared with the Latinon
package: packagesDir points to ../../Latinon_Lean_v1.0/lean/.lake/packages. Set up
the Latinon package first, as its README describes (lake exe cache get), so that
this directory exists.

Build, from this directory, one command after the other:
  lake build GHHSBridge
  lake env lean ReviewAxioms.lean
Do not run two Lean builds at the same time.

The first command compiles the seven modules and the root, and before them every
module of the Latinon sources that they import if it has not been compiled yet.
The second prints the axioms of the principal declarations; each line is expected
to end with [propext, Classical.choice, Quot.sound].

No compiled .olean files are included.

Recorded build of this edition (16 November 2026, Windows): the seven modules and
the root were compiled from scratch; the Latinon and Mathlib objects already existed
and were not recompiled in that run. The Latinon source tree used was compared file
by file with Latinon_Lean_v1.0.zip; all files coincide except source_manifest.json,
which is generated. The build log and the output of the axiom queries are in
preprints/GHHSBRIDGE/02_validation/lean of the publication repository.

License: Apache 2.0 (see LICENSE and the file headers).
