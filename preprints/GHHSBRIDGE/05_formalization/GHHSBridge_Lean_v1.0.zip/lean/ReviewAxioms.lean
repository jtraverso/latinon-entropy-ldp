/-
Axiom queries for the principal declarations of the GHHS bridge.
Run from this directory, after `lake build GHHSBridge`:
  lake env lean ReviewAxioms.lean
Each query is expected to report only `propext`, `Classical.choice` and `Quot.sound`.
-/
import GHHSBridge

#print axioms GHHSBridge.GHHSLatinon.toLatinonMeasure
#print axioms GHHSBridge.ofLatinonMeasure
#print axioms GHHSBridge.toLatinonMeasure_ofLatinonMeasure
#print axioms GHHSBridge.ofLatinonMeasure_toLatinonMeasure_kernel
#print axioms GHHSBridge.ghhsCutDistance_eq
#print axioms GHHSBridge.ghhsPatternDensity_eq
#print axioms GHHSBridge.klDiv_compProd_right_eq_lintegral
#print axioms GHHSBridge.ghhsEntropy_eq
#print axioms GHHSBridge.ghhsEntSup_eq
#print axioms GHHSBridge.ghhsConjecture_12_4
#print axioms GHHSBridge.ghhsConjecture_12_4_bot
#print axioms GHHSBridge.ghhsConjecture_12_4_bot'
